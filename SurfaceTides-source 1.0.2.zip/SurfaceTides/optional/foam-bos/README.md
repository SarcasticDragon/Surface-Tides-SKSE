# Surface Tides — three confirmed standalone foam objects

Install this ZIP as a separate mod with Base Object Swapper 3.0+ installed. `SurfaceTides_Foam_SWAP.ini` belongs at the Data root. No ESP, replacement NIF, texture or new Surface Tides DLL is required for this preset.

It disables all placements of FXRapids (0x01B37D), FXRapids02 (0x106A1D), and FXrapidsBig01 (0x01CCBC) from Skyrim.esm. The user confirmed the winning models are entirely disposable foam. Waterfall impact rings and rapid-rock objects are excluded. Other load orders must recheck the winning meshes. Scripts, enable parents and competing BOS rules can affect individual results.

Use only one SurfaceTides_Foam_SWAP.ini. Disable an earlier generated preset before enabling this one. Disable this mod, restart and reload the preserved test save to restore the objects for comparison. The Surface Tides live preview checkbox does not undo these BOS rules or state saved by other mods.

For attached rock foam, use the separate optional 0.1.20 DLL feature; do not add rock base records to these rules. The source package includes the corresponding reviewed allowlist for regenerating the preset with our xEdit helper.

This preset has been checked against the supplied inventory and inspected winning meshes, but has not been tested in Skyrim here. See the included SurfaceTides-foam-README.md for details and the findings for all seven models.
