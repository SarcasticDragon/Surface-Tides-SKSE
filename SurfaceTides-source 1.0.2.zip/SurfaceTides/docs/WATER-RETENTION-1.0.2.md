# Surface Tides 1.0.2: nearby water after a dry exit

The user reports an abrupt end to waves when leaving water, especially indoors. The supplied Ragged Flagon clip shows the transition. Source inspection found that Game.cpp used only PlayerCharacter::GetWaterHeight to decide whether a surface exists. CommonLib's TESObjectREFR::GetWaterHeight returns loadedData->relevantWaterHeight when available; otherwise it asks the parent cell for exterior water. TESObjectCELL::GetExteriorWaterHeight returns the no-water sentinel for interiors. Losing the actor cache on a dry bank therefore deactivated the field even when the pool remained nearby. No log accompanied this report, so the exact engine path still needs confirmation in game.

The new selection order is actor water height, then a spatial query at the player, then a revalidated nearby water anchor. Only a spatially confirmed anchor is retained. Its query uses the same TES::GetWaterHeight API already used for terrain masking and floe acquisition. The anchor stores coordinates, a rest level and a world/interior ID, never a game pointer. Each reuse requires an attached cell in the current world/interior and the same water level. It expires outside 45% of the field span (1,728 game units with the default settings), on explicit reset/load, preview disable, context change or failed revalidation. No universal infinite last-height fallback is used.

The resulting rest level continues through the existing field update, recentering, mask, solver and rendering paths. Actor contact capture still uses each actor's own water-height/contact information. Leaving water removes that actor as a source; it does not erase the accumulated height and velocity field. Reentry at the same level does not request a field reset. This is still a local single-rest-level simulation, not persistence for every pool in a cell or world.

The five-second statistics now include `Water selection source=actor|spatial|retained`, the raw actor water height and the selected rest level. An invalid raw actor height is expected when the spatial or retained path is needed. This extra line requires LogStats=1; no new trace setting is needed.

## Install and verify

For the existing setup, install `SurfaceTides-1.0.2-water-retention-update.zip` after the accepted installation so its DLL wins. It contains no INI, shaders or BOS/CS settings and preserves the current profile. Restart Skyrim. The alternative full `SurfaceTides-1.0.2-FOMOD.zip` supplies everything, including a complete selected INI; back up tuning and cleanly replace an old full installation when using it.

Repeat the Ragged Flagon exit while looking at the disturbed pool. Waves should continue propagating and fading after the player steps out; entering the same pool again should not abruptly clear the field. The compiled candidate cannot be game-tested in this environment. If the cutoff remains, provide the new log with approximate exit time; ordinary LogStats is sufficient.

## INI choices

The base `SurfaceTides.ini` is complete and also usable with 1.0/1.0.1; this update adds no keys or changes to defaults. It selects Standalone, keeps foam and ice decals, and disables bobbing. The FOMOD writes one complete variant reflecting the renderer and object choices. It covers all independent foam/ice/bobbing combinations. Standalone foam removal is a separate BOS file and cannot be toggled by HideAttachedFoam.

| Desired effects | HideAttachedFoam | HideIceDecals | FloeBobbing |
| --- | --- | --- | --- |
| Remove attached foam, keep ice decals, static ice | 1 | 0 | 0 |
| Keep foam, remove ice decals, static ice | 0 | 1 | 0 |
| Remove attached foam and ice decals, static ice | 1 | 1 | 0 |
| Remove attached foam and ice decals, bobbing ice | 1 | 1 | 1 |

Choose either standalone-foam option in the wizard to add the BOS preset. These object switches and renderer compatibility flags are startup settings. The menu saves/reloads live tuning; it does not change the startup switches during a session. Absence of an INI means built-in defaults, not an automatically generated complete file.
