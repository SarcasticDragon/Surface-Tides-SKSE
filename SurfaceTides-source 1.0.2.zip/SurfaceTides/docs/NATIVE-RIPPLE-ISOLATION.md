# Native ripple isolation — 2026-09-13

**Superseded next test: actor Strength0 also failed to fix the artifact. Current instructions: WADING-SURFACE-ISOLATION.md.**

## Returned result — native ripple test did not fix the artifact

The user confirms native ripples disappeared as intended but the original artifacts remain. This is a successful isolation with a negative result, not a failed shader activation. Native wading geometry/draws were not removed, so do not claim every native wading path has been excluded. SurfaceTides(20260913-033929).log reports36,304 bound/tessellated water draws, failed0/incompatible0, debug0, displacement2/normal2, interaction4, active native context with no ENB module/proxy and advancing simulation with no numerical clipping/dropped solver time. Clip21 is14.4seconds at2560x1440/60FPS; inspected a2-second-spaced contact sheet. No new evidence proves a specific mesh or driver defect.

Comparison baseline is **0.1.17 shoreline-r4**, not0.1.7. Deactivate each temporary Water.hlsl diagnostic after its test, restore the r4 winning shader, and restart. R4 is a fixed reference, not an accepted solution to the artifacts. No DLL rollback to0.1.6/0.1.7 or load-order changes are requested. The restored source is still available this session.

Next existing-INI control: on restored r4 set only [Interaction] Strength=0. Retain [Rendering] DisplacementStrength=2 / NormalStrength=2, [Diagnostics] DebugView=0, wind/gust and all other settings. Restart, walk/wade through the same shoreline, stop briefly, and return the log/clip. SurfaceTides actor-induced wakes are absent by design; idle wave displacement, the moving simulation grid and Skyrim's native ripples remain. Restore Interaction.Strength=4 and restart afterward. Source confirms Strength0 clears actor impulse output before publication. No shader/DLL/solver edits or repeated compilation required.

If the original artifact remains, actor impulse input is not required in this condition; investigate grid/mask changes or other walking-triggered rendering next, without assuming which is defective. If it disappears, investigate the interaction of actor-generated deformation and water shading/coverage; this does not alone prove unstable solver math. Older next-test instructions below are superseded.


## Latest evidence and next action

The shoreline artifact remains unresolved. The user reports no change with the light-pass isolation overlay. A detached/free-camera test with Water for ENB did not reproduce it. The exact console command and whether all world animation continued are not recorded; treat this as evidence against camera movement alone, not proof excluding every camera-dependent path.

Separate user comparisons: Realistic Water 2 looked correct at the tested location; Wavy Waters reproduced a similar, less severe artifact. The original Water for ENB test environment was preserved and reinstated. These are user observations, not independently inspected assets or universal compatibility results. Versions/options for RW2 and Wavy Waters are not supplied. Do not assume the two affected mods share meshes, textures, water records or code, or infer a causal difference from mod age. No replacer assets were downloaded, changed or redistributed.

Retained environment: AE1.6.1170, SurfaceTides0.1.17, near-vanilla with ENB removed, Water for ENB2.19 / Shades of Skyrim /4K, native TAA off, full displacement2 and normal strength2. ENB/CS runtime integration is not part of this investigation. Native ENB integration remains experimental/off; CS coexistence remains pending/gated. No ENB implementation code, shaders, bytecode or SDK used.

Next: apply SurfaceTides-0.1.17-native-ripple-diagnostic.zip last so Shaders/SurfaceTides/Water.hlsl wins. Leave DebugView=0 and current simulation/rendering settings unchanged. Restart and walk/wade normally through the original shoreline route, then stop for a few seconds. Return the ordinary log, a short clip and whether the original fragments persist. There is no new INI setting and no DLL to replace.

This removes the native wading normal-texture contribution in SurfaceTides' above-water replacement shaders. SurfaceTides actor impulses, idle waves, height displacement and simulated normals remain active. Flat native ripples can appear weaker or disappear. Other native splash/decal systems are not disabled. This is a diagnostic, not a claimed fix or a release recommendation. Deactivate the overlay and restart to restore the previously winning shader. Keep the light-pass diagnostic deactivated.

If the original artifact disappears, investigate the native wading input's coordinates, amplitude, normal composition and its interaction with displaced coverage; the result does not by itself prove which is wrong. If unchanged, native ripple normals are less likely and the next branch is actor forcing versus grid recentering/native wading geometry. Do not blindly repeat optical smoothing or declare the mesh defective. Existing Interaction.Strength=0 could later isolate actor impulses while retaining wind displacement and grid movement, but that change is not part of this test.

## Code evidence and exact scope

Water.hlsl:GetWaterNormal has a WADING-only input from DisplacementTex at t2, sampled using TexCoord3.xy (non-flow) or TexCoord3.zw (flow). It constructs a native ripple normal using NormalsAmplitude.w, blends it with material normals, and then adds SurfaceTides' heightfield slopes. Material-scaled native ripples provide a concrete candidate for character-motion and water-material dependence; no actual cross-mod constant values have been captured.

ST_DIAGNOSTIC_NO_NATIVE_RIPPLES defaults0 in source. At1, only the WADING normal block on SPECULAR shaders is omitted, including additional-light SPECULAR variants. It does not discard fragments or draws. The original alpha expression, geometry functions, depth/stencil behavior and simulation code are not edited. The resulting above-water shading/refraction/reflection can change because its normal changes. UNDERWATER preserves native ripple shading.

The packaged shader retains the last r4 comparison's ST_SHORE_REFRACTION=1, ST_DISPLACED_DEPTH_BLEND=1, ST_SHORE_CONTACT_BLEND=1 and ST_DIAGNOSTIC_NO_SSR=0. It includes no light-pass suppression. Source still defaults depth/contact candidates to0. No DLL, INI, NIF, DDS or ENB assets in the diagnostic.

Game.cpp remains unchanged. Its field is centered on the player, not the detached camera. ContactTracker emits wake impulses for moving surface contacts; recenter copies overlapping height/velocity/wet-mask samples to preserve their world coordinates. That read does not establish correct live coverage or rule out shoreline-mask artifacts. No demonstrated solver/recentering defect was found and no speculative solver patch was made.

## Earlier returned tests, recovered after workspace reversion

- Plugin disabled: clean. DisplacementStrength=0 with NormalStrength=2: clean. Do not repeat.
- r1: some terrain-bleed containment, interior fragments remain.
- A, no refraction distortion: no change. B, no SurfaceTides SSR: worse shoreline bleed.
- r3 depth-plane correction and r4 contact blend: no resolution; r4 did not cause new banding.
- ENB removed: artifact persists. Native TAA already off. Do not request these controls again.
- DebugView1 (clip19): small bright fragments among expected colored height/mask bands. This mode colors additional-light passes and forces alpha1; it is not a pure coverage/depth capture.
- The light-pass diagnostic suppressed additional-light pixel fragments. User returned no improvement (clip20). It is not a fix and should be removed.
- Prior host-DXC comparison found identical domain binaries for observed base/light pairs11E/802 and15E/842. No precise qualifier or depth-state override was implemented. Host SM6 does not prove live Windows SM5 behavior.

Previous log SurfaceTides(20260913-024615).log, read locally in the preceding turn: normal debug0, no ENB module/local proxy, same immediate contexts, no draw failures/incompatibilities, advancing uploaded sequence, no measured constant repairs, no numerical clipping/dropped solver time. Water pairs5000,11E,802,15E,842. The five-second reports do not prove texture identity, active overlay content, per-fragment correctness or GPU timing. No new log/video accompanies this source/replacer/free-camera update.

## Validation and recovery identity

The supplied source attachment SurfaceTides-source(1).zip is4,013,918bytes, SHA2561499bffb625b1423a03cf5ac03a565e5ea5b818bf55896f9c39b216f5f1ffd7e. Upload identity libfile_f662ae779aa48191b344e8eb547c8bed / file_00000000e6e881fdb0b5544fb86c8e9a. It is the pre-light-pass checkpoint, not a byte-for-byte recovery of the subsequently saved source version38. Working tree: project-restored20/SurfaceTides. It supersedes older local recovered/project-coexistence17 trees for this work.

Historical canonical source identity: libfile_4355a322deb481918f58dfaa7d9c03c5, last successful save recorded as version38 / file_00000000a9348230ace4133b1377b3b7, SHA2569a790b20573d7b05d50e2c5fd3a542d5b6542bba3a8c45329d433798ceb13128. That archive could not be retrieved this session. The light-pass-only source changes are described above but are not silently represented as recovered bytes. Current changes branch from the user-supplied pre-light archive.

tools/validate_native_ripple_isolation.py ran660 DXC SM6 compilations (33 descriptors,5 stages,4 configurations). New default outputs match all165 supplied-source outputs byte-for-byte. All geometry, underwater, LOD, stencil and non-WADING pixel outputs match r4. Eight above-water WADING pixel variants remove t2/s2 and retain the simulation field and all other texture/sampler bindings. Resource comparisons ignore compiler-internal ordinal IDs but check actual HLSL registers/types/counts. See native-ripple-shader-validation.txt. Compiler Microsoft DXC1.9.2607, Linux2026-07-29; header generator built from supplied project. No Windows SM5 execution, in-game test or DLL rebuild performed here.

Only Water.hlsl and the new validation script implement this diagnostic; other changes are documentation/packaging. No gameplay/simulation C++/INI/native validation binary changes. Preserve the confirmed standalone/coexistence packages and latest-full r1 installer. Do not overwrite them with this overlay. The new source checkpoint ZIP is deliberately named SurfaceTides-source-native-ripple-diagnostic.zip to distinguish it from older local files named SurfaceTides-source.zip.

Library write/retrieval capabilities are not exposed this session. Local package/source links do not constitute a durable save; ask the user to retain both ZIPs and record any later successful save receipt rather than inventing one. No subagents used.
