# Resume checkpoint — 0.1.24

## Latest accepted result and task

The user confirms 0.1.23 prevents clipping on E7B8A~Skyrim.esm. Strong discoloration was isolated to their heavy ENB/Silent Horizons 2 preset; other presets are untested. Neighbouring placement overlap is unrelated. Disconnected chunks within one NIF moving together is an accepted initial-release limitation; do not split game assets. The authorized next step is bobbing across the three reviewed ice models. Keep ENB water OFF coexistence, renderer independence, and existing fixes. CS/full integration/dynamic foam are deferred. No Bobbing Framework dependency or code was added.

## Current candidate

0.1.24 is compiled and locally validated, awaiting user in-game testing. DLL size 1547264; SHA256 `ecb9c39dffe9468cc17a625845bfaa8397b6ec5db988df68e8ddcf9c2eaade5c`. Version banner `SurfaceTides 0.1.24 development (three-model floe bobbing)`. Runtime gate remains Steam AE 1.6.1170 and GOG 1.6.1179. Installer omits INI/NIF/DDS/ESP files and includes the five unchanged accepted shaders.

Implementation changes are in `Floes.cpp`, the new portable `FloeManagement.hpp`, startup configuration/menu/version files and floe tests. `floe-0.1.24-build-validation.json` and `floe-0.1.24-evidence` retain exact build/test/source evidence. Core crest-fitting/solver/renderer/hook code, foam selection, vendor code and low-level physics/pose/rider arithmetic are unchanged.

## Manager invariants

- Match actual winning static model path to ice profiles 2/3/4 and require its reviewed solid shape. Inspect bounded node trees and reject controllers/skinning/extra collision/unsupported transforms or motion. One reference, root and native collision body can have only one owner.
- Fresh engine-owned current cell, world sky cell and attached grid pointers are reconstructed for each scan slice. No raw CELL pointer or cell-ID list survives between frames. Do not replace this with global TES reference iteration or cached `TES::worldSpace`; that caused the withdrawn 0.1.20 load crash. Runtime sky-cell IDs may not be suitable for global form lookup.
- Scan two cells per update, begin passes at most once/second, queue at most 128 nearby candidate handles, acquire at most two references/update, own at most 64. A single cell's reference count remains input-sized; this is not a hard CPU-time bound.
- Acquire outside the CELL iterator callback/lock. Revalidate handles/root/profile/area, fixed motion and wet coverage. Use the accepted spatial `TES::GetCell(position)` / `GetWaterHeight(position,cell)` query: the old reference height can be the finite -3.40282e+38 sentinel. Retain the two-unit water band and placement-height bound. Deduplicate native bodies before mutation and record ownership before converting node motion 5 to 4.
- Snapshot grounded support-body identity once per normal update, after acquisition and before any movement/restoration: player plus at most 128 high-process actors, up to 48 contacts. Route each actor only to its supporting managed body. Do not re-query support after moving a neighbouring floe in the same update.
- At most eight dense crest fits/update. All targets update every frame when active count <=8. Larger groups use age plus bounded rider priority, with no starvation in portable tests. Cached targets move every frame using unchanged crest-fit/48-unit/3-degree/64-unit-per-second limits and live rise response; descent is 3x slower.
- Invalidate goals on field epoch/level, displacement, crest-follow or extra-lift change. Newly invalid goals must not drive motion before refresh. Response applies live. Zero crest-follow or displacement uses cheap original fitting without dense scans.
- Expected ownership/collision failures quarantine only that reference and restore it where still owned. Blocked IDs last until process restart (max512); do not clear merely on menu preview changes. Unexpected exceptions/full rejection cache/failed restoration can stop the manager; water stays active. Cleanup catches per-object exceptions so one failure does not prevent attempts on the others.
- No persistent REFR motion/position mutation is used for statics. Actual node/Havok motion is checked against the expected transform. Riders use the previously accepted actor carry operation. Other mods taking transform ownership are yielded to rather than overwritten.

New startup `[Objects] FloeBobbing` takes precedence when nonempty. If absent, parse legacy `FloeBobbingTest`; value 1 now opts into all three models. Do not eagerly parse an ignored legacy value. Fresh default remains 0. Existing `FloeCrestFollow`, `FloeExtraLift`, `FloeResponseSeconds` are live with defaults 1/4/0.12. The menu section is Floating ice. The installer preserves users' existing INI.

## Validation and next gate

39 portable groups pass (22 solver, 17 floe). New coverage includes the exact three-model selector, conservative bound/field overlap, bounded budget/fairness across 64 floes at 20/60/144 FPS including rider priority and invalidation bursts, and independent footprints. Accepted mathematical groups remain. Windows compile/link and exports pass. The compiled Foam/Floes object guards reject the old global iterator, including a failing 0.1.20 negative control; required spatial/physics APIs remain. No extra tests are needed before delivery.

Next runtime gate: model counts for solid01/ice01/solid02, clearance on all three, collision and player/NPC riding between adjacent floes, streaming/preview restoration, performance and `maxGoalAge` in crowded areas. The other two supplied meshes use `bhkRigidBodyT`; adapter behavior is compiled but untested in game. Do not claim multibody runtime success until the user reports it. Do not diagnose the ENB discoloration again without new contradictory evidence.

## Reproduction paths

Workspace `/workspace/scratch/96cfc0bcb1b2`; canonical tree `project-restored20/SurfaceTides`; Windows build `build-topology-01192-final`; portable build `work/ice-inspection/portable`. CMake/CTest executables are under `work-tools/python-packages/cmake/data/bin`; toolchain/SDK under `work-tools/topology-fresh` and `work-tools/sdk`. Compile with CMake --build and run CTest; do not overlap source edits with a running build.

`tools/package_floes.py --dll <absolute DLL path> --output-dir <absolute output dir>` checks the report, shader/rollback digests, creates an atomic verified installer, then stores it in `recovery` before creating an atomic verified source ZIP. Output folder for this turn: `deliverables-floes-0124`. Package names: `SurfaceTides-0.1.24-three-floe-models.zip` and `SurfaceTides-source-menu.zip`.

## Durable identity and accepted rollback

Existing source identity `libfile_7c418cf884848191814e878db1ad4791`, retained version 13 before this turn's replacement. Replace with expected version 13; use the actual upload receipt for the next version. Do not invent a version or materialize over the completed local source tree. Source archives retain exact rollback installers.

| Build | Installer SHA256 | Status |
|---|---|---|
| 0.1.23 | `0e5807faa0bff15260532548e4705b0930748a3d4ddbb89a038a4c87e40491be` | Immediate accepted rollback, clipping eliminated on selected floe |
| 0.1.22.1 | `5bcc6fd8491c83caedc1d2a6f5d822cd350c9e8bd8502f786d3607c4c27eabc4` | Bobbing/water lookup accepted; small motion |
| 0.1.21 | `af2db00cc9d868b2bef7a97796fe5b894a16b8d5b37996139640b3d6cce47cd2` | Accepted solid01 slush removal |
| 0.1.20.1 | `7fa11087f5543dbd1c4786362eaedb3606240eda7588ee22cbb3129f6e527a6e` | Accepted attached-foam crash fix |
| 0.1.19.2 | `6c7e5a345bc520a77ba857166261e80f2bd87f77aaa2829abc4b824784c9e81d` | Accepted underwater/render fix |

Never roll back to original 0.1.20 (withdrawn CTD). Never use the old local `deliverables-ice-0121/SurfaceTides-source-menu.zip` (truncated). Accepted shaders are byte-identical to 0.1.19.2; Water.hlsl SHA256 `1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e`.
