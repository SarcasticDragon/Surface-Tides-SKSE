# Resume 0.1.15: native stencil candidate and bounded ripple diagnostics

## Latest user evidence and scope

User tested without both Splashes of Skyrim and Splashes of Storms; neither appears responsible. New input: Sequence #1(12).mp4, five seconds at 2560x1440/60 FPS. Library attachment identity libfile_db24e5a326bc8191878a740cfb1bb81d. Read locally, inspected a contact sheet at two samples/second and a full-resolution frame at2.8seconds. Camera moves around an actor wading beside a dock; rings are visible while sections disappear against changing wave contours. This is consistent with overlapping water/depth representations, not proof of an ordinary standalone decal. The smaller camera-linked fragments and foam are explicitly deferred. No new log accompanied the clip.

The native-style Water.hlsl already in this project uses WADING (descriptor bit6) to sample DisplacementTex and blend its normal into water shading. Public Community Shaders UnifiedWater code separately names a displacement water mesh. Neither observation proves every circled pixel belongs to that pass or identifies the final ENB depth operation. No ENB code, shader/texture contents, SDK, bytecode, or decompilation was inspected. No public CS implementation was copied into the new code.

## Candidate change

The0.1.14 custom MeshMotionVectors stencil VS validates ORIGINAL GAME output-interface metadata. Interface agreement does not guarantee that replacing a native ENB stencil VS preserves its semantics. The user first reported clipped native ripples in0.1.14, which introduced this optional replacement. This is a concrete regression candidate, not an established cause.

0.1.15 defaults MeshMotionVectors=0 (both Config initialization and INI fallback), and supplies0 in the INI. This selects the existing native-stencil path with40-byte mesh output and retains native stencil VS as well as native ENB color/tessellation shaders. It preserves all0.1.14 performance optimizations, solver settings, wake amplitudes, bounds behavior and tessellation decisions. Renderer.cpp and ALL shader and core source files remain byte-identical to saved0.1.14. MeshMotionVectors=1 remains available to opt back into the previous experiment. A retained user INI with1 overrides the new default; check the startup log.

Tradeoff: native stencil does not provide our explicit previous-simulation-height motion correction.0.1.14's correction activated in the previous user log and did not eliminate the minor artifacts. This test isolates its possible role in the NEW ripple clipping; it does not claim a fix for the separate older artifact.

## Bounded capture

New RippleTrace.hpp/.cpp, Config.rippleTrace defaultfalse, supplied [Diagnostics] RippleTrace=1. Requires LogStats, AllowENB, ENBMeshInput. WaterPassTrace remains0. No GPU readback, shader compilation, extra draw or D3D setter is added by diagnostics. Existing game/renderer hooks only.

Three families: ordinary above-water color, WADING (VS or PS bit6), stencil (technique10). At most8 scopes per family per launch, no faster than one per5seconds per family, plus at most8 native rows per scope. Thus at most24 scopes and264 trace lines (two scope headers, eight native rows, one end row per scope); ordinary existing periodic logs continue. Unknown geometry is sampled at most once per family. Counters never grow into unbounded maps. Present updates the diagnostic clock once/frame; no clock query per draw.

SetupGeometry copies an optional POD geometry snapshot: bounded name, numeric identity only, type, source counts via AsTriShape, model-bound center transformed to world, scaled bound radius, local/world translation, scale and transform stationarity. No source vertex buffers are read, no persistent engine geometry pointer is later dereferenced. The existing bounds optimization hint is unchanged and remains separate. The scene snapshot is diagnostic only, including for moving geometry excluded from the bounds optimization.

At a selected game water scope, the trace logs the CPU field snapshot sequence/level/origin, original descriptor and draw arguments. Geometry known=false is explicit. A centerLevelDelta/centerInHeightBand estimate uses the two-unit shader height band but is NOT proof of actual vertices or exact GPU field timing. Nearby known candidates require estimated center within32 units of rest height and bounding-circle XY overlap; that is only a logging filter.

Native entry records topology, selector candidacy, HS/DS presence, PS/RT0/DSV object identity, and public depth/blend/raster state descriptors before preparation. Absent state objects have zero descriptor fields in the log, NOT inferred D3D defaults. End row reports total native calls, selector matches, successful mesh preparations and patch calls. COM getter references released by ComPtr. Diagnostic exceptions shut off only diagnostics, never rendering.

If complete geometry metadata is absent, do not return to mandatory SetupGeometry detection or invent a height mismatch. Shader-based water identification and exact scoped native selector are unchanged.

## Next user test

Install entire0.1.15 package. Keep ENB water and tessellation enabled. Reproduce the ripple beside the dock for about40seconds immediately after visible load. Confirm startup MeshMotionVectors=false and RippleTrace=true. Send the normal log; another video only if behavior changes. No global displacement disable, no ripple hiding, no foam changes, no retesting Splashes required.

If clipping improves with this sole visual change, preserve native stencil and investigate any remaining mismatch with the captured passes. If unchanged, use WADING vs base estimated height/density and native depth/pass states to select a targeted follow-up. Do not claim a bounds estimate proves an entire triangle or that high tessellation density automatically aligns two independent meshes.

## Recovery

Workspace had reverted to0.1.11 at turn start. Recovered authoritative source version26 from libfile_4355a322deb481918f58dfaa7d9c03c5 and the0.1.14 installer from libfile_bee959ee4860819180ef110e7b350b67. Both copied into recovery-current. Source extracted into recovered/SurfaceTides; existing toolchain and build caches retained. Do not build the other older source tree. Previous source version26 includes the0.1.14 user-results checkpoint.

No subagents authorized or used. Source includes no downloaded research files or clip frames. Retain0.1.14 installer unchanged. Save source over its existing identity (guard26), latest installer over libfile_09c5e26b5238819187b073e8c574a1df (guard14), and create a separately named0.1.15 installer. Final build/hash/validation results appended after completion.

Build-cache note: the recovered Ninja dependency database reported stored-deps timestamps older than newly rebuilt objects, causing a second large rebuild. Do not assume a further optional rebuild will be incremental; inspect the cache only if a later code change actually needs building. Build logs /tmp/st0115-build.txt and /tmp/st0115-build-final.txt.

## Completed validation

Windows x64 MSVC-ABI compile/link PASS (final build exit0). AMD64 PE and SKSEPlugin_Load/Version exports verified; binary inspection refreshed. Portable19/19 PASS. No shader files changed; no redundant DXC/native SM5 rerun. Native shader validation executable rebuilt and packaged but not executed here. User runtime test remains necessary for the preset and diagnostics. The optional snapshot field missing-initializer compiler warning in Hooks.cpp is value-initialized by the aggregate; no uninitialized snapshot is used. Other warnings are existing compiler/vendor warnings.

Final DLL SHA256: aa8642c8c4dfa819643b8c01812066dfe300aa7f1909e4b6916b25cda5bcc154
