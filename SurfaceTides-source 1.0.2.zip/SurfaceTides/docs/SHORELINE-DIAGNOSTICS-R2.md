# Shoreline follow-up: separate refraction from SSR

## Latest user result

After shoreline-r1, the artifact mostly remains, but the user observes it confined to the water instead of bleeding onto terrain. The brighter scene is a weather change, explicitly unrelated to our changes. Treat this as a reported partial improvement, not proof of a complete terrain-bleed fix or a controlled pixel comparison. The clip contains moving narrow bright fragments and larger angular shading patches within water. It does not establish faulty Water for ENB meshes or identify the optical contribution producing the fragments.

Attachments, read locally:

- Sequence #1(16).mp4: libfile_f0f53e9da054819182d37ff7df2bfdd6,6.9667seconds,2560x1440/60fps. Examined contact sheet and full frame at2seconds.
- SurfaceTides(20260911-153551).log: libfile_0c63927097b4819184dd132a868699da. Internal timestamps09:29:02 startup,09:32:04 first simulation,09:32:49 final report; filename timestamp differs. No user-specified event timing for this run.

The log confirms AE1.6.1170,0.1.17 DLL, AllowENBtrue, saved ENB EnableWaterfalse/confirmedOfftrue, experimental integrationfalse and our water-off renderer. Eight compiled shader pairs:5000,11E,31E,11F,3002,5001,15E,35E. No warnings/errors. Eight draw reports total78,309 bound/tessellated draws, failed0/incompatible0; uploadedSeq1->2087. All sampled forwarding-miss/state-change/constant-repair counts are0. This supports ongoing rendering, not an interception failure. There is no shader-file hash in this DLL's log, so it cannot independently prove the installed overlay's identity. No underwater pass was logged in this run.

Simulation height/slope and actor impulses advance. Numerical clipped count reaches2; that is a solver clamp statistic, not a visual clipping counter. Keep the wave settings unchanged for this investigation. See shoreline-r2-log-summary.json for parsed counts.

## Decision

Do not weaken waves, modify Water for ENB assets, change ENB hooks, or extend the unconfirmed shoreline fix yet. R1 changed foreground refraction rejection but left the existing screen-space reflection contribution intact. Current Water.hlsl samples SSRReflectionTex and RawSSRReflectionTex with a normal-dependent UV offset on the observed11E/31E/11F/15E/35E families. That offers a second plausible source of fragments within water; it is not evidence that SSR is the cause. Isolate the two contributions in separate reversible overlays.

The source adds ST_DIAGNOSTIC_NO_SSR with default0. Its conditional removes only the existing above-water SSR sampling/blend when set1. Cubemap/planar reflection remains. Source ST_SHORE_REFRACTION remains1. Default compiled behavior is byte-identical to delivered r1. No fix is promoted and the latest full installer remains the saved r1 version19.

## Two independent tests

| Overlay | ST_SHORE_REFRACTION | ST_DIAGNOSTIC_NO_SSR | Effect |
| --- | --- | --- | --- |
| A-no-refraction | 2 | 0 | Removes the refraction lookup offset on above-water scene-depth passes; retains the background texture, wave normals, all reflection contributions and geometry. |
| B-no-SSR | 1 | 1 | Retains r1 refraction but removes our above-water SSR contribution; retains cubemap/planar reflection, normals and geometry. |

Install each as a separate mod after the current SurfaceTides/r1 overlay. Enable only ONE diagnostic at a time and restart between A and B. Both replace the same Water.hlsl, so stacking them does not combine the tests. Keep ENB master water OFF and experimental integration0; no INI change, cache deletion, DLL replacement or texture/mesh removal. Log version stays0.1.17. Disable both diagnostics and restart to return to r1. These are temporary isolation tests; changes in reflections or bottom distortion are expected.

Compare the same shoreline view and report whether A, B, both or neither removes the fragments, ideally with labeled short clips. Normal logs can confirm compilation. There is no need for large trace captures. If A removes the artifact, focus next on refraction/depth sampling, including the final rejection's switching and filter footprint. If B removes it, investigate our SSR sampling/compositing with displaced geometry. Neither result proves the water replacer's meshes are faulty. If neither helps, expand to remaining reflection/fog, decorative passes and mesh overlap only after that evidence. Both improving can reflect interaction between contributions or more than one artifact.

Mode A affects above-water REFRACTIONS+DEPTH without VERTEX_ALPHA_DEPTH; all five observed main water families satisfy it. It does not disable every possible water refraction pass or underwater refraction. Mode B only removes SurfaceTides' consumption of its currently bound SSR textures, not engine/global SSR generation or ENB-wide reflection processing. Preserve these limits when interpreting results.

## Validation and provenance

tools/validate_shore_diagnostics.py compiles26 representative/currently observed descriptors across five stages for delivered r1, current defaults and both actual packaged macro configurations:520/520 DXC SM6 successes.130 default outputs byte-identical to delivered r1. All geometry stages and underwater/stencil/non-target PS outputs byte-identical in A and B. Resource checks confirm B no longer binds SSR textures and still binds the cubemap; A still binds the refraction texture. Ten A PS and eight B PS outputs change, as expected. See shoreline-r2-validation.txt.

No C++/DLL/INI changes, no repeated solver tests or new Windows build. Shader-source runtime compilation is already supported by the0.1.17 DLL. New diagnostic variants have not been executed with native Windows SM5, live remapped buffers or Skyrim here. This verifies scope and compilation, not the artifact's cause or a visual fix. Existing Windows shader-test binaries are unchanged. All implementation added here is ours; no ENB implementation, shader contents, bytecode or SDK used; no Water for ENB assets accessed or redistributed. No subagents.

## Recovery and saved identities

Existing project-shore18/SurfaceTides was checked byte-for-byte against the saved source version31 before editing. Its Water.hlsl matched delivered r1 SHA256c253ae2f5a77ad6fc5c81dad3865e8a9f62d961c8230034a98e9f1ec9232413d. No reconstruction from stale project trees was needed this turn. Host DXC/reference tools remained usable.

Source identity libfile_4355a322deb481918f58dfaa7d9c03c5 at version31 is replaced with the diagnostic source/checkpoint. Create two new overlay identities, leaving the latest full installer libfile_09c5e26b5238819187b073e8c574a1df version19 unchanged. R1 overlay libfile_8b74d6e83f708191847f87a5bb51c8b4 version0 remains available. Confirmed unpatched standalone/coexistence packages and the native ENB experimental package are preserved. Use actual upload receipts for future version guards.

Renderer-neutral direction remains: standalone water and ENB water-off coexistence, then CS water-off coexistence. CS support is still pending/gated. Full native ENB integration remains an off-by-default experiment. The shoreline issue remains unresolved pending these tests.

## Package verification

Both overlays contain only the configured Water.hlsl and notes/licenses, with no DLL/INI. Archive integrity and exact macro bytes verified. Source C++/headers/configuration and other shaders are unchanged. Latest full installer hash remains 1b5e0c6dd5d7fc1180fa32bb13685af954c1fdeeabeaa4cb3f8d6e17110da82a (version19 r1).

SurfaceTides-0.1.17-shoreline-A-no-refraction.zip; Water.hlsl SHA256:43506f6a7bb8df720c288c818ce0a9e8ae942bf0a0f76dd338568f23f8950694; archive SHA256:e6f6715062517862554e1f9c59dab93fd314f91d55e58ba1121fc753dad6926a; bytes:36158

SurfaceTides-0.1.17-shoreline-B-no-SSR.zip; Water.hlsl SHA256:6a2d4dd1914c5b569b05e2e9a62970cfc7e45f5f037caafb0717dee5fb8fdc6e; archive SHA256:50383031f8a6b191e6a0d113bc6c5e572a416aeca5f0b614c54be99729de605f; bytes:36070


## User result and next candidate

A produced no visible change. B appeared to return shoreline bleed. No log/video accompanies this report. These observations do not isolate the cause. See SHORELINE-R3.md for a remaining rest-plane mismatch in depth-based material blending and a bounded candidate correction. Keep A/B as diagnostic rollbacks; neither is a fix.
