# Surface Tides 0.1.23 — adjustable floe crest following

The user confirms0.1.22.1 bobbing works. Its log shows26 motion reports, heave between -1.346 and0.8161 game units, and tilt no greater than0.221 degrees. Translation tracking error stays below0.03 units, with grounded rider detection also recorded. The original48-unit heave/3-degree tilt limits are not the source of the subdued targets: the average height across this large floe is small despite much taller individual crests.

The video shows strongly shaded patches where water intersects the ice. This update aims to reduce that intersection by changing the floe's target motion. It does not establish or change the particular ice/water material responsible for the strong color contrast. The adjacent floe overlapping this one is an unrelated placement issue confirmed by the user; placements are not changed.

## Install and compare

Install `SurfaceTides-0.1.23-floe-crest-update.zip` over0.1.22.1 and restart. Your INI is preserved. `[Objects] FloeBobbingTest=1` remains required and already appeared in the supplied log. Only E7B8A~Skyrim.esm outside Septimus Signus' outpost moves. Keep the current load order, ENB master water OFF, IcyFixes, slush and foam settings.

The new controls appear under **Surface Tides / Settings / Selected ice floe** in SKSE Menu Framework. They apply live without resetting the waves and use the existing Save/Reload tuning buttons. New keys missing from the current INI take the defaults below.

| INI key under `[Objects]` | Default | Range | Effect |
|---|---:|---:|---|
| `FloeCrestFollow` | 1 | 0–1 | Blend from the original average fit toward a plane lifted to clear sampled crests. Zero disables the extra lift and dense sampling. |
| `FloeExtraLift` | 4 | 0–32 | Extra clearance in game units, multiplied by crest following. Fades away as local wave amplitude approaches zero. Can reveal more of the ice's sides at high values. |
| `FloeResponseSeconds` | 0.12 | 0–2 | Rise response. With crest following active, descent uses three times this value to reduce abrupt settling. Zero requests immediate following, still subject to the motion-speed limit. |

**Original floe motion** restores crest following0, extra lift0 and response0.35, reproducing the0.1.22.1 target and response. **Crest-following defaults** restores the new three defaults. Both buttons affect floe tuning only. Save if you want changes to persist. `FloeBobbingTest` itself remains a startup switch.

Start with defaults at the same floe. If low interior ice still intersects water, increase **Extra floe lift** gradually, for example to8. Compare with Original floe motion, watch from shore, and check standing/jumping. Return the log and a short clip if overlap or discoloration remains. The faster/larger motion needs an in-game collision/rider check even though that code is retained.

## Implementation

`fitFloeCrestTarget` retains the original3×3 average/tilt fit. A second, denser sample grid covers the same loaded-bound footprint, approximately one simulation-cell interval apart, bounded at65×65 samples. It evaluates the shader-equivalent height/wet/edge/displacement sampler and finds the maximum water height relative to the fitted tilted plane. That residual adds **upward** lift; it does not multiply the troughs and drive the floe farther down. The fit uses the same frame and applied tuning as the simulation update.

The extra margin reaches its configured size at four units of sampled wave amplitude and fades continuously below that. No lift remains in a flat zero-height field, with DisplacementStrength0, on a dry footprint, or outside the local simulation. A temporarily lower crest target settles more slowly than it rises. The existing48-unit absolute heave cap,3-degree tilt limit,64-unit/second conservative point-motion bound and collision synchronization guard are retained.

This is an artistic clearance aid, not full buoyancy or two-way water/ice interaction. A rigid floe cannot conform to every short wave. Its footprint is inferred from the solid bound rather than a detailed map of its upper surface; sampling, response delay, extreme waves, low interior geometry and the hard caps can still permit intersections. More lift may be a useful visual compromise. Actual obstacle coupling and material-aware shallow-water shading remain separate possible future work.

The runtime samples the same published-source field as before, uses the accepted spatial water query, and modifies the same scene-node transform/keyframed collision. Actor support identity and carry, acquisition, restoration and ownership checks are unchanged. Floe motion remains opt-in and limited to one selected reference. No renderer changes, new external framework dependency, NIF/texture replacements or reference-placement edits are introduced.

Periodic `FloeTest` lines now include mean heave, sampled crest, added lift, active controls, sample count and `heaveLimited`. Existing collision errors and rider counts remain. If `heaveLimited=true` appears, the target has reached the existing48-unit cap; increasing lift further cannot improve clearance in that frame.

## Verification and limits

The Windows AMD64/MSVC-ABI DLL compiled and linked with both SKSE exports. All36 portable groups pass (22 existing plus14 floe groups). Four new groups cover an interior crest missed by the original nine points, large waves that cancel in the average, tilted-plane clearance, zero-strength exact fallback, partial strength, calm/dry/outside-field/zero-displacement behavior, amplitude fade, sampling/heave caps, invalid dense samples and live tuning handoff without wave resets.

A standalone optimized CPU test of the logged981.32-unit-radius footprint measured about0.179ms per4225-sample crest fit over2000 iterations. This is a local CPU microbenchmark, not a Skyrim FPS measurement. Sampling runs for only the enabled selected floe; original-motion mode skips the dense scan. No GPU readback or Havok water queries are added per sample.

Source comparison verifies acquisition, collision/rider updates and restoration remain unchanged, along with the core solver, renderer, hooks, foam/slush selection, vendor files and all five accepted water shaders. The compiled dependency guard retains the accepted spatial query/node motion APIs and rejects the formerly crashing global TES reference scan and persistent reference mutation wrappers. Existing Windows INI flush handling remains intact; only the three new live keys are added to Save tuning.

DLL:1530880 bytes, SHA256 `34fbe781349ab33a939b0bb558d68ce1fdc97872d0b397820af8d429a6c83d44`. In-game clearance improvement, new live menu controls and rider behavior with larger lift are **pending user testing**. The0.1.22.1 update remains the exact immediate rollback. The source checkpoint retains it and earlier accepted water/foam/slush rollback packages.
