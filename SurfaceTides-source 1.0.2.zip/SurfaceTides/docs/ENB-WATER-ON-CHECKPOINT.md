# ENB coexistence confirmed; enabled-water black patches

Checkpoint: September 10, 2026. No plugin, shader, solver, or preset changes in this checkpoint. DLL remains 0.1.9.

## User-confirmed milestone

User reports SurfaceTides 0.1.9 simulation works with ENB 0.505 / Silent Horizons 2 when ENB water processing is OFF. FYX Water Mesh Optimization remains installed, and adding Water for ENB textures introduces no observed issue. Stress testing continues; this is confirmation for this setup, not universal compatibility.

Preserved installer: SurfaceTides-0.1.9-ENB-water-off-baseline.zip, byte-identical to the prior 0.1.9 installer. DLL SHA256: 360c9a775351088640faabf9f125117eec0cf0b56d926ad2458ef04f44576eeb.

## Enabled-water experiment

User also enabled ENB water live. Simulation remains visually apparent and parts of the result look good, but water has black patches and sometimes becomes entirely black. Screenshot387.png shows dark middle/background bands behind normally rendered foreground water. Screenshot alone does not identify the failing rendering pass.

Evidence: SurfaceTides(20260910-062902).log. Startup reads saved EnableWater=false; it does not record live ENB state or toggle time. Game-context bridge methodMask=FF and native entryMask=7F. Simulation uploads advance through sequence2309, with active heights and clipped=0. Observed shader pairs compile, failed=0 and incompatible=0. This is unlike earlier total shader-identity rejection.

At 00:24:52, identifiedWater=197364, matchedNative=197364, noMatchingNative=0. At 00:24:57 the interval counts are 200466 / 199929 / 537, then at 00:25:02 204930 / 204171 / 759. Missing matches appear later in the session, but cannot be causally linked to the toggle without timing. Counters are per-report, not cumulative.

changedAfterDraw=0 only checks selected shaders/topology/field bindings after return. It does not prove correct render targets, reflection/refraction resources, shader outputs or ENB internal passes. Renderer::begin replaces both VS and PS; visually convincing layering does not prove ENB's own complete pixel shading survives. No ENB source, shaders, binary implementation or SDK used.

## Next controlled user test (same 0.1.9 DLL)

Keep SurfaceTides settings, FYX, textures, weather and camera fixed. Start with saved [EFFECT] EnableWater=false so the current startup guard allows hooks. Enable ENB water live as in the user's prior experiment. Record approximate time or elapsed seconds for each switch; wait about 10 seconds between states.

With ENB water ON, set ENB [WATER] EnableDisplacement=false and EnableTessellation=false, leaving SurfaceTides tessellation enabled. These public option names are documented by Water for ENB's author: https://www.nexusmods.com/skyrimspecialedition/mods/37061 (description, example WATER settings). Disabling them is our diagnostic experiment, not a published compatibility fix. If already off, report that and do not assume the experiment changed anything.

If black patches remain, additionally test ENB [WATER] EnableParallax=false and report separately. Return ENB water OFF as a recovery comparison. Do not save EnableWater=true with 0.1.9: subsequent startup would decline installation. Request the new log and these three WATER values; no ENB shader files are needed.

A clear improvement with ENB geometry options disabled would implicate that feature path, not establish its exact mechanism. Persistent black patches warrant targeted public D3D diagnostics before a shader rewrite: native forwarded draw count/signature/topology, render-target formats/count, PS resource availability/layout and constant buffer sizes sampled across state changes. Existing CB logging happens once per shader bundle and cannot show toggle changes. Do not blindly widen forwarding to all draws: first exact-match identity is a conservative heuristic and extra ENB passes may require different outputs. Preserve the working water-off behavior and keep any next integration candidate separately versioned.

No new build or tests necessary for this documentation-only checkpoint. Previous build and 16/16 portable test result apply to unchanged code. Native ENB execution remains available only through the user's testing.

## Follow-up received

The requested feature-toggle test is complete: no improvement from disabling ENB displacement, tessellation or parallax. See ENB-TIMED-ISOLATION.md and RESUME-0.1.10.md; do not repeat the now-completed test above as the next action.
