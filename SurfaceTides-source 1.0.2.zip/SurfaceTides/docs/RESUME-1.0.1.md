# Resume: Frozen Marsh decals, 1.0.1

User supplied thirteen winning Frozen Marsh NIFs and explicitly requested decal removal only, no bobbing. Latest source before this turn was library libfile_7c418cf884848191814e878db1ad4791 version21, local deliverables-release-100-r2/SurfaceTides-source-menu.zip SHA256 c2c4f64b84e3572a7f8cdfb59247aeaa28e7afb0292822c37959e667817193d8. Preserve its identity on writeback.

See FROZEN-MARSH-1.0.1.md and frozen-marsh-1.0.1-evidence/. Six attached slush profiles and three frost-only profiles added; four solid-only inputs excluded. Input metadata includes shader_type11 (multilayer parallax), still BSLightingShaderMaterialBase/kLighting; the existing material-family cast remains applicable. No broader material-family bypass was added.

Important: the prior isFloeProfile predicate accepted every iceDecal profile. It is now limited to indices2–4 to prevent animating Frozen Marsh objects and indexing the bobbing manager's five-entry arrays out of bounds. Floes.cpp, physics handling, rider handling and simulation/shaders are byte-identical to the pre-change1.0 baseline. New tests lock this eligibility set and protect standalone collision/extra-geometry rejection.

Compiled Windows DLL at build-topology-01192-final/SurfaceTides.dll; portable build work/ice-inspection/portable. Read-only nifly tool rebuilt locally at work/frozen-marsh-101/inspect_foam; source in tools/nif. Thirteen metadata reports and input hashes preserved; proprietary meshes not included in deliverables. All46 portable test groups pass (22 solver,24 floe/selection), exact9/19 new geometry matches and6/21 legacy matches. Compiled old-global-scan negative control passes.

Deliver small INI-preserving DLL overlay, full FOMOD1.0.1 with updated coverage text, and updated source containing exact recovery packages. FOMOD keeps the double-quoted XML encoding correction and48 options. New profile behavior awaits the user's game test; unknown variants stay visible by design. Two LandBroken mesh paths assume landscape/ice, unlike seven other new paths directly confirmed in the earlier xEdit export. Do not change runtime-version support or add bobbing to this family.

The user's prior technical explanation document is a separate artifact and was not changed by this code task. The original1.0 FOMOD passed user installation with an encoding warning; r2 addresses that warning but the user has not explicitly confirmed its disappearance. Do not claim otherwise.
