# Underwater surface recurrence — 2026-09-13

Follow-up received2026-09-15: Underwater NG ruled out; preview OFF fixes the symptom, diagnostic colors conceal it, and DisplacementStrength0 worsens it. User explicitly corrected "dispersion" to "displacement." See UNDERWATER-CONTACT-ISOLATION.md for the current evidence and one shader-only diagnostic. The sections below preserve the earlier state; they do not supersede that follow-up.

## Confirmed user results

The user confirms 0.1.19.1 fixed INI saving; 0.1.19 menu controls were already confirmed working. This supersedes the save-verification-pending status in the hotfix build notes.

Underwater surface gaps have recurred. User says Experimental.ENBWaterIntegration is disabled and ENB master water is OFF. User plans to test with Underwater NG disabled. That result has not yet been supplied. No current log or INI accompanied this report. Current live/persisted tuning, actual underwater shader descriptors, camera depth, and water-mesh topology are not known for this run.

Attachment: Sequence #1(24).mp4; library_file_id libfile_816d679e928c81919e229e8c2575cae1. Local path /workspace/scratch/96cfc0bcb1b2/upload/Sequence #1(24).mp4. Duration 11.25 seconds, 2560x1440, 60fps. Inspected one-frame-per-second contact sheet and full-size frame at4seconds. Video begins above water, goes under/through surface, then looks toward sky/shore. Broad dark surface areas and apparent openings vary with view/wave motion. This does not prove missing triangles; coverage/depth/stencil rejection and failed/transparent shading can look similar.

## Code review

0.1.19.1 changed only save flushing and runtime version strings relative to0.1.19. Solver, renderer, hooks, menu controls, all shaders byte-identical. Water.hlsl SHA256 remains 1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e. No new shader or DLL is issued in this review.

The confirmed shoreline correction outputs SV_Depth=0 in primary above-water SPECULAR/WADING PS015E, preserving native stencil selection. It does not directly target the UNDERWATER technique, but cannot be ruled out as part of interacting water passes near camera transitions. Do not assume that a new underwater report disproves the accepted shoreline result. The correction has not had broad underwater verification.

The hull shader uses positive tessellation factors, without explicit view-frustum/backface patch rejection. A winding/raster issue is still possible in the current setup but not established. Old0.1.16 native traces had CULL_NONE, so blindly repeating the prior MeshTwoSided experiment is not justified. That setting also affects the experimental mesh-input path, which the user says is OFF.

The shader uses native flat-plane refraction/depth machinery in the UNDERWATER path, while geometry can be displaced. A mismatch around camera/surface crossing is another hypothesis. Do not claim a root cause until current controls/logs discriminate shading from coverage.

Earlier0.1.17 native-baseline user test had no gaps in lakes or rivers. Several later shader/mesh/material/tuning changes exist; that successful local test was not proof of a comprehensive underwater fix.

## Underwater NG primary source

https://www.nexusmods.com/skyrimspecialedition/mods/187230 (checked2026-09-13). Author describes underwater fog/color/blur/lighting changes and camera-based waterline transitions, and states it does not replace water meshes/textures or edit water records. This makes the user's isolation test useful, without establishing either incompatibility or absence of interaction. Do not attribute a mesh-replacement mechanism to Underwater NG. No third-party mod source has been inspected or copied.

## Next discriminating checks

Start with the user's planned Underwater NG test. If the problem remains, use the existing menu at the same view, independently: (1) Preview Surface Tides OFF, then back ON; (2) DisplacementStrength=0 with preview ON, then restore it; (3) diagnostic water colors ON with original displacement. Return the observed gap behavior, restore normal colors/tuning afterward, and attach current SurfaceTides.log plus saved SurfaceTides.ini. No need to save temporary diagnostic settings.

Preview bypasses Surface Tides' replacement water rendering, but does not unload hooks or other mods. Displacement zero isolates geometric movement without removing custom shading/depth correction. Colors test whether the areas receive our visible color output, helping separate normal/refraction shading from coverage/depth/stencil rejection; it is not definitive geometric proof by itself. If needed next, the existing RippleTrace=1/LogStats=1 (restart) can capture current underwater/base/stencil/wading state; budget8perfamily already exists. Do not request another giant logging build before reviewing the inexpensive controls.

CS coexistence remains deferred; preserve the accepted independent water/ENB-water-off baseline and working live menu. Next investigation depends on the user's controls/log, rather than speculative rendering changes.
