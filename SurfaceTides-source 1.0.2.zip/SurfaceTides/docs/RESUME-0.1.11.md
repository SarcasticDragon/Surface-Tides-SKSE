# Resume SurfaceTides0.1.11: guarded PS constant binding repair

Current authoritative source: recovered/SurfaceTides. Latest input SurfaceTides(20260910-073322).log. User: ENB0.505/Silent Horizons2, FYX, Water for ENB textures. ENB water OFF works; ON black patches; OFF fixes again. Prior ENB geometry/parallax switches did not help. Read ENB-CONSTANT-SHIFT-EVIDENCE.md for quantitative0.1.10 trace evidence. Do not repeat previous diagnostic work.

31E color shader shows native PS b0..3 [4976,80,224,1296] while SurfaceTides declares engine groups at b0..2. Baseline/returned layout [80,224,1296,0]. Output color target unchanged; all129 sampled wrapper draws contain one matching native draw. 4904 also shifts, but is LOD and remains excluded. No native shader bytecode or ENB implementation inspected.

## Changes

include/surfacetides/ConstantBinding.hpp implements portable guarded one-slot detector. Requires all3 groups live and engine allocation sizes nonzero, distinct,16-aligned, <=64KiB, at least our reflected requirements; native b1/b2/b3 must exactly equal engine sizes. Native b0 must be aligned, larger than all3 and<=64KiB. No hardcoded4976/80/224/1296 values in production logic; these are regression test fixtures only.

ShaderReflection.hpp adds engineBufferRequirements, reflecting only SurfaceTides' own compiled PS and checking the generated register assignments. Bundle stores requirements. Renderer::begin gets the game's original p->constantBuffers[i].buffer descriptors through public GetDesc and compares the current native PS slots. Only accepted forwarded known-water draws with AllowENB and RestoreWaterConstants can remap. LOD and pipeline rejection happen earlier. Exact match -> PSSetConstantBuffers(0,3,[oldb1,oldb2,oldb3]) before replacement shader binding. DrawState already snapshots/restores b0/b1/b2; source references remain held in DrawState/fourthPS, so overlap cannot drop a buffer early. b3 is read, not overwritten; b12 remains unchanged. No GPU readback or ENB shader parsing. Unknown layouts retain0.1.10 behavior and log the sizes.

Config RestoreWaterConstants defaults true; supplied INI sets1. WaterPassTrace now0 to keep logs compact. LogStats stays1. Each bundle logs a normal/shifted/unrecognized-prefix mode once; every5 seconds reports remappedDraws and unrecognizedLargePrefix. Unrecognized-prefix counts are a diagnostic heuristic, not proof of a defect. Generic shader identity/draw gating unchanged. Startup still requires saved EnableWater=false; live ON is an experimental test. No AllowENBWater override added. Version0.1.11 in CMake/plugin/startup/INI/README.

## Validation

Windows x64 MSVC-ABI compilation/link succeeded with existing LLVM/xwin toolchain. Portable regression suite includes measured OFF/ON/OFF sizes, wrong material buffer, missing source/engine descriptors, too-small data, two-group LOD, duplicate sizes, ordinary/unaligned/oversized prefix rejection. Portable17/17 groups PASS; output in solver-validation.txt. AMD64 and both SKSE exports verified. Native Windows test executables are refreshed, not executed here. HLSL and simulation sources unchanged; runtime reflection, game buffer descriptors and actual visual fix need Skyrim testing.

DLL SHA256: 13c357a2879f05ee74f47ab7885fa60a781f3e91818cf9bc5fb5a1925b137724

## Next test

Install supplied DLL+INI; keep ENB displacement/tessellation/parallax false. Saved EnableWater=false at launch, then about15sec OFF ->20sec ON ->10sec OFF live. Send log and visual result. Need shifted=true and remappedDraws>0 duringON; if0 compare logged engine/required/native arrays. If activated but patches persist, investigate other resources/passes without undoing valid remap. Do not claim full ENB shader preservation: our PS still replaces ENB's PS for these draws. Confirmed0.1.9 baseline and0.1.10 diagnostics remain separate rollback/test archives.

No external repository; source/checkpoints and install artifacts must be preserved under existing saved identities. Native build path build/windows-cross; portable build/portable. Cross-build instructions in CROSS-BUILD-RECOVERY.md. No subagents and no ENB-origin code permitted.

## Subsequent user validation

The0.1.11 repair activates for31E/35E, with27931 remapped draws and no unrecognized layouts in SurfaceTides(20260910-085344).log. User sees no noticeable defects with ENB master water ON and displacement/tessellation/parallax OFF. Enabling individual features restores milder dark regions and intermittent seams. See ENB-FEATURES-FOLLOWUP.md for the pending same-DLL detailed trace; no new build produced.
