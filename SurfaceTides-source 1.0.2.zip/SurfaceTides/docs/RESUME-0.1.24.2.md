# Resume — 0.1.24.2 rider drift

Latest user: 0.1.24.1 improves movement, but a short slide remains after stopping without Ice is Slick. Adding Ice is Slick returns the previous movement block. User permits documenting an incompatibility if it cannot be resolved. Do not attribute the base slide to that mod or claim compatibility from reading its description.

Input `SurfaceTides(20260915-112749).log`: 83749 bytes, SHA256 `5ced954ace8ccdaac11b39da9d758f1421d1d5b572bb9f98e9728ae6299873a9`. AE 1.6.1170, ENB water OFF, experimental integration false, 0.1.24.1. Twelve summaries, six active bodies with profile counts (1,2,3), blocked=0, collision position max0.1531 game units / angle max0.0446 degrees, riders0/1, carry count up to166/interval, no warnings. Log does not identify whether Ice is Slick was enabled for this particular run, its version or controller velocity changes; do not infer those.

## Candidate design

0.1.24.2 removes unconditional velocity reapplication. Shared `offsetFloeRider` reads live position and velocity, applies incremental position with matching center convention/forceWarp=false, then reads velocity again. Only an observed XYZ change above 1e-6 native vector magnitude, or invalid post-velocity, triggers SetLinearVelocityImpl with the incoming value. W-only changes are ignored. No cached previous-frame speed, braking logic, player-input checks, stationary locks, raw controller flags/contact writes or actor-position calls. If the setter really changes velocity, this build still repairs it; diagnostics tell us how frequently that occurs. This is a targeted candidate, not a proven root cause.

New `floeRiderDelta` computes the difference of two floe transforms locally, in double precision, avoiding large float world-position cancellation. For orthonormal rotations R and scales s: local=transpose(Rbefore)*(point-tbefore)/sbefore; delta=(tafter-tbefore)+(safter*Rafter-sbefore*Rbefore)*local. Zero transform change gives exact zero, pure heave gives no lateral delta, and actual tilt remains. Adapter converts the existing NiTransforms once per carry call. Character reference feet still locate the point on the floe; the destination is always an offset of the live controller position. It does not force a character to stay at an old local position.

Global lightweight `FloeRiderStats` records offsets, velocityRepairs, invalidPostVelocity, maxOffset (game units), maxVelocityChange (native units). Existing five-second report prints and resets it. There is no per-frame log. Diagnostic `carried` continues to count successful offsets. The input log lacks these counters; next returned log is important if the candidate fails.

No changes to three-model discovery, selection, collision movement/cleanup, crest sampling/math, scheduling, live tuning, water renderer, hooks, vendor code or shaders. Only carry calculation/velocity policy, bounded report, tests and version strings changed.

## Ice is Slick research

Author Ckw25; primary page https://www.nexusmods.com/skyrimspecialedition/mods/190881 and Files tab ?tab=files inspected 2026-09-15. Public page lists 1.0.3.2 and a desktop source archive in Miscellaneous Files. Source could not be retrieved from available page; no source inspection or code reuse occurred. Do not invent a GitHub repository or download endpoint. User's actual installed version is unknown. Ask for its matching desktop source archive after delivering the base drift candidate.

Author documents moving/animated ice support, per-object ignore rules and custom compatibility files. These give possible future approaches but are not evidence Surface Tides can coexist. Record the user-reported conflict specifically with bobbing, not the whole water simulation. Leave Ice is Slick off for base validation. Do not mutate its settings or contact the author without authorization. No hard module block or automatic bobbing disable was added. Permanent incompatibility remains an acceptable fallback, not an established technical impossibility.

## Build and verification

DLL version tuple {0,1,24,2}; banner `SurfaceTides 0.1.24.2 development (floe rider drift)`. Windows AMD64/MSVC ABI build succeeds with the existing vendor warnings; 1553408 bytes, SHA256 `6fc48e0a7f2327752cdadfe78580ae16a0e9a02639c9e387251fa9a7a71dcfe5`. AE gates unchanged.

43 portable groups (22 solver/21 floe) pass. Two new groups exercise natural braking with no redundant setter, W-only changes, measured repair when a setter clears velocity, exact stationary/heave-only behavior and coordinate-origin invariance for tiny tilt. Existing walking/carry/bounds/fleet/solver tests pass. No game execution occurred. Compiled carry vtable calls: 0x10,0x30,0x18,0x30,conditional0x38. No Actor::SetPosition. Source normalization guard confirms Floes.cpp only differs in carry block and diagnostics compared with 0.1.24.1. Global TES iterator negative control remains rejected for Foam and Floes.

Evidence: `docs/floe-0.1.24.2-build-validation.json`, `docs/floe-0.1.24.2-evidence/`. Script `tools/validate_floe_riders.py --workspace /workspace/scratch/96cfc0bcb1b2` uses 0.1.24.1 source as comparison and existing CTest output. No more optional testing is necessary before delivery. Next gate is user walking/stopping/standing/jumping with Ice is Slick off, then compatibility investigation with the matching external source if desired.

## Continuity and packaging

Workspace/tree/build same as RESUME-0.1.24.1. Work evidence `work/ice-riders-01242`; deliverables folder `deliverables-riders-01242`; installer `SurfaceTides-0.1.24.2-rider-drift.zip`. Package includes the verified DLL and unchanged five water shaders, no INI/NIF/DDS/ESP. Source archive includes this candidate and all older exact rollback installers.

Immediate comparison 0.1.24.1 installer SHA256 `2309b1502ac6118a2f8d0c08f8ea4d8885fe2ae6302944a956e5d228a6c6c2cf`; full source SHA256 `370ffa19e70627482e6e4b1ba9f573579548596154ae906dd5ff6c85f1dd91c7`. It improves locomotion but retains the reported drift and Ice is Slick conflict; not a fully accepted release.

Source Library identity `libfile_7c418cf884848191814e878db1ad4791`, retained concrete version15 before this write. Replace with expected version15, then retain actual receipt version. Never materialize an older source over current work. Original0.1.20 remains withdrawn for CTD; accepted0.1.20.1/0.1.19.2 foam/render fixes retained. No CS/ENB integration work or new affiliations.
