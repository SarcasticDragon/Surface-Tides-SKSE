# Surface Tides 0.1.22.1 — floe water lookup correction

The returned 0.1.22 log resolves the selected E7B8A~Skyrim.esm reference, accepts its base/model and hides its slush. All nine bobbing attempts stop at `different active area/water level`. The adapter never acquires the floe or changes its collision. This is a qualification failure, not evidence that the wave amplitude is too weak or that IcyFixes prevents motion.

## Install and test

Install `SurfaceTides-0.1.22.1-floe-water-fix.zip` over the current update and restart Skyrim. It preserves the existing INI. Your last log already confirms `[Objects] FloeBobbingTest=1` and `HideIceDecals=1`; keep those enabled, retain IcyFixes, and return to the same floe outside Septimus Signus' outpost.

Watch from shore first. If it moves, stand on it, jump off, and toggle Surface Tides preview off/on. Return the log even if there is no motion. `FloeTest: acquired ... motion=5->4` means acquisition succeeded; periodic lines then report heave, coverage and collision error. A remaining water rejection now prints both area IDs, owning/spatial cells, cached reference water, queried water and simulation water. The prototype remains limited to this single placed reference.

## Correction

The previous code called `TESObjectREFR::GetWaterHeight()`. In the bundled CommonLibSSE-NG source this first uses `loadedData->relevantWaterHeight`, then falls back to the owning cell's exterior water height. That is not a position-based water query. A static's cached value or persistent owning cell can differ from the water at its actual placement. The old log did not print those values, so the precise mismatch is still a hypothesis.

The adapter now checks the reference's world/interior identity against the active simulation, resolves its attached spatial cell at its authored position, verifies that cell belongs to the same area, and calls `TES::GetWaterHeight(position, cell)`. This is the engine query already used by the simulation's terrain mask. A finite result must still match the simulation's rest level within the existing strict two-unit band. The player's water level is never substituted to force acceptance. The cached reference height remains diagnostic only.

The reference is resolved against its originating Skyrim.esm ID, then checked against the reviewed base/model. An ESP override does not itself invalidate that identity. The returned log passed those checks, so removing IcyFixes is not the next diagnostic step. A changed scene or collision structure could still fail a later check; those stages have not run in the returned test.

The new acquisition line includes both water values and both cells. Failure diagnostics remain throttled to five seconds. No changes were made to the water simulation, renderer, shader files, motion fit, keyframing, rider handling, cleanup, foam/slush filter or settings menu.

## Verification and rollback

The Windows x64 DLL compiled and linked successfully. Both SKSE exports are present. Compiled floe dependencies include the new spatial cell/water queries and the existing node motion, physics world read lock and character-controller access. The forbidden reference-position/motion mutation wrappers and formerly crashing global TES reference scan are absent from the floe object. The compiled foam object matches 0.1.22 exactly and passes the retained negative-control crash guard.

Comparison with the complete 0.1.22 source archive found executable-source changes only in acquisition diagnostics/water lookup and version metadata. The motion/physics/rider loop and release code are byte-for-byte unchanged. The 32 portable groups passed for 0.1.22; their unchanged sources were compared, not rerun as a substitute for testing the engine query. All five accepted water shaders remain identical. No NIF, DDS, ESP or INI is included.

DLL SHA256: `d454019fd9e7bd41da67331f4e4e608708613cde08431b804fb1d7eddb02ab3b` (1,523,712 bytes). This is a compiled candidate, not an in-game-confirmed fix. Physics synchronization and rider behavior still await the first successful acquisition test.

Disable bobbing alone with `FloeBobbingTest=0` and restart. The previous 0.1.22 package is retained as the immediate comparison build, while 0.1.21 remains the accepted solid01-slush-only rollback. The accepted foam and underwater fixes are also retained. See [FLOES-0.1.22.md](FLOES-0.1.22.md) for unchanged prototype limits and [RESUME-0.1.22.1.md](RESUME-0.1.22.1.md) for the development checkpoint.
