# Surface Tides 1.0.2

Version 1.0.2 keeps a verified nearby water surface active after the player leaves it, allowing existing waves to decay. It addresses an actor water-height cache loss seen on dry ground in interiors. No tuning defaults or rendering, solver, removal or bobbing algorithms changed. The new behavior still needs in-game confirmation. The preceding 1.0.1 Frozen Marsh decal coverage has been confirmed working by the user.

Independent surface water simulation for Skyrim Anniversary Edition, with dynamic waves, dispersive wakes and character interaction. Surface Tides works without a renderer framework and can coexist with ENB or Community Shaders when their water processing is disabled. No ESP or Papyrus script is required by Surface Tides itself.

## Requirements

- Skyrim Steam **1.6.1170** or GOG **1.6.1179**, with matching SKSE and AE Address Library. Other runtimes, including1.5.97 and1.7.x, are not supported by this DLL.
- SKSE Menu Framework **3.x** is optional for the in-game settings page. The simulation works without it.
- Base Object Swapper **3.0+** is required only if you select standalone foam removal. It is installed separately.

Dependencies are not bundled. The installer describes the exact runtime requirements; it does not attempt unreliable detection of SKSE DLLs or substitute a minimum game-version test for the DLL's exact supported-runtime check.

## Installation choices

Install the ZIP through your mod manager so its FOMOD wizard opens. Select the renderer you actually use, then choose the optional surface-object features. By default, the optional removals and bobbing are off.

| Option | Effect |
| --- | --- |
| Standalone | Use Surface Tides without ENB or CS. |
| ENB — water off | Sets AllowENB=1. You must save `[EFFECT] EnableWater=false` in enbseries.ini and keep it off. Your ENB preset is not edited. |
| Community Shaders — water off | Sets AllowCS=1 and installs a small CS override disabling Water shader replacement, Unified Water and Water Effects at boot. |
| Attached foam removal | Hides reviewed foam shapes attached to rapid rocks, retaining rocks and collision. |
| Standalone foam removal | Installs the BOS preset for the three reviewed standalone foam bases. Waterfall impact effects stay. |
| Ice decal removal | Hides reviewed flat slush in the three original ice-floe models and nine Frozen Marsh models (including three standalone frost patches), retaining solid ice and collision. |
| Ice bobbing | Makes nearby supported solid floes follow the simulation. Independent of the ice decal switch. |

The installer writes **one complete SurfaceTides.ini** with your choices. Back up customized tuning before reinstalling. When replacing an older Surface Tides installation, use a clean mod-manager replacement, not a merge that leaves old optional files behind. In particular, a deselected `SurfaceTides_Foam_SWAP.ini` or `CommunityShaders/Overrides/SurfaceTides_Global.json` must not remain active from another mod or an old overlay.

There are 24 complete INI variants: 3 renderers × 2 attached-foam choices × 2 ice-decal choices × 2 bobbing choices. Standalone foam is a separate BOS file, making 48 wizard combinations. `HideAttachedFoam=1` and `HideIceDecals=1` mean remove the respective effects; 0 means keep them. `FloeBobbing=1` enables motion independently of the removal choices. The full INI also documents Frozen Marsh coverage, which uses the existing ice-decal switch.

The DLL uses built-in defaults if the INI is missing; it does not create a file on startup. A small DLL update ZIP preserves existing settings, while the full FOMOD supplies the complete INI. The separately supplied base INI uses Standalone with both removals and bobbing off. Select ENB or CS through the FOMOD for the corresponding compatibility setup.

Restart Skyrim after installation or startup-setting changes. The optional menu is under **Surface Tides / Settings**. Most simulation tuning can be adjusted there; renderer selection and object-feature switches require a restart. Detailed diagnostics default off, with ordinary five-second statistics enabled.

## Compatibility and current limits

**Ice is Slick is incompatible with ice bobbing for now.** Leave bobbing off if you use it. Several disconnected chunks in a single NIF move together because the placed mesh has one rigid motion. Not every modded mesh layout is supported by the reviewed shape filters.

ENB water-off coexistence and initial CS water-off coexistence have passed user testing. Broader stress testing continues. CS version/preset coverage is not universal; the CS override uses its existing settings system and can be superseded by other settings overrides. Surface Tides does not query live CS state. Removing the override may leave values that CS saved in its own configuration; restore those through CS when desired.

Waterfall impact rings remain. Dynamic simulation foam and splitting vanilla ice meshes into independent pieces are future work. Flat effects retained by the chosen options can still intersect moving water. Full ENB water integration remains experimental and is disabled in every installer variant; it is not an offered installation mode.

## Version 1.0

This promotes the accepted0.1.25 implementation to1.0. Runtime code changes are limited to version labels and removing the CS test wording. Simulation, shaders, water draw behavior, foam filters, ice motion and jump handling retain their tested implementations. The FOMOD adds feature selection and consistent INI generation.

The source archive includes build scripts, the installer generator/validator, all dependency notices, test evidence and exact earlier recovery installers. See THIRD_PARTY.md and licenses/ for source attribution and terms. The source archive should accompany a public binary release under the project's existing license terms.
