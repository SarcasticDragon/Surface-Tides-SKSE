# SurfaceTides 0.1.2 diagnostic checkpoint

September 9, 2026. User has limited session budget; do not rebuild/download the toolchain or repeat completed investigation unless scratch is lost.

Evidence: user's SurfaceTides(1).log records 0.1.1 on Skyrim 1.6.1170, successful water/player and D3D11/Present hooks, successful shader compilations 5000/5000, 5001/5001, 2/2, 31E/31E. No subsequent errors. User sees vanilla behavior. This confirms the 0.1.1 compile fix but does NOT establish nonzero CPU waves, valid wet mask, matching world coordinates, or visible replacement draws.

No speculative functional fix made. 0.1.2 adds:
- Game.cpp: five-second stats with player position/cell/water height, origin, wet cells, max height/velocity/slope, actor count, emitted impulse count, solver steps/clips/dropped time, sequence and epoch. Inactive transitions logged.
- Renderer.cpp/.hpp: five-second counts of attempted/bound/tessellated draws and each skip reason, uploaded sequence, and one-time per-pair native VS/PS constant-buffer sizes. Counts indicate CPU-side binding, not GPU execution proof.
- Bridge.hpp/Game.cpp/Main.cpp: LogStats and DebugView config, config startup log, version0.1.2.
- SurfaceField.hlsli/Water.hlsl: extra float4 STDebug at b11 offset64; CPU buffer grows64 to80 bytes. DebugView1 colors non-stencil PS output by patch XY, rest-height band and wet field. Does not bypass simulation gating, change masks/forces, or touch stencil outputs. Normal visuals use DebugView0. Color legend in README and INI.
- Packaged INI intentionally sets DebugView1 and LogStats1. Code default DebugView0 means a user's existing INI can suppress the overlay; check startup log.

Build: Windows x64 MSVC-ABI DLL linked successfully; SKSE exports checked. No solver changes; prior12/12 numerical suite remains applicable. New shader overlay has not executed under FXC or Skyrim. Do not claim a fixed visual effect.

Next requested evidence: 30 seconds looking at nearby water and moving through it, screenshot with overlay, new log, location and active water replacer names. Green means XY/height/wet sample agrees in PS; whiteness tracks abs(height)/2. Blue suggests terrain mask (try TerrainMask0 only after recording baseline); orange suggests height/camera offset; magenta immediately around player suggests XY/camera offset. All vanilla with bound draws and debugView1 suggests invisible/overwritten passes or graphics pipeline state and may require GPU capture. Native VS b12 size0 would flag missing camera constants; do not invent offsets or bind guessed buffers. Large epoch changes indicate resets; wet0 explains empty simulation; impulses0 while wading suggests contact qualification. Distinguish these with evidence before another patch.

Persistence: source and install ZIPs replace existing saved artifacts, retaining older versions. Toolchain and build directories excluded from source ZIP; vendor source and prebuilt Windows tests included. README documents native and cross builds. Current scratch compiler/build intact under work-tools and build/windows-cross.
