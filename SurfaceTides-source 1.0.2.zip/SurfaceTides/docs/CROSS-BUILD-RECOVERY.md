# Cross-build recovery

Known working September 9, 2026: LLVM-MinGW 20260826 Ubuntu22.04 x64 (clang23.1), xwin0.10.0, CMake4.4.3/Ninja1.13.2 from pip, xwin MSVC14.44.17.14 and SDK10.0.26100. This is clang-cl targeting MSVC ABI, not MinGW ABI. The full vendored source is already included; do not re-fetch dependencies.

If the temporary toolchain is lost, download these exact release assets:
- https://github.com/mstorsjo/llvm-mingw/releases/download/20260826/llvm-mingw-20260826-ucrt-ubuntu-22.04-x86_64.tar.xz
- https://github.com/Jake-Shadle/xwin/releases/download/0.10.0/xwin-0.10.0-x86_64-unknown-linux-musl.tar.gz

Extract with tar --no-same-owner. In the LLVM bin directory create clang-cl as a symlink to clang; lld-link already exists. pip install --target work-tools/python-packages cmake==4.4.3 ninja==1.13.2. Use the actual CMake executable at python-packages/cmake/data/bin/cmake and ELF Ninja at python-packages/bin/ninja.

Use xwin --accept-license --cache-dir work-tools/xwin-cache --http-retry 2 splat --output work-tools/sdk --use-winsysroot-style --preserve-ms-arch-notation. Accepting the license is required for SDK acquisition. SDK and compilers are not redistributed in this source package.

Configure the source with Ninja, cmake/windows-clang.cmake, absolute ST_LLVM_BIN and ST_WINDOWS_SYSROOT paths, absolute CMAKE_MAKE_PROGRAM path to Ninja, CMAKE_BUILD_TYPE=Release, ST_BUILD_PLUGIN=ON, ST_BUILD_TESTS=ON, ST_BUILD_SHADER_TESTS=ON. Build with --parallel2 (384 actions on clean build). Install --component SurfaceTides to a staging prefix. Archive staging contents for mod installation; archive source excluding build/out for source distribution. Refresh validation binaries and binary inspection only after successful linking. Shader tests need native Windows; do not spend another session setting up blocked Wine sockets.

Latest workspace: recovered/SurfaceTides is authoritative; an older SurfaceTides directory may also exist. Do not build the stale tree. Save new source and mod ZIPs back over their existing saved identities, retaining version history.
