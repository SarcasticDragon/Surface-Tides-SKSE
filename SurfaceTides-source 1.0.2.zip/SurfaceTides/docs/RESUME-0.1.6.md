# 0.1.6 localized idle crests

User SurfaceTides(9).log and screenshots14/15/18 confirm 0.1.5 wakes are spectacular and strongly displaced. User clarified that distant means interior of active local water, NOT native LOD. Idle field moves waterline but looks flat away from shore. Foam work remains out of scope.

Changed CPU idle excitation, not hooks or shaders. Existing two sinusoidal continuous pressures retained. Every half second of simulation time, a deterministic world-tile hash selects roughly one quarter of 360-unit tiles and emits a signed Mexican-hat velocity impulse through existing addImpulse. Radius50..90, velocity=Wind*GustStrength*(5..8), wet-footprint mean removed. Tiles include a270-unit margin so intersecting footprints are considered. Positions depend on world tile and event index, not patch origin, and survive ordinary recentering without moving the forcing pattern. Reset restarts deterministic simulated time. No height jump is injected; velocities evolve through existing solver. These are procedural localized pressure gusts, not weather-linked wind.

New Settings.gustStrength default1, validated0..4; INI [Simulation] GustStrength=1, parsed/clamped and startup-logged. GustStrength0 reproduces prior continuous forcing; Wind0 disables both idle sources. Existing preset Wind5, displacement2, normals2, actor strength4/radius1.5 unchanged. No GPU shader/ABI/interception change.

Portable14/14 groups pass. New20-second test measures interior squared-curvature sum13.5212x continuous-only reference, peak9.87762, no clips; checks30/120Hz identical heights, masked zero-net-height and deterministic reset. Existing stronger wake and combined wind/wake tests pass. Additional tools/gust-validation.cpp probes192-square full patch and curved river mask near Riverwood for30seconds: peak10.9294 and15.7067 respectively, both finite/no clips. These CPU results do not prove appearance or all configurations in Skyrim. New idle appearance still requires user test.

Build and packaging status recorded in VALIDATION.md. Source and install archives should be replaced under their existing identities. Toolchain and recovery instructions remain in CROSS-BUILD-RECOVERY.md. Do not return to vtable-only draw hooks or change the supported runtime gate.

Latest user confirmation: idle simulation is exactly the desired result. Next task is renderer compatibility discussion, with an explicit ban on ENB-origin implementation code. See COMPATIBILITY-NEXT.md. No compatibility mode is implemented yet.
