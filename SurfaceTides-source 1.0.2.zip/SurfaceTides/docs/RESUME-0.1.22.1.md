# Resume: floe acquisition water query, 0.1.22.1

User saw no motion with 0.1.22 and asked whether an IcyFixes.esp override was responsible. Target is REFR E7B8A~Skyrim.esm, base 8CCFE, icefloessolid01 outside Septimus Signus' outpost. Do not ask for those details again. Three reviewed ice-slush profiles and earlier water/foam fixes are retained. Dynamic foam and CS remain later work; accepted ENB coexistence uses ENB master water OFF.

## New evidence

`SurfaceTides(20260915-083741).log`: version0.1.22, runtime1.6.1170, both object switches true. Ref000E7B8A/model/slush matched. Nine acquisition attempts all report `different active area/water level`; none acquired. Field water is consistently -14000 with active waves and wet coverage. The code's ordering proves reference/base/model/attached checks passed. It does not prove whether the reference area or cached water was wrong: the prior combined message omitted both values. No physics conversion or motion was attempted. IcyFixes is not established as the cause.

## Candidate

0.1.22.1 changes Floes.cpp's water qualification and waiting/acquired diagnostics, plus version metadata in Main.cpp/CMakeLists.txt. It uses TES::GetCell(ref position), validates attached spatial cell and world, then TES::GetWaterHeight(position, cell), the same positional engine API as Game.cpp's wet mask. A matching reference area is required before using the active grid. Interior queries use the actual owning interior cell. Returned water still must match the active field's strict two-unit band. No hardcoded sea height and no substitution of the player field's height. Reference GetWaterHeight is kept for diagnostics only. Owner-cell versus spatial-cell/cached-water behavior is the current hypothesis, awaiting logged values.

The acquisition success log includes ownerCell/spatialCell/referenceWater/fieldWater. Water failures have separate reasons with targetArea/fieldArea/spatialWorld/position and both water values, throttled to five seconds. Other acquisition checks, fixed->keyframed collision conversion, rider handling, sampling and cleanup are unchanged from0.1.22. No motion was visible in that returned baseline because the early qualification never passed; do not weaken the downstream collision-tracking guard to obtain visuals.

## Build and files

Compiled Windows AMD64 DLL at `build-topology-01192-final/SurfaceTides.dll` relative to session workspace. Bytes1523712, SHA256 `d454019fd9e7bd41da67331f4e4e608708613cde08431b804fb1d7eddb02ab3b`. Working root `project-restored20/SurfaceTides`; toolchain and SDK as in RESUME-0.1.22.md. Build log and diff/compiled dependencies/PE info/returned-log excerpt are under `docs/floe-0.1.22.1-evidence`.

`tools/package_floes.py` now packages0.1.22.1 to `deliverables-floes-01221/SurfaceTides-0.1.22.1-floe-water-fix.zip` and `SurfaceTides-source-menu.zip`. Atomic temporary ZIP writes, byte checks and rollback hashes remain enforced. DLL overlay retains the five identical accepted water shaders and omits INI/NIF/DDS/ESP. Existing switches are already active in user's INI. Preserve0.1.22 under recovery for comparison; accepted0.1.21,0.1.20.1,0.1.19.2 rollbacks also remain.

The source Library identity before this task's writeback was `libfile_7c418cf884848191814e878db1ad4791`, version11. Replace that same identity with expected version11; record the returned version for the next turn. Never substitute the truncated old local0.1.21 source ZIP. Complete0.1.22 source was verified and used for current comparison.

## Validation and next test

Build/link/AMD64 and SKSE exports pass. Floes object calls engine spatial GetCell/GetWaterHeight and existing node SetMotionType/physics lock/controller methods; forbidden REFR setters/MoveTo/AddChange/global TES scans absent. Compiled Foam object is identical to0.1.22 and retains the old crash negative-control guard. Source comparison found only CMakeLists.txt/Main.cpp/Floes.cpp changed among executable source/data/vendor/tests; acquisition-external motion and cleanup functions unchanged. The prior32 portable groups are recorded as historical passes with unchanged source, not falsely claimed to test this new engine query.

Runtime result PENDING. Tell user to keep IcyFixes and repeat at the same floe, shore view before standing/jumping, then return the log. If water still rejects, use the new actual area/cell/height values. If the reason progresses to scene/collision/coverage, diagnose that gate. If acquired, inspect collision errors and riders before expanding reference coverage. Do not claim the bobbing prototype or water-query hypothesis is confirmed by compilation.
