# ENB constant binding shift: captured evidence

Input: SurfaceTides(20260910-073322).log, SurfaceTides0.1.10 / Skyrim1.6.1170. User toggled ENB water ON15.34 seconds after visual load and OFF35.37 seconds after load. The final OFF step fixes the black water again. ENB displacement, tessellation and parallax were left disabled from the preceding test.

393579 decoded characters,896 lines,129 sampled wrapper draws. All129 samples contain one observed native draw, matching the expected signature, with no truncation. This sampling does not rule out unobserved rare or asynchronous passes. No evidence of an additional color render target in the affected31E samples: they retain one format10 target (R16G16B16A16_FLOAT), the same target resource and depth/blend settings in representative OFF/ON/OFF samples. The native PS object changes; VS/topology remain the same.

## Pixel constant sizes

Sizes in bytes, as returned by public D3D11 descriptors:

| Game PS | State/layout | PS b0 | b1 | b2 | b3 | b4 | b12 | Samples |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 31E | Baseline / returned | 80 | 224 | 1296 | 0 | 0 | 720 | 19 |
| 31E | Enabled-water interval | 4976 | 80 | 224 | 1296 | 720 | 720 | 10 |
| 4904 (LOD) | Baseline / returned | 80 | 224 | 0 | 0 | 0 | 720 | 19 |
| 4904 (LOD) | Enabled-water interval | 4992 | 80 | 224 | 720 | 0 | 720 | 10 |

The 31E shift first appears in trace63 at+25.792 seconds from the first simulation update and reverts in trace103 at+45.929. This20.137-second sampled interval is consistent with the user's20.03-second ON interval. The first simulation update precedes the user's visual-load stopwatch reference; do not confuse these time origins. Last baseline sample before the shift: trace59 at+23.771; last shifted31E sample: trace99. Captured buffer sizes strongly indicate a one-slot insertion, but do not alone establish buffer-content identity; the candidate additionally verifies against the game's own buffer descriptors.

The existing generated SurfaceTides pixel shader always declares STEngine0/1/2 at b0/b1/b2. Replacing the native PS while retaining the shifted bindings therefore feeds incorrect groups into our shader. This is a concrete layout mismatch to correct, not proof that it is the only remaining integration issue. PS textures t13–15 also change; our shader does not use those slots. Some t1 changes occur for4904, which SurfaceTides skips as LOD. Do not treat every resource difference as a defect or modify LOD as part of this correction.

## Candidate

0.1.11 validates native b1/b2/b3 sizes against the selected BSGraphics::PixelShader constantBuffers[0..2] buffer descriptors and the live requirements reflected from SurfaceTides' own compiled PS. All three groups must be active, allocated, distinct-sized and sufficiently large. A distinct larger prefix at b0 is required. Bind the existing b1/b2/b3 resources at b0/b1/b2 only for the accepted SurfaceTides draw; retain references and restore original b0/b1/b2 afterwards. Unrecognized layouts keep previous behavior. No generic slot search, content readback or ENB shader inspection.

Expected next evidence: `Water constant layout ... shifted=true` and positive `Water constant repair: remappedDraws` during ON, returning to0 after OFF. If engine buffer descriptors are absent or differ from the native shifted resources, the guard refuses the remap; use logged engine/required/native sizes to investigate instead of weakening it blindly. Native GPU behavior still requires user testing.
