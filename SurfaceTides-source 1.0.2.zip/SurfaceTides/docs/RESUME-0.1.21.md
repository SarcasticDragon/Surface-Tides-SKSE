# Resume checkpoint: 0.1.21 ice slush, 2026-09-15

Read `ICE-0.1.21.md` first. 0.1.21 is compiled/packaged but awaits in-game ice-filter confirmation. The user confirmed the preceding 0.1.20.1 load-crash fix and initially correct foam hiding; broader testing continues. Do not repeat the old crash investigation or foam classification.

## Exact current state

- DLL 1,459,200 bytes; SHA256 `5c059c72ff384e6a87c78a571c2ce13662d50d5d53de77775e79ecf0bfdf22bd`.
- New startup `[Objects] HideIceDecals=0` defaults off, independent of existing HideAttachedFoam. Update ZIP excludes INI. User enables the new key manually.
- Third reviewed profile in `FoamSelection.hpp`: `landscape/ice/icefloessolid01.nif`, solid `IceFloesSolid01:0`, slush `L1_IceFloesSolidSlush`, lighting shader and diffuse/normal `landscape/icefloes.dds` / `landscape/icefloes_n.dds`.
- The runtime manager remains `Foam.cpp`: branches material extraction by profile category and selects enabled profiles. Same ownership/restoration, bounded discovery/cache and accepted AE iterator fix. Log prefix `IceDecals:` for the new profile, `AttachedFoam:` for the original two.
- Inspected input hash `038e772a9d8c3503eff36e5c39d7c5c7f36eda4d32de0738f092490cc4621959`. Nifly JSON in `docs/ice-0.1.21-evidence/icefloessolid01.json`. Shared root fixed collision, no child controllers/collision; slush and solid shapes use BSLightingShaderProperty. No user NIF is redistributed.
- `FloeMotion.hpp/.cpp`: shared float4 SurfaceTexel (`plugin::Texel` is an alias; ABI unchanged), non-owning CPU field view, shader-matching height sampler, yaw-aware 3x3 rigid footprint fit and time-based response. Eight portable test groups. Not called by plugin runtime. No float motion switch exists yet.
- Validation: 22 existing + 8 new test groups; captured eight-NIF audit selects 4 of 17 geometries; compiled crash regression passed. AMD64/SKSE exports/system imports checked. Rendering, hook, physical solver and five HLSL files byte-compared unchanged to previous source. Dependencies' C/C++ source unchanged.
- New code is original. No ENB, CS or Bobbing Framework source copied.

## Next work

Obtain winning `icefloes01.nif` and `icefloessolid02.nif` to review additional slush shapes, and one detached placed floe's reference ID plus originating plugin. Inventory base IDs are not reference IDs. The supplied solid01 is a large single collision body; verify target suitability before moving every placement of that model.

Implement the narrow runtime motion adapter, initially explicit reference selection. Capture/restore authored transform, water rest level/freeboard and collision motion type; update collision together with render transform; handle standing actors, pause, unload/reload, save/load, preview disable and transform ownership. Use matched frame/tuning snapshots, worldspace/interior identity and epoch. Field/tuning are currently separate snapshots and Frame has no area member: the new sampler requires area identity from its future caller. Do not wire it blindly to a stale exchange frame. Fit target is relative to footprint center; engine adapter must preserve the authored pivot/yaw rather than use object Z as water level. Only one controller may own a test floe.

Do not equate math tests with in-game buoyancy. No runtime bobbing or collision motion is implemented in 0.1.21. No global ocean simulation or fully coupled fluid/solid feedback is promised. CS remains later; accepted ENB coexistence uses master water OFF. Full ENB water integration remains experimental/off. Dynamic foam remains after release.

## Build/recovery

Use the existing clang-cl Windows x64 MSVC-ABI configuration described in `CROSS-BUILD-RECOVERY.md`. Current scratch build directory was `build-topology-01192-final`, toolchain under `work-tools/topology-fresh/llvm-mingw-20260826-ucrt-ubuntu-22.04-x86_64`, SDK under `work-tools/sdk`. This build has ST_BUILD_TESTS/SHADER_TESTS OFF; portable tests were configured separately in `work/ice-inspection/portable` with both plugin and shader tests OFF. `cmake --build ... --parallel 4` compiled the DLL; `ctest --test-dir ... --output-on-failure` ran both portable suites. No Skyrim or native Windows test execution was available.

`tools/package_ice.py --dll <DLL> --output-dir <dir>` packages the overlay/source and checks recorded build hash, profiles, discovery guard and unchanged rollback/shaders. Refresh build validation when changing source. `tools/nif/inspect_foam.cpp` now also reports XY bounds and rigid-body metadata; it still never saves/optimizes NIFs. `tools/nif/validate_profiles.py` accepts either the original seven-mesh JSON or that set plus solid01.

Preserve accepted `recovery/SurfaceTides-0.1.20.1-foam-hotfix.zip` (SHA256 `7fa11087f5543dbd1c4786362eaedb3606240eda7588ee22cbb3129f6e527a6e`) and `recovery/SurfaceTides-0.1.19.2-topology-update.zip` (`6c7e5a345bc520a77ba857166261e80f2bd87f77aaa2829abc4b824784c9e81d`). Do not return to the original 0.1.20 load-crashing DLL. Never reintroduce global TES::ForEachReference: use player-cell/worldspace and attached-grid traversal. The map retains nested lambda/RTTI names containing that text through dependency folding; inspect direct decorated function names and Foam.obj unresolved dependencies, not substring presence alone.
