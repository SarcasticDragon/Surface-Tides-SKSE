# Current: user-confirmed shoreline correction

2026-09-13: user reports fragments gone in the standard near-vanilla configuration and with ENB loaded/master water disabled. Preserve the tested shader SHA2561c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e and0.1.18 DLL. This turn is documentation-only; no runtime edits or new compilation/testing. The previous660host shader checks remain applicable. No new log/footage or broader occlusion/performance result was supplied. Keep the overlay enabled for ongoing full-wake testing; release hardening and CS coexistence remain pending. See WADING-DEPTH-TEST.md.

---

# Current: primary WADING depth-comparison diagnostic

660host DXC SM6 builds passed. Source-default outputs remain unchanged; only active PS015E adds a constant SV_Depth0 output. All geometry, stencil/motion, underwater, additional lights and other pixel outputs match r4 byte-for-byte; pixel resources and color target remain unchanged. No C++/DLL/solver modification or native Windows/in-game execution. See WADING-DEPTH-TEST.md and wading-depth-validation.txt. The restored0.1.18/r4 rendering is user-confirmed; original fragments remain. Older validation sections are historical.

---

# Current: 0.1.18 native water metadata trace

Cross-compiled and linked an x64 Windows SKSE DLL with clang-cl23.1 using the MSVC ABI and SDK10.0.26100. The final forced plugin recompilation completed223build actions with exit0. Verified DLL size1,395,712bytes; SHA25619c7154594c2844f5b1a3b066b9c61dae39aa1e96b2e1c32576b74f0166a794c. The binary contains the final fieldSource and standalone-end markers and exports SKSEPlugin_Load and SKSEPlugin_Version. PE imports contain standard Windows/D3DCompiler libraries; no CS or ENB runtime import was added. See native-water-trace-build.txt and native-water-trace-binary-inspection.txt. Existing vendor/compiler warnings and the pre-existing partial GeometryHint aggregate initializer warning remain; no compilation error.

Compared source to the previous WADING diagnostic checkpoint: only six plugin C++/header files changed, plus CMake version and INI comments. Data/Shaders, src/core and include remain byte-identical. The supplied overlay Water.hlsl matches the known r4 SHA2563f4779120b62d21c41f7060ac57c01d4f5d48a046f34393f62fffa0ca85e8a21. Tracing source contains no D3D pipeline setters, draws, GPU readbacks or synchronous query waits. Fixed sampling limits and RAII ownership reviewed. Runtime gates and existing draw decisions/restoration are retained. Separate original/published and uploaded field labels avoid misinterpreting a CPU publication as a rendered update.

The previous WADING suppression test is complete and withdrawn: user footage shows severe repeated-image smearing. Native ripple omission, actor-force suppression and the extra-light diagnostic all left the original artifact. See NATIVE-WATER-TRACE.md for the new test and continuity. Older sections below are historical, including their pending-result wording.

No Skyrim/ENB/CS execution, native Windows SM5 test run or in-game performance measurement was performed here. No solver or shader logic change needed new numerical/shader tests. The matching Windows validation executables are included for optional native use, not claimed as executed. The r4 shader's earlier host validation remains historical supporting evidence.

---

# Latest: WADING visible-surface isolation

660 host DXC SM6 builds passed:165 default outputs byte-identical to the previous default source; all geometry, underwater, LOD, stencil and non-WADING PS outputs match r4. Eight above-water WADING PS variants unconditionally discard, with no texture or engine/simulation buffer reads. Other PS resource tables match. See wading-surface-shader-validation.txt and WADING-SURFACE-ISOLATION.md. No DLL/solver change, native SM5 execution or in-game test. Discarded color-pass fragments change their own depth/color contributions; separate stencil/motion shaders remain unchanged. Visual result pending.

---

# Latest: native ripple normal isolation

660/660 host DXC SM6 compilations passed (33 descriptors,5 stages,4 configurations). All165 new default outputs match supplied defaults byte-for-byte. Geometry, underwater, LOD, stencil and non-WADING PS outputs match r4. Eight above-water WADING PS variants omit the engine ripple texture/sampler, retain the simulation field and retain all other texture/sampler register bindings. See native-ripple-shader-validation.txt and NATIVE-RIPPLE-ISOLATION.md. No DLL/solver change, Windows SM5 or in-game validation. User result pending. The light-pass isolation returned no improvement; detached-camera and replacer results supersede earlier proposed tests below.

---

# Latest user clarification: TAA already disabled

User confirms native TAA is already off. No new files attached. This removes the need for the proposed TAA comparison; do not re-request it. Read-only audit confirms Diagnostics.DebugView=1 is read at startup, copied into STDebug.x and overrides water color at the end of non-stencil Water.hlsl pixel shaders while retaining geometry and stencil outputs. This is the next existing-INI diagnostic. See SHORELINE-COVERAGE-CONTROL.md for interpretation limits, including the diagnostic alpha override and retained engine blending/later passes.

Documentation-only checkpoint. No source-code, shader, INI, executable or installer changes; no new compile or solver tests. The current r4 package is unchanged and remains unsuccessful for the reported artifact.

---

# Earlier user result: r4 unchanged; TAA control pending

User reports no banding and no artifact improvement with r4. Inspected Sequence #1(18).mp4:10.033333seconds,2560x1440,60FPS, via a contact sheet and sequential crops. No new runtime log or shader-identity confirmation. The footage does not establish a geometric versus temporal cause. Read-only audit finds prepare() consumes one field per Present interval and pairs current/previous field history; this is not proof of correct live TAA behavior.

Documentation-only checkpoint. No new shader edits, compilation or solver tests, and no installer changes. Next compare with native TAA disabled while retaining r4 and full displacement; if TAA is already off, skip and report that. See SHORELINE-R4-RESULT.md. R4 remains an unsuccessful candidate for this user's reported artifact.

---

# Earlier: shoreline-r4 contact-blend candidate

User reports both plugin-disabled and zero-displacement controls are clean, with Water for ENB2.19 / Shades of Skyrim /4K and ENB removed. No new log/clip accompanies this result. Displacement is necessary in these comparisons; an exact collision/material/depth cause is not proven.

R4 adds a continuous full-color blend into the undistorted refraction background over the first12 view-depth units of scene clearance. Geometry remains displaced; no stencil, depth, motion, alpha or underwater change. Only above-water DEPTH+REFRACTIONS base passes without VERTEX_ALPHA_DEPTH are targeted. R1 refraction and r3 depth blending are retained in the overlay; new source switch defaults0. See SHORELINE-R4.md.

580/580 DXC SM6 compilations across29 descriptors,5 stages and4 configurations passed.145 default outputs match source version34 byte-for-byte. R4 geometry, underwater, LOD, stencil, additive-light and non-target PS outputs match r3 byte-for-byte; all PS resource tables match. See shoreline-r4-shader-validation.txt. A proposed LOD+refraction test descriptor481E was invalid in the saved baseline (no MPosition field); replaced with the valid depth-less LOD descriptor4802 before this final run. No production change was made to accommodate the invalid fixture.

No new DLL build or solver changes. Native SM5, Skyrim execution, contact appearance and performance remain unverified here. Package and code scope verified; user testing is the remaining visual gate.

---

# Earlier: shoreline artifact persists with ENB removed

User reports r3 did not resolve the artifact with Water for ENB retained in a near-vanilla load order and ENB removed. New log reports system d3d11/dxgi modules, no local graphics proxy or ENB module, identical native/renderer immediate contexts, no forwarding bridge or constant repairs, five compiled shader pairs, 86,875 bound/tessellated draws, failed0/incompatible0, and advancing uploaded sequences. The ENB-water-OFF label follows a leftover enbseries.ini. This does not identify the offending material/mesh, nor does the log independently identify the winning Water.hlsl overlay.

No code, shaders, configuration, binaries or installers changed. Source-only documentation checkpoint. Next controls use existing startup settings: General.Enabled=0 for native water, then only if clean Enabled=1 plus Rendering.DisplacementStrength=0 with NormalStrength=2. Keep shader files/load order fixed and restart for each comparison. See SHORELINE-NATIVE-CONTROLS.md and shoreline-native-log-summary.json. No compilation or solver tests repeated for documentation changes.

---

# Earlier: shoreline-r3 depth-blend candidate

User reports A unchanged, B worse shoreline bleed; no new logs/clips. A/B did not isolate the cause. Main water depth/material blending still uses the rest plane. R3 applies the actual geometry's vertical displacement to that plane distance, while retaining r1 refraction and normal SSR. Candidate only; source switch defaults0 and latest full installer remains r1.

405/405 DXC SM6 checks across27 descriptors and three configurations;135 default outputs byte-identical to saved r2 defaults. Geometry/underwater/stencil/non-target PS unchanged in the candidate; all PS resource tables match. Eight analytical ray/depth cases pass against geometric expectations. No new DLL, native SM5 or Skyrim execution. See SHORELINE-R3.md and shoreline-r3-* reports.

---

# Latest follow-up: shoreline optical diagnostics

R1 is a partial improvement per the user: terrain bleed appears contained, but artifacts remain within water. Latest log shows78,309 reported successful bound/tessellated draws, failed0/incompatible0 and advancing uploads. No shader hash is logged; no definitive source of the residual artifact is established.

Two removable overlays separately disable above-water refraction distortion (A) or SurfaceTides SSR contribution (B). Source defaults remain byte-identical DXIL to delivered r1.520/520 DXC SM6 compilations across26 descriptors and five stages/configurations pass; all geometry/underwater/stencil/non-target PS outputs remain identical, with targeted resource-usage checks. See shoreline-r2-validation.txt and SHORELINE-DIAGNOSTICS-R2.md. No new DLL, native SM5 execution or in-game test here. Latest full installer remains r1; diagnostics are not fixes.

---

# Latest: ENB coexistence confirmed; shoreline-r1 candidate

User confirms0.1.17 ENB master-water-OFF coexistence works. The latest clip reports shoreline refraction artifacts after adding Water for ENB. No new log was attached. See SHORELINE-R1.md; a material/mesh cause is not established.

Only Water.hlsl changes. Same0.1.17 DLL, source C++/headers, other four shader files, INI values and experimental gates. DXC SM6 scope validation:460/460 compilations covering23 descriptors,5 stages and baseline/0/1/2 modes. Baseline mode reproduces115 byte-identical DXIL outputs. All geometry stages and all underwater/stencil/non-target pixel shaders remain byte-identical in candidate and diagnostic modes. Nine above-water refraction PS families change. Output:shoreline-r1-validation.txt. This verifies compilation and change scope, not rendered images, live constants or performance.

No new DLL build was necessary or performed. No solver changes, so no repeated CPU tests. Native D3DCompiler SM5 and Skyrim execution are unavailable here; runtime compile and visual outcome require the user's test. User-confirmed baseline installers remain separate and unchanged.

---

# Latest result: 0.1.17 standalone confirmed; ENB coexistence preset prepared

User reports no ripple clipping or underwater gaps in rivers/lakes. New log confirms standalone mode, nine shader pairs including410E/430E underwater,171,816 reported bound/tessellated draws, zero failed draws and incompatible-pipeline rejections. See COEXISTENCE-0.1.17.md for scope and the numerical-clamp distinction.

ENB coexistence preset reuses the exact tested DLL and shaders; only effective INI difference is AllowENB0->1. Source default remains standalone, experimental native water integration remains disabled. No source-code changes, recompilation or repeated numerical/shader tests in this turn. Verify package bytes/configuration; the ENB comparison on this preset still requires user testing.

---

# Current validation: 0.1.17

Windows x64 MSVC-ABI compile/link PASS, all391 actions. AMD64, SKSEPlugin_Load and SKSEPlugin_Version exports, and Windows system DLL imports verified. Native test executables checked as nonempty Windows PE files and refreshed in validation/. Portable19/19 PASS after relinking intact portable test/core objects to resolve an empty host output file. All four standalone shaders and all Simulation/Interaction/Rendering INI values match preserved0.1.9 (the0.1.6 visual preset). Renderer, hooks, core simulation and experimental mesh shader are byte-identical to saved0.1.16 source.

No shaders changed; the prior0.1.16 mesh DXC65/65 result remains historical. Native SM5 validation executable rebuilt but not executed here. New Config::read defaults/migration and startup path messages are compiled and inspected, not executed in Skyrim. The underwater surface, native ripples, visual equivalence, FPS and subsequent renderer coexistence still need the user's tests. This build establishes the requested standalone baseline, not a confirmed fix for the0.1.16 defects.

DLL SHA256: 5239ecd7f403fb73f0377bedfb3cf33bbe23d204962c8303a06836b7de8c857c

---

Earlier validation records follow.

# Current validation:0.1.16

Windows x64 MSVC-ABI compile/link PASS in build/windows-0116. AMD64 and SKSEPlugin_Load/Version exports verified. Portable19/19 PASS; mesh HLSL65/65 DXC SM6 semantic checks PASS (two cap variants). Native SM5 validation executable rebuilt, covering150 stage checks and34 remaps, but not run here. Runtime D3D11/Skyrim execution unavailable. Neither lake ripple improvement, underwater culling fix nor FPS has been verified in game for this build.

The user's0.1.15 follow-up reports river ripple improvement, residual lake ripple clipping with master ENB water ON/OFF, and underwater surface gaps. This supersedes the initial impression that ripple clipping was fully fixed. See RESUME-0.1.16.md for the candidate, evidence and performance tradeoff.

DLL SHA256: cd1218d22c4fa5a90caebc6997d8abdfd4d0dd10d886419fdde2247b4ff346b8

---

Historical records follow.

# Current validation:0.1.14

Windows x64 MSVC-ABI compile/link PASS, AMD64 and both SKSE exports verified. Portable19/19 PASS. Mesh shaders33/33 DXC SM6 checks PASS, including optional previous-frame data and stencil motion VS. Native SM5 test executable compiled (118stage checks,34remaps) but not executed here. New0.1.14 D3D state changes, bounds bypass, SM5 compilation, stencil interface matching, FPS and artifact behavior require user testing.0.1.13 is now user-confirmed seam-free with ENB tessellation ON, but has a substantial performance regression. See RESUME-0.1.14.md and ENB-0.1.13-USER-RESULT.md.

DLL SHA256:341202e2aca8f003212d44833d545b341789276a8454099efe9e14f50f7e3118

---

Earlier validation records follow; the current entry above supersedes their totals and runtime status.

# Current validation:0.1.13

Windows x64 MSVC-ABI build/link PASS. AMD64 and both SKSE exports verified. Portable suite18/18 PASS, including mesh multipass selection and allocation bounds. New mesh HLSL four stages x four attribute families16/16 DXC SM6 syntax/semantic checks PASS. Native SM5 test executable now includes16 additional mesh checks; compiled but not executed here. In-game SM5 compilation, device creation, stream-output/DrawAuto rendering, ENB behavior and performance remain unverified. This is an experimental integration candidate, not a confirmed visual fix. Details: RESUME-0.1.13.md.

DLL SHA256: 1a9558385b1f80900ebb9c5d3fc944917cfd7c3ff2aea89f4173d79886b26c44

---

The following sections are historical records; their earlier test totals are superseded by the current entry above.

# Validation record

Prepared September 9, 2026. This distinguishes build verification from runtime testing.

- Portable numerical/ABI suite: **12/12 passed**, GCC 13, C++20. Covers calm state, symmetry/conservation, impermeable boundaries, diffraction, damping, CFL stability, measured dispersion, world-space scrolling, timestep/stalls, contacts, invalid inputs, and constant-layout mapping including inactive aliases. Output: `solver-validation.txt`.
- Earlier session: **75/75 DXC Shader Model 6 checks passed** on the water source, including the control-point position fix. DXIL compilation does not establish Shader Model 5 compatibility. These earlier checks did not catch the SM5 inactive-array initializer failure; 0.1.1 changes generated HLSL.
- Windows x64 MSVC-ABI build: **PASS**. All plugin translation units and dependencies compiled; final DLL and Windows test executables linked. Both `SKSEPlugin_Load` and `SKSEPlugin_Version` exports are present. PE machine is AMD64. Imported DLLs are Windows system libraries; no CS, ENB, or external MSVC runtime DLL is imported. Toolchain: clang-cl 23.1.0, LLVM-MinGW 20260826 host tools with explicit MSVC target, lld-link, Microsoft SDK 10.0.26100 and VC 14.44.17.14 headers/libraries obtained through xwin. Static CRT.
- Windows D3DCompiler SM5 execution: **not run here**. The previous attempt to run Wine was blocked by the environment's local-socket restriction. No bypass is used. `validation/RunTests.cmd` runs the included Windows tests; the shader test checks 85 stages plus 34 live-constant remaps and stripped-bytecode input-signature compatibility.
- User test of 0.1.0 on Skyrim 1.6.1170: hooks installed, but all four observed water permutations failed SM5 compilation on inactive `LightPos` initialization and fell back to original rendering. Version 0.1.1 fixes that generated initializer for both light arrays. The new DLL has **not been tested in game**; GPU validation, material/TAA fidelity, performance, and compatibility remain open.

The preview demonstrates the numerical solver with a schematic obstacle mask. It is not a recording from Skyrim.

Key functional corrections from the interrupted build: CommonLib-before-Windows include order; ActorState swimming access; mask-disabled scrolling; active-constant filtering to avoid false overlaps; native input-signature parsing independent of stripped reflection metadata; deterministic dependency fixes and static CRT selection.

DLL SHA-256 (0.1.2): `1258fc25e82573a27205c2dd2593577392cc392f19e81dcc7f3c58fee894b6de`

## 0.1.2 diagnostic update

The user tested 0.1.1: descriptors 5000, 5001, 2 and 31E compiled successfully with no reported errors, but visuals appeared unchanged. Thus the SM5 initializer fix is confirmed for those encountered pairs; rendered simulation behavior remains unverified.

0.1.2 Windows DLL: incremental compilation and linking passed, both SKSE exports verified. CPU solver is unchanged from the 12/12 passing suite. New runtime statistics and diagnostic HLSL overlay have not executed in Skyrim or native D3DCompiler here. The overlay changes shader liveness and may expose another remapping error; inspect the next log. Included Windows shader tests remain available in validation/RunTests.cmd.

## 0.1.3 bound-shader detection update

User 0.1.2 log establishes nonzero CPU field and impulses but only seven startup stencil draws, then zero attempts and uploadedSeq1 throughout. This build removes the geometry scope gate and identifies bound native water shaders across immediate draws. Clean Windows x64 build and both SKSE exports: PASS. Portable suite12/12: PASS. Shader sources unchanged from0.1.2; new hook path has not run in Skyrim. Binary inspection and prebuilt native test executables refreshed. DLL SHA-256 (0.1.3): `94e7ed239abe2e036fbe12d9f9c5846e4ce6ce6d976344298e9bc4ab5270b8f7`.

## 0.1.4 direct draw-entry detours

0.1.3 user test again showed only startup stencil draws, then zero attempts and a frozen uploaded sequence. It did not validate the geometry-scope hypothesis. 0.1.4 changes D3D interception to seven MinHook function-entry detours, obtains the canonical device context, and reports raw calls/filter rejects/entry health. Windows build and SKSE exports: PASS. MinHook statically linked. Solver and HLSL unchanged; previous numerical12/12 result applies. New detours and GPU behavior remain untested in-game.

DLL SHA256 (0.1.4): `5a04102b233a64e04597c69cc8d0d25927a112e7f8b4eb998d2409c99b5c1e1c`.

## User confirmation of0.1.4 visible rendering

SurfaceTides(4).log and ScreenShot2.png confirm visible diagnostic water colors, advancing uploaded sequence1->4758, ongoing bound/tessellated water draws and zero shader failures. Local wet/height/XY sampling is visually plausible. targetMask00 with entryMask7F and continuing calls confirms changed table targets without loss of the function-entry interception. See FIRST-VISIBLE-RENDERING.md. Ordinary water appearance, displacement and moving-character wake visibility remain to be tested with DebugView0. No new binary required.

## 0.1.5 wake controls and hull refinement

Windows x64 MSVC-ABI build and SKSE exports: PASS. Portable suite13/13: PASS. New stronger-wake test checks finite/no-clipping behavior, mean height,4x forcing energy scaling, zero strength,30/120Hz comparison and combinedWind5. Initial6x/radius2 candidate hit height limiter and was reduced to4x/radius1.5. Hull shader refines interiors enclosing patch center and uses configurable target edge length. Native SM5 compilation and in-game appearance/performance of the new hull code have not been tested here. DistantLOD and foam decals unchanged.

DLL SHA256 (0.1.5): `b66caf37dff3cf6a0639e4e84b6b823d77621e0d1b387f8bf4cb07fda5521375`.

## 0.1.6 localized idle gusts

User confirmed strong 0.1.5 wake displacement. Updated CPU idle excitation uses localized signed impulses across the active patch, retaining continuous background wind. Portable14/14 tests pass, including increased interior curvature, fixed-frame-rate agreement, masked zero-net-height, reset, and combined wind/wake stability. Full192x192 open and curved-river30-second probes remained finite without clipping (peak10.93 and15.71 simulation units). See solver-validation.txt and RESUME-0.1.6.md.

Windows x64 DLL and both native test executables compiled/linked; AMD64 and SKSEPlugin_Load/SKSEPlugin_Version exports verified. No shader source changes in this version. Native Windows tests and Skyrim were not executed here; idle visual quality and game performance remain unverified.

DLL SHA256 (0.1.6): `5f891d93a1bdeb7bd0c16861d16159b8e5daf640a6a6e7cb1a52d34195b3a5c8`.

Reproduce extra CPU probes after portable build: `c++ -O2 -std=c++20 -I include tools/gust-validation.cpp build/portable/libSurfaceTidesCore.a -o /tmp/gust-validation` then `/tmp/gust-validation`.

## 0.1.7 ENB coexistence candidate

Windows x64 DLL compiled and linked successfully with new startup policy and sampled draw probes. Solver/HLSL are unchanged from0.1.6 (14/14 portable suite and full-patch probes previously passed). Windows ENB module/config detection and D3D probing were reviewed and cross-compiled, not executed here. Skyrim with ENB remains untested; this is a controlled coexistence candidate, not a compatibility certification. No ENB implementation or SDK code used.

DLL SHA256 (0.1.7): `1338c348bfa514039a8489bac874694c70cb3e3de1e7f6c355e63a99720f2e06`.

## 0.1.8 shader identity bridge

Correct0.1.7 user log confirms ENB guard success but100%shader-identity rejection, before field upload or tessellation. Candidate0.1.8 uses app-owned D3D metadata to resolve wrapper/native identity differences; this hypothesis and actual forwarding remain unverified. Portable15/15 groups pass, including new shader-identity validation. Windows x64 DLL and native test executables compiled/linked, both SKSE exports verified in binary inspection. No HLSL or solver changes. Native D3D/ENB execution unavailable here.

DLL SHA256 (0.1.8): `a337222bee1beac275fb634286231f27ddfd68619b95d2c11a97bed6a5cf8960`.

## 0.1.9 scoped game-context forwarding

User0.1.8 log: private-data writes succeeded but no bound shader tag matched; all rejection atVS before upload/tessellation. New mode captures known game-side shader bindings and forwards their identity only to the first same-method/same-arguments/same-topology native direct draw within the synchronous call scope. Game-facing COM table hooks coexist with existing system D3D MinHook detours. Actual ENB behavior remains untested here.

Toolchain recovered after workspace maintenance using documented versions. CleanWindows389-action build passed; DLL AMD64 and SKSEPlugin_Load/SKSEPlugin_Version exports verified. Portable16/16 passed, including new forwarded-draw matching and single-use tests. Native Windows test executables refreshed, not executed. Solver and HLSL unchanged.

DLL SHA256 (0.1.9): `360c9a775351088640faabf9f125117eec0cf0b56d926ad2458ef04f44576eeb`.

## September 10 user validation of0.1.9

User confirms visible simulation with ENB water OFF, ENB0.505/Silent Horizons2, FYX and Water for ENB textures. With ENB water enabled live, displacement remains visible but intermittent black patches occur. Full ENB water integration is not validated. See ENB-WATER-ON-CHECKPOINT.md. Documentation-only update; DLL and prior build/test results unchanged.

## 0.1.10 ENB water pass diagnostics

Timed0.1.9 user test confirms black patches persist after disabling ENB displacement, tessellation and parallax, including save/apply. Matching returns to100% in later intervals while the problem remains; no precise failing pass identified. See ENB-TIMED-ISOLATION.md.

0.1.10 adds rate-limited public D3D metadata capture before shader replacement, with extra forwarded native pass visibility. Windows x64 build and both SKSE exports PASS; binary inspection and native test executables refreshed. Solver/HLSL/renderer and existing tests unchanged from0.1.9. Previous16/16 portable result applies; tracing has not run in native D3D or Skyrim here. This is a diagnostic build, not a black-water fix.

DLL SHA256 (0.1.10): `6401a29f043056fc5877b88f3b94f9b64a3d4417c1c20ef9417969e57b8963b3`.

## 0.1.11 guarded pixel constant remap

0.1.10 user trace identifies a reversible native PS constant-slot shift in31E: [80,224,1296,0] -> [4976,80,224,1296] -> original, while our generated PS continues to readb0/b1/b2. All129 traced wrapper draws contain one matching native call. This supports a targeted buffer-slot correction; full integration remains unverified.

Windows x64 build PASS; AMD64 and both SKSE exports verified. Portable17/17 groups PASS, including captured OFF/ON/OFF layout and malformed/ambiguous/missing/undersized mapping rejection. HLSL and solver sources byte-compared unchanged to0.1.10. Reflection of SurfaceTides' own shader and original engine buffer descriptor checks compiled; native D3D/Skyrim execution remains pending. Windows test executables refreshed, not executed here.

DLL SHA256 (0.1.11): `13c357a2879f05ee74f47ab7885fa60a781f3e91818cf9bc5fb5a1925b137724`.

## User test of0.1.11

The guard accepts original engine descriptors and reflected requirements for31E/35E in game;27931 draw repairs logged with0 unrecognized prefixes,0 incompatible draws and0 shader failures. User reports master ENB water ON with the three individual water features OFF has no noticeable defects, but individual features ON produce darker regions and transient seams. Full ENB water integration remains incomplete. See ENB-FEATURES-FOLLOWUP.md. Documentation-only checkpoint; DLL unchanged.

## 0.1.12 tessellation diagnostics

User isolates remaining dark regions/seams to ENB tessellation; latest log has WaterPassTrace=false. Constant remap remains active with0 failures/unrecognized layouts.0.1.12 adds independent changed/unmatched scope sampling and hull/domain metadata, enables the diagnostic preset, and warns if capture is disabled. Windows x64 build and SKSE exports PASS. Renderer, HLSL, solver and tests unchanged; prior17/17 result applies, no in-game execution here. No visual fix claimed. See RESUME-0.1.12.md.

DLL SHA256 (0.1.12): `cecaeef5c223490c3b7754ab19ca3ca9158924f33a86bb41a2014ea99760dc27`.
