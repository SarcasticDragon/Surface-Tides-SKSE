# 0.1.17: confirmed standalone baseline and ENB water-OFF preset

## User-confirmed result

User reports neither native ripple clipping nor underwater surface gaps occurs in0.1.17, in rivers or lakes. The camera-angle-dependent underwater problem from the mesh-input experiments is absent in the standalone comparison. This supports a defect associated with the combined integration path, not a claim that ENB itself is faulty or that every aspect of the earlier cause is established.

Latest log: SurfaceTides(20260911-113149).log, attachment libfile_9cb0962fa9a081919b8aa54dd1a330db, read locally. Confirms AE1.6.1170; SurfaceTides standalone renderer; AllowENBfalse; Experimental.ENBWaterIntegrationfalse; no ENB proxy/INI; displacement2/normal2/wind5/gust1 and baseline tessellation64/spacing20. Nine independent shader pairs compile:5000,11E,31E,802,15E,35E,842,410E,430E. Last two are underwater. All reported171,816 bound draws are tessellated; failed0/incompatible0. Uploaded sequence advances1->7561. No logged warning/error. One reported numerical height-clamp count near the end is not a visual ripple-clipping report; no tuning change justified by it. The log is a short baseline sample, not broad stress-test certification.

## Next package

The necessary ENB-water-OFF coexistence code is already present in the confirmed0.1.17 DLL. No C++, HLSL, core simulation, hook, ABI, or DLL change is needed to enable it. Deliver SurfaceTides-0.1.17-ENB-coexistence.zip with the SAME DLL and shader bytes as SurfaceTides-0.1.17-standalone-baseline.zip. The only effective configuration change is Compatibility.AllowENB0->1; comments/docs identify the preset. Experimental.ENBWaterIntegration remains0, RestoreWaterConstants1, mesh motion0/cap8/two-sided0, normal/displacement2 and both detailed trace switches0. LogStats1 remains. DLL/startup version correctly remains0.1.17; this is a preset, not a newly compiled binary.

Preserve the standalone installer untouched as the confirmed rollback. Default source Data/SKSE/Plugins/SurfaceTides.ini also retains AllowENB0 and experimental integration0, keeping the project standalone by default. The optional profile lives in presets/enb-water-off/SurfaceTides.ini. For a future source build, install normally and overlay that preset at SKSE/Plugins/SurfaceTides.ini only when making the optional coexistence package. CS remains a subsequent, separate compatibility task, with its existing startup gate retained. Neither renderer is required or affiliated.

## Existing implementation used

Data-load compatibility check verifies saved [EFFECT] EnableWater=false in enbseries.ini beside SkyrimSE.exe when experimental integration is off. Missing/true value disables SurfaceTides with a clear log; the plugin never edits ENB settings. Existing game-context shader identification forwards exact synchronous native draw matches to the SurfaceTides shader replacement path. Existing validated constant-buffer repair remains enabled. Internal enbMeshInput is false, so native mesh preparation/DrawAuto and the retained ENB water shaders are not selected. The ordinary SurfaceTides shaders supply both simulation displacement and shading normals.

These are existing code paths audited in current source version29, not newly inferred ENB behavior. No ENB source, shader contents, SDK or decompilation used. No additional external research or subagents. No compiler/toolchain recovery or shader-test rerun needed for unchanged binaries.

## User test

Install this full optional package with its INI as the winning mod-manager files. Restore the intended ENB setup, set and save [EFFECT] EnableWater=false, then restart through SKSE. Keep ENB master water OFF throughout. Its other effects can remain enabled. Do not enable Experimental.ENBWaterIntegration, even though ENB is now allowed. This coexistence test uses our own water rendering.

Expected log: ENB config check confirmedOff=true; Water renderer: SurfaceTides with ENB water OFF (displacement and simulation normals). On the previously observed ENB0.505 wrapper, game-context bridge installation/identifiedWater/matchedNative and advancing uploadedSeq establish ongoing interception. Normal stats suffice initially; do not enable the old massive WaterPassTrace capture without a concrete remaining issue.

Compare the confirmed river/lake wakes and underwater views and report log plus FPS/appearance observations. The desired result is preserving the baseline wave shape/readability and absence of clipping while ENB handles the rest of the scene. ENB's overall lighting/tone mapping can alter final color/contrast even with water processing disabled, so no pixel-identical appearance is promised. FYX/Water for ENB textures have an earlier positive0.1.9 coexistence result; the new load-order variant still needs its own confirmation. CS support follows after this test.

## Validation and recovery

Recovered source version29 from libfile_4355a322deb481918f58dfaa7d9c03c5 and standalone installer libfile_aefb4e1935f881919c25657373184782 (version0) into recovery-coexistence17; source extracted to project-coexistence17/SurfaceTides. Old workspace files had reverted and must not overwrite these. All five supplied shader files byte-compared with the recovered source; baseline DLL SHA256 verified:5239ecd7f403fb73f0377bedfb3cf33bbe23d204962c8303a06836b7de8c857c. Parsed preset comparison confirms only AllowENB changes. Package validation must compare ALL DLL/shader bytes and confirm unchanged default source preset.

Prior Windows build/19 portable tests remain applicable to identical code. This turn performs package/configuration verification, not a new build or native SM5 test. User log confirms runtime compilation for the nine observed standalone families. ENB coexistence on this exact0.1.17 package remains pending; the earlier0.1.9 success is historical evidence.

Preserve source identity at version29->30 and latest installer identity libfile_09c5e26b5238819187b073e8c574a1df at version17->18 after a successful save. Create separate0.1.17 ENB-coexistence installer. Record actual save receipts for next mutation guards. Do not replace the standalone baseline identity or activate the experimental native ENB water path to solve coexistence issues.

## Completed package checks

Source code, headers, default Data tree, tests, tools, vendor files and existing native validation binaries are byte-identical to recovered source version29. Parsed optional preset differs only in AllowENB. Installer DLL and all five shader files match the confirmed standalone installer exactly. Archive integrity checked; no compiler or runtime test claimed for the preset-only update.

## Subsequent user confirmation and shoreline report

User now confirms the0.1.17 ENB-water-OFF coexistence package works. Adding Water for ENB reveals small intermittent shoreline refraction artifacts. Sequence #1(15).mp4 is the new evidence; no new log attached. This supersedes the pending ENB test status above, without certifying all water replacements. See SHORELINE-R1.md for a shader-only candidate. Preserve this confirmed installer and its DLL unchanged.
