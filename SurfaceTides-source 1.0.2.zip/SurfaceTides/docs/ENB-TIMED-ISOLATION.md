# ENB timed isolation test, September 10 2026

Source: SurfaceTides(20260910-065603).log, plugin0.1.9, Skyrim1.6.1170. User: ENB0.505, Silent Horizons2, FYX, Water for ENB textures.

User-reported elapsed seconds from game load:

| Seconds | Change | User observation |
| --- | --- | --- |
| 35.30 | ENB EnableWater=true | Black patches return |
| 53.28 | ENB EnableDisplacement=false | Unchanged |
| 60.86 | ENB EnableTessellation=false | Unchanged |
| 74.60 | ENB EnableParallax=false | Unchanged |
| 106.63 | Save and apply ENB settings | Unchanged |

Only turning ENB water processing off resolves the observed issue. Do not repeat these individual toggle tests as the next step. This narrows the issue beyond a simple fix using these geometry/parallax switches; it does not identify the precise failing resource or pass.

The table below uses the first simulation log update (00:53:57.997) as an approximate load reference. User's stopwatch reference may differ, so do not assign exact causality to a reporting interval. All counts are per-report, not cumulative.

| Seconds from first simulation update | Identified | Matched | No matching native draw |
| --- | --- | --- | --- |
| 1.44 | 28 | 28 | 0 |
| 6.77 | 2985 | 2985 | 0 |
| 11.79 | 103171 | 103171 | 0 |
| 16.80 | 117280 | 117280 | 0 |
| 21.82 | 158068 | 158068 | 0 |
| 26.83 | 161224 | 161224 | 0 |
| 31.84 | 154651 | 154651 | 0 |
| 36.86 | 162441 | 162441 | 0 |
| 41.88 | 160078 | 160078 | 0 |
| 46.88 | 157803 | 157583 | 220 |
| 51.89 | 152379 | 152357 | 22 |
| 56.90 | 153883 | 153883 | 0 |
| 61.92 | 153562 | 153336 | 226 |
| 66.94 | 153123 | 152729 | 394 |
| 71.94 | 152202 | 151986 | 216 |
| 76.97 | 153080 | 153080 | 0 |
| 81.98 | 153224 | 153224 | 0 |
| 87.00 | 153932 | 153932 | 0 |
| 95.54 | 73851 | 73851 | 0 |
| 100.56 | 151992 | 151992 | 0 |
| 105.56 | 148426 | 148426 | 0 |
| 110.56 | 153436 | 153436 | 0 |

Late intervals show complete matching despite persistent black water (including after parallax=false and save/apply). Missing matches alone cannot explain the issue. No error or warning entries. Shader compilation succeeds and rendering/upload counters remain active. The old changedAfterDraw probe does not inspect color/depth targets or ordinary shader resources.

Next experiment:0.1.10 public D3D metadata tracing, baseline ENB water off -> on -> off with other three water switches left false. Need log, toggle times and whether disabling water restores normal appearance. No shader files requested. New native pipeline metadata will separate output-layout mismatch, missing/remapped resources and extra forwarded passes as hypotheses; no root cause claimed yet.
