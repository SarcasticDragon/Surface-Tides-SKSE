# Resume 0.1.17: standalone default and explicit experimental integration

## Accepted direction

User accepts returning to the 0.1.6 visual baseline, retaining useful fixes. Next sequence: near-vanilla underwater evaluation, ENB water-OFF coexistence, then CS water-OFF coexistence. ENB integration should be retained as an experiment off by default. The reason for renderer neutrality is avoiding affiliation or taking sides in the ENB/CS community dispute. Public docs should describe optional compatibility and technical status without community-war framing. Neither renderer is a runtime requirement. No subagents. No ENB-origin implementation code. Live settings, dynamic foam and other new simulation features are deferred.

Previous test:0.1.16 did not fix lake ripple clipping or underwater holes. Looking straight up from underwater increases the gaps. Native sampled water raster state already had CULL_NONE; twoSidedDraws 0, so the override did nothing. Cap 16 produced 66 stream-capacity skips (rate-limited reason VS 5000 count 6126) without reported ripple improvement. See REASSESSMENT-0.1.16.md for full evidence and attachment identities. Do not claim this baseline build fixes either visual defect.

## Recovery and comparison

Recovered current source version 28 from libfile_4355a322deb481918f58dfaa7d9c03c5 into recovery-0117/SurfaceTides-source.zip, extracted to project-0117/SurfaceTides. That is the authoritative tree for 0.1.17; recovered/SurfaceTides remains stale 0.1.15 and must not overwrite the saved source. Recovered confirmed 0.1.9 water-OFF installer libfile_15df576f3fd08191a2f8657d0fb52674 into recovery-0117 for byte comparison.

All four standalone shaders (Water.hlsl, SurfaceField.hlsli, Tessellation.hlsli, FrameBuffer.hlsli) match 0.1.9 byte-for-byte. The 0.1.9 checkpoint establishes they and the solver/preset were unchanged from 0.1.6. Current solver, shader and renderer/hook implementations retained; no underwater, ripple, foam, geometry or normal-math edit in this version. We are selecting the existing SurfaceTides-owned shader path, not rewriting it or reverting useful later code.

## Changes

Version 0.1.17 in CMake, plugin metadata/banner, INI and README. Supplied Compatibility.AllowENB=0; standalone only for the first test. Explicit Experimental.ENBWaterIntegration=0 maps to internal config.enbMeshInput. The old Compatibility.ENBMeshInput is no longer read as a switch; its presence logs a migration message. MeshBounds/MeshMotionVectors/MeshTessellationMax/MeshTwoSided now read exclusively from Experimental. Defaults 1/0/8/0. Existing mesh implementation, SO buffer guard, state restoration and diagnostics retained behind the mode gate. No automatic native ENB integration if an old test INI is left installed.

Simulation/Interaction/Rendering values equal the preserved 0.1.9 baseline:192 x 192,spacing 20,speed 210,dispersion 180000,damping.32,wind 5,gust 1,maxHeight 24,terrain mask 1/query 96;48 actors,strength 4,radius 1.5; tessellation 1/max64/spacing 20,normal 2/displacement 2. Config::read fallbacks for missing Wind/TessellationMax/NormalStrength/DisplacementStrength changed from.25/32/1/1 to 5/64/2/2, and Config's three rendering field initializers aligned. Core Settings defaults are unchanged because the numerical library is a separate component.

WaterPassTrace 0/RippleTrace 0, LogStats 1, DebugView 0. Runtime data-load log now identifies actual standalone, ENB-water-OFF SurfaceTides shading or experimental native mesh path. Startup requested integration settings are explicitly labeled requests; this prevents confusing them with renderer selection after compatibility checks. Removed obsolete messaging encouraging live ENB-water-ON tests in SurfaceTides-owned mode; water OFF remains required for that mode.

Later identity/forwarding and validated PS constant repair retained. CS startup rejection retained until its coexistence work; removing the gate alone is not integration. Conservative possible-renderer detection remains unchanged, including leftover enbseries.ini detection. If a supposedly near-vanilla launch is disabled, inspect that log and remove/move leftover ENB config along with renderer binaries for the test. Do not disguise unsupported runtime use with claims of confirmed compatibility.

## Validation plan and user comparison

Portable existing 19 groups; full Windows x64 MSVC-ABI compile/link and exports/imports; baseline shader and INI comparisons. No new shader source or ABI changes, so 0.1.16's 65/65 DXC mesh checks remain historical evidence rather than rerunning them. Native SM5 test executable is rebuilt but cannot execute here; no Skyrim available. No tests mirroring trivial INI edits added.

User should install complete package/INI and test the same near-vanilla underwater views (directly up and forward) plus river/lake wakes. Startup should report SurfaceTides standalone. Preserve displacement/normals values while evaluating. If gaps persist here, the next fix should focus on our water depth/underwater behavior based on that evidence; do not assume the pivot fixed it. ENB water-OFF test follows after this baseline. Experiment still available through AllowENB 1 plus Experimental.ENBWaterIntegration 1, but leave it off for this test.

## Toolchain and persistence

Recovered LLVM tar/libclang were again truncated and compiler --version failed with SIGBUS. Downloaded official 20260826 LLVM-MinGW release to the unique work-tools/st0117-toolchain directory; no reuse of damaged compiler directory. Build path project-0117/SurfaceTides/build/windows, SDK work-tools/sdk, CMake work-tools/python-packages/cmake/data/bin/cmake, Ninja work-tools/python-packages/bin/ninja. No Wine attempts. Dependencies are bundled source; no external git repository.

Save source over version 28 and latest experimental installer over version 16; create a distinct 0.1.17 standalone-baseline installer. Preserve separate 0.1.16 (libfile_2810589ed4dc8191a5b2af80219723b7, DLL cd1218d22c4fa5a90caebc6997d8abdfd4d0dd10d886419fdde2247b4ff346b8) and 0.1.9 (DLL 360c9a775351088640faabf9f125117eec0cf0b56d926ad2458ef04f44576eeb) unchanged. Final validation/hash appended when complete.

Portable test note: the CMake-reported test output was found empty after build, while its object and core archive were intact. Relinked those exact outputs with /usr/bin/c++ to /tmp/st0117-solver-tests and ran it successfully:19/19. This was a host output-file issue, not a source/test change. Windows native test executables must be copied only after checking their actual output files.

## Completed validation

Windows compile/link exit0,391 actions. AMD64/both SKSE exports/system-only imports verified. Native test binaries refreshed after PE/size checks; portable test output repaired from the successfully executed relinked binary. Portable19/19 PASS. Baseline shader/preset equality and retained core/renderer/hooks/mesh code comparisons PASS. Native SM5/Skyrim execution not available; no visual-fix claim.

DLL SHA256: 5239ecd7f403fb73f0377bedfb3cf33bbe23d204962c8303a06836b7de8c857c

The final save batch intends source28->29 and latest16->17, plus new0.1.17 standalone-baseline installer. Use actual save receipts when resuming.

## Subsequent user result and next preset

User confirms the0.1.17 standalone comparison has neither ripple clipping nor underwater gaps in rivers/lakes. Reviewed SurfaceTides(20260911-113149).log. Next authorized task: ENB water-OFF coexistence while user prepares a load-order variant. Existing DLL already contains that path; optional preset changes only AllowENB0->1, keeps experimental integration0. No rebuild required. See COEXISTENCE-0.1.17.md, which supersedes the pending baseline-test status above. Standalone default and separate confirmed installer remain unchanged.
