# Resume SurfaceTides0.1.10: ENB water pass metadata

September10,2026. Current authoritative source: recovered/SurfaceTides. Latest user test of0.1.9 is SurfaceTides(20260910-065603).log. See ENB-TIMED-ISOLATION.md for exact user switches and interval counters. ENB water ON gives black patches even with ENB displacement, tessellation and parallax disabled and settings saved/applied. ENB water OFF remains user-confirmed coexistence with FYX and Water for ENB textures under ENB0.505/Silent Horizons2. Preserve SurfaceTides-0.1.9-ENB-water-off-baseline.zip as rollback; do not overwrite its bytes.

## Evidence and decision

Matching is complete again in late intervals while black patches persist. Missing forwarded draws alone cannot explain the symptom. Solver uploads and water draws continue; no logged shader compilation errors or pipeline incompatibility rejections. Previous postdraw probe only checks retained shader/topology/field bindings, not render-target or ordinary input resource contracts. SurfaceTides replaces pixel shaders too, so textured/displaced success does not prove full ENB shading preservation.

No speculative shader fix yet. Added a separate0.1.10 diagnostic build to observe the native public D3D11 pipeline before SurfaceTides changes it. No ENB implementation, bytecode, resources contents, shader sources or SDK inspected/extracted/copied. No full ENB integration claim.

## Implementation

New src/plugin/PipelineTrace.hpp/.cpp, built into the DLL. Config [Diagnostics] WaterPassTrace defaults false when absent; shipped diagnostic INI sets1, with LogStats1 and AllowENB1. Other settings unchanged. Startup version tuple0.1.10 and log banner identify the build. Startup still requires saved [EFFECT] EnableWater=false. User saved true during last test: explicitly restore false before restarting.

Hooks.cpp creates a sampled trace ID per known game-side WaterPair before forwarding the wrapper draw. Up to32 distinct VS/PS descriptor pairs per thread; one sample per pair every2 seconds. Native interception still forwards identity only on the first exact method/arguments/topology match on the canonical context. Diagnostic sampling does not broaden eligibility. Each sampled scope counts depth-one intercepted native calls (including foreign contexts and later/unmatched passes). First8 calls log their signature, canonical flag, hint consumption, pre-SurfaceTides pipeline state, and whether Renderer::begin changed bindings. End logs total observed call count, match and truncation status. It cannot capture unhooked APIs, reentrant driver calls or asynchronous work outside the scope. Indirect argument contents are not read; signatures for those calls contain no argument-buffer data.

Pipeline metadata: all8 RTV formats/dimensions and texture resource shapes/pointers; DSV and flags; blend/sample/write-mask state; depth/stencil enable/ref/masks; rasterizer flags; all viewports; shader object pointers and class counts (no bytecode); VS/PS constant-buffer byte sizes in all14 API slots; PS SRV slots0..15 formats/dimensions/resource shapes and sampler descriptors0..15. All getters' acquired interfaces are released via ComPtr. No setters, GPU readback, Map or resource creation in tracing. Catch-all diagnostic exception boundaries leave drawing policy alone. Logging is rate-limited but can produce a larger log and some diagnostic overhead. Turn WaterPassTrace0 for long stress tests.

Logs use numeric DXGI format, resource/view dimension, topology and state enums as defined in Microsoft SDK headers. Null blend/depth/rasterizer pointers indicate API defaults; don't interpret them as absent rendering. Non-null resources don't prove correct content. Sampling can miss rare passes, descriptors beyond the32-pair cap, or different geometries sharing a shader pair. Lack of a recorded resource mismatch is not proof of compatibility.

Public reference semantics verified from Microsoft OMGetRenderTargets and PSGetShaderResources documentation:
https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-omgetrendertargets
https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-psgetshaderresources

## Validation

Windows x64 MSVC-ABI build PASS (LLVMclang-cl23.1, same SDK/toolchain as0.1.9). New tracing code and updated hooks compiled/linked. One initial member-name typo (args instead of arguments) corrected before successful final build. Final log /tmp/st0110-build-final.txt. AMD64 and both SKSEPlugin_Load / SKSEPlugin_Version exports verified; only Windows system DLL imports. Binary inspection refreshed; included Windows solver and shader executables refreshed, not executed here. Solver, HLSL, renderer and portable tests byte-compared to0.1.9 source and unchanged; previous16/16 portable result applies, not a new D3D runtime test. No Skyrim/ENB runtime available here.

DLL SHA256: 6401a29f043056fc5877b88f3b94f9b64a3d4417c1c20ef9417969e57b8963b3

## Next user test

Install DLL and supplied INI together. Restore saved ENB EnableWater=false before game startup so the current startup guard installs hooks. Leave ENB displacement/tessellation/parallax false. At the problem location, wait15sec with ENB water OFF, enable water live for20sec, then disable for10sec and quit. Send log and approximate toggle times plus whether the final OFF step restores normal water. No further individual feature-toggle sweep, shader files or GPU capture requested.

Compare Water trace begin/native/outputs/inputs/result/end records across OFF/ON/OFF: shader pointer/layout changes, render-target count/format and write masks, missing/rebound reflection/refraction/depth slots, constant buffer sizes, and extra native pass order. Follow the evidence before attempting pixel shader preservation or changing first-match policy. An auxiliary pass can require a different output contract; never inject our color shader into arbitrary extra passes merely because they occur inside a water call. Keep0.1.9 baseline and user-approved simulation untouched during integration work.

## Follow-up received

The diagnostic trace is now analyzed. It shows a reversible native PS constant-slot shift for31E, with one native call in all129 samples. See ENB-CONSTANT-SHIFT-EVIDENCE.md and RESUME-0.1.11.md for the compiled candidate. Do not repeat0.1.10 tracing by default;0.1.11 has compact repair counters.
