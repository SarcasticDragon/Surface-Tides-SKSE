# Resume — 0.1.24.3 jump release

Latest user: 0.1.24.2 leaves very occasional drift, accepted for now, but jumps often animate without significant height. User explicitly agrees to mark Ice is Slick incompatible with bobbing for now. Defer its integration and do not ask for its source again. Current focus is jump takeoff; no CS/full ENB integration, foam or rendering changes.

Input `SurfaceTides(20260915-114751).log`: 87836 bytes, SHA256 `87416ff92f2a04adaca676ee23368144251e68ba085f3131f16aa7698524453a`. AE1.6.1170, 0.1.24.2, bobbing enabled, ENB water off. Twelve rider summaries all record velocityRepairs=0, invalidPostVelocity=0, maxVelocityChange=0. Carry offsets reach 169/interval, maximum offset2.005304 game units. No warnings/errors. The log does not report input/pending jump state, so it excludes actual velocity replay in this run but does not prove what suppresses takeoff.

## Implementation

`FloeRiderTakeoff` in the existing portable FloeRider.hpp pauses carry on a jump request or pending/current jumping state. Minimum release0.25s, landing confirmation0.10s, tolerates a contact gap up to0.15s in landing history. Unsupported frames never carry. Ordinary non-jump support loss does not latch a release: the log suggests contact can flicker during bobbing. A first0.10s gap tolerance failed the rejected-jump test sampled0.11s apart; final0.15s tolerance and longer-gap case pass. This is timing policy, not an engine-state guarantee.

Floes.cpp uses 49 bounded per-actor gates (maxRiders+1), actor handles and controller/support pointer identity only. Slots are reclaimed if unused/stale over2s; a full array refuses carry rather than evicting an active gate. Controller change resets the gate; managed support change resets landing history. Player jump request time is an atomic steady-clock timestamp, accepted for0.25s. Reset clears all gates/request state. Eligibility is checked during the once-per-frame rider snapshot and again before applying carry, including the same support-body check. Current ground state, requested ground state, actor airborne/swimming flags and managed support all gate carry. Actual jumping latches from wantState/currentState kJumping or CHARACTER_FLAGS::kJumping; do not broaden this to every airborne/contact-loss frame.

Hooks.cpp adds an opt-in observer at JumpHandler ProcessButton slot0x4. Signature and slot match the bundled CommonLib headers. New press calls noteFloeJumpRequest; the original handler is always forwarded exactly once with the original pointers. Input is not mutated or consumed, and jump velocity is not manufactured. Existing hook patch registry/rollback covers the new slot. No observer is installed when config.floeBobbing is false. Water hooks are unchanged after normalizing just this observer and its installation block.

Existing live additive controller offsets, double-precision local carry delta and conditional velocity repair are retained. The five-second rider summary adds takeoffReleases, landingResumes, takeoffSkips. Skips count checks, not frames. Startup logs observer installation and takeoff policy. The menu and sample INI document the Ice is Slick incompatibility; no setting/dependency is added, and no automatic module block is imposed.

## Verification and remaining gate

Version tuple {0,1,24,3}; banner `SurfaceTides 0.1.24.3 development (floe jump release)`. DLL1561088 bytes, SHA256 `e8bd3e9f062e99c37e9bc1e4e9c8a8432879cfb415214163a66e8a690826274b`. Existing AE runtime gates retained. Build completed with existing vendor/compiler warnings. All45 portable groups pass (22solver/23floe). Two added groups cover early release/landing and preservation of jump impulse with stale support and no position/velocity-set calls during takeoff. No Skyrim execution occurred.

`tools/validate_floe_riders.py` compares exact0.1.24.2 source, checks changed-file scope and unchanged collision/acquisition/crest/discovery/update/restore functions, emits source diff and compiled observer/carry evidence, checks AMD64 exports and historical global TES iterator crash negative controls. Carry vtable slots remain0x10/0x30/0x18/0x30/conditional0x38; no actor-position call. Evidence in `docs/floe-0.1.24.3-evidence` and build-validation JSON. Allfiveacceptedshaders are byte-identical to0.1.19.2, verified by packaging.

Next gate is user stationary/running jumps on rising/falling ice, followed by landing/standing/walking. Do not call it fixed before that test. If failed, inspect observer installation and release/resume counts before changing behavior. Rare residual drift remains acknowledged. Ice is Slick testing/source research is deferred, superseding the prior resume document's request.

## Reproduce and recover

Workspace `/workspace/scratch/96cfc0bcb1b2`; source `project-restored20/SurfaceTides`; Windows build `build-topology-01192-final`; portable build `work/ice-inspection/portable`; tools under `work-tools/python-packages/cmake/data/bin`. Incremental build/test logs in `work/ice-riders-01243`. Validator takes `--workspace /workspace/scratch/96cfc0bcb1b2`. Package with `tools/package_floes.py --dll <workspace>/build-topology-01192-final/SurfaceTides.dll --output-dir <workspace>/deliverables-riders-01243`.

Installer `SurfaceTides-0.1.24.3-jump-release.zip`: DLL, unchanged five shaders, readme/license/manifest; noINI/NIF/DDS/ESP. Source archive embeds this installer plus all earlier exact recoveries. Immediate comparison0.1.24.2 installer SHA256 `c7ef664d383eabcf42f5adc43d4f6b68a89567e32c66744407c8a2b73025b4e3`; source SHA256 `d0d03d5cf582021ff4332d9b9badf5704dbbdb5939d5688cb5bcb38d4aef0202` in deliverables-riders-01242. 0.1.24/0.1.23 have the old movement-blocking carry path; use only as visual baselines. Original0.1.20 is withdrawn for CTD; accepted0.1.20.1/0.1.19.2 fixes remain intact.

Source identity `libfile_7c418cf884848191814e878db1ad4791`, concrete version16 before this replacement. Save with expected version16, retain actual receipt version. Installer is a new file. Do not overwrite local work with an older source archive. Preserve renderer neutrality and the user's expert testing workflow.
