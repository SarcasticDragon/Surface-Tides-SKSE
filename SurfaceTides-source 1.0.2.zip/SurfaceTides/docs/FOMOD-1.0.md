# Editing the Surface Tides FOMOD

The current ready-to-install file is `SurfaceTides-1.0.2-FOMOD.zip`. Import that ZIP through your mod manager and its installation wizard should open. You do not need to install a FOMOD-building application to use or edit this package.

A FOMOD is a normal archive with XML instructions in a folder named `fomod`. The mod manager reads those instructions, displays choices and copies selected files into Skyrim's Data directory. A `<plugin>` in this XML means an installer option; it does not mean an ESP.

## Where to start

Extract a copy of the installer ZIP and open `fomod/ModuleConfig.xml` in a text editor. This is the file to inspect first. The editable generated XML is also in `installer/fomod/` in the source archive.

| Location inside the installer | What it does |
| --- | --- |
| `fomod/info.xml` | Display name, author, version and package description. No invented Nexus ID or website is included. |
| `fomod/ModuleConfig.xml` | Pages, groups, option descriptions, flags and file-selection rules. |
| `core/` | DLL, five water shaders, user readme and third-party notices; always installed. The `core/` prefix is removed at installation. |
| `options/config/` | 24 complete INIs covering renderer, attached-foam, ice-decal and bobbing choices. Exactly one is installed as `SKSE/Plugins/SurfaceTides.ini`. |
| `options/foam/` | The optional standalone BOS preset, installed at the Data root. |
| `options/cs/` | The optional CS override, installed only for the CS renderer choice. |

For simple wording changes, edit the option's `name` and `<description>` text. Keep the technical flag names/values and file paths intact. Use `&amp;` for an ampersand in XML text. Zip the contents again with `fomod/` directly at the archive root, alongside `core/` and `options/`; do not add an extra containing directory.

For permanent changes in the source project, edit the option tables and descriptions in `tools/build_fomod.py`. That script regenerates the XML, so editing only the generated XML will not survive another generator run. The base tuning values come from `Data/SKSE/Plugins/SurfaceTides.ini`.

## Adding option preview images

Use actual in-game screenshots, ideally the same camera/weather with the feature off and on. For example, a 1280x720 PNG is a useful starting size, not a format requirement. A single side-by-side before/after image also works. Keep important details large enough to see in the manager's preview panel.

For manual ZIP editing, extract the installer and create `fomod/images/`. Put your PNGs there, then open `fomod/ModuleConfig.xml`. Find the relevant `<plugin name="...">` and insert the image immediately after its closing `</description>` tag, before `<conditionFlags>`. For example:

```xml
<image path="fomod/images/foam-all-removed.png" />
```

Use that line inside `Remove both (BOS)`. Inside `Remove ice decals`, use:

```xml
<image path="fomod/images/ice-decals-removed.png" />
```

Paths are relative to the archive root, not to ModuleConfig.xml. Preserve the existing flags and type descriptor. Preview images need no `<files>` entry: they belong to the installer and should not be copied into Skyrim's Data directory. Save XML as UTF-8, retaining the **double-quoted** encoding declaration. Rezip with `fomod/`, `core/` and `options/` directly at the archive root.

For repeatable source builds, the generator now automatically attaches these PNGs when placed in `installer/fomod/images/`:

| Option | PNG filename |
| --- | --- |
| Keep all foam | `foam-kept.png` |
| Remove attached foam only | `foam-attached-removed.png` |
| Remove standalone foam only (BOS) | `foam-standalone-removed.png` |
| Remove both (BOS) | `foam-all-removed.png` |
| Keep ice decals | `ice-decals-kept.png` |
| Remove ice decals | `ice-decals-removed.png` |

Missing images are simply omitted; no placeholder or broken image link is created. Use a new staging directory after removing preview files. The validator checks image paths and PNG signatures; visually check the wizard in the mod manager. No screenshots are supplied by this revision.

## How the choices work

There are three pages: requirements/configuration, renderer, and surface objects. The renderer and each surface-object group use `SelectExactlyOne`. Every option sets named flags. After the choices are made, `conditionalFileInstalls` evaluates those flags and selects the matching files.

The standard XML installer copies complete files; this package does not run a script to edit individual keys in the user's existing INI. Supplying separate tiny INIs for each checkbox would overwrite settings from another choice. Instead, the generator produces a complete INI for each relevant combination. There are24 unique INIs and48 total choice combinations because standalone BOS removal does not change the INI.

Only one renderer can be selected. This prevents enabling both AllowENB and AllowCS. Every combination leaves experimental ENB water integration off. The optional standalone foam choices state the BOS requirement; attached foam and ice filtering do not require BOS. Waterfall impact effects remain excluded from the preset.

Defaults follow the prior opt-in policy: standalone rendering, keep foam, keep ice decals, static ice. You can change which option is marked Recommended in the generator. Dependency DLLs are not bundled or automatically installed. Runtime selection is manual, since a FOMOD file check cannot reliably establish all supported SKSE/renderer versions across mod managers.

## Rebuild and validate

From the project directory, with a compiled1.0 DLL:

```bash
python tools/build_fomod.py --dll /absolute/path/SurfaceTides.dll --stage /absolute/path/fomod-stage
python tools/validate_fomod.py --stage /absolute/path/fomod-stage --output /absolute/path/fomod-validation.json
```

The builder uses Python's standard library. The validator additionally needs `lxml`. It checks the official5.0 schema, every referenced file, all48 option combinations, one INI per installation, INI values, conditional BOS/CS files and required notices. The schema is retained at `tools/fomod/ModConfig5.0.xsd` for offline validation. `tools/package_release.py` validates and packages the completed staging tree and full source checkpoint.

Before publication, import the ZIP in your mod manager and click through the wizard. Check at least the default route, ENB with removals enabled, and CS with removals/bobbing enabled. Inspect the installed INI and optional-file presence. Reinstall while changing choices to confirm the manager removes deselected files; use replacement rather than merging old overlays. Automated XML/file validation does not exercise MO2 or Vortex's actual UI.

Keep your stress-test profile's customized INI separately before testing this installer. That preserves a useful comparison against the accepted0.1.25 build.

The [FOMOD5 tutorial](https://fomod-docs.readthedocs.io/en/latest/tutorial.html) explains the same flags and conditional-install structure, and the [official generic5.0 schema](https://qconsulting.ca/gemm/ModConfig5.0.xsd) defines the accepted XML. This package uses standard XML features and no executable installer script.
