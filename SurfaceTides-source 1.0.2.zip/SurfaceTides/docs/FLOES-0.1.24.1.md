# Surface Tides 0.1.24.1 — rider locomotion hotfix

The user reports that all three floe models look good in 0.1.24, but walking stops while the ice bobs, with the movement animation continuing. The supplied log confirms six active floes (one solid01, two ice01, three solid02), no blocked references or warnings, and low collision errors. It also records repeated rider carry operations.

The previous carry path called `Actor::SetPosition(..., true)` every update. That replaces the controller position from the actor reference and can disrupt normal locomotion. The log cannot expose the engine's internal movement state, but this call is the leading suspect and is removed in this hotfix.

Carry now adds only the floe's translation/tilt delta to the character controller's live position through its non-warping position API. It preserves the controller's linear velocity and leaves normal actor position synchronization to Skyrim. The actor reference position locates the foot point for calculating the small tilt displacement; it is never used as the controller destination. Grounded support-body selection and airborne/swimming exclusions remain. No actor yaw, input/state flags or raw physics fields are overwritten.

## Install and test

Install `SurfaceTides-0.1.24.1-rider-locomotion.zip` after 0.1.24 and restart. No INI changes are required. Existing bobbing opt-in, all three models, live controls, slush removal and water shaders remain as before. The package contains no INI or replacement meshes/textures.

Walk, run and jump on the moving floes; also stand still briefly to check that the ice still carries you, then step between neighbouring floes. Please return the new log if walking remains blocked or standing riders begin slipping. Startup identifies version 0.1.24.1 and the additive controller carry path. Existing `carried` counts now measure successful controller offsets.

## Validation and limits

The Windows AMD64 DLL builds with both SKSE exports. All 41 portable groups pass (22 solver, 19 floe). The new regression advances walking independently of platform movement over 120 updates, simulates a setter that clears velocity, and verifies that walking, vertical carry, native units and velocity survive. Additional checks reject invalid, excessive and zero offsets without mutations. These are portable adapter tests; they do not execute Skyrim's controller implementation.

Compiled rider code calls the controller position/velocity methods and no actor reposition method. Discovery guards retain the accepted cell-local scan and spatial-water query. Source comparison confirms that floe acquisition, sampling/scheduling, crest math, collision/restore handling, foam/slush selection, renderer, solver, hooks and accepted shaders are unchanged apart from routing the existing two rider-carry sites to the new adapter. In-game locomotion remains pending confirmation.

DLL: 1,549,312 bytes; SHA256 `00adcfa4a187f2c972daaa2488cdd0ecd621b8c707bd06917e4d3b6ee6411173`.

The source archive retains 0.1.24 for exact comparison (known locomotion issue) and the earlier 0.1.23 selected-floe baseline. Both old versions contain the previous carry method. If necessary, disabling bobbing and restarting avoids that rider path while preserving the water simulation. Disconnected chunks within one mesh still move as one object; this accepted initial-release limitation is unchanged.
