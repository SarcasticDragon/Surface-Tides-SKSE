# Resume — 0.1.24.1 rider locomotion candidate

## Latest user result

0.1.24 all three ice profiles visually work. Walking animation plays but the character cannot translate while bobbing. Input log `SurfaceTides(20260915-104941).log`, 133488 bytes, SHA256 `a22645caa621a5ae9d70492f83ee086e7d6d4898341987003768148ebf50f11f`. Runtime AE 1.6.1170; ENB water OFF and experimental integration false. 28 floe summaries: six active objects with profile counts (1,2,3), blocked=0, maximum collision error 0.1553 game units / rotation 0.046 degrees, riders 0/1, up to 192 carry operations per reporting interval, no warnings. The three-model physics adapters acquire, including the two bhkRigidBodyT models. Broad stress/streaming testing is still ongoing.

## Change

Old `carry()` in Floes.cpp mapped the actor's reference position through the floe delta then called Actor::SetPosition(next,true) every update. Suspected mechanism: full reposition disrupts controller locomotion and/or overwrites controller advancement with a lagging reference position. Exact proprietary engine side effect is not proven by this log.

New `RiderController` adapter reads live controller position with GetPositionImpl(false), adds the floe delta in native units, and uses SetPositionImpl(false,false), with matching center-offset convention and forceWarp=false. Preserve GetLinearVelocityImpl result with SetLinearVelocityImpl after reposition. No Actor::SetPosition even with false, no SetAngle, no state/flag/contact overrides, no raw proxy cast, and no hardcoded Havok scale. The existing per-entry validated inverse scale converts game-unit delta. A NiPointer keeps the controller alive across calls. Engine-owned actor/reference synchronization remains with Skyrim.

The actual shared portable helper is `include/surfacetides/FloeRider.hpp`. It bounds travel to 128 game units, validates scale/position/velocity/offsets, preserves float4 W, skips zero or unrepresentable offsets, and offsets the current controller position. `actor->GetPosition()` is used only as the point to evaluate the floe's tilt delta, never as the new absolute controller position. Both ordinary movement and owned restoration call the same helper. Grounded snapshot/routing, jump/swim exclusion, collision bookkeeping, mesh acquisition and scheduler are unchanged.

Bundled CommonLib headers establish the APIs. Previously downloaded public Bobbing Framework source was also inspected as a usage reference, but its implementation is not copied, linked or required. No ENB code was used. Web search provided no additional authoritative engine implementation; do not cite search landing pages as evidence.

## Validation and exact build

All 41 portable test groups pass, including two new rider groups. A controller test double integrates walking while bobbing for 120 frames and deliberately clears velocity in the position setter; the shared helper preserves total walking travel, platform offset, native scale/W, rollback deltas and velocity. Invalid/zero/oversized offsets cannot mutate state. This establishes helper behavior, not Skyrim runtime success.

`tools/validate_floe_riders.py --workspace /workspace/scratch/96cfc0bcb1b2` reruns the binary/source verification using already completed CTest evidence. The carry disassembly has controller virtual slots 0x10/0x30/0x18/0x38 (GetPosition/GetVelocity/SetPosition/SetVelocity); setter bool registers R8/R9 are zero. No actor reposition call remains. Foam and Floes object dependency guards still reject the old crashing global TES reference scan with the 0.1.20 negative control. Source comparison against exact 0.1.24 archive confirms only the carry block/include/two call-site scale arguments change in Floes.cpp; core solver, crest math, renderer, hooks, assets, vendor code, Game.cpp and configuration semantics are unchanged.

Windows build succeeds; AMD64 DLL exports SKSEPlugin_Load and SKSEPlugin_Version. Version tuple {0,1,24,1}. DLL 1549312 bytes, SHA256 `00adcfa4a187f2c972daaa2488cdd0ecd621b8c707bd06917e4d3b6ee6411173`. See `floe-0.1.24.1-build-validation.json` and `floe-0.1.24.1-evidence/`. Existing vendor warnings remain. No extra optional tests are needed before delivery.

Next user gate: walking/running/jumping on bobbing ice, standing support, crossing adjacent references, and normal collision behavior. If still blocked, measure current controller and reference movement plus requested/observed velocity around the setter; do not claim the exact engine cause is established or revert to Actor::SetPosition. Do not mask locomotion failure by permanently disabling carry without checking standing/rider behavior.

## Delivery and continuity

Same workspace/tree/build paths as RESUME-0.1.24.md. Work logs in `work/ice-riders-01241`. Delivery folder `deliverables-riders-01241`; installer `SurfaceTides-0.1.24.1-rider-locomotion.zip`; source `SurfaceTides-source-menu.zip`. Package script validates DLL/shaders/rollbacks and embeds the new installer under recovery before archiving sources. No INI changes or new settings. No game NIF/texture assets distributed.

Source Library identity remains `libfile_7c418cf884848191814e878db1ad4791`; concrete version before this replacement is 14. Replace with expected version 14 and use the returned version for future work. Do not overwrite completed local sources with an older materialization.

Exact 0.1.24 comparison installer SHA256 `08f728a06543bebd4f7bff41bdd248e59d83b7f13c05dfb412563fb185587c2f`; its full source SHA256 `d806b41714be99231d57105cf93fae9ea4258e802c424145e4e30c8bc0714b62`. Keep that installer for comparison but mark walking as defective. 0.1.23 is the accepted selected-floe visual baseline but contains the same old rider method. All older rollback rules remain: original 0.1.20 withdrawn for crash, accepted 0.1.20.1 foam fix and 0.1.19.2 shader/render fix retained. No new ENB/CS work; neutral coexistence remains the goal.
