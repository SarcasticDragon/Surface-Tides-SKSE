# Wading surface isolation — 2026-09-13

## Returned result — suppression withdrawn

The next user test caused severe repeated-image smearing after walking. This experiment is complete and must not be used as a fix. Restore full r4 rendering. See NATIVE-WATER-TRACE.md for the replacement diagnostic and qualified interpretation. The remaining text records the prior experiment.

## Prior result and interpretation

The original shoreline fragments persist with SurfaceTides Interaction.Strength=0. The user supplies a new sequence: camera pitch alone initially looks clean; after walking back and forth, camera pitch alone exposes artifacts. This supersedes the earlier inference that camera-only movement cannot reproduce the problem. Walking appears to establish a condition that survives stopping; the clip does not identify that condition.

The active comparison is SurfaceTides0.1.17 shoreline-r4 (not0.1.7), Water for ENB2.19 / Shades of Skyrim /4K, near-vanilla with ENB removed, native TAA off, DebugView0, NormalStrength2 and DisplacementStrength2. Actor forces are zero for this control; ambient wind5/gust1 remains. RW2 was clean at the user's tested location and Wavy Waters affected less severely. Original Water for ENB environment is restored. No shared asset defect or universal compatibility result is established.

Native ripple normal isolation was negative: flat native ripples disappeared, original fragments did not. Extra-light-pass isolation was also negative. Suppressing an input to a draw does not suppress the draw itself. Do not repeat those controls, the no-displacement/native-water controls, TAA test, r1/r3/r4 optical changes or the already returned Strength0 test.

## New diagnostic

SurfaceTides-0.1.17-wading-surface-diagnostic.zip suppresses above-water WADING pixel fragments, including their additional-light variants. It is a temporary experiment, not a fix. Install last over r4; Shaders/SurfaceTides/Water.hlsl must win. Keep other diagnostic overlays disabled. Leave Interaction.Strength=0, DisplacementStrength=2, NormalStrength=2 and DebugView=0. Restart and repeat the same look–walk–look sequence from the same saved location. Return the clip and normal log, noting whether original artifacts remain and whether any water coverage disappears.

SurfaceTides idle displacement and the moving simulation grid remain active. The ordinary non-WADING base-water shaders remain r4. Native flat ripple shading may be absent. If water holes appear, record them: this indicates these draws supply necessary coverage at that location; it does not justify disabling them permanently. Deactivate the overlay, restore r4 and Interaction.Strength=4, then restart after the test.

If the artifact disappears without missing water, the visible wading draws and their interaction with other water passes become a much stronger lead. Overlapping meshes with different triangle sampling of a displaced heightfield could disagree in depth, but the current evidence does not prove that is happening. If holes replace the affected region, lack of artifacts there is inconclusive; capture topology/bounds/state next. If the artifact remains, retained stencil/motion work, later image-space processing and grid/mask state remain candidates. Do not treat this as disabling the entire native wading subsystem.

## Evidence examined

Local attachment SurfaceTides(20260913-035508).log: libfile_992f656e9850819189601a109380b93b / file_00000000d06481fda88f00099a703f17. It records Interaction strength0 and impulsesSinceReport0 in every simulation report. It records227,592 bound/tessellated water draws, failed0/incompatible0; native context equality; no ENB module/local proxy; no constant repairs or changed-after-draw detections; no numerical clipping/dropped solver seconds. Compiled pairs are5000,11E,802,15E,842. WADING variants15E/842 remain active despite actor-force suppression.

The field origin changes while walking, then stays constant across long sampled intervals. Samples are five seconds apart, with larger gaps of unknown cause, so no exact mapping to the attached clip or claim of a particular grid transition causing an artifact is justified. Stable origin does not prove stable native rendering or rule out an earlier persistent change. The log does not contain a shader-file hash, per-draw mesh correspondence, blend/depth states or GPU timings.

Local attachment Sequence #1(22).mp4: libfile_0dab681a98688191b2eba127b71e6b84 / file_00000000d47881fd8eed6c1a532ddd49,12.516667seconds,2560x1440/60FPS. Inspected a one-second-spaced contact sheet, alongside the user's stated temporal sequence. Do not claim measured pixel tracking or precise alignment to wall-clock log entries.

Source inspection: Game.cpp recentering follows the player, and Interaction.Strength0 clears actor impulse output; it does not disable Skyrim's own wading behavior. Vendored CommonLibSSE headers expose TESWaterDisplacement::displacementGeometry, TESWaterObject::waterRippleObject and TESWaterSystem::wadingWaterData. These structures support investigating separate native water surfaces but do not establish how meshes overlap in this captured scene. No game/ENB bytecode, private shader contents, SDK or replacer assets were inspected.

## Implementation and validation

Water.hlsl adds ST_DIAGNOSTIC_SKIP_WADING_SURFACES, default0. At1, SPECULAR+WADING pixel main executes clip(-1) and returns zero; all other shader paths retain their previous code. There is no draw-hook, topology, vertex/hull/domain, actor, terrain-mask or solver change. Discarded fragments do not contribute ordinary color/depth output; their separate native stencil/motion passes are deliberately retained and remain byte-identical. Do not describe all scene depth/stencil effects as unchanged or claim geometry was removed from the engine.

The packaged macro configuration is r4: ST_SHORE_REFRACTION1, ST_DISPLACED_DEPTH_BLEND1, ST_SHORE_CONTACT_BLEND1, ST_DIAGNOSTIC_NO_SSR0. ST_DIAGNOSTIC_NO_NATIVE_RIPPLES remains0; no light-pass suppression. The only new diagnostic is ST_DIAGNOSTIC_SKIP_WADING_SURFACES1. Default source retains both diagnostic switches at0 and depth/contact candidates at0. No DLL, INI, NIF, DDS or external mod assets in the overlay. Version in logs stays0.1.17.

tools/validate_wading_surface_isolation.py passed660/660 host DXC SM6 compilations (33 descriptors,5 stages,4 configurations). All165 default outputs match the previous source defaults. All geometry, underwater, LOD, stencil and non-WADING pixel outputs match r4 byte-for-byte. Eight above-water WADING PS variants contain unconditional discard and no texture/engine/simulation buffer reads. Other PS resource tables match. See wading-surface-shader-validation.txt. No native Windows SM5 execution or in-game confirmation, DLL rebuild, or repeated solver tests; solver code is unchanged.

The runtime supports shaders with no active PS constant spans (same pattern exercised by the earlier light-pass diagnostic). Runtime activation still requires user verification; compiled/bound counts alone do not fingerprint the winning Water.hlsl.

## Continuity and preservation

Working tree: project-restored20/SurfaceTides, restored from user-supplied pre-light source archive SHA2561499bffb625b1423a03cf5ac03a565e5ea5b818bf55896f9c39b216f5f1ffd7e. The prior native-ripple source checkpoint SHA2562af3c12074c275c553d327fe6b4dd328f42c08e5037b8f944accb3afb26774d0 remains intact as SurfaceTides-source-native-ripple-diagnostic.zip. Follow-up returned-result documents existed locally and are included in this new source package. See NATIVE-RIPPLE-ISOLATION.md for historical Library identities and earlier tests.

New source deliverable: SurfaceTides-source-wading-surface-diagnostic.zip. Preserve previous installers/diagnostics rather than replacing them. Library transfer tools remain unavailable this session; local delivery is not a persistent save. Ask the user to retain the source ZIP; do not invent a successful receipt or version. No subagents used.

Renderer-neutral policy remains: standalone and ENB master-water-OFF coexistence confirmed in prior user testing, full native ENB integration experimental/off, CS coexistence pending/gated. No affiliation or renderer preference is implied by this investigation.
