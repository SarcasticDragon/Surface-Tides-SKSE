# Surface Tides 0.1.24.2 — rider drift candidate

The user confirms that 0.1.24.1 improves locomotion, but sometimes leaves a short slide after stopping. This occurs without Ice is Slick. Adding Ice is Slick makes movement blocking return. The latest log still shows six active floes across all three profiles, no rejected bodies or warnings, and low collision tracking errors; it does not record the controller's before/after velocity and cannot establish the remaining movement mechanism.

## Changes

- The floe's carry delta is evaluated near the floe in double precision. The old float calculation formed and subtracted full world positions, which can lose small displacement components at Sea of Ghosts coordinates. Pure vertical movement now produces exactly zero lateral carry in the portable regression, while real tilt still carries riders sideways as appropriate.
- Carry reads velocity again after its non-warping position update. If XYZ velocity survives unchanged within a tiny numerical tolerance, Surface Tides makes no velocity-set call. If the setter actually changes or invalidates velocity, the earlier locomotion repair still restores the just-observed incoming value. W metadata alone does not trigger repair. There is no artificial braking, stationary-position lock, input override or zeroing of horizontal speed.
- A five-second `Floes riders:` summary records offsets, actual velocity repairs, invalid post-update velocity, maximum offset and maximum observed velocity change. This distinguishes unnecessary velocity reapplication from a setter that really changes velocity. It does not log every frame.

All three models, crest response, collision movement/restoration, rider support selection, discovery/scheduling, settings and water shaders retain their previous behavior. No new settings or dependencies.

## Install and compare

Install `SurfaceTides-0.1.24.2-rider-drift.zip` after 0.1.24.1 and restart. Your INI is preserved. For the first comparison, leave Ice is Slick off and repeat walking, stopping, standing still and jumping on the bobbing floes. Return the log if any sliding or movement blocking remains. The new velocity-repair counts matter even when the visuals are unchanged.

Ice is Slick remains a reported conflict with floe bobbing, not a claimed compatibility fix in this build. The author documents moving-ice support and per-object exclusions, so a permanent incompatibility conclusion would be premature. Its desktop source archive is available under Miscellaneous Files on the [Nexus Files tab](https://www.nexusmods.com/skyrimspecialedition/mods/190881?tab=files). The archive could not be retrieved through the available public page in this session. The source matching the user's installed version is the next useful input for inspecting the interaction. No Ice is Slick code was copied, modified or bundled.

The author's documented “Ignore this object type” custom-surface rule may provide a later workaround by excluding the three floe types from its sliding, but that workaround has not been tested with Surface Tides. See the [author's description](https://www.nexusmods.com/skyrimspecialedition/mods/190881). Do not automatically change another mod's configuration or mark all of Ice is Slick incompatible with the water simulation.

## Validation and limits

Windows AMD64 DLL compilation, exports and compiled dependency checks pass. All 43 portable groups pass (22 solver, 21 floe). New tests cover native acceleration/braking without redundant velocity writes, metadata-only changes, actual velocity loss repair, no lateral movement from pure heave, exact zero carry for stationary tilted objects and precision independent of a large world-origin offset. Tests exercise the shared carry helper, not Skyrim's proprietary controller implementation.

Binary inspection confirms controller GetPosition/GetVelocity/SetPosition/GetVelocity and a conditional SetVelocity call. Both position booleans remain false; no Actor::SetPosition call returns. The source guard confirms no change to floe acquisition, collision, crest motion, scheduler or restoration apart from carry arithmetic and bounded diagnostics. The five accepted water shaders remain identical.

DLL: 1,553,408 bytes; SHA256 `6fc48e0a7f2327752cdadfe78580ae16a0e9a02639c9e387251fa9a7a71dcfe5`.

Drift reduction and Ice is Slick coexistence are not runtime verified. The exact 0.1.24.1 installer remains in the source archive for comparison; it has the reported residual sliding. Earlier 0.1.24/0.1.23 packages retain the old movement-blocking carry path and are visual baselines, not locomotion fixes. Restart when changing DLLs. Existing mesh-chunk and ENB-preset findings are unchanged.
