# Surface Tides 0.1.19 — in-game tuning

This update adds an optional settings page using SkyrimThiago's SKSE Menu Framework 3.x. The user-confirmed 0.1.18 shoreline correction shader is included byte-for-byte; water rendering, the ENB water-off coexistence policy, and runtime version gates are preserved. Community Shaders coexistence is still pending.

## Install

Install **SurfaceTides-0.1.19-menu-update.zip** after your existing Surface Tides installation and all previous test overlays, allowing its DLL and shaders to win conflicts. Restart once for the new DLL. This is an update archive: it deliberately excludes the active INI so your tuned values and AllowENB setting survive. No ESP, Papyrus scripts, or framework binary is included.

Install the official [SKSE Menu Framework](https://www.nexusmods.com/skyrimspecialedition/mods/120352) 3.x and its listed requirements separately (current Nexus version checked 2026-09-13: 3.14.1). Surface Tides still runs without it. Open the Mod Control Panel using the framework's configured key (default F1), then **Surface Tides / Settings**. For a live view with the menu open, use **Options / Resume Game**; otherwise close the menu after adjusting. Surface Tides does not change global pause/input preferences.

Keep ENB master water OFF when using the confirmed coexistence configuration. Full ENB water integration remains experimental/off by default.

## Controls

| Apply behavior | Settings |
|---|---|
| Live; current waves preserved | Wind, GustStrength, WaveSpeed, Dispersion, Damping, MaxHeight, Interaction.Strength, RadiusScale, MaxActors, NormalStrength, DisplacementStrength, TessellationSpacing, TessellationMax, TerrainQueriesPerUpdate, DebugView |
| Apply grid; resets local waves, no restart | Resolution, Spacing, TerrainMask |
| Session only | Preview Surface Tides toggle; Reset local waves |
| Read-only display; edit INI and restart | General.Enabled, Rendering.Tessellation, Compatibility.AllowENB/RestoreWaterConstants, all Experimental options, Diagnostics.LogStats/WaterPassTrace/RippleTrace |

Values respect the existing solver/render limits. Distances and height are Skyrim world units. Hover controls for descriptions. Sliders support the framework's normal keyboard entry behavior. Extreme resolution, fine spacing, high wave speed/dispersion, and dense tessellation can be costly; the grid panel shows the solver's required fixed-step rate.

- **Save tuning to INI** persists live tuning and the last applied grid, preserving startup/compatibility values and unrelated settings. Unsaved grid edits and the session preview toggle are excluded. An adjacent temporary file is written before replacing the INI; failures are reported in the panel and log. With a mod manager, the resulting file follows its virtual-file/overwrite rules.
- **Reload tuning from INI** reads only live tuning for this session. Changed startup flags still require a restart. Invalid numeric values leave the previous live settings intact.
- **Restore session-start tuning** returns to the values read when Skyrim launched; it does not write the file until Save is selected.
- **Reset local waves** clears waves on the next unpaused simulation update; no savegame data is written.
- **Preview Surface Tides** allows a temporary native-water comparison. Re-enabling starts a fresh local simulation once gameplay updates resume. It cannot override startup or compatibility rejection.

For the accepted full-wake baseline, the previous intended defaults are Wind=5, GustStrength=1, Interaction.Strength=4, RadiusScale=1.5, NormalStrength=2, DisplacementStrength=2, DebugView=0, RippleTrace=0. Existing INIs are preserved rather than reset to these values.

## Validation and limits

Windows x64 DLL compiled with clang-cl using the MSVC ABI and the Windows SDK. All 20 portable solver/interop tests passed, including live retuning without erasing waves, grid-reset classification, invalid-setting rejection, and concurrent settings snapshots. The accepted Water.hlsl SHA-256 remains `1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e`.

The optional integration checks that the framework DLL is actually loaded, checks all exports it calls, and requires API version 3 or later. It does not link against or distribute the framework binary. Public API header: [QTR-Modding/SKSE-Menu-Framework-3-API](https://github.com/QTR-Modding/SKSE-Menu-Framework-3-API), commit `1dcb70179076aae4ab626f43c5baab2735ca5877`, LGPL-2.1. No ENB code or assets were used.

This menu build has not been executed inside Skyrim here. In-game menu drawing, Windows INI saving under your mod manager, pause behavior, and live grid resizing need your test. No claim of CS compatibility or broader release readiness accompanies this update.

## Implementation checkpoint

`Config` remains startup-only after DataLoaded policy selection. `TuningExchange` validates and copies values under a mutex. Game and renderer each take a snapshot once per update/water frame, with no menu lock on every draw. `Surface::retune` recalculates timestep-dependent damping without clearing state, origin, velocity or simulation time. Dimension/mask changes recreate the surface on the game thread, reset terrain/contact history, and increment the field epoch; render history therefore cannot sample an old grid with new dimensions. The uploaded field carries its own sponge width. Normal/displacement sliders do not cause shader recompilation. No hooks are added by the menu itself.

To resume work: canonical source is project-restored20/SurfaceTides; use the 0.1.19 menu checkpoint, not an older recovered tree. The experimental shader history is retained under packaging/. Data/Shaders/SurfaceTides/Water.hlsl now contains the accepted correction directly. Build tools and runtime gates remain as documented in CROSS-BUILD-RECOVERY.md. The immediate next step is user menu/stress testing; CS remains the next compatibility project after that.
