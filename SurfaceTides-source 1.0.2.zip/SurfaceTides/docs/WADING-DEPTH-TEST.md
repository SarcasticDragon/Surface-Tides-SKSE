# Confirmed shoreline correction — SurfaceTides0.1.18

## Confirmed result — 2026-09-13

The user reports that the original shoreline fragments are gone in both the standard near-vanilla environment and with ENB loaded and master water disabled. The reported successful shader is preserved byte-for-byte (SHA2561c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e), with the existing0.1.18 DLL. This checkpoint changes documentation only; it does not introduce a new rendering revision. No new log or footage was attached, so broader occlusion/performance results are not inferred from this report.

The shoreline-fragment correction is accepted for these tested configurations. Keep the wading-depth overlay enabled as the ongoing comparison baseline; this supersedes the earlier instruction to remove it after the diagnostic. Restore [Interaction] Strength=4 and set [Diagnostics] RippleTrace=0, retaining LogStats=1 and DebugView=0, then restart for continued testing with full simulated wakes. Keep ENB master water disabled. The corrected shader remains restricted to primary WADING pixel descriptor015E.

The successful intervention confirms that changing this pass's depth-output path removes the symptom. It does not independently establish which earlier draw wrote every competing depth value or prove a particular interpolation error. The moving overlapping mesh explanation remains supported by the prior metadata, not a complete frame reconstruction. Do not repeat the negative ripple-texture, actor-force, light-pass or WADING-suppression controls without new evidence.

Before broad release, guard the zero-depth override against native state variations and ensure solid-object occlusion is preserved. The captured configuration had depth writes disabled, LESS_EQUAL comparison and selective stencil testing; those conditions should inform a bounded implementation with a fallback for unrecognized states. The source review confirms the current test relies on native stencil selection and emits depth0 rather than explicitly testing opaque-scene occlusion. No such safeguards are newly implemented or claimed in this documentation checkpoint, and no regression is reported by the user. Preserve the exact working shader while doing that work separately.

CS coexistence remains the next renderer-compatibility task, still unimplemented/gated. ENB full water integration remains experimental/off. This success confirms ENB water-OFF coexistence with the correction in the user's setup; it does not expand support to ENB master water ON.

The remaining sections record the completed diagnostic and its evidence; their original test/rollback instructions are historical. See wading-depth-confirmed-result.json for the current outcome.

## Historical result of the native trace

The user confirms restored r4 rendering removed the large repeated-image smear; the original smaller shoreline artifacts remain. Walking began about10.35seconds after their visible load, running began3.2seconds later, and continued45seconds. Do not treat the plugin startup timestamp or first simulation report as the visible load-complete time. The log contains no such marker, so the exact alignment remains approximate.

The log captured24scopes:8base,8stencil and8wading; no underwater scopes. Summary of all captured native states:

| Family | Geometry | Vertices / triangles | Stationary | Depth write / comparison | Raster bias / slope bias |
|---|---|---|---|---|---|
| Stencil | DefaultProceduralWater:0 |1089 /2048 |true |on / LESS_EQUAL |0 /0 |
| Base color | DefaultProceduralWater:0 |1089 /2048 |true |off / LESS_EQUAL |0 /0 |
| Wading color | Water2048:0 |289 /512 |false |off / LESS_EQUAL |-3 /-0.4 |

Paired base/stencil samples have the same geometry identity and VB/IB, resting at water height600, with bounds radius2896.31. Wading uses a separate VB/IB and moves with the character; radius1448.15 and the same resting height. Counts and bounds are consistent with similarly spaced regular grids of different extent; they do not demonstrate a coarser wading mesh or actual vertex positions. Do not attribute this to FYX from polygon totals alone.

The initial frame0 trace samples repeat at the first Present, before the normal five-second schedule starts. This uses two budget entries near startup; it is a logging-only scheduling issue, not evidence of duplicate rendering. All sampled color passes use the same RT and DSV resource identities. Base stencil tests use mask1/NOT_EQUAL; wading uses mask2or4/EQUAL. Wading keeps stencil on depth fail and pass. These different masks and the suppression result establish that the wading draw is not safely removable as a redundant ripple overlay. The trace does not capture every stencil draw or establish which earlier draw last wrote each pixel's depth.

The first captured WADING pair015E appears at00:07:53.599 (about15.746seconds after the first simulation report). Its moving mesh is centered at(504,-59284,600); later samples track different player locations. The unchanged ambient field was already active while the character was still. Actor forces remain zero. This supports investigating native wading coverage/depth, independently of the simulated actor wakes.

## Interpretation

Displaced meshes with different grid placement can approximate the same heightfield with slightly different triangles. A wading color pass can consequently fail a depth comparison where its stencil still requires it to supply color. This is a specific hypothesis consistent with the trace and user sequence, not a proven cause. Bias behavior, other unlogged depth writers and coverage mismatches are still possible. RW2's clean result and the WFENB/Wavy Waters differences are useful user observations; we have not inspected or established a shared defective replacer asset.

## One shader-only test

SurfaceTides-0.1.18-wading-depth-diagnostic.zip overrides only Shaders/SurfaceTides/Water.hlsl. Install it after the current0.1.18/r4 baseline with earlier diagnostic overlays disabled. No DLL or INI is supplied. Keep the same near-vanilla WFENB2.19 / Shades of Skyrim /4K configuration, ENB removed, native TAA off, Strength0, displacement2, normal2, DebugView0, LogStats1 and RippleTrace1. Restart and repeat the look–walk–look route. Send the log and whether the original small fragments disappear, decrease or remain unchanged. Note any new water appearing over rocks or the character; a short clip is useful if the result changes.

This test changes only the observed primary WADING pixel permutation015E. It emits comparison depth0 while retaining actual displaced input coordinates for all color, reflection and refraction calculations. With the captured LESS_EQUAL state, near depth cannot be rejected by the stored nonnegative depth. The native stencil test still selects pixels. Captured depth writes are disabled and all captured stencil pass/fail operations keep their values, so this is intended to affect color acceptance without changing stored depth/stencil values in the tested pass. Those native states are observations, not a runtime guarantee for unrelated configurations; this is not a release fix.

Every geometry stage, the stencil/motion shaders, underwater, base water and additional lights remain unchanged. Native ripple shading and the moving wading surface remain present. SurfaceTides idle displacement is retained; actor forcing stays off as the existing control. No color-discard experiment is active.

Afterward deactivate this overlay to restore r4. For normal play, restore Strength4 and RippleTrace0 and restart. The DLL startup version remains0.1.18. Keep full ENB water integration disabled; this test concerns the standalone shader path.

If the original fragments disappear, investigate water-depth agreement or a bounded tolerance that still respects solid-object occlusion. Do not promote comparison depth0 into a permanent fix. If nothing changes with PS015E compiled/bound, this narrows the fault away from that primary color pass's ordinary depth rejection, but does not rule out unmodified stencil/coverage or additional-light work. If severe coverage defects recur, report them and revert.

## Validation

660host DXC SM6 builds across33descriptors and5stages:165 default-source outputs unchanged;164of165 diagnostic/r4 outputs unchanged. Only PS015E changes, adding a constant zero SV_Depth output, with no discard and the same resource bindings and color target. See wading-depth-validation.txt, wading-depth-target-ps.txt and tools/validate_wading_depth.py. The previous default shader fixture is included for reproducibility.

No C++/DLL/solver change. No native Windows SM5 execution, Skyrim test, renderer compatibility expansion or performance claim. The game will compile this HLSL through its existing D3DCompiler path. Existing shader GPL/credits retained; no ENB code or shader contents used.

The technical mechanism uses documented [pixel-shader depth semantics](https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl-semantics) and [output-merger depth/stencil testing](https://learn.microsoft.com/en-us/windows/win32/direct3d11/d3d10-graphics-programming-guide-output-merger-stage). Pixel depth participates in the comparison after viewport/format clamping, and stencil remains a separate acceptance condition. The test writes the declared depth output on its only return path. No multisampling was observed in the captured state.

## Evidence and recovery checkpoint

Input log: SurfaceTides(20260913-061030).log,193,748bytes; libfile_f47d22e128d881918ac73b27b9eeb328 / file_00000000f32081fd9db5a9e9b62ed680. See wading-depth-returned-trace.json for parsed samples and actual input size. It reports233,592bound/tessellated draws and zero failures. Runtime1.6.1170, no ENB module/local proxy, leftover ENB INI present with master waterfalse, experimental integrationfalse. Its coexistence startup label comes from that INI and does not demonstrate ENB loaded. No actor impulses or numerical clipping/dropped solver time are reported.

Base source: SurfaceTides-source-native-water-trace.zip, SHA256e4ae507f3a017f7a49227e36638e040899dcb39185718f920907eaa2adbfe040. Existing compiled0.1.18 diagnostic overlay SHA25638714cc033cfd110b1382446c51f5b27692710fb5e74d5745475872fa477e3a1; DLL SHA25619c7154594c2844f5b1a3b066b9c61dae39aa1e96b2e1c32576b74f0166a794c. R4 shader SHA2563f4779120b62d21c41f7060ac57c01d4f5d48a046f34393f62fffa0ca85e8a21. Preserve earlier installers and failed diagnostics as history. The source checkpoint includes the unchanged compiled0.1.18 baseline overlay in recovery/SurfaceTides-0.1.18-native-water-trace.zip so its DLL and exact r4 shader can be recovered without rebuilding.

Working tree remains project-restored20/SurfaceTides, recovered from the user's pre-light source and advanced locally. It is not a byte-exact recovery of historical Library sourcev38. This new source checkpoint has a distinct filename and preserves the prior branch. Standalone and ENB master-water-OFF coexistence have prior user confirmation; CS remains pending/gated; full ENB integration remains experimental/off. No subagents used. Current artifacts are intended for a fresh persistent save now that transfer capabilities are available again; record receipts only after success.
