# Shoreline r4: soften displaced water contacts

## Subsequent user result

The user reports no banding but no improvement. Sequence #1(18).mp4 accompanies this result; no new log. R4 is not an accepted fix. See SHORELINE-R4-RESULT.md for the next temporal control and retained implementation status. Do not strengthen or extend the contact blend merely because the current band had no visible effect.

## Evidence and decision

The user reports the artifact disappears with SurfaceTides disabled and also with its displacement strength at0 while normal strength remains2. ENB has been removed; Water for ENB remains installed. Version/options now known: Water for ENB2.19, Shades of Skyrim,4K textures. No new attachments accompany this result. The prior native-renderer log is recorded in SHORELINE-NATIVE-CONTROLS.md; do not treat it as the log of these two controls.

These comparisons establish that SurfaceTides displacement is required to expose the issue in this setup. They do not isolate a particular Water for ENB file, prove a defective mesh, or exclude optical/temporal effects driven by displacement. Updating Water for ENB or substituting RW2 is not the next control: retain the current version to keep this comparison consistent.

The code still lets a displaced water triangle shade a thin intersection with strong reflections even as its clearance above a rock approaches zero. Earlier r1 attenuated refraction UV distortion; r3 adjusted depth-dependent material weights. Neither fades the complete water color at the opaque contact. A visible sliver of water moving over uneven terrain is also possible without a mesh defect. R4 therefore tests a bounded screen-space contact blend while retaining the geometry that the user wants.

## Implementation

Only Water.hlsl changes. ST_SHORE_CONTACT_BLEND defaults0; the r4 overlay sets1 and retains ST_DISPLACED_DEPTH_BLEND=1, ST_SHORE_REFRACTION=1, ST_DIAGNOSTIC_NO_SSR=0. The delivered overlay includes the earlier r1/r3 shader changes, so no extra dependency on their notes/files is introduced. Source defaults continue to render like r1.

For above-water DEPTH+REFRACTIONS base color passes without VERTEX_ALPHA_DEPTH, the shader linearizes rasterized SV_Position.z using existing CameraData. It subtracts that displaced-surface depth from the opaque depth already read by main. smoothstep(0,12,max(0,clearance)) blends from undistorted scene color to the complete fogged water color. Twelve units is a view-depth contact band, not a vertical water-depth measurement or physical collision radius. Deeper pixels take the existing color path unchanged by this new blend.

The background uses the existing native refraction texture at the undistorted pixel UV, with the same VPOSOffset/dynamic-resolution mapping and brightness conversion as the current refraction shading. SampleLevel(...,0) avoids implicit texture derivatives inside the varying branch. There is at most one additional color sample for affected pixels and no additional depth sample or render pass. Invalid/nonpositive/nonfinite depth returns full water weight rather than erasing it. Do not claim this branch has been tested on a live GPU.

The blend is applied after water fog/color assembly and before the existing optional (inactive in this build) WATER_BLENDING block. It retains the native alpha meaning and adds no discard, SV_Depth output, depth-state override or resource binding. Wave displacement, solver impulses, tessellation, simulated and texture normal calculations, underwater rendering, stencil water mask and motion vectors are unchanged. Additive-light passes and depth-less/vertex-alpha-depth families retain their existing shading.

This is a visual contact treatment, not terrain-aware hydrodynamics. It does not make the field collide with arbitrary rocks, fix a missing/clipped native refraction capture, repair TAA history, or guarantee material fidelity. A view-depth band varies with camera angle; the new blend may visibly soften shoreline reflections or change their clarity. Keep this an optional test overlay until the user confirms the result. If the artifact is not at thin scene contacts, this candidate may not affect it.

Public API references: [Microsoft HLSL semantics](https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl-semantics), [SampleLevel](https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl-to-samplelevel). No ENB code, shader contents, bytecode decompilation or SDK used. No Water for ENB assets inspected, modified or redistributed.

## Validation

tools/validate_contact_blend_shaders.py compiles saved source version34 defaults, new defaults, saved-source r3 settings and new r4 settings across29 descriptors and5 stages.580/580 DXC SM6 compilations pass.145 default outputs are byte-identical to source version34. All candidate geometry, underwater, LOD, stencil, additive-light and non-target pixel shader outputs are byte-identical to r3. The11 targeted PS variants change:001E,005E,071E,075E,003E,015E,031E,011E,035E,011F,581E. All PS resource-binding tables match r3; no new engine constants/resources required. Output:shoreline-r4-shader-validation.txt.

The initially added synthetic LOD+refraction481E fixture failed in the saved baseline because LOD has no MPosition. It was replaced with the valid4802 LOD fixture; no shader change was made to conceal a failure. This does not affect runtime behavior because SurfaceTides leaves LOD native.

No new DLL, CPU solver test rerun, Wine attempt or Windows SM5 execution. Existing compiler binaries were usable. Native shader compilation happens in Skyrim on restart, as with the preceding shader overlays. Compile/scope checks do not validate rendered images, live buffer contents, exposure agreement or performance.

## Installation and user comparison

Install SurfaceTides-0.1.17-shoreline-r4.zip after the current SurfaceTides mods and let Shaders/SurfaceTides/Water.hlsl win. The overlay contains no DLL, INI, mesh or texture replacement. Restore General.Enabled=1 and Rendering.DisplacementStrength=2; keep NormalStrength=2. Restart the game. Keep Water for ENB2.19/Shades of Skyrim/4K and ENB absent for this comparison. No water-replacer update or new load order needed.

Compare the same shallow shoreline: look for changes in the irregular fragments and in the thin transition over rocks. Also check that the established wakes/open-water waves remain visible and that the water has not faded over a broad area. A short clip and ordinary log, identified as r4, are sufficient. The startup version remains0.1.17 because the DLL is unchanged. Disable r4 and restart to restore the previously winning shader; manual installs can restore Water.hlsl from the preserved r3 overlay.

If unchanged, stop adding further contact color terms without identifying whether the artifact footprint follows actual water coverage or a temporal/material sample. A focused diagnostic view or matched TAA control may be justified next; neither is a requested extra test yet. Do not claim success before the user's result, and do not re-request the completed zero-displacement controls.

## Checkpoint and artifact identities

Working source: project-shore-r3/SurfaceTides. Before this turn, the tree matched source version34 byte-for-byte; archive SHA2563289ab2eed96df843105d9a3ed94824482f5d807ee3f2aa56dddcd9aadb3657c,3,998,548bytes. Preserve source identity libfile_4355a322deb481918f58dfaa7d9c03c5; replace with expected version34 and retain the actual receipt. Create a separate r4 overlay; do not replace the r3 overlay or latest full installer. Latest full installer libfile_09c5e26b5238819187b073e8c574a1df remains version19/r1. All confirmed baseline installers remain unchanged.

Code scope: Water.hlsl only; new scope-validation script and docs/report. No C++, other shader files, INI or native validation binary changes. Same DLL SHA2565239ecd7f403fb73f0377bedfb3cf33bbe23d204962c8303a06836b7de8c857c. The project remains renderer-neutral, native ENB integration experimental/off, CS coexistence pending/gated. No subagents or external git remote. Persist this complete source checkpoint and separate overlay.
