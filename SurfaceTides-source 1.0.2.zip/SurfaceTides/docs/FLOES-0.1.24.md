# Surface Tides 0.1.24 — three-model floe bobbing

The user confirms that 0.1.23 prevents wave clipping on the selected test floe. This update extends that same crest-following motion to eligible loaded placements of all three reviewed models. Each reference follows the local simulation independently, including its collision and supported riders. The original water shaders and crest-fitting math are unchanged.

| Winning model path | Coverage |
|---|---|
| `landscape/ice/icefloessolid01.nif` | Includes the accepted E7B8A~Skyrim.esm test floe |
| `landscape/ice/icefloes01.nif` | Newly eligible for bobbing |
| `landscape/ice/icefloessolid02.nif` | Newly eligible for bobbing |

## Install

Install `SurfaceTides-0.1.24-three-floe-models.zip` after the current Surface Tides installation and restart Skyrim. It preserves your INI and includes no replacement NIFs, textures or ESPs. Keep the current load order, ENB master water OFF and slush removal settings for this comparison.

An existing `[Objects] FloeBobbingTest=1` automatically enables all three models when the new `FloeBobbing` key is absent. No INI edit is necessary for the existing test setup. For a fresh setup, use `[Objects] FloeBobbing=1`. The explicit new key takes precedence, including `FloeBobbing=0`; this startup setting requires a restart. Bobbing remains opt-in. `[Objects] HideIceDecals=1` continues to hide the reviewed flat slush shapes independently of bobbing.

The menu section is now **Surface Tides / Settings / Floating ice**. Existing live controls and saved values apply to every managed floe:

| Key under `[Objects]` | Default | Effect |
|---|---:|---|
| `FloeCrestFollow` | 1 | Blend between the original average fit and the lifted crest-following fit; range 0–1. |
| `FloeExtraLift` | 4 | Additional crest clearance in game units; range 0–32. Fades out in calm water and is scaled by crest following. |
| `FloeResponseSeconds` | 0.12 | Rise response time; range 0.03–1 seconds. Descent remains three times slower. |

The comparison buttons and existing Save/Reload tuning remain available. The inherited 48-unit heave, 3-degree tilt and 64-unit-per-second point-motion limits still apply.

## Scope and limitations

Motion is limited to the active local simulation field, with at most 64 eligible floes managed at once. The manager requires a reviewed winning model path and solid shape, compatible static collision, an attached reference in the same area/water band, and an appropriate water-level placement. It leaves unsupported or externally controlled objects alone. Mods placing the reviewed models can qualify; this is no longer restricted to one Skyrim reference. Distant unloaded objects and LOD do not move.

Disconnected chunks contained inside one NIF move as one rigid object. Separate placed references move independently. Splitting those chunks and their collision is deferred beyond the initial release. Existing overlaps between neighbouring placed floes are also outside this change.

The user isolated the strong ice/water discoloration to their ENB preset, which uses Silent Horizons 2. This does not establish behavior in other presets. No shader change or ENB integration change is included here. CS coexistence remains a separate future task.

Discovery and acquisition are spread across frames. The manager refreshes up to eight dense crest fits per update, then moves all managed floes toward their cached targets each frame. With eight or fewer active floes, every target refreshes each frame, preserving the accepted small-scene behavior. Larger groups share the sampling budget; occupied floes receive bounded priority. Very crowded scenes or low frame rates can produce older targets and need runtime evaluation.

## Next in-game check

Check motion and wave clearance on all three models, stepping onto and between floes, and leaving/re-entering the area. Briefly switching the simulation preview off should restore owned objects. Watch performance in dense ice. The new `Floes: ... profiles(solid01,ice01,solid02)=(...)` summary reports active model counts, collision errors, supported riders and target age. Detailed examples identify each model and reference.

An unsupported or failed reference can be skipped without stopping other floes. References rejected for ownership/collision failures stay excluded for the session; restart after correcting such a conflict. Unexpected manager exceptions or failed restoration can stop floe motion while leaving water active. Transform restoration only applies while Surface Tides still owns the transform.

## Verification and rollback

The Windows AMD64 DLL compiled and exports both SKSE entry points. All 39 portable groups pass: 22 solver groups and 17 floe groups, including model selection, field overlap, bounded scheduling/fairness and independent footprint motion. Compiled dependency guards reject the old crashing global reference scan. Core crest math, renderer, solver, hooks, foam/slush selection and all five accepted shaders are unchanged; low-level pose, collision and rider carry calculations are preserved.

These checks do not run Skyrim. Multi-model collision, riders, streaming, performance and visual clearance still require this in-game test, particularly for the other models' `bhkRigidBodyT` assets.

DLL: 1,547,264 bytes; SHA256 `ecb9c39dffe9468cc17a625845bfaa8397b6ec5db988df68e8ddcf9c2eaade5c`.

The immediate accepted rollback is `SurfaceTides-0.1.23-floe-crest-update.zip`, retained in the source archive's `recovery` directory. Restart when changing DLLs. Version 0.1.23 uses `FloeBobbingTest=1`; retain that legacy key if you add the new key and plan to compare against the rollback.
