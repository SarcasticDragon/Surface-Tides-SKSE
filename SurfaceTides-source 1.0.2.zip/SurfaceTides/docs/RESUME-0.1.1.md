# SurfaceTides 0.1.1 hotfix checkpoint — September 9, 2026

User reported no visible effect. The 0.1.0 log on Steam Skyrim 1.6.1170 confirmed water/player hooks and D3D11/Present hooks installed. Descriptors 5000, 5001, 2 and 31E all failed ps_5_0 compilation: EnginePS.hlsli(29), X3017, LightPos initializer does not match type. The fallback retained original water. This is not an INI tuning issue.

Fix: src/core/ShaderLayout.cpp emits eight explicit float4(0,0,0,0) elements for inactive LightPos[8] and LightColor[8], instead of eight scalar zeros. tests/SimulationTests.cpp checks both arrays. tests/ShaderTests.cpp includes all four observed descriptors (17 total, 85 stage checks, 34 remaps). CMake/Main/README/INI identify 0.1.1; startup log includes SM5 light-array fix.

Validation: incremental Windows x64 MSVC-ABI DLL and native test executable build succeeded. Portable suite passed all 12 test groups. Export inspection is in windows-binary-inspection.txt. Native SM5 tests have not executed here (Wine local sockets blocked); no in-game success is claimed. Source validation/RunTests.cmd runs the supplied Windows test executables.

Next action: replace the installed mod with the updated install ZIP, restart Skyrim, verify log version 0.1.1 and retest. There is no on-disk shader cache to clear. If it still fails, inspect the new log before changing settings or doing broader work. Stay within Steam 1.6.1170/GOG 1.6.1179 runtime gate and use a baseline without CS/ENB. This fixes the known first blocker; later integration errors may still surface.

Build dependencies remain bundled in vendor. See README for native Windows builds and cmake/windows-clang.cmake for the cross-build. Scratch build directories/toolchain are intentionally excluded from the source ZIP; generated tests and validation results are included. No new compiler setup is needed while the existing workspace remains available.
