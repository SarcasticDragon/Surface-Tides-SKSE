# Surface Tides 0.1.22 — three ice profiles and selected floe prototype

The user confirms the 0.1.21 solid01 slush filter appears to work. This update extends slush removal to both newly supplied meshes and implements a first simulation-driven motion adapter for **`0x0E7B8A~Skyrim.esm`**, the user-selected IceFloesSolid01 outside Septimus Signus' outpost. This is a compiled prototype awaiting in-game motion/collision testing, not a completed floating-object framework.

## Install and activate

Install `SurfaceTides-0.1.22-floe-prototype.zip` after the current Surface Tides updates. It includes the new DLL and unchanged water shaders, with no INI or replacement meshes. In your existing `[Objects]` section use:

```ini
HideIceDecals=1
FloeBobbingTest=1
```

Restart Skyrim. These are startup settings, shown read-only in the menu. Keep your existing foam and water tuning. `FloeBobbingTest` defaults to 0 when absent; it does not move every placement of the base. The accepted ENB configuration still uses master water OFF. Bobbing Framework is not required. If another motion controller already targets this particular floe, remove that duplicate target from its configuration before using this prototype; either mod can remain installed for other objects.

At the selected floe, watch its motion from shore, stand on it and jump off, then toggle Surface Tides' preview off/on. Preview off should restore its authored resting transform; preview on reacquires it. Live DisplacementStrength changes the sampled geometric displacement, with a brief settling response. NormalStrength only changes water shading. Return the log even if motion is subtle: it records target height, actual requested heave, coverage, collision error and rider counts.

Disable only bobbing with `FloeBobbingTest=0` and restart. Slush filtering is independent. The accepted 0.1.21 overlay remains available for a DLL rollback. No new SKSE serialization records or floe reference-position/angle writes are introduced.

## Slush coverage

| Mesh | Hidden geometry | Retained solid geometry |
|---|---|---|
| `landscape/ice/icefloessolid01.nif` | `L1_IceFloesSolidSlush` | `IceFloesSolid01:0` |
| `landscape/ice/icefloes01.nif` | `L1_IceFloes01` | `IceFloes01:0 - L2_IceFloesChunks:0` |
| `landscape/ice/icefloessolid02.nif` | `L1_IceFloesSolid02Slush` | `IceFloesSolid02:0 - L1_IceFloesChunks:0 - L2_IceFloesChunks01:0` |

Each slush shape is separate BSLightingShaderProperty geometry using `landscape/IceFloes.dds` and `landscape/IceFloes_n.dds`. The filter also checks the exact model/shape names, solid sibling and absence of child collision/controllers; ambiguous variants remain visible. Texture resolution changes at those paths do not affect selection. Parent collision remains intact. The new files contain bhkRigidBodyT with fixed motion (5), mass 0 and one parent collision object. The solid01 input instead has bhkRigidBody; only that selected model is animated by this prototype.

Read-only nifly inspection found 459/771 slush vertices/triangles in icefloes01 versus 3,312/5,558 solid geometry, and 293/520 slush versus 5,134/7,920 solid geometry in icefloessolid02. NIF inputs are not distributed. Hashes and full block reports are in `floe-0.1.22-evidence`.

## Motion and collision implementation

`Floes.cpp` resolves local reference E7B8A against Skyrim.esm through TESDataHandler. It additionally requires the expected base 08CCFE and reviewed solid01 model, attached 3D, a bounded scene tree without child collisions/controllers/skinning, one fixed parent collision body, plausible live bounds and a matching simulation area/rest-water level. It does not perform the formerly crashing global TES reference scan.

The prototype reads the **same freshly produced Frame and applied Tuning** in the game-thread update before publication. It uses the 0.1.21 CPU sampler's cell-center bilinear height/wet interpolation, shader multiplication order, edge fade and displacement strength. It queries at the water's rest level, not the mesh pivot. Worldspace/interior identity is passed alongside the frame. This avoids an unrelated or stale exchange/menu snapshot. Rendering can consume the published frame later; exact render/physics timing still requires observation.

The footprint is a square inscribed in the loaded solid shape's bound sphere, incorporating the actual placed scale. A 3×3 fit produces average height and slope. Minimal world-space tilt is composed with the authored orientation around a pivot at the footprint center and rest water plane, preserving the authored freeboard and local/world-parent transforms. It adds no independent sine-wave oscillator, horizontal drift or wave amplification. The user-selected model is large: a rigid floe averages short waves and should not reproduce every small crest under its footprint.

First-prototype limits are internal: 48 units maximum heave, 3° maximum tilt, 0.35-second exponential response, at most 0.1 seconds of response per update, and a conservative 64-units/second bound on point travel across the floe radius. The latter bounds combined height/rotation movement, including after stalls. Future tuning can expose these once behavior is confirmed.

Collision is switched from fixed to keyframed with **NiAVObject::SetMotionType**, followed by engine UpdateTransformAndBounds calls with collision enabled. The TESObjectREFR wrapper is intentionally not used because its implementation explicitly calls AddChange(kHavokMoved). There are no direct writes to Havok motion matrices or ad-hoc SetPosition/MoveTo calls on the floe reference.

The adapter reads coherent native rigid-body transform snapshots under the existing bhkWorld read lock, converts Havok units using the engine scale, and checks them against the requested whole-body transform. Engine mutation methods run outside that read lock. Current or previous frame pose pairs are accepted to allow a one-frame physics delay. A translation error over 1 unit or rotation error over 0.25° lasting one simulated second restores and stops the prototype for the session. This is an operational diagnostic, not proof that every physics behavior has been validated.

For riders, it considers the player and at most 128 high-process actors, retaining at most 48 actual riders. An actor must be grounded and have the exact selected native body as its character-controller support. Swimmers, airborne/jumping actors and nearby actors selected only by bounds are excluded. The adapter applies the old-to-new rigid transform to the actor's current position through Actor::SetPosition with character-controller updates; it does not overwrite input velocity or actor orientation. This is an initial support-identity approach: boarding detection, engine platform velocity interaction, TDM behavior and edge contacts must still be tested. Clutter transport, navmesh motion and other attached references are not implemented.

## Lifecycle and diagnostics

The manager retains a reference handle and owned scene/physics wrappers, revalidates attached 3D/body/parent identity, and records authored transforms and flags. Normal release restores the node and fixed motion, restoring only the flag bits changed during conversion. It restores on preview disable, game inactivity, area/water changes, 3D detachment and pre-load/new-game/revert messages. Valid same-area field resets follow the new field with bounded response. On loss of wet coverage it settles back and releases ownership. The main simulation exception path also attempts cleanup.

Existing non-fixed collision bodies are not acquired. A changed externally owned scene transform causes the prototype to stop rather than overwrite that controller's new transform or physics settings. This exceptional handoff cannot promise restoration of the original motion type; the log reports it explicitly. Normal startup should use a single motion owner for the test reference. C++ restoration failures are logged; the adapter retains its tracked entry until normal cleanup completes so cleanup can be retried.

Expected log entries:

- `FloeBobbingTest=true` — configuration active.
- `FloeTest: waiting ...` — target unavailable, outside coverage, wrong water band or unsupported/owned collision; throttled to five seconds.
- `FloeTest: acquired ... motion=5->4` — the selected reference passed the gates and collision converted.
- `FloeTest: seq=... heave=... target=... coverage=... collisionError=... riders=...` — five-second motion report.
- `FloeTest: restored ...` — normal release.
- `collision did not track node` / `prototype stopped` — retain the log for diagnosis; water simulation remains active.

No remote renderer API, shader integration or Bobbing Framework dependency is required. API behavior was checked against the bundled [CommonLibSSE-NG source](https://github.com/CharmedBaryon/CommonLibSSE-NG/tree/b93280e832f263dbef44e44cbe2936622a02f91a) and the public [Bobbing Framework implementation](https://github.com/RavenKZP/Bobbing-Framework/blob/6cc8a033ffbfc757f48f4507cd901357367c9a47/include/Manager.h). The motion/filter code here is original; no CS, ENB or Bobbing Framework code is copied into this update.

## Verification and limits

Windows x64/MSVC-ABI DLL compilation and linkage passed. Both SKSE exports and standard Windows imports are checked. The portable suites pass 22 existing solver/regression groups and 10 ice/floe groups, including actual solver sampling, rigid-normal alignment and point-travel bounds. The captured ten-NIF audit selects exactly six reviewed foam/slush shapes out of 21 geometries. The old global-scan crash regression is retained. Water shaders, renderer and physical solver are unchanged; the hook only adds floe cleanup in its existing exception handler.

Skyrim, collision contacts and standing/jumping were **not executed here**. Passing math/build checks does not establish in-game collision synchronization or rider stability. The entire motion path is opt-in and limited to the one supplied reference. This is one-way surface following within the player's local simulation patch, not full buoyancy, collision feedback into water or global sea animation. CS coexistence and dynamic foam remain future work.
