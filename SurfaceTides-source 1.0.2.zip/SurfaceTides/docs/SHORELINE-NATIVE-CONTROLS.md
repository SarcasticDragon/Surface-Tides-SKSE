# Shoreline artifact: native-renderer controls, September 12, 2026

## Returned controls

The user reports neither control shows the artifact: Enabled=0 is clean, and Enabled=1 with DisplacementStrength=0 is also clean. Water for ENB is version2.19, Shades of Skyrim,4K. ENB remains absent. No new log or clip accompanies these observations, so do not cite the earlier log as runtime confirmation of the control settings. Displacement is required in these comparisons, but this does not identify a faulty mesh or exclusively geometric cause; optical/depth/temporal behavior can also change with displaced geometry. The next candidate and interpretation limits are recorded in SHORELINE-R4.md. Do not request these same controls again.

## Current result

The user reports the latest r3 candidate still leaves shoreline artifacts after returning to a near-vanilla load order, removing ENB and retaining Water for ENB. ENB is therefore not required for the reported problem. This narrows the investigation to Water for ENB, SurfaceTides, their interaction, or another retained component; it does not establish a defective mesh or universal incompatibility with this water replacer.

Earlier controls: r1 appeared to contain terrain bleed but left fragments within water. A (refraction distortion disabled) made no visible difference; B (SurfaceTides SSR contribution disabled) appeared to restore shoreline bleed. R3 corrected displacement in depth-dependent material blending but has not resolved the reported issue. Stop speculative optical edits until the controls below are returned.

## Evidence retained

- SurfaceTides(20260912-173942).log: libfile_2f02928a577881919e1819a64e998a9e / file_000000007ffc8230b84118556847f683.
- Sequence #1(17).mp4: libfile_b07bd16391f08191886c64d8726af2a3 / file_000000003ea881fdb9a6b29d78fb8da7. Duration 5.033333 seconds, 2560x1440, 60 FPS. Inspected extracted frames/contact sheet; shallow gravel shoreline near a boat. Frames alone do not confidently distinguish displaced coverage from optical distortion.
- Parsed log totals: shoreline-native-log-summary.json. Nine diagnostic reports, five compiled pairs (5000,11E,802,15E,842), 86,875 reported bound and tessellated draws, zero failed/incompatible draws. Uploaded sequences advance 1 through 8327. No logged warnings/errors in this inspection. Success counters do not establish correct rendered pixels.
- Runtime 1.6.1170, plugin 0.1.17. Experimental integration false; normal strength2, displacement2. System d3d11.dll/dxgi.dll paths, localGraphicsProxy=false, enbModule=false. Renderer context equals native immediate context, no forwarding bridge installed, zero constant repairs. enbINI=true explains the conservative ENB-water-OFF label despite the absent ENB graphics wrapper. Do not ask the user to reinstall/remove components based on that label alone.
- Log does not record the winning shader file hash. The user is reporting against the latest candidate, but overlay identity is not independently proven. Keep the existing shader selection fixed for the next comparisons.

## Next two controls (no new download)

Keep Water for ENB installed, ENB absent, the same scene, the current shader files and all other settings/load-order choices unchanged. Edit the INI that wins in the active profile. All settings below require a game restart.

1. Set [General] Enabled=0. Compare the same shoreline. In Main.cpp this returns from SKSEPlugin_Load before RegisterListener and hook installation; the log should say "Disabled in configuration". This is a native-water control with Water for ENB still present, not merely a zero-amplitude simulation.
2. Only if the first control is clean, restore [General] Enabled=1 and set [Rendering] DisplacementStrength=0. Retain NormalStrength=2. Compare again after restarting. SurfaceField.hlsli multiplies the sampled height by displacement strength independently of the gradient normal strength, so this removes our geometry height displacement while retaining simulation/shading normals and tessellation.

Restore Enabled=1 and DisplacementStrength=2 after the tests. Do not change to an older shader overlay alongside either control: that would change two variables. This replaces the old r3 note proposing a return to r1 before a zero-displacement test. No wind, terrain-mask, tessellation, refraction or SSR adjustments are needed for these controls.

Interpretation:

| Observation | What it establishes / next direction |
| --- | --- |
| Artifact remains with Enabled=0 | SurfaceTides is not required to reproduce it in that setup. Stop the second control; investigate the retained water setup and matched vanilla comparison. |
| Enabled=0 is clean; zero displacement also clean | Our displaced geometry is needed to expose the issue in this comparison. Investigate displaced surface coverage and depth/material agreement, without assuming a bad mesh. |
| Enabled=0 is clean; zero displacement still affected | Our height displacement is not required. Investigate the active shading/material/depth path, including normals or tessellation if subsequent evidence warrants. |

A Realistic Water Two comparison can later establish breadth, but these controls isolate the present failure with fewer load-order changes. Request the installed Water for ENB version and installer preset/options with the user's next report; they are currently unknown. Its author page documents several plugin/option combinations (https://www.nexusmods.com/skyrimspecialedition/mods/37061), so do not treat the installed package as necessarily texture-only. No Water for ENB assets have been read, modified or redistributed here.

## Source and recovery status

Authoritative working tree: project-shore-r3/SurfaceTides. Before this follow-up it matched source ZIP version33 byte-for-byte: SHA256 e722483d058f153c5e501e357cda48491ca565c17cc09fbf62cea6e7f820fe31, 3,956,787 bytes. This follow-up changes documentation only. No shader, C++, INI, native validation executable or installer changes; no compilation or solver tests needed.

Replace only source libfile_4355a322deb481918f58dfaa7d9c03c5 using version33 as the guard; retain the actual save receipt for the next turn. Latest full installer libfile_09c5e26b5238819187b073e8c574a1df remains version19 (r1). R3 overlay libfile_43d30fdc14ac819198e84e4f1baeaed8 remains version0, SHA256 cc3311eef5dede3f3603a7bbe7ddfc731a1891a15570b6d1638cf3f7fe8bdcc2. Source switch ST_DISPLACED_DEPTH_BLEND still defaults0; source defaults are not the r3 overlay. Preserve all confirmed baseline packages.

Renderer-neutral direction remains unchanged: standalone and ENB master-water-OFF coexistence; native ENB integration experimental/off; CS coexistence pending/gated. No ENB implementation code, shader contents, decompilation or SDK used. No subagents. Await these controls before selecting the next implementation change.
