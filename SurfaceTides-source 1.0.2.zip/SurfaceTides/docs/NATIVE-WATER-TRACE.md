# SurfaceTides 0.1.18 — native water draw diagnostic

## Returned result

The user confirms the large suppression smear is gone, while the original fragments persist. The log captured24scopes with complete base/stencil/wading metadata. See WADING-DEPTH-TEST.md for the analysis and next controlled test; the instructions below record the completed capture.

## Original purpose and result so far

The WADING color-suppression experiment failed. Sequence #1(23).mp4 shows severe repeated-image smearing after walking, including stretched/repeated scenery and dark areas. These draws appear necessary for correct coverage or later rendering inputs. This is not proof that the original minor shoreline fragments share exactly the same mechanism. Do not ship suppression as a fix or repeat the native-ripple, light-pass, actor-force, TAA, or no-displacement controls.

This build restores full shoreline-r4 rendering and adds a finite trace of native water draws. It does not attempt another rendering fix. The original minor fragments may remain; the much larger suppression smear should be absent.

## Install and one test

1. Disable all earlier temporary shader diagnostics. Keep the 0.1.17 installation and shoreline-r4 as the base. Install SurfaceTides-0.1.18-native-water-trace.zip last; its DLL and Water.hlsl must win. No INI is supplied.
2. In the existing SurfaceTides.ini set [Diagnostics] RippleTrace=1 and LogStats=1. Keep DebugView=0, [Interaction] Strength=0, displacement2 and normal strength2. Keep the existing Water for ENB2.19 / Shades of Skyrim /4K, ENB removed, native TAA off, Experimental.ENBWaterIntegration=0 setup. No other mod or setting change is needed.
3. Restart Skyrim, load the same save, look up/down without walking for about10seconds, walk back/forth, then stop and look up/down again. Allow about45seconds total after load. Return SurfaceTides.log and note when walking began. A clip is optional unless behavior differs materially.
4. Afterward disable this overlay to restore the old 0.1.17 DLL and r4 shader, set RippleTrace=0 and restore Interaction.Strength=4, then restart. Preserve both diagnostic/source ZIPs.

A successful diagnostic startup reports SurfaceTides0.1.18 and RippleTrace=true. The log should contain `Ripple scope=`, `Ripple resource`, `Ripple buffer` and `Ripple standalone end` rows. Do not enable experimental ENB integration to obtain these rows.

## Implementation

The native path passes raw draw-call arguments and a value-only SetupGeometry snapshot to Renderer::begin. After positive engine water-shader identification, active-field and compatibility checks, and successful shader compilation, the trace observes original draw bindings before replacement. Forwarded ENB draws continue to use their existing trace path, without duplicate standalone sampling. No rendering decision, binding restoration, shader-identity gate, solver, actor impulse, terrain mask, mesh preparation or runtime gate changes.

RippleTrace now requires only LogStats and its own opt-in flag. Each of four families (base, WADING, stencil, underwater) has eight lifetime samples, at least five seconds apart: maximum32scopes per process. Unknown geometry may be sampled again, because cached engine setup can leave the draw without a fresh snapshot. The existing nearby/same-height bound filter affects logging only. No maps or retained geometry pointers are introduced.

Standalone samples record:
- Raw API kind/arguments, shader IDs, topology, frame serial and field origin/sequence. Standalone uses the uploaded field snapshot, labeled fieldSource=uploaded; the older forwarding trace uses the latest published field and labels that explicitly.
- Available scene geometry identity/name, counts, transforms' Z components, stationarity and bounds. These bounds do not prove individual vertex heights.
- Depth/stencil comparisons, writes and face operations, blend factors/masks, raster settings, viewport and scissor rectangles. Null state uses SDK-defined D3D11 defaults in the log.
- Bound VB/IB identities, sizes, strides/offsets; input-layout identity; VS/PS constant-buffer identities and sizes.
- All bound render-target views, depth view, and PS SRV slots0..11, with resource identities, texture dimensions/formats and sample counts. This lets us detect target/input relationships without reading pixels.

Metadata getters only: no GPU buffer readback, shader-bytecode inspection, copying resources, synchronous GPU query, pipeline setter or extra draw in the trace. Logging is still work and has not been profiled in Skyrim. After the fixed budget is spent, detailed capture stops until process restart.

Limits: five-second family samples are not a complete frame capture and can repeatedly select the first eligible mesh. A missing geometry snapshot is reported as unknown, never guessed. No vertex data, constant-buffer contents, texture pixels, GPU timing or full intervening draw sequence is recorded. Resource identity alone does not prove contents or a feedback loop. Different native meshes/depth state remain hypotheses pending the returned log.

The supplied Water.hlsl is byte-for-byte the r4 comparison shader: SHA256 3f4779120b62d21c41f7060ac57c01d4f5d48a046f34393f62fffa0ca85e8a21. Data/Shaders source defaults remain unchanged from the previous checkpoint, including all disabled diagnostic switches. The exact r4 overlay payload is retained separately in packaging/native-water-trace/Water.hlsl. Use tools/package_native_water_trace.py to select that payload, rather than a generic cmake install, when recreating this test. This is a trace-only version bump, not a new visual release.

## Evidence and continuity

Latest log: SurfaceTides(20260913-042324).log, libfile_625f1b655c8081918388a6fc213c3429 / file_00000000a89481fda62a94f040812516. It records0.1.17 on AE1.6.1170, no ENB module/local proxy, displacement2/normal2/wind5/gust1/terrain mask on, Interaction.Strength0 and zero actor impulses,32,788 bound/tessellated draws, zero failed or incompatible draws. Shader pairs include5000,11E,802, then15E/842 after walking. Solver diagnostics show no numerical clipping or dropped simulation time. It contains no native mesh/depth/target correspondence.

Latest clip: Sequence #1(23).mp4, libfile_a8084c1df9808191b83f1c377b7dc029 / file_0000000070e481fd9dba989f3b2be79e;9.066667seconds,2560x1440/60FPS. Inspected a2FPS contact sheet and a full-resolution frame. No exact frame/log alignment or measured pixel tracking is claimed.

Working source: project-restored20/SurfaceTides, recovered from the user's pre-light-pass source archive SHA2561499bffb625b1423a03cf5ac03a565e5ea5b818bf55896f9c39b216f5f1ffd7e. This is not a byte-exact recovery of inaccessible saved source v38. Latest prior local source checkpoint was SurfaceTides-source-wading-surface-diagnostic.zip, SHA256ecd17fb985f81b78da18cc1ab468f5699dc5a4c28b21285bd83f8019dcaf7ff2. Earlier installers are preserved. The known old0.1.17 DLL SHA256 is5239ecd7f403fb73f0377bedfb3cf33bbe23d204962c8303a06836b7de8c857c.

Compiler recovery this turn: old extracted LLVM executable failed with SIGBUS; its cached archive was truncated at44MB. Downloaded the exact same LLVM-MinGW20260826 release fresh, extracted under work-tools/native-trace-toolchain, verified clang-cl23.1 MSVC target, and configured successfully using the existing Windows SDK. Do not use the older work-tools/llvm-mingw... directory. Build directory: build-native-trace. See build evidence for final link/inspection results.

No ENB-origin code or shader contents used. Existing CS-derived HLSL credits/GPL remain; no CS runtime dependency. ENB master-water-OFF coexistence remains previously user-confirmed, full ENB integration experimental/off, CS coexistence pending/gated. Runtime gates remain AE1.6.1170 and GOG1.6.1179 only. No subagents used.

Library transfer capabilities are unavailable in this session; local output is not a persistent save. Retain both new ZIPs. Do not invent a saved Library version or overwrite older confirmed installers with this diagnostic.
