# SurfaceTides: 0.1.16 test result and release-direction recommendation

Recorded 2026-09-11. This is an evidence checkpoint and recommendation, not a new build or an accepted implementation decision. No plugin code, INI, source archive or installer was changed in this turn. Live settings work remains tabled. No subagents or ENB-origin code used.

## User result

Both lake ripple clipping and underwater surface gaps remain in0.1.16. Underwater gaps become more evident looking directly up than looking forward. New14.3667-second2560x1440/60fps clip compares0.1.6 (first9seconds) with current integration (last5seconds). User prefers the older appearance and is considering independent SurfaceTides water with external renderer water effects disabled. Dynamic foam and additional simulation features are future interests.

Inputs read locally: Sequence #1(14).mp4 (libfile_09ffbb0a65b48191b47afeee27e669d6) and SurfaceTides(20260911-100756).log (libfile_ad10c5945dfc81918ceb635f2a0d5f41). Inspected a1fps contact sheet plus frames at4 and12seconds. Baseline wave crests and troughs read much more clearly; later section has stronger texture/reflection detail that visually competes with the broad waves. Different locations, lighting, camera views and materials mean the footage is not a controlled amplitude measurement and cannot establish parallax alone as the cause.

## Log findings

0.1.16, AE1.6.1170, ENBMeshInput=true, cap16, MeshTwoSided=true confirmed.18 periodic reports sum653,723 prepared draws,3,550 native patch draws,66 skips, zero preparationFailures; no suspension. All31 captured native raster states have cull=1 (D3D11_CULL_NONE), including underwater. All periodic twoSidedDraws counters are0 because the native states already disable face culling. This argues against the last rasterizer face-culling hypothesis for captured draws; do not keep presenting MeshTwoSided as an active remedy.

Underwater scopes24/25/26, VS/PS410E, each nativeCalls1/selected1/prepared1/nativePatches0. Main mesh49vertices/72triangles, rest600, bounds center matches rest. HS/DSfalse, topology4, depthWrite0, depthFunc4, stencil1, ref1, cull1. Camera-angle dependence remains unexplained; these samples do not prove pixel coverage, shader discard, projection, refraction or depth/stencil correctness. Do not claim every missing surface is an engine-culled draw or an ENB hull issue.

Two rate-limited skip reason lines identify VS5000 stencil count6126 failing the stream capacity bound.66 total skips appear early in the reports; this is not proof they coincide with the filmed underwater gaps. Cap16 increases SO requirements enough to invoke the128MiB guard for this source count. More refinement is not justified by this test: ripple appearance was unchanged, and there is now a concrete coverage/performance concern.

D3D enum primary reference: https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ne-d3d11-d3d11_cull_mode

## Architectural assessment

0.1.6 standalone Water.hlsl displaces geometry and explicitly incorporates CPU-field slopes into its shading normal. Current mesh-input integration samples height while retaining native/ENB downstream shaders; it does not supply the simulation gradient to ENB's water-normal calculation. Thus the geometry and apparent reflected/refraction detail need not describe the same wave shape. This is a plausible architectural explanation for weaker visual readability, not evidence of missing CPU waves or proof of an ENB implementation detail. No ENB shader contents have been inspected.

Full integration is not proven impossible. A coherent combination would need agreement on displaced geometry, normals, depth/refraction, ripple rendering and temporal passes. Current public-boundary mesh handoff does not establish that agreement. Given the user's visual preference and future foam plans, full ENB water layering is a poor first-release dependency; preserve the experiment separately.

Recommend independent SurfaceTides-owned water rendering as the first-release path, with0.1.6 visual reference and0.1.9 ENB-water-OFF coexistence starting point.0.1.9 checkpoint confirms unchanged0.1.6 solver/HLSL plus forwarded shader identification, and user-confirmed FYX/Water for ENB texture compatibility. Keep useful later hook/state/performance fixes selectively, not a blind revert or assumption that current EnableWater=false restores old shading. Current mesh-input mode retains downstream shaders even when ENB water master is off; switching renderer path matters.

Support standalone without either renderer; aim to preserve ENB's non-water effects with its water disabled. CS coexistence remains unimplemented/untested; current startup gate disables SurfaceTides if CommunityShaders.dll is loaded. Do not instruct users that disabling a CS feature already makes it compatible, and do not remove the gate as a substitute for testing. ENB and CS are separate optional renderer configurations.

Standard compatible water textures/material records can remain inputs to SurfaceTides shading; Water for ENB's tested textures are an encouraging existing case, not blanket support for every replacement or ENB-specific shader map. Evaluate sets individually.

Future dynamic foam fits this architecture: generate a foam field from selected wake/crest/shore activity, render it in the same displaced surface material, and add decay/transport behavior. This would avoid using a separate flat foam plane for that generated foam. Existing placed foam assets still need a separate replacement/suppression strategy; foam is not implemented by this recommendation. Neither this pivot nor foam automatically fixes the current underwater/ripple defects. Retest those in the SurfaceTides-owned path and fix remaining cases before release.

## Recovery and persistent artifacts

At this turn's inspection the local recovered/SurfaceTides tree again contained0.1.15 Main.cpp/Renderer.cpp, despite successful prior0.1.16 save. It was used only to inspect the unchanged legacy shader path and0.1.9 historical notes. Do not overwrite saved source from that stale local tree. Before implementation, recover the actual saved0.1.16 source version28, or the intended earlier baseline, into an isolated working tree.

Latest source: libfile_4355a322deb481918f58dfaa7d9c03c5, version28, file_000000003e3081f583d9cbb2c05b1927.
Latest experimental installer: libfile_09c5e26b5238819187b073e8c574a1df, version16, file_000000000d9081f58019b2248f695ab9.
Separate0.1.16 installer: libfile_2810589ed4dc8191a5b2af80219723b7, version0, file_00000000744881f59c9e960d4106d1e8; DLL SHA256 cd1218d22c4fa5a90caebc6997d8abdfd4d0dd10d886419fdde2247b4ff346b8.
Confirmed0.1.9 ENB-water-off installer: libfile_15df576f3fd08191a2f8657d0fb52674, file_00000000c13081f5a9bccea103e31448; DLL SHA256360c9a775351088640faabf9f125117eec0cf0b56d926ad2458ef04f44576eeb.

Next implementation should first reproduce0.1.6-style shading under ENB water OFF, validate wakes/idle waves/ripples/underwater/FPS, and keep the full native-ENB mesh experiment as a separately preserved branch or source snapshot. Do not spend another cycle increasing the tessellation cap or testing face culling without new evidence.
