# Resume: floe crest following0.1.23

Read FLOES-0.1.23.md and preceding0.1.22.1/0.1.22 checkpoints. The core simulation, menu, foam/ice filters, ENB-water-OFF coexistence and selected floe bobbing are working in user tests. CS and dynamic foam are deferred. No new dependencies or ENB code. Target remains E7B8A~Skyrim.esm (base8CCFE, solid01 outside Septimus Signus); only this reference moves. Do not ask again for the target or three already supplied NIFs.

## Returned evidence and user steering

`SurfaceTides(20260915-090906).log` SHA256 c231ae8c7f8ac80be116ce7396fc54ba74435401157dc9ebf7fbf2c611b53013 confirms0.1.22.1 acquires. ReferenceWater=-3.40282e+38 (finite no-water sentinel), actual water=-14000, target/field Tamriel3C, ownerCellFF001409, spatialCell3934. Pivot(115477.84,140240.22,-14000), radius981.32. This confirms spatial lookup fix while IcyFixes remains.

26 motion samples: heave[-1.346,0.8161], target[-1.6626,0.8095], tilt<=0.221deg. Collision translation error<=0.0294, rotation error<=0.0223deg; riders0/1 and actual carry counts present. No FloeTest stop/error. User confirms motion but it is too subtle to prevent individual crests piercing low interior ice. Water/ice intersections are strongly discolored. `Sequence #1(26).mp4` is6.3s, frames0/2/4s inspected. User explicitly clarified that a neighbouring floe clipping this one is a pre-existing placement issue: exclude it from this fix. Strong material color cause is not proven and was not modified.

## New implementation

Version0.1.23 implements an artistic clearance aid, not physical buoyancy. Original3x3 fit remains, then fitFloeCrestTarget performs at most65x65 (4225) height samples over the loaded-bound footprint at roughly field spacing. Lift uses maximum residual above the fitted tilted plane, blends0..1, adds optional clearance, and retains48-unit heave cap. Clearance margin fades with max absolute sampled displacement, fully active at4units. Zero field/displacement/dry/outside coverage returns rest; crest-follow0 returns exactly the old fit and avoids dense sampling. Invalid dense samples reject the target.

Live Tuning fields/INI keys under Objects: floeCrestFollow/FloeCrestFollow(default1,range0..1), floeExtraLift/FloeExtraLift(default4,0..32), floeResponseSeconds/FloeResponseSeconds(default0.12,0..2). Loaded in Config::read, validated in Tuning, saved by existing atomic saveTuning. No reset of water on change. Menu has Selected ice floe section and Original floe motion button(0,0,0.35), Crest-following defaults button(1,4,0.12). FloeBobbingTest remains startup-only/off by default. Existing INI omitted from update ZIP; missing new keys use defaults, user already has FloeBobbingTest1.

Runtime tick uses the crest goal, rise response as configured and3x slower descent when crest-follow>0. Existing dt cap0.1,64unit/s point bound, collision checking/rider carry/restoration/acquisition are unchanged. Logs add mean, crest, addedLift, three controls, sample count and heaveLimited. A bound-based target plane cannot guarantee no intersections for all mesh hollows, waves, sampling gaps, response delays or hard limits. Keep this limitation explicit; do not claim material discoloration fixed without the user's result.

## Build and verification

Working root project-restored20/SurfaceTides. Windows build build-topology-01192-final, SDK/compiler as earlier checkpoints. DLL1530880bytes SHA25634fbe781349ab33a939b0bb558d68ce1fdc97872d0b397820af8d429a6c83d44. AMD64/exports/compiled API dependency checks pass.36 portable groups pass:22 existing +14 floe (four new regression groups). Evidence in docs/floe-0.1.23-evidence includes source diff, full group results, logs, PE/dependency guards and test-video metadata. No NIFs/videos distributed.

New tools/benchmark_floe.cpp: compile optimized with src/core/FloeMotion.cpp and include path.2000 dense fits for the logged radius measured179.227us perfit versus0.649us old mode on this CPU. Not a Skyrim FPS claim. Sampling bounded to4225, no GPU readback, no per-sample Havok/cell API queries. Broader fleets will need a separate performance design; only one reference active here.

Source comparison against complete0.1.22.1 source SHA b658f2cc6376081f69012ea9f8a3150792a3c68846004806ab8e515b708f6113 verifies unchanged acquisition, collision/rider/release functions, water solver/renderer/hooks/shaders, foam selection and vendor files. Changed sources: CMakeLists/Main version, FloeMotion.hpp/cpp, Tuning.hpp, Game Config reader, Menu controls/save, Floes target/response/logging, sampleINI, FloeMotionTests. Build-only existing clang warnings remain, no new build errors.

## Packaging and next test

tools/package_floes.py emits deliverables-floes-0123/SurfaceTides-0.1.23-floe-crest-update.zip and SurfaceTides-source-menu.zip with atomic ZIP writes and retained rollback hashes. Keep0.1.22.1 (5bcc6fd8491c83caedc1d2a6f5d822cd350c9e8bd8502f786d3607c4c27eabc4) as immediate accepted bobbing baseline, older0.1.21/0.1.20.1/0.1.19.2 as accepted feature rollbacks. Never use withdrawn original0.1.20. Never use truncated old0.1.21 source ZIP.

Source Library identity before writeback: libfile_7c418cf884848191814e878db1ad4791 currentversion12. Replace same identity with expected12 and record actual returned version. New standalone update is a new item. User values checkpoints due usage limits.

Runtime result PENDING. User should start with default crest-following, compare Original floe motion, increase Extra floe lift gradually if needed, then test standing/jumping and preview release. Examine new collision errors under larger lift, addedLift/crest/target and cap diagnostics. If color remains without actual overlap, isolate shading separately using returned evidence instead of changing the established water renderer blindly. Neighbour overlap remains an authored placement issue, not this project's bug.
