# 0.1.14 user result: improved performance, remaining ripple artifacts

Input: SurfaceTides(20260910-113002).log, Screenshot391.png, Screenshot390(2).png. Reviewed 2026-09-10. No code or installer changes made in this follow-up.

## Confirmed observations

User reports much better performance, close to sustained stress testing. Small water fragments appear to freeze briefly and move with the camera, especially with ENB tessellation OFF, possibly occasionally ON. A second circled region shows what the user identifies as the existing flat ripple effect clipping against the displaced surface. User values that ripple's contribution and considers the first artifact a lower-priority issue. Previously deferred foam clipping remains out of scope.

The log identifies 0.1.14, MeshBounds=true, MeshMotionVectors=true, and ENBMeshInput=true. Game stencil VS=5000 compiled with stride=56 and motionHistory=true. The motion-history candidate therefore activated; persistence of the symptom means it did not eliminate it. This does not prove all temporal/depth causes are excluded.

Mesh reports show no preparation failures, skips or suspension. Peak reported scratch capacity is 27,869,184 bytes. The final five reporting intervals contain 187, 201, 194, 205 and 196 presented-frame boundaries over approximately five seconds each (roughly 37–41 per second). These counters support the user's improvement report in those intervals; they are not a GPU profile or a claim of uniform performance throughout loading or play. The log cannot identify which visible pixels belong to ripples or splashes.

## Splashes of Skyrim investigation

Read the author's public repository, not ENB code:

- https://github.com/powerof3/Splashes-of-Skyrim
- https://github.com/powerof3/Splashes-of-Skyrim/blob/master/src/Manager.cpp
- https://github.com/powerof3/Splashes-of-Skyrim/blob/master/Skyrim/Data/SKSE/Plugins/po3_SplashesOfSkyrim.ini

The public source adds projectile/explosion splashes and native ripples. create_ripple uses TESWaterSystem::AddRipple or TaskQueueInterface::QueueAddRipple. InstallOnDataLoad, when its displacement setting is enabled, clears kNoDisplacement on eligible water activators (water, no currents, no random animation) and enables bUseBulletWaterDisplacements when the setting exists. The distributed INI defaults [Settings] bWaterDisplacement=true. Thus absence of rain does not rule out this mod's influence; some changes occur at data load even without an active projectile effect. The installed version has not been supplied, so exact parity with current public source is unverified. SplashesOfStorms is a separate repository; do not confuse the two.

This is evidence of a plausible interaction, NOT proof Splashes causes either circled artifact. No code from this project was copied into SurfaceTides. No ENB source, bytecode, shader, SDK or decompilation was used.

## Next bounded test

Keep SurfaceTides 0.1.14 and its settings unchanged. Temporarily disable Splashes of Skyrim for one fresh game launch, reproduce the same location and camera movement, observe fragments and clipped ripple separately. Start with ENB tessellation ON, briefly check OFF, then restore ON. Restart matters because the candidate modifies records at data load; an in-session toggle does not undo those changes. No giant trace is needed; keep WaterPassTrace=0.

If artifacts disappear, isolate Splashes' displacement patch versus spawned effects using its supported configuration in a subsequent test, accounting for the installed version. If they persist, return attention to SurfaceTides/ENB depth, motion and effect placement; do not blame Splashes based on similar shapes. A short video is more informative about camera-relative movement than more static crops, if convenient.

The second screenshot is consistent with an effect intersecting a moving surface, but does not establish that a separate flat decal is the actual implementation. Native ripples may enter the water displacement/normal texture path. Do not blindly hide TESWaterObject::waterRippleObject, hook away AddRipple, disable global water displacement, or remove contributing ripples. Identify the affected effect/path first; if separate geometry, an eventual solution may need to follow the simulated height across its footprint. Simple whole-effect vertical translation may be insufficient for curved crests. Leave foam work deferred.

## Baseline and validation

Retain the user-confirmed 0.1.14 installer unchanged:

SurfaceTides-0.1.14-ENB-performance.zip

DLL SHA256: 341202e2aca8f003212d44833d545b341789276a8454099efe9e14f50f7e3118

This follow-up updates documentation only. Existing Windows build, portable 19/19 and mesh DXC 33/33 results remain as recorded in RESUME-0.1.14.md; no redundant rebuild or new binary release. In-game performance improvement is now user-confirmed. Remaining fragments/ripple clipping are unresolved. Full ENB tessellation plus simulation remains the goal; no newly claimed complete ENB compatibility.
