# Surface Tides 0.1.19.2 — game topology tracking

**Confirmed by the user on 2026-09-15: the underwater gaps are gone.** This is the accepted build for sustained stress testing. Keep ENB master water OFF and experimental integration OFF; CS coexistence remains deferred. The report confirms the visible result; no new trace was supplied with the confirmation. The original candidate evidence and evaluation procedure below are retained for recovery, not as a request to repeat completed tests.

## Install and evaluate

Disable the previous underwater-contact-test overlay. Install SurfaceTides-0.1.19.2-topology-update.zip after the working0.1.19.1 installation and restart. This update replaces the DLL and supplies the accepted shoreline shader. It preserves the active INI, live menu and save correction. Do not return to the pre-fix shoreline-r4 shader.

Keep [Diagnostics] LogStats=1, RippleTrace=1 and DebugView=0 for this comparison. Use the same underwater view and the boundary between cells(0,-15) and(-1,-15), first with DisplacementStrength=2, then0. Keep NormalStrength=2 and Dispersion=180000. Restore displacement to2 afterward. Report whether the gaps change, include the log, and briefly check the earlier shoreline-fragment fix. RippleTrace can return to0 after the comparison.

The startup line should identify0.1.19.2. A fully intact game-context bridge now reports methodMask=1FF (nine setters/methods), formerlyFF. New five-second Game topology counters show observed setters, tracked water draws, initial getter fallbacks, underwater getter samples and disagreements. One detailed disagreement line is permitted for the whole process. The intended result is continued native matches despite requested=4/getter=35; the native draw is still required to match the requested4 exactly. If no setter has been observed yet, the existing getter fallback is used and counted; no topology is guessed.

To undo the candidate, disable it to restore the prior0.1.19.1 package; keep the unsuccessful contact-fade test disabled. Existing recovery ZIPs remain available in the source checkpoint.

## Returned evidence

SurfaceTides(20260915-005630).log (71,660bytes), Library identity libfile_e191ea4b6d2c819187297c797b699629. Parsed scopes and report windows are in underwater-topology-returned-trace.json. Runtime1.6.1170, DLL0.1.19.1, menu framework3.7, ENB master water confirmed OFF at startup, experimental integrationfalse. The user reports no improvement from contact-fade isolation and a cutoff at the cell boundary. Dispersion is not the setting previously varied; DisplacementStrength0 worsened the gaps.

The log captures25scopes:8stencil,6base,3wading,8underwater. All underwater scopes describe the same geometry identity: DefaultProceduralWater:0,49vertices/72triangles, stationary, bounds center(2048,-59392,600), corresponding to cell(0,-15). Its resting water height matches the simulation band. No underwater sample of the western neighbor(-1,-15) was captured; do not claim an observed material/mesh difference between those two cells.

| Underwater scope | Game-facing topology | Native topology | Forward-selection result |
|---|---:|---:|---|
|16, first sample|4, triangle list|4, triangle list|selected1|
|18,20,21,22,23,24,25|35, three-point patches|4, triangle list|selected0|

All eight samples retain depth writes OFF, LESS_EQUAL depth comparison, stencil read mask1/NOT_EQUAL, culling NONE and blending disabled. RGB write mask7 means the diagnostic overlay's alpha difference is not an explanation for this captured draw. HS/DS are absent at the native pre-replacement capture. There is one native draw per scope; no ENB tessellation conversion was observed in them. candidate/selected in these trace rows describes the mesh-signature test, not proof of a prepared replacement. The mismatch also fails the strict replacement forwarding gate, which compares the full DrawSignature including topology.

After underwater entry, all eight report windows with misses have matchedNative equal to bound+tessellation-independent LOD skips. Their noMatchingNative counts are145,213,216,211,211,210,225,223. Thus the aggregate totals provide no fallback replacement recovery for those misses. Individual native draw outcomes were not separately logged in the old build, so a complete per-pixel reconstruction is still unavailable. The periodic failure/incompatibility counters are zero; they did not flag this because an unmatched shader identity is treated as a non-water draw rather than a compilation failure.

This explains a concrete bridge defect. If the affected underside remains native while earlier depth/mask water draws are displaced/tessellated, inconsistent water rendering is a plausible consequence. The subsequent user test confirms the gaps disappeared with this correction. The contact-fade hypothesis is not supported as the sole cause by the unchanged test.

## Implementation

The bridge already records VS/PS setters rather than trusting potentially wrapped getters. It now records IASetPrimitiveTopology at the game-facing context's slot24. Only outer game calls update the tracked value. Nested calls and Surface Tides' temporary native patch bindings cannot replace that request. The logical snapshot is protected by the existing mutex and selected before entering the synchronous forwarding scope.

ClearState and ExecuteCommandList(FALSE) reset logical topology to the documented UNDEFINED default together with the existing shader history. ExecuteCommandList(TRUE) retains the previous tracked topology; internal playback occurs under the existing recursion guard. Before any setter/reset is observed, a getter fallback preserves initial behavior.

ForwardedDraw itself is unchanged. It still requires the same complete direct-call arguments, matching topology, canonical immediate context and one consumption per synchronous scope. Genuine game patch requests remain patches and cannot match native triangle draws. Indirect/auto calls remain excluded. The experimental mesh-input path receives the corrected expected signature through the existing separate gate; it is not newly enabled or claimed compatible.

Changed runtime files: Hooks.cpp and the small portable LogicalTopology helper in ForwardedDraw.hpp. Main.cpp, Menu.cpp and CMakeLists.txt change only version labels to0.1.19.2. Renderer.cpp, all shaders, simulation, INI persistence and runtime gates remain unchanged. Menu.cpp is otherwise byte-identical. No ENB implementation code or shader bytecode was inspected or copied.

## Validation

The portable regression replays requested triangle topology4 against stale getter35/native4, verifies the old gate rejects it and the tracked request allows exactly one correct draw, rejects changed offsets and genuine topology conversions, excludes nested setter writes, and tests default reset/new setter behavior. All21portable tests pass, including existing solver, live tuning and forwarding checks. See topology-0.1.19.2-tests.txt. These portable tests do not execute Windows profile APIs or COM hooks.

Windows x64/MSVC-ABI configure, compile and link passed using clang-cl23.1 and the existing SDK/MSVC import libraries. AMD64 architecture and SKSEPlugin_Load/SKSEPlugin_Version exports verified; imports contain Windows system components, with no unexpected compiler-runtime dependency. DLL size1,437,184bytes, SHA2563e0c1a49903c6e3f69a0cc56baec370eefc29ce9d7be7dd7ae417a85723da68b. See topology-0.1.19.2-build.txt, topology-0.1.19.2-binary.txt and topology-0.1.19.2-package.json.

All five shipped shader/include files match the prior accepted checkpoint byte-for-byte. Renderer.cpp, Game.cpp and Simulation.cpp are unchanged; Menu.cpp differs only in the displayed version. The SDK vtable check confirms IASetPrimitiveTopology is slot24. No native Skyrim/D3D execution is available here; in-game confirmation comes from the user's returned test. No HLSL recompilation sweep is needed for byte-identical shader files.

## Recovery and public references

Canonical source: /workspace/scratch/96cfc0bcb1b2/project-restored20/SurfaceTides. Source identity libfile_7c418cf884848191814e878db1ad4791, replacing version5 after packaging. Preserve all existing recovery archives, including0.1.19.1 and the unsuccessful contact-fade test, and include the new compiled candidate. Accepted Water.hlsl SHA256 remains1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e; do not overwrite it with the diagnostic macro variant.

The compiler archive left in scratch was truncated. The complete official LLVM-MinGW20260826 asset was fetched again (83,880,560bytes, SHA256cee8d2ce3da5145ce4dc882e70d0b0719a783d53a99752c60948fc0659975a65). Do not reuse the old44MiB llvm.tar.xz. Toolchain/SDK files are not part of the mod/source deliverable.

Working compiler directory: /workspace/scratch/96cfc0bcb1b2/work-tools/topology-fresh/llvm-mingw-20260826-ucrt-ubuntu-22.04-x86_64/bin. Working build directory: /workspace/scratch/96cfc0bcb1b2/build-topology-01192-final. Extraction into a fresh directory was necessary to avoid the older truncated shared libraries; libLLVM.so.23.1 must be81,847,848bytes and libclang-cpp.so.23.1 must be55,467,320bytes. Configure options are the existing windows-clang.cmake workflow with this ST_LLVM_BIN, the existing work-tools/sdk ST_WINDOWS_SYSROOT, Release, ST_BUILD_PLUGIN=ON, ST_BUILD_TESTS=OFF and ST_BUILD_SHADER_TESTS=OFF; portable tests were run separately with host g++. Clean build used parallel4.

Public D3D contracts: [IASetPrimitiveTopology](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-iasetprimitivetopology), [ClearState](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-clearstate), [ExecuteCommandList](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-executecommandlist). Method slot24 is checked against the local Windows SDK d3d11.h vtable, not an executable instruction offset.
