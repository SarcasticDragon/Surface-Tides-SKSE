# Static foam and floating objects — 2026-09-15 checkpoint

Current test: **0.1.22**, three reviewed slush profiles and a runtime motion prototype for user-selected E7B8A~Skyrim.esm. See [FLOES-0.1.22.md](FLOES-0.1.22.md). The user confirms the 0.1.21 solid01 filter appears to work, the 0.1.20.1 load crash is gone and initial foam behavior is correct. The original 0.1.20 DLL remains a known-failing artifact. Preserve accepted 0.1.21, 0.1.20.1 and 0.1.19.2 rollback packages.

## Accepted baseline and task boundaries

The user confirms 0.1.19.2 removes the underwater gaps. Preserve the tested topology-update ZIP and its DLL/shaders byte-for-byte while stress testing continues. The optional 0.1.20 foam update now implements the first two reviewed attached-foam profiles, with no changes to water rendering or the solver. See [FOAM-0.1.20.md](FOAM-0.1.20.md). ENB water-off coexistence remains accepted in the tested configuration. CS coexistence is still future work; full ENB water integration remains experimental/off. The project remains independent of both renderers.

The user has visited the ice-floe region and reports both solid ice and attached thin ice clipping, with the thin ice worse. The supplied solid01 mesh confirms separate slush geometry and a parent collision body. Hide its reviewed slush shape, then implement motion for selected Sea of Ghosts floes. Dynamic foam belongs after the initial release. Do not reintroduce tests for the fixed underwater/shoreline problems without a new regression.

## Foam: use two different scopes

| Asset structure | Preferred treatment | Compatibility consequence |
|---|---|---|
| A placed object whose entire mesh is flat foam | Optional BOS reference/base property rule | No replacement NIF or ESP needed; disabling a base affects every placement |
| Rock plus a separate foam geometry child | Hide that identified geometry on the loaded instance | Retains whichever rock model/textures the load order supplies |
| Rock and foam triangles merged into one geometry, or ambiguous node structure | Generate a local patch from the winning NIF, removing only verified foam triangles/shapes | Must regenerate after changing that winning asset; do not distribute a generic rock replacement |

BOS documents direct property overrides in `[Transforms]`/`[Properties]`, and `flags(0x00000800)` marks a reference initially disabled. Its current implementation applies those flags on the reference. It cannot select a child shape inside a NIF. `NONE` is not an empty-model shortcut to invent here. The supplied xEdit helper generates property rules for explicitly reviewed whole objects and an inventory of foam/rapids/ice candidates. Its default allowlist is empty. The newly inspected and user-confirmed FXRapids, FXRapids02 and FXrapidsBig01 bases have a separate optional preset and reviewed allowlist in `optional/foam-bos`. See tools/xedit/README.md and FOAM-0.1.20.md. Waterfall impact rings remain excluded.

The inventory is load-order aware at the record level. It cannot infer the actual asset provider from the winning ESP alone. A record can still point to the original path while ERM, Gol Mora or another mod supplies its bytes. Runtime BOS swaps can also change the eventual model. Record names alone are insufficient to prove that a surface is disposable foam.

### Embedded foam design (first two profiles implemented in 0.1.20)

First inspect representative winning rapid-rock NIFs. If the foam is a distinct geometry child, use the loaded reference's own scene tree after its winning mesh is installed. Match a reviewed combination of model path, geometry identity and material/texture information; do not globally hide every shape using a foam-looking texture. Node names by themselves may be generic or change between replacers.

The CommonLib dependency already exposes NiAVObject::GetAppCulled/SetAppCulled and NiNode children. This supports investigating instance-local geometry suppression, not a claim that a single cull flag has already been validated with every animated NIF. Preserve the original visibility state, restore only changes owned by Surface Tides, and handle animation controllers that could restore visibility. Hold reference handles, re-resolve on 3D reload, and avoid modifying shared cached template meshes. Unknown structures must remain visible and be reported rather than risk hiding the rock.

This should preserve rock geometry, textures and collision in variants where foam is separate. If the geometry is merged, whole-child culling is unsuitable; an offline winning-asset patch is the fallback. Whole-file replacements remain possible but are not the first choice. Dynamic foam later can replace these removed flat sheets without a dependency on CS/ENB; its temporal field and shading still need a separate design and budget.

## Ice floes: JSON is useful for selection, not sufficient for synchronization

The author page currently identifies Bobbing Framework 3.1, updated 2026-09-09. Inspected repository commit: `6cc8a033ffbfc757f48f4507cd901357367c9a47`. In include/Manager.h, the Update path builds translation and rotation from independent sine functions of elapsed time, configured axis speeds, ranges and phase. The plugin listener handles SKSE lifecycle messages. No exported motion-provider API or external water-sampling callback was found in this inspected revision. This does not prove such an interface can never be added, or guarantee that a separately distributed binary matches the repository exactly.

Therefore, a JSON-only preset could create plausible bobbing but would not track Surface Tides gusts, wakes, scrolling field, wet mask or live displacement scale. Matching one frequency/phase would not solve that. Rewriting JSON every frame or hooking undocumented addresses in another plugin is not the intended integration.

Two viable implementation paths:

1. Add an optional surface-motion provider to Bobbing Framework, allowing its existing collision/occupant machinery to consume Surface Tides height/tilt targets. This requires a framework-side code change and an agreed versioned interface. No author contact or external message has been sent. No Bobbing Framework code is copied or shipped in this checkpoint.
2. Implement a narrow Surface Tides floe controller for explicitly selected references. This keeps the proof of concept independent and avoids needing an unavailable callback. It must implement collision movement and lifecycle restoration correctly, rather than only moving the visible node.

Recommendation: design the Surface Tides sampling contract first; use the second path for a small prototype unless a supported framework extension becomes available. The same data can later support the first path. Only one controller may own a given reference: any Bobbing Framework/other animation entry for those test floes must be excluded. This is object-animation ownership, unrelated to the choice of renderer.

### Sampling and motion contract

SurfaceTides already solves on the CPU and publishes immutable Frame snapshots (src/plugin/Bridge.hpp, Game.cpp). Each texel contains height, slopes and wet coverage; no GPU readback is needed to expose them. The shader's actual displaced height is not simply Surface::sample:

- Bilinearly sample the same cell-center field used by STCurrent.
- Apply the same wet coverage, grid-edge fade, active state and rest-water-height band as SurfaceField.hlsli, then Rendering.DisplacementStrength.
- Query at the object's associated **rest water plane**, not its raised mesh pivot. Preserve the authored pivot/freeboard offset rather than snapping the NIF origin onto water.
- Pair field and tuning snapshots at a defined frame boundary and track sequence/epoch. Renderer upload can lag the producer; measuring that relationship is part of the prototype. Do not promise zero-latency synchronization merely because both use the CPU solver.
- Reject a different worldspace, water level or inactive/reset epoch. Smoothly return to the authored transform as simulation coverage fades, rather than following an unrelated lake or teleporting at the local grid edge.

For a rigid floe, sample several points across its water-contact footprint. Fit an average height and plane for heave, pitch and roll. Preserve yaw and the authored rest transform. Larger floes should respond to broader waves and average over small ripples; following a single point would exaggerate tilting. Keep horizontal position fixed for the first prototype. Filtering should be time-based with bounded tilt, with pause/load behavior specified. This is one-way surface following, not full buoyancy, hydrodynamic force feedback or water displacement by solid obstacles.

NormalStrength affects shading and should not change floe motion. DisplacementStrength affects the visible geometric height and must change the target. Surface Tides currently simulates one nearby water-height band, not the entire Sea of Ghosts at once. Outside that band/patch the floe returns to its authored resting state; broad global bobbing would be a separate feature.

### First in-game proof and acceptance criteria

Choose a few detached, small floe REFRs and record their original transforms, winning NIFs, collision and water levels. Exclude shore ice, grounded pieces, giant icebergs, quest-linked placements and large walkable/navmeshed platforms initially. Do not assume that anything containing `Ice` in its name is floating.

1. Verify rest offset and motion with a controlled wave and a wake, including live DisplacementStrength changes and zero displacement.
2. Move collision with the visual ice using a supported keyframed mechanism; test standing, jumping, walking off and returning. A visual-only bob does not qualify as a completed proof.
3. Verify entry/exit from simulation coverage, wet mask changes, low frame rates, pause, unload/reload, save/load and feature disable without cumulative offsets or stale pointers.
4. Recheck near-vanilla and the accepted ENB water-off configuration. Renderer cooperation should not be required for this CPU/game-object feature.

The CPU sampler/fit from 0.1.21 is now wired into the opt-in 0.1.22 controller. Both remaining meshes were supplied and audited. E7B8A~Skyrim.esm outside Septimus Signus' outpost is the selected reference. The controller consumes the exact game-produced Frame/applied Tuning/area, uses keyframed node collision with observed transform checks, and implements support-body rider handling. **In-game motion, collision and boarding validation remain pending.** The implementation details and limitations in FLOES-0.1.22.md supersede the earlier design-only notes above.

## Evidence and recovery

- [Base Object Swapper author documentation](https://www.nexusmods.com/skyrimspecialedition/mods/60805): property/flag syntax and requirements.
- [BOS flags](https://github.com/powerof3/BaseObjectSwapper/blob/c0b9c093aa6260fd9b68beddea411db97f585ea2/src/ObjectProperties.cpp), [hook application](https://github.com/powerof3/BaseObjectSwapper/blob/c0b9c093aa6260fd9b68beddea411db97f585ea2/src/Hooks.cpp).
- [Bobbing Framework author documentation](https://www.nexusmods.com/skyrimspecialedition/mods/186081): JSON configuration, object hierarchies and version. [Inspected motion/configuration implementation](https://github.com/RavenKZP/Bobbing-Framework/blob/6cc8a033ffbfc757f48f4507cd901357367c9a47/include/Manager.h), [plugin entry/listener](https://github.com/RavenKZP/Bobbing-Framework/blob/6cc8a033ffbfc757f48f4507cd901357367c9a47/src/plugin.cpp).
- [Official xEdit scripting reference](https://tes5edit.github.io/docs/13-Scripting-Functions.html); current API reviewed at TES5Edit commit `9fb016884bec138ea6c7b872cec831537d464c3e`.

Preserve recovery/SurfaceTides-0.1.19.2-topology-update.zip unchanged, SHA256 `6c7e5a345bc520a77ba857166261e80f2bd87f77aaa2829abc4b824784c9e81d`. Its DLL SHA256 remains `3e0c1a49903c6e3f69a0cc56baec370eefc29ce9d7be7dd7ae417a85723da68b`; Water.hlsl remains `1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e`. The packaged historical manifest still says candidate/pending because it records the original build, not this later user confirmation.
