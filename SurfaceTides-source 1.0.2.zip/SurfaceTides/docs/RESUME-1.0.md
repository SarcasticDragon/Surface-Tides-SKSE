# Surface Tides 1.0 release checkpoint — 2026-09-15

The user accepted initial CS water-off coexistence in 0.1.25, is beginning sustained stress testing, and explicitly requested v1.0 plus a FOMOD for optional removals and bobbing. Do not change the accepted water, object or rider implementation while preparing this release.

## Completed

- Compiled DLL promoted to SKSE version 1.0.0.0, CMake 1.0.0, menu title 1.0. Only version/status strings differ from accepted 0.1.25 runtime code.
- Three-page FOMOD: requirements; standalone/ENB water-off/CS water-off renderer; independent foam, ice decal and bobbing options. Keep-all/static options default selected. Experimental ENB integration stays disabled.
- Attached foam filter requires no BOS. Standalone removal uses the exact existing three-base BOS preset and requires BOS 3.0+. Waterfall impacts remain.
- CS choice ships the exact accepted three-setting override; its 0.1.25 metadata identifies the retained compatibility-preset revision. ENB choice does not edit the user's preset. Neither dependency is bundled.
- 24 full INIs cover 48 combinations (standalone foam changes only BOS payload). Every route installs exactly one INI. Reinstall replaces tuning: back it up; cleanly replace old mod installations to avoid residual optional files.
- Schema and exhaustive XML selection evaluation pass. Official schema's single leading-space QName is normalized only in memory for libxml2. Installer GUI has NOT been exercised in MO2/Vortex.
- Source includes generator, validator, packaging script, authoring guide, licenses, evidence and recoverable installer. No game meshes/textures distributed.

## Evidence and rebuild

`docs/release-1.0-evidence/` contains the DLL inspection/build log, exact version-only source diff, all48 selection results, DLL/schema hashes and packaged-file hashes. The prior45 portable groups passed for accepted0.1.25; they were not rerun for this version-label-only promotion. No new in-game test is claimed.

Run `tools/build_fomod.py --dll <compiled-dll> --stage <clean-stage>` then `tools/validate_fomod.py --stage <stage> --output <report>`. See `docs/FOMOD-1.0.md`. `tools/package_release.py --stage <stage> --baseline-source <accepted-source-zip> --output-dir <output>` enforces the scope of this specific release.

Accepted source baseline: `SurfaceTides-source-menu.zip`, SHA256 `18e313401e406851d67c2ba70d8b9fd8ebefd2d391c5fc2512db41364b1d8201`, source identity `libfile_7c418cf884848191814e878db1ad4791`, version19 before this release writeback. Preserve identity when saving updated source.

Accepted0.1.25 recovery: `SurfaceTides-0.1.25-CS-coexistence.zip`, SHA256 `ee1f818a44fc603695ad9f02c08c32dce15bfeda6a1073bb9d3c3bd87f3527fc`. All older recovery bytes retained. Original0.1.20 is withdrawn for CTD and must never be recommended as rollback.

## Next

User should click through the actual mod-manager wizard, at least default, ENB/all-options and CS/all-options, and verify a reinstall clears deselected files. Then continue stress testing. No release publication is performed here. Ice is Slick remains incompatible with bobbing; disconnected chunks move as one object. Dynamic foam and split ice assets remain deferred.

## Installer revision r2

The user confirms the original wizard installs and works, but reports System.Xml.XmlException Xml_InvalidCharacter at line1 position39 during validation. The original XML is valid UTF-8 and byte39 is a newline; no illegal source character was found. Nexus-Mods/fomod-installer src/InstallScripting/XmlScript/XmlScriptType.cs StringStream rewrites text as UTF-16BE but only strips double-quoted encoding declarations. ElementTree emitted single quotes, so the UTF-8 declaration survives. This is the likely encoding mismatch; exact .NET/UI reproduction was unavailable. r2 emits double-quoted declarations in both XML files and checks the manager's rewrite explicitly. DLL, shader, INI and optional payload bytes remain unchanged. User must confirm warning gone.

Preview support added: six optional PNG filenames under installer/fomod/images automatically attach to foam/ice choices. Docs explain manual XML insertion immediately after description. No screenshots invented or included. Keep original 1.0 recovery intact; r2 has a separate recovery filename. Source library version20 precedes this update.
