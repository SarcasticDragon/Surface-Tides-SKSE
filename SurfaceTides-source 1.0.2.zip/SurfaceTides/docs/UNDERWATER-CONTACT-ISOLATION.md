# Underwater contact-fade isolation — 0.1.19.1, 2026-09-15

This is one diagnostic overlay, not a confirmed fix or a new DLL release.

Returned result2026-09-15: no behavioral change. The user also reports a sharp cell boundary: gaps in(0,-15), absent in(-1,-15). This test is complete; remove its overlay. Follow TOPOLOGY-0.1.19.2.md for the new DLL candidate based on the returned native draw trace. Instructions below are historical and must not be repeated as the current test.

## Install and compare

Install SurfaceTides-0.1.19.1-underwater-contact-test.zip after the current working 0.1.19.1 installation. Its Shaders/SurfaceTides/Water.hlsl must win conflicts. Keep earlier unrelated diagnostic overlays disabled. No DLL or active INI is supplied; the working live menu and INI-save correction are retained.

For this run, set [Diagnostics] RippleTrace=1 and retain LogStats=1 in the existing INI, then restart the game. Despite an obsolete comment in the user's INI, current RippleTrace supports standalone rendering; it does not require experimental ENB integration. It has a fixed budget of 32 scopes, eight per family, with samples at least five seconds apart. WaterPassTrace stays 0. Keep experimental integration OFF and ENB master water OFF.

At the same underwater view, compare normal appearance at DisplacementStrength=2, then 0, using the menu. Keep NormalStrength=2, Dispersion=180000 and DebugView=0. Spend about 15 seconds underwater so the log can capture the underside passes. Restore displacement to 2 afterward. Report whether the gaps disappear, diminish or remain, and attach the log; a clip is useful if the appearance changes. A brief check of the previously fixed shoreline fragments will identify an above-water regression.

After the comparison, disable this test overlay to restore the current accepted 0.1.19.1 shader, and return RippleTrace to 0 for ordinary testing. Do not roll back to the pre-correction shoreline-r4 shader. If the test works, report that result before adopting it permanently; shoreline contact appearance also needs evaluation.

## What changes

The overlay is byte-for-byte the accepted shader except for ST_SHORE_CONTACT_BLEND changing from 1 to 0. This removes the later r4 color fade into undistorted captured scene color. It retains the separate PS015E wading comparison-depth correction that eliminated the earlier fragments, the r1 refraction guard, the displaced-plane depth calculation, all waves, native ripples and all normals.

The fade is compiled into selected non-UNDERWATER pixel permutations. This test does **not** modify the dedicated UNDERWATER shader. It checks whether other water draws or captured water color contribute the apparent gaps. Which passes actually own the affected pixels is not established by the current log. A negative result is useful: it rules against this specific fade as the sole cause and the bounded native trace supplies current depth/stencil/blend state for the next investigation.

## Evidence received

- User ruled out Underwater NG. Preview Surface Tides OFF removes the symptom. Diagnostic water colors conceal it. DisplacementStrength=0 greatly worsens it. The user's initial word "dispersion" was explicitly corrected to "displacement"; do not change the solver's dispersion coefficient based on that initial wording.
- Sequence #1(25).mp4 is 9.383333 seconds, 2560x1440, 60fps. Inspected a one-second contact sheet and a full-resolution frame at five seconds. It shows bright, sharply bounded apparent openings when displacement is reduced. Shape alone does not prove missing geometry.
- Supplied INI has DisplacementStrength=2, NormalStrength=2, Dispersion=180000, TerrainMask=1, Resolution=192, Spacing=20, tessellation 64/20; AllowENB=1 and ENBWaterIntegration=0. Do not equate the saved INI with every live setting in the clip.
- Log reports DLL0.1.19.1 / Skyrim1.6.1170, SKSE Menu Framework3.7, ENB master water confirmed OFF at startup, and the SurfaceTides independent renderer. UNDERWATER410E and430E compile and bind successfully. Reported failures/incompatible draws are zero; no shader error explains the symptom.
- Live tuning changes are not logged individually. At the final simulation report, height/velocity/slope remain finite (8.8189 /42.6857 /0.27104), cumulative clipped cells3, dropped solver time0.097 seconds. These values do not establish solver instability. Displacement zero does not disable the heightfield, simulation normals or custom shading.

The existing diagnostic overlay replaces the final water color and changes its alpha to1. It also paints several water permutations identically. Therefore its apparent coverage is evidence for investigating shading/composition, not proof that every underwater geometry or depth/stencil path is correct. The contact fade normally runs before that override, making it a reasonable narrow isolation. A normal-orientation review did not establish a sign error: the existing underwater Fresnel calculation intentionally reverses the upward surface normal. No speculative normal change is included.

The fade compares rasterized surface depth against sampled scene depth. If that sample includes water or another coincident water surface rather than opaque scenery, the small difference can select captured background color. Zero displacement makes water surfaces coplanar, but this mechanism remains a hypothesis until the isolation result and current native trace are available. Full-frame ownership/depth data has not been captured here.

## Validation and source recovery

tools/validate_underwater_contact.py passed330/330 host DXC SM6 compilations across33 descriptors and five shader stages. All geometry, UNDERWATER (including410E/430E), stencil/motion, LOD, additive-light and non-contact pixel outputs match the accepted shader byte-for-byte. Eleven contact-fade PS permutations change. Their resource tables, discard presence and depth-output presence remain unchanged. The PS015E comparison-depth correction remains enabled. See underwater-contact-validation.txt.

Compiler: Microsoft's official DXC1.9.2607 Linux release. Header generator rebuilt from the unchanged project core. No Windows FXC/SM5 execution, Skyrim run or performance validation was possible. The plugin compiles the supplied HLSL at runtime after restarting.

Canonical Data/Shaders/SurfaceTides/Water.hlsl remains the accepted shader, SHA2561c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e. The candidate is separate at packaging/underwater-contact-isolation/Water.hlsl. Existing0.1.18,0.1.19 and0.1.19.1 compiled recovery ZIPs remain untouched; the new diagnostic ZIP is also retained in recovery. No runtime gates, ENB code, CS integration, hooks, menu or solver code changed.

Source checkpoint identity: libfile_7c418cf884848191814e878db1ad4791, replacing version4. Local working tree: /workspace/scratch/96cfc0bcb1b2/project-restored20/SurfaceTides. Current compiled DLL SHA2568928d842d41170d3f9c51696e8cebb8fdfbf5d7357d277f7f41a636ad4c4341f. Current baseline was recovered from source archive SHA256832cd6d338aba7b25ca84602e1f4909a425859c543ab4a6dceeec169aef9bc3a.

Incoming attachments, all read locally without modification:

- SurfaceTides(20260915-002449).log: libfile_c91a1e514990819196d3db6a281a06ca
- SurfaceTides.ini: libfile_b9acf1be646c8191a1af9e4763f2e35d
- Sequence #1(25).mp4: libfile_9c87a6af7c008191bff502a0eb01cbe6

Public shader comparison used the existing upstream provenance, Community Shaders v0.8.7 Water.hlsl (https://github.com/doodlum/skyrim-community-shaders/blob/v0.8.7/package/Shaders/Water.hlsl); no additional upstream code was copied. GPU depth precision is a separate possible contributor, not changed by this test. Microsoft's precise documentation (https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl-variable-syntax) describes invariance across tessellation and depth passes, but a numerical fix would require more evidence than the present video supplies.
