# Resume 0.1.16: lake ripple refinement and underwater culling candidate

## Evidence and scope

User reports0.1.15 improves river ripples but calm-looking Lake Ilinalta still clips, with ENB master water ON and OFF. New underwater Screenshot393.png shows polygonal surface gaps. Sequence #1(13).mp4 is11.633 seconds,1920x1080, showing ripple sections interrupted before and after a master-water toggle. Read attachments locally; inspected extracted contact sheet. No new log accompanied this lake test. Live settings changes are tabled. Foam and smaller camera-linked artifacts are deferred. Do not attribute the new footage to the previous log.

The previous SurfaceTides(20260911-011731).log identifies DefaultProceduralWater:0,49 vertices/72 triangles, radius2896.31 (4096-wide tile), versus Water2048:0,289 vertices/512 triangles, radius1448.15 (2048 wide), moving with the player. Both bounds centers match active rest height -250; this is not a read of actual source vertex positions. Original shader family31E vs wading35E; both are prepared successfully. Wading native depth write0, function4, stencil ref3, raster bias-3/slope-.4; main bias0. No mesh skips or failures in the12 previous periodic reports.

For regular grids implied by counts, factor8 gives main edge spacing about85 units versus about16 for wading. Different linear approximations can intersect even when sampled from the same height field. This is a concrete candidate, not demonstrated pixel provenance. Master ENB water OFF still retains SurfaceTides mesh-input architecture when ENB is installed; it excludes ENB water effects as a necessary trigger, not this shared rendering path.

## Changes

Rendering.MeshTessellationMax integer8..16, fallback8, supplied16. Compiled into our MeshInput HS maximum and adaptive factor clamps. All source families use the same setting; short edges still request smaller adaptive factors. Cache keys need not include this startup-only value. No live updates supported. SO capacity calculation now takes factor, retaining stride40/56 checks and128MiB upper guard.1536 source indices at cap16 require71,024,640 bytes for40-byte vertices,99,434,496 for56-byte history. Unsupported/oversized inputs retain existing native fallback, not a per-draw lower factor that could create seams. Higher cap may cost approximately four times as much preparation geometry on affected coarse triangles; actual FPS unknown. Independent triangles still do not align exactly.

Rendering.MeshTwoSided boolean, fallbackfalse, suppliedtrue. Only the visible prepared draw gets a cloned rasterizer state with CullMode NONE; RAII restores original. Native depth/stencil/bias/front convention/scissor untouched, offscreen preparation unchanged. Preserve RasterizerState2 and State1 extended descriptors when present, including conservative rasterization/forced sample count. Cache at most64 variants, retaining original COM references to prevent pointer reuse. Clone failure or cache exhaustion retains native state. No engine visibility, shader discard or native hull-culling repair is claimed. Native draws outside the prepared patch are unchanged. Extra overdraw or underside material differences need testing.

RippleTrace adds underwater technique8 as fourth family, native cull/frontCCW/depthClip fields. Maximum32 scopes/352 lines plus normal stats, no readback. Mesh report adds maxFactor/twoSidedDraws. Native motion option remains off. Solver, interactions, Water.hlsl, SurfaceField.hlsli and FrameBuffer.hlsli unchanged. No ENB code, shader contents, bytecode inspection, resource contents, SDK or decompilation used. No subagents.

## User comparison

Use full0.1.16 package/INI. First compare same lake and underwater view with usual ENB settings. Send normal log, visual result and FPS. Optional isolation after that: cap8 with two-sided1 restores earlier density; cap16 with two-sided0 restores native culling. Restart for each INI change. Do not call the candidate a confirmed fix before user testing. If ripples persist, consider matching the two surface representations more directly; merely increasing density cannot guarantee coincidence. If underwater holes persist despite nonzero twoSidedDraws, investigate pass submission/depth/hull behavior rather than increasing displacement or blaming ENB.

## Build recovery and validation

Authoritative tree recovered/SurfaceTides. A truncated44MiB LLVM archive and truncated38MiB libclang-cpp caused compiler startup SIGBUS. Re-downloaded official LLVM-MinGW20260826 archive (about80MiB), extracted to a fresh directory, and verified clang --version. Reusing the old tool directory still produced inconsistent/truncated compiler files on subsequent calls; use the unique work-tools/st0116-toolchain/llvm-mingw-20260826-ucrt-ubuntu-22.04-x86_64 directory instead. Fresh configured build is build/windows-0116; do not resume windows-cross for this version. Fresh libclang-cpp is55,467,320 bytes. Preserve this fact to avoid repeating shader debugging for a host-tool failure. Stale Ninja dependency database moved to /tmp/st0116-old-ninja-deps; full rebuild required. Official Microsoft DXC v1.9.2607 downloaded only as a host validation tool, not distributed.

Portable suite19/19 PASS, including cap8/cap16/stride40/56/128MiB checks. Mesh shader65/65 DXC SM6 semantic checks PASS (8 attribute families x4 stages x2 caps plus motion VS). This does not establish native SM5 or runtime D3D state correctness. Native Windows shader test source covers both caps; executable will be cross-built but cannot run here. Skyrim unavailable. Final link/hash results appended after successful build.

Persist source over libfile_4355a322deb481918f58dfaa7d9c03c5 guard27, latest installer over libfile_09c5e26b5238819187b073e8c574a1df guard15, and create separate0.1.16 installer. Keep0.1.15 DLL hash aa8642c8c4dfa819643b8c01812066dfe300aa7f1909e4b6916b25cda5bcc154 baseline untouched. All modifications preserved in source, no user footage bundled.

## Completed build

Fresh Windows build/windows-0116 compile/link exit0,391 actions. Portable19/19 and DXC65/65 as above. AMD64, both SKSE exports, and system DLL imports verified. Native validation executables refreshed; native SM5 execution not performed. Existing compiler/vendor warnings only. No in-game validation performed.

DLL SHA256: cd1218d22c4fa5a90caebc6997d8abdfd4d0dd10d886419fdde2247b4ff346b8

Save batch intends source27->28 and latest15->16, plus new versioned installer. Retain the actual save receipts to confirm version guards for future work.
