# Surface Tides 0.1.20.1 — AE foam discovery crash hotfix

The first 0.1.20 attached-foam test crashed while scanning loaded objects. This hotfix corrects that discovery path. **User result, 2026-09-15: the crash is gone and initial attached-foam behavior appears correct.** Broader location testing continues. The published hotfix ZIP retains its original pending-test manifest as historical build evidence; these later source notes record the returned result.

## Install and test

Install `SurfaceTides-0.1.20.1-foam-hotfix.zip` after the previous Surface Tides updates, allowing its DLL to win. Keep your current INI, including `[Objects] HideAttachedFoam=1`, and retry loading the same save. No other load-order change is requested. The separate standalone BOS preset can remain enabled. Master ENB water and experimental integration should remain off for the accepted coexistence setup.

The log should begin `SurfaceTides 0.1.20.1 development (AE foam discovery fix)`. It also identifies discovery through the player cell/worldspace and attached grid. If loading succeeds, check the two rapid-rock examples: only their reviewed attached foam shapes should disappear. Waterfall impact rings remain excluded. Return SurfaceTides.log and the new crash log if a crash persists.

This overlay preserves the INI and includes the unchanged accepted shaders. Selection profiles, loaded-shape visibility handling, rocks/collision, menu tuning/saving and simulation behavior are unchanged from the intended 0.1.20 feature. The filter still defaults off when its key is absent.

For a rollback to the established stress-test build, use 0.1.19.2 and disable the 0.1.20/0.1.20.1 DLL overlays. **Do not return to the original 0.1.20 DLL with HideAttachedFoam=1**: that is the known crashing build. Alternatively, HideAttachedFoam=0 with a restart bypasses the new feature. The BOS preset is independent and can be disabled separately.

## Evidence and correction

Input: `crash-2026-09-15-00-56-10.log`, Skyrim 1.6.1170. The crash is at SkyrimSE+0x030B0B3, Address Library ID 20543+0x43, reading through the noncanonical value `0x456FB00045305000`. The supplied library maps ID 20543 to TESWorldSpace::GetSkyCell.

The shipped DLL's actual machine code matches the return addresses:

| SurfaceTides return RVA | Matched call |
|---|---|
| 0x00B2CEB | TESWorldSpace::GetSkyCell wrapper returning from engine function 20543 |
| 0x007C668 | TES::ForEachReference sky-cell tail, after loading the supposed worldspace from TES+0x140 |
| 0x00382ED | New attached-foam discovery calling TES::ForEachReference |

The bundled TES header gates its AE tail layout on `SKYRIM_SUPPORT_AE`, while this NG build defines `ENABLE_SKYRIM_AE`. The compiled global iterator therefore treats the data at TES+0x140 as a worldspace pointer. The log and disassembly identify this invalid-pointer path; merely waiting longer or changing meshes does not correct that layout mismatch.

The hotfix uses the player's parent cell to select interior or exterior discovery, walks the attached exterior grid when appropriate, and obtains the exterior worldspace from `player->GetWorldspace()`. That accessor uses TESObjectCELL's version-aware runtime data and is already used by the accepted simulation. The sky cell is still visited through that worldspace, preserving persistent-reference discovery. The global TES iterator and its stale worldspace member are not used by the foam filter.

The change is local to foam discovery. No global compatibility macro or third-party layout definitions were changed. Discovery also propagates the reference-limit stop across cells. No ENB code or new mod dependency is introduced.

The crash log contains other mods in the update chain and a nearby rock reference; those entries alone do not demonstrate a conflict. This fix addresses the invalid lookup made by Surface Tides. It does not claim to exclude every unrelated future crash.

## Validation and continuity

- Windows x64 Release DLL compiled and linked with the existing MSVC-ABI toolchain; normal SKSE exports and imports checked.
- Compiled-object regression check: the original 0.1.20 object fails the guard; the hotfix has no dependency on TES::ForEachReference or its range variant, and resolves through GetWorldspace/GetSkyCell/cell-local iteration instead.
- The corrected call chain was inspected in machine code. A linker map is retained with this source checkpoint for future crash-address lookup; it is not installed in Data.
- The existing 22 portable tests and seven-NIF/15-geometry audit are prior validation of unchanged solver/selection logic. They did not execute Skyrim's global TES iterator and could not detect this crash. The hotfix's new check targets that compiled dependency specifically.
- Package checks confirm byte-identical accepted shaders, an untouched INI, unchanged BOS preset, and the preserved 0.1.19.2 rollback.
- Full in-game loading, foam suppression and cell transitions remain to be verified by the user.

The original 0.1.20 recovery ZIP is retained solely as a known-failing diagnostic artifact. The source checkpoint includes the matched disassembly excerpts, input-log hash, build validation, regression result and hotfix package manifest. The user's full crash log is not redistributed. CS coexistence and ice-floe work remain deferred while foam is tested.
