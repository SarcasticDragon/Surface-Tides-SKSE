# Surface Tides 0.1.25 — Community Shaders coexistence test

**Update, 2026-09-15:** the first user test passed: normal simulation, no immediate visual issues, and clean Surface Tides draw/probe diagnostics. See [CS-0.1.25-ACCEPTED.md](CS-0.1.25-ACCEPTED.md). The original build notes below are retained as the initial test procedure; the exact installer is unchanged.

The previous build deliberately disabled Surface Tides whenever CommunityShaders.dll was loaded. That guard explains why disabling Unified Water alone did not activate the simulation. This build adds an explicit CS coexistence opt-in. It is the first CS test build, not a confirmed compatibility release.

The user reports that 0.1.24.3's jump release works well. Its floe, foam and simulation implementations are retained exactly. Ice is Slick remains incompatible with ice bobbing for now. All five accepted water shaders are unchanged, including the shoreline and underwater corrections.

## Install

1. Install `SurfaceTides-0.1.25-CS-coexistence.zip` after the current Surface Tides build in your CS testing profile.
2. Add `AllowCS=1` under the existing `[Compatibility]` section of `Data/SKSE/Plugins/SurfaceTides.ini`. Your INI is not included in the overlay, so existing tuning is preserved.
3. Restart Skyrim. Keep CS water processing disabled for this test; do not toggle it on during the session.

The overlay includes `SKSE/Plugins/CommunityShaders/Overrides/SurfaceTides_Global.json`. Through CS's settings override system, it requests exactly these three values:

| CS setting | Value | Purpose |
| --- | --- | --- |
| Replace Original Shaders / Water | false | Let Surface Tides identify the original water shader records and supply its water rendering. |
| Disable at Boot / UnifiedWater | true | Prevent Unified Water's mesh/material/LOD hooks from loading. |
| Disable at Boot / WaterEffects | true | Turn off CS's additional water effects for the initial coexistence test. |

Other shader-class and feature settings are not included in the override. No complete CS preset or user-settings file is replaced. Surface Tides has no CS SDK, binary dependency or copied CS implementation. The configuration file is inert when CS is absent.

CS settings overrides can be overridden by other configuration or user customizations. Surface Tides does not query live CS feature state, and its `present=true` message confirms only that the override file exists. In `CommunityShaders.log`, check for `Applied global override from SurfaceTides` and the boot-disabled entries for `UnifiedWater` and `WaterEffects`. Also confirm Water is unchecked under Replace Original Shaders in CS's advanced settings. Menu placement can differ between CS versions; the inspected source puts these controls under Advanced / Developer and Advanced / Disable at Boot. Save and restart if manual changes are needed.

The user's installed CS version was not supplied for this build. If it does not support this override format, make those same three changes through its menu and restart. Return the CS log/settings if the controls or configuration differ; do not rename guessed JSON keys.

## What changed

`AllowCS` defaults to0. With CS present and the opt-in enabled, Surface Tides selects its standalone water renderer and activates the existing D3D shader-identity/context-forwarding diagnostics for coexistence. It still replaces only positively identified water draws. It does not guess that an unfamiliar CS shader is a compatible vanilla permutation.

The ENB-specific mesh-input path and constant-buffer repair are not selected for a CS session. An old enbseries.ini or an unrelated graphics proxy no longer routes a CS session into the ENB configuration check. Simultaneous CommunityShaders.dll and enbseries.dll remain outside this test. When CS is absent, the accepted standalone/ENB startup branch is unchanged.

The included water configuration uses existing CS controls, not private memory writes or replacement of its DLL. The first test may expose further differences in CS's shared water composition, lighting or render targets. Passing the startup guard is not proof of visual compatibility.

## Test result needed

Check visible idle displacement and wakes in a river and lake, plus an underwater view. Please return both `SurfaceTides.log` and `CommunityShaders.log`, even if the initial result looks good. Surface Tides logs its selected mode, native shader matching, bound/tessellated draws, rejected pipeline states and sampled downstream binding changes. Normal five-second statistics are sufficient; `WaterPassTrace` and `RippleTrace` can remain off unless requested later.

Build validation passes: Windows AMD64 DLL, SKSE exports, source comparison, prior discovery-crash regressions and all45 portable groups. DLL1566208 bytes; SHA256 `782ebc27de156d18e3ceac6e403e565973fa4afa15c63de337dda7799d458500`. These checks do not run Skyrim or validate CS visuals/performance.

To roll back, remove this overlay, restore0.1.24.3 and remove its `SurfaceTides_Global.json` override. That DLL still blocks CS. Restore CS's own water settings as desired and restart; settings saved by CS while the override was active may remain disabled after the override is removed.

## Primary references

Inspected upstream commit `dd2677fc4020db1da91b39cebef3dbfbe8913983` (2026-08-25), retrieved2026-09-15. This is a source reference, not identification of the user's installed CS version.

- [CS shader-class selection and settings loading](https://github.com/community-shaders/skyrim-community-shaders/blob/dd2677fc4020db1da91b39cebef3dbfbe8913983/src/State.cpp).
- [Native VS/PS fallback when a class is disabled](https://github.com/community-shaders/skyrim-community-shaders/blob/dd2677fc4020db1da91b39cebef3dbfbe8913983/src/Hooks.cpp).
- [Global settings override loading and merging](https://github.com/community-shaders/skyrim-community-shaders/blob/dd2677fc4020db1da91b39cebef3dbfbe8913983/src/SettingsOverrideManager.cpp).
- [Unified Water's startup mesh/material/LOD hooks](https://github.com/community-shaders/skyrim-community-shaders/blob/dd2677fc4020db1da91b39cebef3dbfbe8913983/src/Features/UnifiedWater.cpp).

No ENB source was retrieved, inspected or incorporated for this change.
