# Surface Tides 0.1.21 — attached ice slush removal

Later user result: the first solid01 slush filter appears to work. The user supplied both remaining meshes and selected E7B8A~Skyrim.esm for motion. Continue with [FLOES-0.1.22.md](FLOES-0.1.22.md); this document records the earlier single-profile build.

The supplied `icefloessolid01.nif` has separate slush and solid-ice geometry. This build adds an optional loaded-instance visibility filter for the reviewed slush shape. No NIF or texture replacement is required. It retains the accepted 0.1.20.1 reference-discovery crash fix and the existing foam profiles.

## Installation and first test

Install `SurfaceTides-0.1.21-ice-slush-update.zip` after the previous Surface Tides updates so its DLL wins. The ZIP deliberately contains no INI, preserving your live-tuned settings. Add `HideIceDecals=1` to the existing `[Objects]` section of your current `SurfaceTides.ini`, then restart Skyrim. Keep your existing `HideAttachedFoam` setting. The new key defaults to 0 if absent and is shown under the menu's read-only startup settings.

Test a placed `IceFloesSolid01` example (base form `0x08CCFE~Skyrim.esm`, path `landscape\ice\icefloessolid01.nif`). The surrounding thin slush should disappear while the solid ice and collision remain. Other ice models are deliberately unmodified. The log identifies `HideIceDecals=true` and successful `IceDecals: ref=... matched=1 hidden=1 solid geometry retained` matches. A mismatched runtime variant is reported as incomplete/ambiguous and left visible.

Toggle the simulation preview off and on to check restoration/reapplication, then leave and return to the cell. To disable only this filter, set `HideIceDecals=0` and restart. To revert the DLL, disable this overlay and reveal the accepted 0.1.20.1 hotfix. Do not restore the withdrawn original 0.1.20 DLL with its foam filter enabled.

## Evidence from the user's mesh

Input SHA256: `038e772a9d8c3503eff36e5c39d7c5c7f36eda4d32de0738f092490cc4621959` (89,566 bytes). Read-only inspection using ousnius/nifly commit `cca0a770094bb962fb28ea1fec5ea903e68fda8e`. The input NIF is not redistributed.

| Block | Geometry | Material textures | Action |
|---|---|---|---|
| 7 | `L1_IceFloesSolidSlush`, 134 vertices / 223 triangles | `landscape/IceFloes.dds`, `landscape/IceFloes_n.dds` | Hide this shape only |
| 11 | `IceFloesSolid01:0`, 1,112 vertices / 1,862 triangles | `landscape/GlacierSlab.dds`, `landscape/GlacierSlab_n.dds` | Retain |
| 0 / 6 / 5 | Parent BSFadeNode / bhkCollisionObject / bhkRigidBody | One parent collision body, MOPP/compressed shape | Retain unchanged |

Both visible shapes use BSLightingShaderProperty. Slush extends over roughly 2,200 × 2,239 local units and Z −51.55 to +2.08; the solid shape spans roughly 1,552 × 1,659 units and Z −150.55 to +28.87. The slush is not mathematically flat, but is structurally separate. The root body is serialized with motion system 5, mass 0, and no translation. Neither child owns collision or a controller.

Selection requires the reviewed full model path, slush shape name, lighting material, diffuse and normal texture paths, absence of child collision/controllers, and the expected solid shape elsewhere in the bounded tree. Ambiguous/duplicate profiles remain visible. Different texture resolutions at the same paths are supported by this selector; different names/paths/merged layouts need inspection. This is not blanket compatibility with every ice replacer.

The manager uses the same 128-reference/128-node bounds and safe attached-cell traversal as the foam hotfix. It stores original visibility ownership, retains handles/root pointers, restores only its changes, and re-resolves on 3D reload. Shader materials, the collision body and source files are never altered. Foam and ice have independent startup switches.

## Bobbing work included in source

`FloeMotion.hpp/.cpp` implements the CPU sampling and motion-target foundation, with eight portable test groups. It shares the float4 texel representation already uploaded by the renderer. The sampler reproduces bilinear height/wet interpolation, multiplication order, cell-center convention, patch edge fade, strict 2-unit rest-height band and displacement scaling. It requires a matching nonzero area identity. NormalStrength does not affect motion.

The target fitter samples a yaw-rotated 3×3 footprint and fits mean heave and world-space slope, with combined tilt and heave bounds. The response uses elapsed time rather than an independent wave oscillator. Invalid coverage settles toward the authored resting pose; no artificial bobbing is generated. This is a first rigid-plane approximation, not full buoyancy or shape-conforming motion.

**No runtime bobbing is wired or enabled in this DLL.** The core is compiled into the development library and exercised in tests; it does not discover/move references. There is no Bobbing Framework dependency. No code from Bobbing Framework, CS or ENB has been copied into this feature.

The next engine adapter must pair actual field/tuning snapshots and area/epoch, retain the authored transform/freeboard/pivot, apply the target to both visible ice and collision, and handle standing actors, reload/reset and ownership restoration. Moving only the visible node is insufficient. Rendering may lag simulation publication; synchronization still needs runtime measurement. The current simulation covers one nearby patch and water level, not every floe in the Sea of Ghosts simultaneously.

Next input: `icefloes01.nif` and `icefloessolid02.nif` from the winning assets for additional slush profiles, plus one small detached placed floe's **reference ID and originating plugin** for the motion proof. A base-form ID alone selects all placements and cannot establish that a particular floe is detached/free-floating. Prefer a non-quest placement without a grounded connection or an existing bobbing controller. The supplied solid01's single collision body also means separate visible pieces in that model, if any, would move together unless the asset/collision structure is split.

## Validation and release status

- Windows x64 MSVC-ABI DLL compile/link passed. AMD64, both SKSE exports and system-only imports checked.
- Portable solver/regression suite: 22/22. New ice/floe suite: 8/8. The latter includes an actual solver impulse passed through the new sampler and fitter.
- Captured NIF selector audit: 17 geometry cases from eight supplied meshes; exactly the original three foam shapes and one slush shape selected. Solid geometry and waterfall rings excluded.
- Compiled discovery guard passed with the original crashing 0.1.20 object as a negative control. No global `TES::ForEachReference` dependency was reintroduced.
- All five water shaders, renderer/hooks and physical solver source match the accepted checkpoint. Texel representation has an identical 16-byte layout. No HLSL changes or extra water draw passes.
- Native Windows test executables/Skyrim were not executed here. Ice filtering still requires the user's in-game confirmation. Collision/occupant motion is explicitly pending.

The user confirms 0.1.20.1 fixes the load crash and initial attached-foam behavior looks correct; wider location testing continues. That accepted ZIP and the 0.1.19.2 water rollback remain preserved byte-for-byte in `recovery/`. ENB master-water-OFF coexistence remains the accepted configuration; full water integration stays experimental/off and CS is still future work.
