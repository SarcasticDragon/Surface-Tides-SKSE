# SurfaceTides 0.1.17 shoreline-r1: resume and test record

## User result and scope

ENB master-water-OFF coexistence is now user-confirmed on0.1.17. With Water for ENB introduced, small pieces of shoreline rocks appear intermittently refracted. User suggests either replacement meshes or water displacement briefly exposing a submerged part of the water mesh. Both remain hypotheses. New evidence is Sequence #1(15).mp4, attachment libfile_1156fe31ce3c8191bdf23b7619533c9c,6.0833seconds,2560x1440/60fps. Read locally from upload/; examined full-size frames and consecutive crops near the large shoreline rock. No new log accompanied this report. Do not reuse the previous standalone log as evidence of this run's shader descriptors or settings.

Confirmed packages remain unchanged: standalone libfile_aefb4e1935f881919c25657373184782 and ENB coexistence libfile_a248074fec308191b70024cd2c8760f9, both version0. DLL SHA256:5239ecd7f403fb73f0377bedfb3cf33bbe23d204962c8303a06836b7de8c857c. Continue with renderer-neutral SurfaceTides water; native ENB integration stays experimental/off, CS remains a later separate adapter and is currently gated. No subagents, ENB implementation code, shaders/bytecode or SDK used.

## Evidence and candidate

Water.hlsl's old foreground-refraction rejection compares against ReflectPlane, the original flat plane. It also reconstructs the distorted lookup using the fragment's original view direction. The vertex/domain stages have displaced the actual surface. At a moving shoreline, the old plane test therefore does not reliably represent the rendered surface. A wave crossing a rock can legitimately expose a new sliver of water; that alone is not a missing-mesh bug. The clip cannot distinguish that geometry from incorrect sampling or establish which Water for ENB component triggers it.

shoreline-r1 replaces this rejection only in above-water refraction passes with scene DEPTH and without VERTEX_ALPHA_DEPTH. It linearizes the rasterized SV_Position.z using the same CameraData conversion as the scene-depth texture; reuses the existing unperturbed scene-depth read; fades UV distortion over the first24 view-depth units; rejects foreground and out-of-bounds proposed samples; and checks the final, faded UV again because changing coordinates can cross a foreground silhouette. Conversion from raw UV back to depth pixels removes VPOSOffset.zw before scaling. Two candidate depth reads replace the old one; no new rendering pass or mesh preprocessing is added.

Wave height, simulation normals, opacity, water fog, reflection/SSR, original textures, underwater shading and all geometry stages remain unchanged. No new constants or resources, INI keys or hooks. Source default AllowENB remains0; optional coexistence preset remains1. No C++/DLL changes; log and binary version remain0.1.17.

This is a screen-space approximation, not ray-traced refraction or rock collision. It compares against the current fragment depth, not the exact water intersection along every refracted ray, and uses point depth checks rather than a full color-filter footprint. It cannot recover hidden background geometry. Depth-less/vertex-alpha-depth passes retain baseline behavior. It does not fix intersecting decorative meshes or foam, nor establish whether this footage uses any such mesh. Preserve the baseline and evaluate the candidate before adopting it as a general fix.

## Installation and next test

SurfaceTides-0.1.17-shoreline-r1.zip is a removable shader overlay, with Shaders/SurfaceTides/Water.hlsl at its Data root plus notes/license files. Install after the confirmed0.1.17 package and let the shader win. Restart the game; the DLL compiles loose shaders at runtime and keeps them in memory for that process. No INI changes or disk shader-cache deletion required. ENB [EFFECT] EnableWater must remain saved false and Experimental.ENBWaterIntegration0.

Repeat the same shoreline approach with Water for ENB active. Check the moving rock fragments and ensure the established waves/wakes remain readable. Send a short comparison clip and ordinary SurfaceTides.log; the startup version will still be0.1.17, so identify the shader overlay in the report. Disable the overlay and restart to restore the known shader (manual installs can reinstall the confirmed full package).

If the candidate does not change the artifact, the next bounded diagnostic is ST_SHORE_REFRACTION=2 at the top of Water.hlsl, followed by restart. This removes optical refraction offset on the SAME above-water depth-supported passes while preserving geometry/normals/reflections. It is not an INI setting and does not disable every possible water pass. A remaining artifact could involve reflection/SSR, geometry or an unaffected shader family; mode2 alone cannot prove meshes are responsible. Mode0 compiles the original baseline refraction behavior. Modes0/2 are developer diagnostics, not additional user settings to tune initially.

## Verification

Microsoft DXC1.9.2607 from its official Linux2026-07-29 release used for SM6 syntax/semantics. The portable reference-header generator was built from unchanged source using host g++. tools/validate_shore_scope.py checks23 representative/previously observed descriptors across five stages for original shader and candidate modes0/1/2:460 successful compilations. Mode0 gives115 byte-identical DXIL outputs against the unmodified shader. All vertex/control/hull/domain outputs and underwater/stencil/non-target PS outputs are byte-identical to baseline in modes1/2. Only nine above-water refraction PS families change (001E,005E,071E,075E,003E,015E,031E,011E,035E). See shoreline-r1-validation.txt.

Example validation command (use actual local tool/fixture paths):

```
python3 tools/validate_shore_scope.py --dxc /path/to/dxc --reference /path/to/SurfaceTidesReference --baseline-water /path/to/unmodified/Water.hlsl
```

The pre-existing full140-check HLSL validator also passed during development before the final equivalent baseline-branch/scene-depth-reuse refactor. The final460 scope checks cover the changed water code. Unchanged MeshInput has no new test requirement. Windows SM5, live engine remaps, actual visuals and GPU cost are not verified here. Do not describe this candidate as an in-game fix before user confirmation. No new DLL compilation, Wine attempt or repeated solver tests.

Public technical reference: [Microsoft HLSL semantics](https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl-semantics). Public [Water for ENB author page](https://www.nexusmods.com/skyrimspecialedition/mods/37061) reviewed only for context; no assets inspected, changed or redistributed. User's installed version/options remain unknown. No attribution of fault to that mod is established.

## Recovery and saving

Recovered authoritative source version30 from libfile_4355a322deb481918f58dfaa7d9c03c5 and coexistence installer version0 into recovery-shore18. Working source is project-shore18/SurfaceTides. Other recovered project trees may be stale. Source modifications:Water.hlsl, this checkpoint, validation report/tool and current README/validation/coexistence status. No other code/configuration changes. Latest full installer can be assembled from confirmed0.1.17 coexistence bytes with this shader and current docs overlaid; the user-facing patch is shader-only. Preserve standalone/coexistence/experimental-native rollback identities.

Save source over version30; latest installer libfile_09c5e26b5238819187b073e8c574a1df over version18; create distinct SurfaceTides-0.1.17-shoreline-r1.zip. Use actual final save receipts for subsequent version guards. No source-control remote exists, so preserve all authored source and documentation in the source archive.

## Final package verification

Water.hlsl SHA256:c253ae2f5a77ad6fc5c81dad3865e8a9f62d961c8230034a98e9f1ec9232413d

Original source entries differ only in Water.hlsl, README.md, VALIDATION.md and COEXISTENCE-0.1.17.md; checkpoint/report/scope tool are new. Full candidate installer preserves every original non-document file except Water.hlsl, including the exact DLL and INI. Overlay contains no DLL/INI. ZIP integrity and baseline comparisons verified before saving. Source project version remains0.1.17 with explicitly named shoreline-r1 shader revision.

## Subsequent user result

User reports artifacts mostly remain after r1, but now appear confined to the water. Brighter weather in Sequence #1(16).mp4 is unrelated. The new log shows successful rendering. See SHORELINE-DIAGNOSTICS-R2.md for separate refraction/SSR isolation overlays; no further rendering fix is adopted yet.
