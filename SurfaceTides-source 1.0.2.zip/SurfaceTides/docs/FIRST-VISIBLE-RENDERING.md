# First confirmed visible rendering — 0.1.4

User SurfaceTides(4).log and ScreenShot2.png, September9 2026, Skyrim1.6.1170 near Riverwood. Diagnostic colors appear on water. Green covers local wet field, blue follows coarse shore mask, magenta covers water outside local XY patch. This is the first user-confirmed visible replacement rendering; do not regress to vtable-only draw hooks.

Evidence: shader pairs5000,31E,802,1002 compile successfully. Renderer uploadedSeq advances1->1158->2358->3558->4758. After startup, bound water draws19026..22800 per five-second interval, all marked tessellated, failed0. CPU wet17600/36864, epoch1, maxHeight0.2894..0.3878, nonzero slopes/velocities. Player stationary, impulsesSinceReport0 as expected. This test does not validate moving-character wakes or visible displacement without overlay.

Hook health: targetMask00, entryMask7F, immediateContextSame=true; foreign/noOwner/disabled all0. Thus current context table draw targets differ from the original hooked addresses, while detoured entry bytes remain unchanged and those functions continue receiving calls. Do not conclude specifically cached calls vs wrapper forwarding from this alone. No need to auto-repatch tables: direct entry hooks are visibly working. Raw scanned draw calls reach~5.46million per five seconds; profiling hook overhead is a later task, not proof of an error. Most are correctly rejected as non-water.

Next user test requires no rebuild: change [Diagnostics] DebugView=0, keep LogStats=1, restart, wade through shallow water then stop and watch for wakes spreading/decaying. Leave remaining settings unchanged. Wind-only waves in this stationary run peak around0.3..0.4 Skyrim world units, so do not promise large visible swells. Request a short clip and log if ordinary visuals remain indistinguishable. Graphics fidelity, tessellation displacement, wake visibility and performance still need acceptance testing.

No DLL or shader changes for this checkpoint. Existing0.1.4 install package remains current. Source archive updated only with this evidence and validation note.
