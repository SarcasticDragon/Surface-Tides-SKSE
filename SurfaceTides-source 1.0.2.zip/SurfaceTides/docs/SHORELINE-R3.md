# Shoreline r3: displaced depth for material blending

## Subsequent user result, September 12

The artifact remains with ENB removed and Water for ENB retained. The new log supports native D3D rendering; the remaining ENB label comes from an INI on disk. See SHORELINE-NATIVE-CONTROLS.md. This supersedes the earlier proposed fallback below: keep the currently installed shader fixed while testing plugin-disabled and zero-displacement controls. Do not return to r1 at the same time as changing the displacement setting. No new shader candidate is issued in this follow-up.

## Latest evidence and interpretation

User reports A (refraction distortion removed) made no visible change. B (SurfaceTides SSR contribution removed) appeared to restore the original shoreline bleed. No new clip or log accompanied these results. Do not treat the earlier log as verification of these two runs or assume their winning file/runtime compilation was independently established.

A weakens the hypothesis that refraction UV distortion alone causes the remaining fragments on the tested surface. B did not fix them either. B retains r1 refraction and uses the existing cubemap/planar reflection contribution without SSR. That can change which artifacts are visible, but it does not by itself establish why shoreline bleed appears worse. It is not proof of a mesh fault, a new ENB bug, or an SSR-only cause.

Review of Renderer.cpp and ConstantBinding.hpp found no evidence justifying a new hook/buffer repair: unused engine constants are reflected and remapped, and the shifted-buffer repair requires exact group sizes plus a distinct inserted large buffer. No current A/B log is available to verify their live bindings. Do not claim this audit rules out all runtime binding problems.

## Remaining source inconsistency

R1 modified the foreground test for refraction sampling in GetWaterDiffuseColor. The main water pixel shader still computes distanceMul using the original ReflectPlane.w. distanceMul controls shallow/deep color, attenuation and depth-dependent reflection/normal/sun weighting through DepthControl. Neither diagnostic A nor B changed that calculation. Thus the water geometry moves but these material-depth weights still use the rest plane. This is a concrete code inconsistency, not yet a proven explanation of this user's residual artifacts.

R3 computes the actual interpolated vertical displacement:

```
displacedHeight = input.WPosition.z + PosAdjust.z - input.STBaseHeight;
depthPlaneDistance = ReflectPlane.w - ReflectPlane.z * displacedHeight;
```

It substitutes depthPlaneDistance only for the main depth-blend calculation. The sign follows the existing plane convention: w=dot(-restPosition,n); translating the plane vertically by dz changes w by -n.z*dz. No new field sample is used: the displaced geometry itself supplies the offset, so the depth calculation matches the rendered triangle, including interpolation. At zero displacement the plane is unchanged.

This correction applies to above-water scene-DEPTH passes without VERTEX_ALPHA_DEPTH and excludes UNDERWATER/LOD. It does not change the reflection capture plane or regenerate captured textures. Both r1 refraction and the ordinary SSR contribution are enabled in the candidate. No simulation, wave-amplitude/normal-strength setting, mesh, tessellation, texture, hook or INI changes. Depth-dependent normal weighting and apparent water clarity may change as part of the corrected material blend; they are not claimed pixel-identical. The existing division/saturation and depth convention remain otherwise intact. It is still a local plane approximation, not refracted-ray intersection with the full wave field or arbitrary rock collision.

Source ST_DISPLACED_DEPTH_BLEND defaults0, preserving r1 behavior until testing. The r3 overlay sets1. ST_SHORE_REFRACTION=1 and ST_DIAGNOSTIC_NO_SSR=0. These are shader-build switches, not live/INI settings. DLL and startup version remain0.1.17.

## Verification

tools/check_depth_blend_geometry.py independently constructs eye/scene rays and intersects them with known displaced horizontal planes. Eight analytical cases pass, including crest-over-rock, trough, contact, foreground scene, grazing ray and camera-relative translated coordinates. The old calculation yields0 instead of28 depth units for a rock below a crest but above the rest plane, and60 instead of20 below a trough; the corrected calculation matches the geometric distances. This checks the mathematical model in host arithmetic, not actual engine constants or GPU float32 rendering. Output:shoreline-r3-geometry-check.txt.

tools/validate_depth_blend_shaders.py compiles27 representative/previously observed descriptors across five stages for saved r2 defaults, new defaults, and actual packaged r3 macro configuration:405/405 DXC SM6 compilations pass.135 new-default outputs are byte-identical to saved r2 defaults (already shown to match r1 rendering). All geometry stages, underwater/stencil and non-target pixel shader outputs remain byte-identical in r3. Eleven above-water depth PS variants change, including depth shading without refraction. Every PS resource-binding table matches baseline; refraction/SSR resources remain present. Output:shoreline-r3-shader-validation.txt.

No new DLL build, CPU solver test rerun, Wine attempt, SM5 execution or in-game test performed here. The new shader needs the user's Windows/runtime test. Native test binaries remain unchanged. The change adds arithmetic only, with no extra texture fetch or render pass; actual performance is not measured.

## Installation and next test

Install SurfaceTides-0.1.17-shoreline-r3.zip as a separate overlay after SurfaceTides/r1. Disable both A and B diagnostics and let r3 Water.hlsl win. It includes r1 refraction plus this depth-blending correction and restores the normal SSR contribution. Keep ENB master water OFF and experimental integration0, leave wave settings as before, and restart. No INI edit or shader-cache deletion required. Same0.1.17 log version is expected.

Repeat the shoreline view and report whether the fragments/terrain bleed change, ideally with a short clip and ordinary log. The previous A/B result has no accompanying logs, so current compilation confirmation is useful. Disable r3 and restart to return to the underlying r1 shader. Manual installs can restore Water.hlsl from the r1 overlay.

If this candidate also makes no meaningful difference, do not keep changing optical terms without an additional control. Next isolate whether actual displacement is required: return to r1 and temporarily set Rendering.DisplacementStrength=0 while retaining NormalStrength=2, then restart and compare the same shoreline. That preserves simulated shading slopes while flattening our geometry; it is a diagnostic, not a proposed permanent loss of waves. Existing DebugView can later distinguish surface coverage from shaded appearance if needed. Do not run these extra tests initially or describe them as conclusive proof of mesh fault.

## Recovery, constraints and saving

Workspace had reverted: project-shore18 was absent and the local source ZIP hash differed. Recovered authoritative source version32 from libfile_4355a322deb481918f58dfaa7d9c03c5 / file_00000000ef28820cb45033e159bd8c8b into recovery-shore-r3, verified SHA256334f127bf7b76cd9aac81df48b4f9dba8d84a1b9a8c691ce888a2c16411e3a35, extracted to project-shore-r3/SurfaceTides. Do not overwrite from old local projects/deliverables. Fresh official DXC1.9.2607 Linux2026-07-29 tools restored in work-tools/shore-r3-dxc; unchanged reference-header generator built with host g++ to /tmp/SurfaceTidesReference-r3.

Replace source identity version32 with this checkpoint/candidate implementation. Create a separate r3 overlay. Do not change the latest full installer identity libfile_09c5e26b5238819187b073e8c574a1df version19 (r1), r1 overlay libfile_8b74d6e83f708191847f87a5bb51c8b4 version0, A libfile_88879c34ed9481919e09acbe48211324 version0, B libfile_65ee9668c9b881919b72b53b344dae3b version0, or confirmed baseline installers. Use actual save receipts for future source-version guards.

Renderer-neutral policy unchanged; ENB master-water-OFF coexistence remains the supported test direction. Native ENB integration remains experimental/off, CS compatibility remains pending/gated. No ENB implementation code, shader contents, bytecode or SDK used; no Water for ENB assets modified or redistributed. No subagents. No git remote; persist source/checkpoints with the reusable artifacts.

## Final package verification

Overlay contains Water.hlsl plus notes/licenses only; no DLL/INI. Shader macros match the tested r3 configuration:displaced-depth1,refraction1,noSSR0. Existing source files differ only in Water.hlsl,README,VALIDATION and the R2 result checkpoint; new tools/reports and this checkpoint added. All other code, headers, shaders, configuration and native validation executables are preserved. Source defaults remain displaced-depth0. ZIP integrity passed. Prior full installer and overlay identities were not changed.

Shader SHA256:976dea608466c75d28844a09fe43a2307913035a2848d693ba599a1a242d609c

Overlay SHA256:cc3311eef5dede3f3603a7bbe7ddfc731a1891a15570b6d1638cf3f7fe8bdcc2
