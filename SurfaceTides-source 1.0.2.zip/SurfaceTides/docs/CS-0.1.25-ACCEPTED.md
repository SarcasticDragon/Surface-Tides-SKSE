# Surface Tides 0.1.25 — initial CS coexistence accepted

On 2026-09-15 the user reported: the simulation is working normally with CS and there are no immediate visual issues. The supplied Surface Tides log supports a successful first coexistence test. Preserve this exact build for sustained stress testing. No code, DLL, shader, settings or version changes accompany this checkpoint.

## Evidence

Input `SurfaceTides(20260915-135946).log`: 206096 bytes, 862 lines, SHA256 `dfcaf83d98cb31b556cc9f81804687f59bcafe3ba065a88998da118e06f88ec7`. Runtime1.6.1170; Surface Tides0.1.25; CS detected, AllowCS=true, CS coexistence branch selected. Canonical and game immediate contexts are identical. The recording covers approximately49 seconds after the first simulation update.

| Check | Recorded result |
| --- | --- |
| Water shaders | 14 independent permutations compiled; 2172 engine VS and PS records indexed each |
| Water draws bound to Surface Tides | 538929 across10 reports, all tessellated |
| Incompatible / failed draws | 0 / 0 |
| Sampled downstream binding checks | 4211; changedAfterDraw=0 in every report |
| Hook health | All10 reports show targetMask=7F, entryMask=7F; no disabled calls or foreign contexts |
| Log warnings / errors | None |
| Simulation | Field uploads progress; actor impulses active; last reported maximum wave height13.8383 game units |
| Attached foam | Reviewed rapid-rock foam shapes hidden with solid geometry retained |

The numerous non-water/unmatched-VS counts are expected from scanning all scene draws; they are not failed water draws. The probe checks bindings after the downstream draw returns, so it does not prove absence of temporary internal changes. The user observation supplies the visual confirmation.

The CS override file is present. CommunityShaders.log was not supplied, so the exact CS version and explicit application of each boot setting are not independently confirmed. Do not invent them. No active floes appear in this run, so it does not establish ice-rider behavior under CS. The prior successful jump/floe test remains separate evidence.

## Status and next step

The neutrality goal now has an initial successful test with both ENB water off and CS water off, each in its own setup. Surface Tides remains independent of either renderer. This is support for the tested configurations, not a claim about every preset, CS version or feature combination.

Continue stress testing the accepted0.1.25 build. No new diagnostic build is needed. `RippleTrace=1` remains on in this log; setting `[Diagnostics] RippleTrace=0` and retaining `LogStats=1` will keep routine logs smaller. It does not change simulation behavior. Keep the CS water override and existing opt-in. Ice is Slick remains incompatible with ice bobbing for now.

Exact accepted installer `SurfaceTides-0.1.25-CS-coexistence.zip`: 665780 bytes, SHA256 `ee1f818a44fc603695ad9f02c08c32dce15bfeda6a1073bb9d3c3bd87f3527fc`.

DLL: 1566208 bytes, SHA256 `782ebc27de156d18e3ceac6e403e565973fa4afa15c63de337dda7799d458500`.

Water.hlsl: SHA256 `1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e`.

Pre-acceptance source checkpoint: 14918770 bytes, SHA256 `3cb040c1fabf9378cdbe22be410c98005c6ab16878f69df7deffb0ea9854167f`. This documentation-only source replacement retains the exact installer and all prior recoveries. The embedded original installer manifest still says pending because it predates the test; this dated acceptance note supersedes that status without mutating the tested package.
