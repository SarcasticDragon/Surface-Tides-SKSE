# R4 result and next temporal control

**Historical checkpoint; current findings and test: NATIVE-RIPPLE-ISOLATION.md. Do not repeat the controls below.**

## Subsequent clarification: do not repeat TAA control

The user states TAA is already off and AA is normally handled by their ENB. ENB is absent in the retained near-vanilla/Water for ENB comparison. This rules out native TAA needing to be enabled to reproduce the artifact, but it does not by itself identify the problem or disable every independent water/SSR history path. The next existing-INI diagnostic is DebugView=1; see SHORELINE-COVERAGE-CONTROL.md. No new log or video accompanied this clarification.

## Returned result and evidence

The user reports "no banding but no improvement either" from the r4 contact-blend candidate. New attachment Sequence #1(18).mp4: libfile_ee2075ee21ec819192a4705f449969cf / file_000000006f8881fdb7192a016f482637. Read from the supplied local upload path, not through Library. Size29,013,812bytes; duration10.033333seconds;2560x1440,60FPS. No new log accompanied it.

Inspected a one-frame-per-second contact sheet, a full-size frame near6seconds and a sequence of crops at10FPS over the same interval. The character walks/wades near the shallow gravel shoreline and boat; camera framing changes. The reported artifact remains unresolved. These images do not clearly establish whether the affected pixels are visible geometric slivers, optical samples or accumulated frame history. Do not claim measured camera-locked motion or proof of a TAA defect from this inspection.

Retained controls: plugin disabled is clean, and displacement strength0 with normal strength2 is clean. ENB is removed. Water for ENB2.19, Shades of Skyrim,4K remains installed. Thus displacement is required in the returned comparisons; the particular water-replacer component is still not isolated. Do not repeat those controls or ask for a water-replacer update before the next bounded comparison.

R4 did not solve the artifact. No further contact/refraction/color patch is issued here. Keep r4 fixed for the next comparison rather than combining its rollback with a graphics setting change.

## Read-only source audit

Renderer::prepare consumes the exchanged field once between nextFrame calls. nextFrame resets the consumed flag after the game's Present (excluding DXGI_PRESENT_TEST). The current/previous textures and patch origins are paired from current/old GPU frames, with an epoch validity flag; the same field is then supplied to the water geometry stages for that interval. No concrete mid-frame upload error was identified by this code read. That does not prove correct native frame scheduling, constants or history use on the user's machine.

The standalone stencil shader writes water-mask data and motion vectors from current/previous displaced world positions. Therefore disabling height displacement also changes the data feeding later passes; the successful zero-displacement control is not sufficient to exclude temporal processing. CommonLibSSE's bundled ImageSpaceManager/RTTI headers identify temporal AA and a water temporal-AA shader. Their presence does not prove which of those passes ran in the new clip, and a global TAA setting should not be described as disabling every possible accumulated SSR/water history path.

## Next requested control

If native TAA is enabled in this active profile, temporarily disable it using the user's usual graphics configuration, restart, and repeat the same shoreline with r4 and all SurfaceTides/Water for ENB settings unchanged. Retain Enabled=1, DisplacementStrength=2, NormalStrength=2 and ENB absent. Avoid switching to another temporal upscaler/AA method for this comparison. If native TAA is already off, skip the repeat and report that; its current state is unknown.

For a short clip, let the character and camera stop for roughly5seconds, then pan slowly for roughly5seconds. This supplements the on/off comparison with stationary versus moving-camera behavior. Report whether the actual irregular fragments change; ordinary aliasing/shimmer after disabling AA is a separate expected comparison concern, not evidence that the original artifact remains. Restore the previous TAA setting after comparison.

If the artifact disappears, prioritize how displaced water/motion/depth interact with temporal processing, without assuming Water for ENB's meshes are defective or immediately disabling AA as a permanent workaround. If unchanged, native TAA becomes a weaker lead; other history paths are not conclusively excluded. A focused surface-coverage diagnostic may then be more informative than another optical blend. No additional diagnostic overlay is requested yet.

## Preservation and validation

Working source: project-shore-r3/SurfaceTides. Before this turn it matched saved source version35 byte-for-byte. Source archive SHA256c017f6b91e2e44cc947ed9304276bfbd97bcdbfdbf12d0e933fafc6ee815a548,4,007,279bytes. This follow-up edits README and documentation only; no C++, shaders, INI, binary or installer changes, and no repeated compilation/solver tests.

Replace source libfile_4355a322deb481918f58dfaa7d9c03c5 with expected version35; retain the actual receipt. R4 overlay remains libfile_b7dc1a2470fc81919fef9e19e1ce6eef / file_00000000246081f5a2b401b66d906855,version0,SHA2564c54ddb43149ce25e33d37aca26b4c2379f87e057b033bee093b2819e3792c2a. Latest full installer remains libfile_09c5e26b5238819187b073e8c574a1df,version19/r1. Source default contact/depth-blend switches remain0. Preserve the successful baseline and every prior candidate separately.

No ENB code, shader contents, bytecode or SDK used. No Water for ENB assets inspected/modified/redistributed. No subagents. Full native ENB integration remains experimental/off; CS coexistence remains pending/gated. Renderer-neutral project direction unchanged.
