# 0.1.11 user validation and remaining feature-enabled seams

Input: SurfaceTides(20260910-085344).log and Screenshot389.png. User reports enabling ENB water alone with displacement/tessellation/parallax still disabled produces no noticeable defects, only a mild color shift. ENB wave amplitudes are absent. Re-enabling individual features brings back darker water regions, much less severe than the original black patches; intermittent cell-boundary-like seams appear and disappear. No screenshot of the transient seams was captured.

## What is now confirmed

The constant-buffer repair activates correctly in the game, for both31E and35E. For both, engine buffers=[80,224,1296], SurfaceTides required=[80,224,96], shifted native slots=[4976,80,224,1296]. First shifted log at02:50:12.418. Across report intervals,27931 remapped draws,0 unrecognizedLargePrefix,0 incompatible and0 shader failures. No error entries. Runtime requirement reflection and original engine buffer metadata are now demonstrated to work for these encountered pairs.

This supports the candidate repair and user-reported defect-free appearance with the three individual features OFF. It does not certify full ENB processing, all cells/weather or stress stability. Preserve the existing version-named0.1.11 installer as the current candidate;0.1.9 remains the previously confirmed water-OFF rollback. No new DLL or shader edits in this follow-up.

## Remaining evidence

4584 identified game water draws fail to match a native draw signature across the log's report intervals. First such interval at02:50:55.497 (171 misses); peak638 misses/interval. Matching requires identical direct-draw kind, arguments and topology in one synchronous wrapper scope. Changed topology or draw shape with ENB features enabled is a hypothesis; this log has no detailed native pass capture (WaterPassTrace=false) and no precise feature-toggle times, so it does not prove which feature or mechanism caused misses. Previous tests showed black patches even in intervals with100%matching; do not equate all darkness with missed draws now.

Screenshot389.png, successfully viewed, shows reflective/displaced foreground water and broad dark regions across middle/background. It cannot establish true cell boundaries, identify a particular pass or confirm a tessellation crack. Do not assume FYX is responsible; it is unchanged from successful tests.

Missing ENB wave amplitude is expected under this architecture: SurfaceTides supplies its own vertex/hull/domain displacement, and its simulation never reads ENB amplitude parameters or combines the two height fields. Pixel-shader replacement also means preserving textures is not equivalent to preserving ENB water shading. Separate these functional limits from the remaining dark-region defect.

## Next useful capture (same0.1.11 DLL)

The existing detailed trace was taken with individual ENB water features disabled. Need a trace comparing those disabled/enabled while the ENB master water switch stays ON, using the repaired build.

In SurfaceTides.ini set [Diagnostics] WaterPassTrace=1, retain LogStats=1 and [Compatibility] RestoreWaterConstants=1. Restart after restoring saved ENB EnableWater=false (unchanged startup guard). At the affected viewpoint enable ENB water live; leave its displacement/tessellation/parallax OFF for15 seconds. Enable those features to reproduce the screenshot for20 seconds; then disable the three again for10 seconds while keeping master water ON. Send log and approximate toggle times; identify any individual switch that clearly causes a visual change if observed. No need to reassemble mods or alter wave amplitudes. Turn WaterPassTrace back to0 after capture to limit log size.

Compare native signatures, shader stages, constant slots, PS resources and output/depth/blend state before and after feature switches. Some topology changes may fail before Renderer::begin and therefore never register as incompatible draws; inspect the native trace instead. Sampling is first-per-pair every2seconds, max32pairs and8calls/scope. It can miss rare unmatched water geometries. If the next trace misses them, add bounded first-unmatched-scope diagnostics (actual kind/arguments/topology, expected signature and VS/PS identity) rather than blindly relaxing the forwarding policy. No shader extraction or ENB implementation code is needed.

No new compile or regression run: source changes here are documentation only. Existing0.1.11 DLL SHA256:13c357a2879f05ee74f47ab7885fa60a781f3e91818cf9bc5fb5a1925b137724. Previous17/17 tests and x64 build remain applicable.

## Later isolation received

User identifies ENB tessellation as the visual trigger in SurfaceTides(20260910-091423).log. That run still had WaterPassTrace=false. Use0.1.12's enhanced capture and the shorter tessellation-only comparison in RESUME-0.1.12.md; the earlier three-feature sweep is superseded.
