# Surface Tides 0.1.20 — optional foam preview

**Superseded by [0.1.20.1](FOAM-0.1.20.1.md).** The first 0.1.20 in-game test crashed in global reference discovery. The hotfix retains the profiles and settings described here while replacing that failing lookup. Use its install ZIP, not the original 0.1.20 DLL.

This development update adds an opt-in filter for the separate foam shapes in two reviewed rapid-rock meshes. It retains the accepted 0.1.19.2 water rendering, underwater correction, shoreline correction and live settings/save behavior. It is compiled, but its new scene filtering still requires in-game testing.

## Install and enable attached-foam filtering

Install `SurfaceTides-0.1.20-foam-update.zip` after the current Surface Tides installation. It contains the DLL and the unchanged accepted shaders; it deliberately does not replace your INI. Add this section to the winning `Data/SKSE/Plugins/SurfaceTides.ini`:

```ini
[Objects]
HideAttachedFoam=1
```

If `[Objects]` already exists, add/update the key there instead of duplicating the section. Restart Skyrim. The default for a missing key is 0. The menu displays this startup setting read-only; Save/Reload tuning preserves it. The existing live simulation preview checkbox restores filter-owned visibility changes when off and reapplies filtering when on, once gameplay resumes.

No ENB/CS settings changes accompany this update. Keep master ENB water off and experimental ENB integration off for the accepted coexistence setup. CS remains a later task. The Skyrim/SKSE/Address Library requirements are unchanged.

## Exact attached coverage

| Winning model path, relative to meshes | Foam shapes hidden | Rock retained |
|---|---|---|
| `effects\fxrapidsrocks01.nif` | `Plane12`, `BIGwHITEWATER` | `WetRocksCombined` |
| `architecture\whiterun\wreffects\wrrapidrocks01.nif` | `rockRapid04` | `RockM06` |

Selection requires the reviewed model path, shape names, effect-shader material and source/greyscale texture paths. A solid rock shape must also be present. Paths are case/slash normalized; polygon counts are not used. The first profile expects FXWhiteWater01/GradWhiteWaterSoft; the second NWF_Rapids/GradWhiteWater02. Unsupported or ambiguous layouts stay visible. This supports the supplied variants; it is not a blanket claim for every ERM/Gol Mora version or every rapid-rock NIF.

The filter changes only the selected loaded shape's hidden flag. It does not replace or edit NIF files, detach nodes, edit shared materials, change rock vertices/textures, alter collision, move references or write save records. `FxRapidsRocks01.nif` has root-owned Havok collision that remains untouched. The supplied Whiterun NIF contains no collision blocks; this update does not create collision for it.

The supplied foam shapes have shader-property animation controllers, with no controllers attached directly to the shapes. Therefore their texture animation can continue while their geometry is hidden. The filter rejects directly controlled shapes and reasserts its owned hidden flags each gameplay update. A separate mod changing these same shape visibility flags could still conflict; there is no engine ownership token for a flag.

## Standalone foam: separate optional BOS preset

Install `SurfaceTides-standalone-foam-BOS-0.1.zip` as a separate mod. It needs Base Object Swapper 3.0+ and places `SurfaceTides_Foam_SWAP.ini` at the Data root. It works independently of the DLL update. The supplied inventory and your confirmation identify exactly these whole objects:

| Base key | Model | Placements in the supplied inventory |
|---|---|---:|
| `0x01B37D~Skyrim.esm` | `effects\fxrapids.nif` | 104 |
| `0x106A1D~Skyrim.esm` | `effects\fxrapids02.nif` | 60 |
| `0x01CCBC~Skyrim.esm` | `effects\fxrapidsbig01.nif` | 129 |

These are base rules and apply to all placements of those bases, not just the inventoried references. The preset sets the initially-disabled flag through BOS. Enable-parent/scripted references or other swaps can override the result. Recheck the winning assets if changing load orders. Disable an older generated SurfaceTides foam INI before installing this preset; use one active copy.

The simulation preview checkbox does not restore BOS-disabled objects. Disable this separate preset, restart and load the preserved test save to compare. This does not clear reference state already saved by another mod/script.

`fxrapidsringheavy.nif` and `fxrapidsringheavy1way.nif` remain untouched, as do waterfall bodies and all other unreviewed objects. They share material paths and generic FoamLayer names with the removable meshes, so neither texture-wide nor name-wide suppression is appropriate. The rock base records are not disabled by BOS.

## Test and rollback

Check one example of each attached model: foam should vanish, rocks should retain their existing appearance and collision behavior, and the preview toggle should restore/re-hide the attached foam. Move away and return, then reload the test save to exercise reattachment. Waterfall impact rings should remain. A short log is enough: look for `HideAttachedFoam=true` and `AttachedFoam: ... matched=... hidden=...`, or `profile incomplete or ambiguous` if a runtime variant differs.

Discovery runs at most once per second over attached references; newly loaded foam can appear briefly before discovery. At most 128 references are retained; each inspected scene tree is bounded to 128 objects. Only known candidates receive geometry inspection. Handles and strong scene pointers protect cached lifetimes; visibility is restored on invalidation, preview-off and load/revert reset. Logging is limited to 24 match lines and 12 mismatch lines per session.

To restore the accepted baseline, disable the 0.1.20 overlay to reveal the 0.1.19.2 DLL and disable the separate BOS preset. Setting HideAttachedFoam=0 and restarting disables only the new attached filter. The accepted rollback ZIP is preserved in the source archive's `recovery` directory.

## Validation and retained evidence

- Windows x64 MSVC-ABI DLL cross-build completed using the existing clang-cl/Windows SDK toolchain. SKSE exports and imports were checked; no added plugin/DLL dependency.
- 22/22 portable tests pass, including negative selection cases for waterfalls, rock names, other models/materials, collision-bearing shapes and directly controlled shapes.
- The same C++ selector was exercised against all 15 geometry records parsed from the seven supplied NIFs: exactly the three attached foam shapes matched. This is offline selection validation, not an in-game visibility test.
- All accepted shader files and rendering/solver source files are unchanged; no shader recompilation is needed for this feature. No Skyrim runtime is available here for testing.
- `foam-0.1.20-nif-inspection.json` retains block/shape/controller evidence. `foam-0.1.20-inputs.json` records hashes and inventory mapping. User NIFs/textures are not distributed in these packages.
- The read-only inspection CLI in `tools/nif` was linked locally against [ousnius/nifly](https://github.com/ousnius/nifly), commit `cca0a770094bb962fb28ea1fec5ea903e68fda8e`. nifly is not linked into the SKSE DLL.
- BOS syntax follows [the author's configuration documentation](https://www.nexusmods.com/skyrimspecialedition/mods/60805) and pinned source `c0b9c093aa6260fd9b68beddea411db97f585ea2`. The original inventory script remains in `tools/xedit`; the reviewed allowlist is in `optional/foam-bos`.

## Next decisions

Keep the waterfall impact rings until there is a replacement for both their localized turbulence and their visible foam. A stationary waterfall impulse source could provide the disturbance later, but that alone would not replace whitewater rendering. Dynamic foam remains after initial release. Expand attached-foam profiles only from inspected winning meshes; genuinely merged rock/foam geometry may still require a local winning-asset patch. Ice floes follow the foam work. No author contact or third-party renderer integration is part of this update.
