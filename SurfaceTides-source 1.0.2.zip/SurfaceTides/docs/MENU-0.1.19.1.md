# Surface Tides 0.1.19.1 — INI save hotfix

The user confirmed that the 0.1.19 menu controls work in game. Saving stopped with “Settings operation failed: Cannot flush settings file.”

This was a bug in Surface Tides: the cache-flush form of WritePrivateProfileStringW returns zero when it flushes, but the save routine interpreted zero as an error. It therefore aborted before replacing the active INI. See Microsoft's [documented return value](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-writeprivateprofilestringw).

The hotfix calls the cache flush without applying the key-write success check. Each actual key write and the final file replacement remain checked. The file is still staged before replacement, and startup/compatibility settings remain untouched by Save tuning.

## Install and verify

Install **SurfaceTides-0.1.19.1-menu-update.zip** after 0.1.19, allowing it to replace SurfaceTides.dll, and restart. It preserves the active INI; included shaders are byte-identical to 0.1.19. Keep your existing SKSE Menu Framework installation and water configuration.

Change one value, choose **Save tuning to INI**, then move that value elsewhere and choose **Reload tuning from INI**. It should return to the saved value. Restart once more if you want to check persistence across launches.

Only save handling and the displayed/logged version changed in runtime code. Simulation, rendering, hooks, menu controls and the accepted shoreline correction are unchanged. The previous 20/20 portable test result remains applicable to the unchanged solver/interop code; those tests cannot execute the Windows profile API. The hotfix DLL is cross-compiled for Windows x64/MSVC ABI; Windows save/reload needs the user's verification.

The 0.1.19 guide in the source at docs/MENU-0.1.19.md still describes the controls. CS coexistence remains pending, and the established ENB master-water-off policy is unchanged.

## Resume checkpoint

Canonical source: project-restored20/SurfaceTides. CMake/SKSE version 0.1.19.1. Source archive keeps the 0.1.18, 0.1.19 and 0.1.19.1 compiled recovery packages. Await the user's Save/Reload result before treating persistence as confirmed. Do not reintroduce a BOOL failure check for the all-null cache-flush call, or weaken checks on real key writes or final replacement.

## Subsequent user result

The user confirms this hotfix solved INI saving. The new report concerns underwater surface gaps; see UNDERWATER-RECURRENCE-0.1.19.1.md. No further save fix is needed based on this result.
