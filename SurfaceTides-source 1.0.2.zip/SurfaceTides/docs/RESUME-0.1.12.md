# Resume0.1.12: ENB tessellation mismatch diagnostics

Latest input SurfaceTides(20260910-091423).log. User reports individually testing steps at15-second intervals, about75seconds total. Both the dark region and transient water seams disappear when ENB tessellation is turned off. ENB tessellation supplies most of the additional depth they want to combine with SurfaceTides; disabling it is only a fallback, not completion. Preserve this acceptance criterion. Exact feature-toggle order/timestamps were not supplied; do not invent them.

## Evidence

Latest log header says WaterPassTrace=false:193 lines,38289 decoded characters, no detailed Water trace entries. Constant repair still active:16498 remapped draws,0 unrecognizedLargePrefix,0 incompatible,0 shader failures.1368 missed native matches, first at03:13:42.079; max402/report. No detailed topology or shader-stage metadata, so user isolation identifies the feature but the specific native pipeline mismatch is not known. Failed matching may exclude draws before the renderer's incompatible counter, so0 incompatible does not prove no native tessellation was present. Do not weaken matching or discard ENB tessellation to make counters look successful.

## New0.1.12 diagnostic build

No visual correction claimed. Source src/plugin/Hooks.cpp and PipelineTrace.hpp/.cpp add a separate changed/unmatched sample budget, independent of regular samples. Each budget has32 VS/PS pairs/thread, once perpair every2seconds. Known water scopes retain expected signature and compact first8 observed native signatures/canonical flags. traceActive controls counting even without an initial periodic sample. A changed/foreign call before an exact match can start a trace immediately while native bindings are still present. A scope ending without any match can start a trace at exit (including zero intercepted native calls), dumping retained signature history. Full metadata is only available for native calls after capture starts; earlier signatures remain available. Captures after pass8 or beyond pair/rate caps can still be missed. Not an exhaustive frame capture.

Logs add reason=periodic or changed-or-unmatched on Water trace begin; Water trace unmatched shows first8 signatures for an unmatched scope. Water trace end reports actual observed call count and matched/truncated. A changed prepass can be benign if a later native call matches; interpret end status. A zero-call scope does not prove ENB culling: calls might be issued through an unhooked path or asynchronously. Same-thread depth-one native interception only.

Added hull/domain constant-buffer byte sizes when those stages are present, and domain SRV/sampler metadata0..15. Existing PS inputs, output/depth/blend/rasterizer/viewport and shader-object metadata retained. No shader bytecode, ENB implementation, texture contents or GPU readback inspected. Existing function-entry hooks, canonical filtering and one exact-match forwarding gate stay intact. Constant remap, Renderer.cpp, HLSL, solver and regression tests unchanged from0.1.11.

Packaged INI WaterPassTrace=1, LogStats=1, RestoreWaterConstants=1. Startup prints version0.1.12 and WaterPassTrace state and warns if detailed trace or LogStats is disabled by a winning older INI. Runtime false does not silently become true; install supplied INI with DLL. Saved ENB EnableWater=false is still required for startup. All wave settings and runtime gates unchanged.

## Validation

Windows MSVC-ABI x64 build PASS. AMD64 and SKSEPlugin_Load / SKSEPlugin_Version exports verified. Existing renderer, HLSL, solver, portable selectors and tests byte-compared unchanged to prior source. Previous17/17 portable results apply; no new native runtime verification and no optional solver rerun for observational changes. Compiler only reports existing unsupported /Zc:preprocessor warning. Final log /tmp/st0112-build-final.txt. Native tests remain unchanged binaries from0.1.11.

DLL SHA256: cecaeef5c223490c3b7754ab19ca3ca9158924f33a86bb41a2014ea99760dc27

## Next user test

Install0.1.12 DLL+INI, verify active startup WaterPassTrace=true. Launch with saved EnableWater=false. At problem location enable ENB master water and displacement, keep parallax OFF. Leave master water/displacement ON, keep SurfaceTides tessellation ON, and toggle only ENB tessellation OFF15sec -> ON15sec -> OFF15sec. Send log and toggle times. No full five-step repeat needed. A large trace log is acceptable.

## Integration target and limits

The accepted goal is preserving ENB's depth while adding the simulation. Our present replacement path supplies its own geometry and pixel shaders; repairing constants is not combined displacement. Must establish native tessellated input/output/resource contracts and a suitable insertion point before changing geometry handling. Unknown downstream shader assumptions, world/clip coordinates and shoreline/mask consistency must be resolved. Do not promise that a counter/topology fix alone will combine wave heights. No ENB-origin code permitted.

Microsoft public pipeline reference: https://learn.microsoft.com/en-us/windows/win32/direct3d11/direct3d-11-advanced-stages-tessellation . Domain stage produces displaced vertex positions; pipeline then continues to later stages. This describes potential integration locations, not evidence that ENB's particular output contract is compatible with ours. No ENB implementation was obtained from this reference.

0.1.9 water-off baseline,0.1.11 constant-fix candidate and0.1.10 diagnostics remain separate versioned artifacts. Current authoritative workspace recovered/SurfaceTides; build/windows-cross toolchain documented in CROSS-BUILD-RECOVERY.md. Preserve source under existing saved identity and create separately named0.1.12 diagnostics installer. No subagents authorized.
