# Surface Tides 0.1.24.3 — jump release candidate

This update targets jumps that animate but fail to gain height on bobbing ice. The latest 0.1.24.2 log records zero velocity repairs throughout, so velocity restoration was not active during that run. A carry update arriving before the controller reports takeoff remains a plausible explanation; it is not yet a proven engine-level cause.

Surface Tides now pauses rider carry as soon as the engine's jump handler receives a new player press, or the character controller reports a current/requested jumping state. Carry resumes after a short ground-contact confirmation. The input observer forwards the original handler and its arguments unchanged; it does not consume input or inject a jump impulse. It uses the engine's mapped action, including rebound keyboard and controller buttons.

The observer installs only when ice bobbing is enabled. Ordinary unsupported frames receive no carry. Brief contact gaps during landing are tolerated in the confirmation history, so normal bobbing does not repeatedly latch a takeoff or leave carry disabled. Rejected jumps also recover after the short release window.

## Install and test

Install `SurfaceTides-0.1.24.3-jump-release.zip` over the current build and restart Skyrim. No INI changes are needed; the package preserves your settings. Test stationary and running jumps while the ice rises and falls, then land, stand briefly and walk again.

**Ice is Slick is incompatible with ice bobbing for now.** Keep it disabled when testing bobbing. Further integration is deferred as agreed; this does not classify it as incompatible with the rest of Surface Tides. The compatibility note is also shown in the Floating ice menu. No other mod's configuration is changed.

The occasional residual slide is not separately addressed here. Floe crest response, collision transforms, water simulation and the five accepted water shaders retain their previous implementations. Disconnected ice chunks within one mesh still move together.

## Validation

The Windows AMD64 DLL compiled successfully. All 45 portable test groups pass: 22 solver and 23 floe groups. The added cases cover early input/requested-state release, stale support during takeoff, landing recovery, brief contact gaps and rejected jumps. These tests use a portable controller model; they cannot establish the in-game result.

Compiled inspection confirms the jump observer forwards the original handler and the carry path retains conditional velocity repair without Actor::SetPosition. Source comparisons preserve collision/crest/streaming functions and existing renderer hooks; only the new input observer is added to hook installation. The prior global-reference-scan crash regression remains guarded.

DLL: 1,561,088 bytes; SHA256 `e8bd3e9f062e99c37e9bc1e4e9c8a8432879cfb415214163a66e8a690826274b`.

In-game jump behavior still needs confirmation. If it persists, return the log: `Floes riders:` now includes `takeoffReleases`, `landingResumes` and `takeoffSkips`. Skips count eligibility checks, potentially twice per frame, rather than frames. The exact 0.1.24.2 installer remains in the source archive for comparison.
