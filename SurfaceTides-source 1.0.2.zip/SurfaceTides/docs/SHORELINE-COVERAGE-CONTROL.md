# Shoreline diagnostic color control

**Historical checkpoint; current findings and test: NATIVE-RIPPLE-ISOLATION.md. Do not repeat the controls below.**

## Current evidence

The user confirms native TAA is already disabled. They normally use ENB for AA; that is context for their usual setup, not evidence that ENB is still active in the current comparison. Retain the earlier confirmed state: ENB removed, Water for ENB2.19 / Shades of Skyrim /4K, SurfaceTides0.1.17 with r4, full displacement. No attachments accompany this clarification. Do not ask for the TAA comparison again, and do not infer the state of other AA options from this statement.

The artifact is absent with SurfaceTides disabled and absent with displacement0/normal strength2. R1 partially contained terrain bleed; refraction-distortion diagnostic A made no difference; SSR diagnostic B appeared worse. R3 and r4 did not resolve the artifact. Latest clip Sequence #1(18).mp4 is retained in SHORELINE-R4-RESULT.md; there is no new log proving the current winning shader. Stop changing optical terms without isolating whether the visible fragments come from colored surface coverage or normal shading.

## Next test: existing DebugView

In the active SurfaceTides.ini set [Diagnostics] DebugView=1 and restart Skyrim. Keep Enabled=1, DisplacementStrength=2, NormalStrength=2, the current r4 shader and the same load order. ENB stays absent and native TAA stays off. Do not also change shader overlays or update Water for ENB.

Record the same shallow shoreline for roughly10seconds, with a short stationary view followed by slow camera movement. Bright diagnostic colors are expected. Supply the clip and ordinary SurfaceTides.log, which records debugView=1 at startup and in draw statistics. Restore DebugView=0 and restart afterward. No new download, compile, cache deletion or further settings change is required.

Look for whether the irregular terrain fragments or detached patches remain visible within the colored water, versus the colored surface appearing continuous where the normal shading showed the artifact. In particular, distinguish actual patches of terrain showing through from the blue/green debug colors themselves. A surviving discontinuity directs attention toward coverage/depth/overlapping geometry or later passes; a clean colored surface makes normal material/refraction/reflection output a stronger lead. Neither result alone proves a defective mesh or fully excludes other pipeline stages.

## Audited behavior and limitations

Game.cpp reads Diagnostics.DebugView as0..1 at startup. Renderer.cpp uploads it as STDebug.x. Water.hlsl overrides psout.Lighting after normal color/fog/contact calculations when STDebug.x>0.5 on non-stencil passes. The heightfield sampling, water geometry/tessellation, depth test and stencil/motion outputs stay active. The diagnostic replaces the visible material color but does not stop all preceding shader work or later engine passes.

SurfaceField.hlsli returns magenta outside the simulation patch, orange for a different water-height band, blue for a dry mask sample, and green blending toward white for wet samples with increasing absolute field height. These colors label the underlying water geometry; blue/magenta are not intrinsically holes. Mask values reflect the existing coarse terrain mask, not exact collision against every rock mesh.

DebugView also writes alpha1, while ordinary water output retains its per-pass alpha meaning. Engine blending and later image-space processing are still present, and the diagnostic applies to additive color passes too. It is therefore not a pure instrumented depth-buffer dump. Treat the result as a useful routing control, not an absolute proof of correct geometry/material state. If necessary, a dedicated constant-color test that preserves ordinary alpha or additional pass metadata can follow; do not create that package before seeing this available control's result.

## Checkpoint

Working source project-shore-r3/SurfaceTides matched saved source version36 byte-for-byte before this turn. Archive SHA2567bb8d2b25d0affcc96e013a6fb1d23ed8628e1d5847abbc2260f64bc5f38533f,4,010,690bytes. This follow-up changes documentation only. No C++, shader, INI, native binary or installer change and no repeated tests.

Replace source libfile_4355a322deb481918f58dfaa7d9c03c5 with expected version36 and retain the actual receipt. R4 overlay libfile_b7dc1a2470fc81919fef9e19e1ce6eef remains version0,SHA2564c54ddb43149ce25e33d37aca26b4c2379f87e057b033bee093b2819e3792c2a. Latest full installer libfile_09c5e26b5238819187b073e8c574a1df remains version19/r1. Source contact and displaced-depth switches still default0; prior baseline packages remain intact.

Renderer-neutral project policy unchanged. Native ENB integration experimental/off; CS coexistence pending/gated. No ENB implementation code, shader contents, bytecode or SDK used, no Water for ENB assets modified, no subagents. Do not repeat completed controls after the next context interruption.
