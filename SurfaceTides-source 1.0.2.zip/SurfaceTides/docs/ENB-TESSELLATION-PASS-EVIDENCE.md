# ENB tessellation pass evidence, September 10, 2026

Input: SurfaceTides(20260910-094030).log, 930624 decoded characters / 1746 lines. Plugin0.1.12, RestoreWaterConstants=true, WaterPassTrace=true. User enabled master water within5seconds of visible load, ENB tessellation at41.04seconds, disabled it about55seconds, and ended about70seconds after visible load. Darker areas and seams recur with tessellation ON and disappear OFF.

220 sampled water scopes:186 single-native-call matched,19 three-call matched,14 two-call unmatched,1 two-call matched. These are sampled scopes, not complete frame counts. Detailed extracted trace records accompany this document as ENB-0.1.12-traces.json.

The first simulation log time is03:38:45.324. First native tessellation appears51.266seconds later, consistent with approximately10seconds between simulation startup and the user's visible-load stopwatch. Do not map their41.04seconds directly to the first simulation timestamp. The main observed patch interval lasts through65.992seconds. Further patches are sampled81.817–84.645seconds; the exact late user action is unknown.

## Concrete mismatch

| Trace | Original game draw | Native calls | SurfaceTides0.1.12 |
|---|---|---|---|
|123, VS/PS35E|DrawIndexed1536, start0, base0, triangle list|Two identical-count three-control-point patch draws; HS and DS bound|Neither draw replaced; no exact topology match|
|124, VS/PS31E|DrawIndexed216, start0, base0, triangle list|Two patch draws, then one triangle-list draw|Only the third draw replaced|
|126, VS/PS5000|DrawIndexed216, triangle list|One triangle-list mask/depth draw|Replaced|

D3D topology4 is triangle list;35 is three-control-point patch list (33 would be one control point). Both35E patch passes target the same2560x1440 RGBA16F render target and depth/stencil resource. The31E three passes also share those output resources. They are not merely unrelated offscreen draws. Patches use bound HS/DS; the31E third draw has neither. Original VS buffer sizes stay16/96/224 for these color passes. HS b0=4976; DS b0/b1=4976/224. The two patch passes use different pixel shaders and different PS constant layouts: first80/224/1296, second4976/80/224/1296/720. This is consistent with the earlier validated PS prefix repair, but that repair never reaches the skipped patches.

The5000 draw writes two render targets including motion vectors and enables depth writes. Existing SurfaceTides replaces its geometry too. Hence the current path can put simulation-deformed depth/mask geometry alongside undeformed-by-SurfaceTides ENB color geometry, and can overlay another differently displaced color pass for31E. This is a strong causal hypothesis for the user's artifacts, not a proven complete pixel-level diagnosis.

## Architectural consequence

Broadening the old one-shot topology match and replacing ENB's HS/DS/PS would discard the ENB depth the user wants. The0.1.13 experiment instead creates a denser local-position/UV/color input mesh from the original game vertex input and simulation field, then restores the native shaders and submits that mesh to every qualifying native pass. Native ENB HS/DS/PS remain in charge of the visible draw. No ENB shader bytecode, output signatures, shader source, resource contents, decompilation, or implementation code is inspected.

This is upstream composition, not proof that ENB will preserve the altered input height. Its displacement algorithm could reconstruct the surface or depend on original primitive size. Native-game motion vectors also do not know the previous simulation height. The next visual test must establish combined displacement, remaining seams and performance.

Public API references:
- https://learn.microsoft.com/en-us/windows/win32/direct3d11/direct3d-11-advanced-stages-tessellation
- https://learn.microsoft.com/en-us/windows/win32/direct3d11/d3d10-graphics-programming-guide-output-stream-stage
- https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-drawauto
