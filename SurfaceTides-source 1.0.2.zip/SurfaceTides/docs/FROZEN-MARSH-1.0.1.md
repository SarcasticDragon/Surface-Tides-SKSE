# Surface Tides 1.0.1 — Frozen Marsh ice decals

Extends the existing `[Objects] HideIceDecals=1` startup option to nine reviewed Frozen Marsh meshes. No new settings, mesh replacement, texture replacement or BOS dependency. Bobbing remains restricted to icefloessolid01, icefloes01 and icefloessolid02. Water simulation and all five shaders are unchanged from 1.0.

For an existing installation, install `SurfaceTides-1.0.1-ice-decal-update.zip` after Surface Tides so its DLL wins. This overlay includes no INI and preserves tuning and previous FOMOD selections. Keep HideIceDecals=1 and restart Skyrim. The alternative full `SurfaceTides-1.0.1-FOMOD.zip` writes a fresh INI, as before; back up tuning and cleanly replace the old full installation if using it.

| Supplied mesh | Action |
| --- | --- |
| frozenmarshicefloel01.nif | Hide L1_FrozenMarshIceFloeL01; retain solid FrozenMarshIceFloeL01:0. |
| frozenmarshicefloem01.nif | Hide L1_FrozenMarshIceFloeM01; retain solid FrozenMarshIceFloeM01:0. |
| frozenmarshicefloes01.nif | Hide L1_FrozenMarshIceFloeS01; retain solid FrozenMarshIceFloeS01:0. |
| frozenmarshicefloes02.nif | Hide L1_FrozenMarshIceFloeS02; retain solid FrozenMarshIceFloeS02:0. |
| FrozenMarshIceLandBrokenl01.nif | Hide FrozenMarshIceLandBroken02:1; retain FrozenMarshIceLandBroken02:0. |
| FrozenMarshIceLandBrokenl01Skirt.nif | Hide FrozenMarshIceLandBroken01Skirt:1; retain FrozenMarshIceLandBroken01Skirt:0. |
| frozenmarshicefloefrosts01.nif | Hide the standalone frost shape FrozenMarshIceFloeFrostS01:1. |
| frozenmarshicefloefrosts02.nif | Hide the standalone frost shape FrozenMarshIceFloeFrostS02:1. |
| frozenmarshicefloefrosts03.nif | Hide the standalone frost shape FrozenMarshIceFloeFrostS03:1. |
| frozenmarshice01.nif | Unchanged; solid ice material only. |
| frozenmarshicefloechunks01.nif | Unchanged; solid ice material only. |
| frozenmarshicefloechunks02.nif | Unchanged; solid ice material only. |
| frozenmarshicefloechunks03.nif | Unchanged; solid ice material only. |

Profiles use exact `landscape/ice/` mesh paths, inspected shape names and the IceFloes diffuse/normal texture paths. The prior xEdit export confirms that directory for the L/M/S/frost family. The two LandBroken paths use the same expected directory and require runtime confirmation. Case and slash direction are normalized. There is no wildcard rule hiding every FrozenMarsh object or every use of an ice texture.

The six attached profiles retain the solid anchor requirement. The three frost-only profiles require all geometry to match their reviewed decal count and reject collision/controllers anywhere in the traversed scene, including shader-property controllers. Unsupported scenes remain unchanged. The implementation sets only the matched shape's AppCulled flag and uses the existing restoration/lifecycle handling. The original bounded scan (128 managed references) is retained.

Validation: read-only nifly inspection of all13 user NIFs, input SHA256s, exactly9 selected decals and10 excluded solid geometries, all13 excluded from bobbing, all21 earlier supplied geometry cases still match their accepted results, all46 portable test groups pass, x64 DLL compiled and SKSE exports checked. The old crash-prone TES global-reference traversal remains excluded by a compiled-object regression check. No simulation, render-hook, collision or rider algorithm changed; the shared bobbing eligibility predicate is now explicitly restricted to the original profile indices2–4. In-game results remain pending.

Runtime support stays Steam1.6.1170 and GOG1.6.1179; this update does not add support for other executable versions. The original1.0 and r2 installers are preserved in the source recovery folder. Input NIFs are not redistributed.
