# Installer metadata correction

Source: https://github.com/Nexus-Mods/fomod-installer/blob/master/src/InstallScripting/XmlScript/XmlScriptType.cs (StringStream/Validate, inspected 2026-09-15). The validator writes UTF-16BE after regex removal of double-quoted encoding attributes only. Emit double quotes to match this behavior. Python/lxml accepts the original despite the encoding mismatch, so merely rerunning the old XML parser would not cover this risk. Added explicit declaration-removal check and UTF-16 serialization parse. .NET and the actual manager UI were not available here.

Original v1.0 installation and wizard success confirmed by user, with validation warning. r2 warning resolution pending user confirmation. No game-file payload changes.
