#include "surfacetides/ShaderLayout.hpp"
#include <array>
#include <algorithm>
#include <sstream>
#include <stdexcept>

namespace st {
namespace {
struct Constant { const char* name; const char* type; int id, group, floats; const char* suffix; };
constexpr Constant vertex[] = {
    {"QPosAdjust","float4",3,0,4,""},
    {"VSFogParam","float4",8,1,4,""}, {"VSFogNearColor","float4",9,1,4,""},
    {"VSFogFarColor","float4",10,1,4,""}, {"NormalsScroll0","float4",5,1,4,""},
    {"NormalsScroll1","float4",6,1,4,""}, {"NormalsScale","float4",7,1,4,""},
    {"World","row_major float4x4",1,2,16,""}, {"PreviousWorld","row_major float4x4",2,2,16,""},
    {"WorldViewProj","row_major float4x4",0,2,16,""}, {"ObjectUV","float3",4,2,3,""},
    {"CellTexCoordOffset","float4",11,2,4,""}
};
constexpr Constant pixel[] = {
    {"VPOSOffset","float4",24,0,4,""}, {"PosAdjust","float4",6,0,4,""},
    {"CameraData","float4",8,0,4,""}, {"SunDir","float4",14,0,4,""}, {"SunColor","float4",15,0,4,""},
    {"ShallowColor","float4",1,1,4,""}, {"DeepColor","float4",2,1,4,""},
    {"ReflectionColor","float4",3,1,4,""}, {"FresnelRI","float4",4,1,4,""},
    {"BlendRadius","float4",5,1,4,""}, {"VarAmounts","float4",10,1,4,""},
    {"NormalsAmplitude","float4",23,1,4,""}, {"WaterParams","float4",19,1,4,""},
    {"FogNearColor","float4",12,1,4,""}, {"FogFarColor","float4",13,1,4,""},
    {"FogParam","float4",11,1,4,""}, {"DepthControl","float4",20,1,4,""},
    {"SSRParams","float4",21,1,4,""}, {"SSRParams2","float4",22,1,4,""},
    {"TextureProj","column_major float4x4",0,2,16,""}, {"ReflectPlane","float4",7,2,4,""},
    {"ProjData","float4",9,2,4,""}, {"LightPos","float4",17,2,32,"[8]"}, {"LightColor","float4",18,2,32,"[8]"}
};
std::span<const Constant> constants(ShaderStage s) {
    if (s == ShaderStage::Vertex) return vertex;
    return pixel;
}
}
std::string engineConstantHeader(ShaderStage stage, std::span<const std::int8_t> table,
    std::optional<std::span<const std::string>> activeNames) {
    if (table.size() < (stage == ShaderStage::Vertex ? 12u : 25u)) throw std::invalid_argument("Short shader constant table");
    const auto active = [&](const Constant& c) {
        return !activeNames || std::find(activeNames->begin(),activeNames->end(),c.name) != activeNames->end();
    };
    if (activeNames) for (const auto& c : constants(stage))
        if (active(c) && table[c.id] < 0) throw std::invalid_argument(std::string("Missing live shader constant: ") + c.name);
    std::ostringstream result;
    std::array<std::array<bool,256>,3> used{};
    for (int group = 0; group < 3; ++group) {
        result << "cbuffer STEngine" << group << " : register(b" << group << ") {\n";
        for (const auto& c : constants(stage)) {
            if (c.group != group || table[c.id] < 0 || !active(c)) continue;
            const int offset = table[c.id];
            if ((c.floats >= 4 && offset % 4 != 0) || offset + c.floats > 256)
                throw std::invalid_argument("Unsupported shader constant alignment");
            for (int i = offset; i < offset + c.floats; ++i) {
                if (used[group][i]) throw std::invalid_argument("Overlapping shader constants; leaving original water shader active");
                used[group][i] = true;
            }
            result << c.type << ' ' << c.name << c.suffix << " : packoffset(c" << offset / 4;
            if (offset % 4) result << '.' << "xyzw"[offset % 4];
            result << ");\n";
        }
        result << "};\n";
    }
    // Original permutations omit unused constants. Declare harmless defaults for compiler parsing.
    for (const auto& c : constants(stage)) if (table[c.id] < 0 || !active(c)) {
        std::string type(c.type);
        if (const auto i = type.find(' '); i != std::string::npos) type = type.substr(i + 1);
        result << "static const " << type << ' ' << c.name << c.suffix << " = ";
        if (c.suffix[0]) {
            // FXC/SM5 does not broadcast one scalar initializer to each float4
            // array element. Emit all four components of each light explicitly.
            result << '{';
            for (int element = 0; element < c.floats / 4; ++element) {
                if (element) result << ',';
                result << "float4(0,0,0,0)";
            }
            result << '}';
        }
        else result << '(' << type << ")0";
        result << ";\n";
    }
    if (!activeNames && stage == ShaderStage::Vertex && (table[0] < 0 || table[1] < 0))
        throw std::invalid_argument("Water shader lacks World or WorldViewProj");
    return result.str();
}

std::vector<std::pair<std::string,std::string>> shaderDefines(std::uint32_t descriptor, const char* stage,
                                                            std::uint32_t pixelDescriptor) {
    if (descriptor & ~0x7FFFu) throw std::invalid_argument("Unknown water descriptor bits");
    std::vector<std::pair<std::string,std::string>> d{{stage,"1"},{"ST_PIXEL_DESCRIPTOR",std::to_string(pixelDescriptor)}};
    constexpr const char* flags[] = {"VC","NORMAL_TEXCOORD","REFLECTIONS","REFRACTIONS","DEPTH","INTERIOR","WADING",
                                     "VERTEX_ALPHA_DEPTH","CUBEMAP","FLOWMAP","BLEND_NORMALS"};
    for (int i = 0; i < 11; ++i) if (descriptor & (1u << i)) d.emplace_back(flags[i],"1");
    const auto technique = (descriptor >> 11) & 15u;
    if (technique < 8) { d.emplace_back("SPECULAR","1"); d.emplace_back("NUM_SPECULAR_LIGHTS",std::to_string(technique)); }
    else if (technique == 8) d.emplace_back("UNDERWATER","1");
    else if (technique == 9) d.emplace_back("LOD","1");
    else if (technique == 10) d.emplace_back("STENCIL","1");
    else if (technique == 11) d.emplace_back("SIMPLE","1");
    else throw std::invalid_argument("Unsupported water technique");
    return d;
}

std::vector<std::int8_t> referenceConstantTable(ShaderStage stage) {
    std::vector<std::int8_t> out(stage == ShaderStage::Vertex ? 20 : 64, -1);
    int next[3]{};
    for (const auto& c : constants(stage)) {
        out[c.id] = static_cast<std::int8_t>(next[c.group]);
        next[c.group] += (c.floats + 3) / 4 * 4;
    }
    return out;
}
}
