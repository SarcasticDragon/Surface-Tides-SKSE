#include "surfacetides/Simulation.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace st {
void Settings::validate() const {
    if (resolution < 16 || resolution > 512 || !std::isfinite(spacing) || spacing < 4 || spacing > 128 ||
        !std::isfinite(waveSpeed) || waveSpeed <= 0 || waveSpeed > 1000 ||
        !std::isfinite(dispersion) || dispersion < 0 || dispersion > 1e8f ||
        !std::isfinite(damping) || damping < 0 || damping > 10 ||
        !std::isfinite(edgeDamping) || edgeDamping < 0 || edgeDamping > 30 ||
        spongeCells < 0 || spongeCells > resolution / 3 ||
        !std::isfinite(maxHeight) || maxHeight <= 0 || maxHeight > 128 ||
        !std::isfinite(wind) || wind < 0 || wind > 50 ||
        !std::isfinite(gustStrength) || gustStrength < 0 || gustStrength > 4) {
        throw std::invalid_argument("Invalid SurfaceTides simulation settings");
    }
}

double Settings::timestep() const {
    validate();
    const double lambda = 8.0 / (double(spacing) * spacing);
    // Neumann graph Laplacian spectrum <= 8/dx^2, including masked boundaries.
    const double maxOmega = std::sqrt(double(waveSpeed) * waveSpeed * lambda + dispersion * lambda * lambda);
    return std::min(1.0 / 120.0, 1.7 / maxOmega);
}

Surface::Surface(Settings settings) : settings_(settings) {
    settings_.validate();
    const auto count = static_cast<std::size_t>(settings_.resolution) * settings_.resolution;
    state_.resize(count); scratch_.resize(count);
    wet_.assign(count, 1); wetScratch_.resize(count);
    heights_.resize(count); lap_.resize(count); bilap_.resize(count); attenuation_.resize(count);
    updateAttenuation();
    reset({}, 0);
}

void Surface::retune(const Settings& settings) {
    settings.validate();
    if (settings.resolution != settings_.resolution || settings.spacing != settings_.spacing)
        throw std::invalid_argument("Grid changes require a new surface");
    settings_ = settings;
    updateAttenuation();
    // The next fixed step enforces a lower MaxHeight without fabricating an impulse here.
}

void Surface::updateAttenuation() {
    const int n = settings_.resolution;
    const float dt = static_cast<float>(settings_.timestep());
    for (int y = 0; y < n; ++y) for (int x = 0; x < n; ++x) {
        const int distance = std::min({x, y, n - 1 - x, n - 1 - y});
        const float edge = settings_.spongeCells ? std::max(0.0f, 1.0f - float(distance) / float(settings_.spongeCells)) : 0;
        attenuation_[std::size_t(y) * n + x] = std::exp(-(settings_.damping + settings_.edgeDamping * edge * edge) * dt);
    }
}

void Surface::reset(Vec2 center, float waterLevel) {
    if (!std::isfinite(center.x) || !std::isfinite(center.y) || !std::isfinite(waterLevel))
        throw std::invalid_argument("Nonfinite surface origin");
    const float dx = settings_.spacing;
    origin_ = {(std::floor(center.x / dx) - settings_.resolution / 2) * dx,
               (std::floor(center.y / dx) - settings_.resolution / 2) * dx};
    level_ = waterLevel;
    std::fill(state_.begin(), state_.end(), Cell{});
    std::fill(wet_.begin(), wet_.end(), 1);
    accumulator_ = time_ = 0;
}

void Surface::recenter(Vec2 center) {
    if (!std::isfinite(center.x) || !std::isfinite(center.y)) return;
    const float dx = settings_.spacing;
    const int n = settings_.resolution;
    const Vec2 next{(std::floor(center.x / dx) - n / 2) * dx, (std::floor(center.y / dx) - n / 2) * dx};
    const double sx = std::round((double(next.x) - origin_.x) / dx);
    const double sy = std::round((double(next.y) - origin_.y) / dx);
    if (sx == 0 && sy == 0) return;
    if (std::abs(sx) >= n || std::abs(sy) >= n) { reset(center, level_); return; }
    const int ix = static_cast<int>(sx), iy = static_cast<int>(sy);
    for (int y = 0; y < n; ++y) for (int x = 0; x < n; ++x) {
        const auto dst = std::size_t(y) * n + x;
        const int ox = x + ix, oy = y + iy;
        const bool overlap = ox >= 0 && oy >= 0 && ox < n && oy < n;
        scratch_[dst] = overlap ? state_[std::size_t(oy) * n + ox] : Cell{};
        wetScratch_[dst] = overlap ? wet_[std::size_t(oy) * n + ox] : 0;
    }
    state_.swap(scratch_); wet_.swap(wetScratch_); origin_ = next;
}

void Surface::setWetMask(std::span<const std::uint8_t> mask) {
    if (mask.size() != wet_.size()) throw std::invalid_argument("Mask size does not match surface");
    for (std::size_t i = 0; i < wet_.size(); ++i) {
        const bool wasWet = wet_[i] != 0;
        wet_[i] = mask[i] ? 1 : 0;
        if (!wet_[i] || !wasWet) state_[i] = {};
    }
}

void Surface::setState(std::span<const Cell> values) {
    if (values.size() != state_.size()) throw std::invalid_argument("State size does not match surface");
    for (const auto& v : values) if (!std::isfinite(v.height) || !std::isfinite(v.velocity))
        throw std::invalid_argument("Nonfinite state");
    std::copy(values.begin(), values.end(), state_.begin());
    for (std::size_t i = 0; i < state_.size(); ++i) if (!wet_[i]) state_[i] = {};
}

void Surface::addImpulse(const Impulse& impulse) {
    if (!std::isfinite(impulse.position.x) || !std::isfinite(impulse.position.y) ||
        !std::isfinite(impulse.radius) || !std::isfinite(impulse.velocity) || impulse.radius <= 0) {
        ++diagnostics_.rejectedImpulses; return;
    }
    const int n = settings_.resolution;
    const float dx = settings_.spacing;
    const float radius = std::clamp(impulse.radius, dx, 12 * dx);
    const float cx = (impulse.position.x - origin_.x) / dx;
    const float cy = (impulse.position.y - origin_.y) / dx;
    const float extent = 3 * radius / dx;
    if (cx + extent < 0 || cy + extent < 0 || cx - extent >= n || cy - extent >= n) return;
    const int x0 = static_cast<int>(std::max(0.0f, std::floor(cx - extent)));
    const int y0 = static_cast<int>(std::max(0.0f, std::floor(cy - extent)));
    const int x1 = static_cast<int>(std::min(float(n - 1), std::ceil(cx + extent)));
    const int y1 = static_cast<int>(std::min(float(n - 1), std::ceil(cy + extent)));
    double weightSum = 0; int wetCount = 0;
    const auto kernel = [&](int x, int y) {
        const float ux = (float(x) - cx) * dx / radius, uy = (float(y) - cy) * dx / radius;
        const float r2 = ux * ux + uy * uy;
        return r2 <= 9 ? (1 - 0.5f * r2) * std::exp(-0.5f * r2) : 0.0f;
    };
    for (int y = y0; y <= y1; ++y) for (int x = x0; x <= x1; ++x) {
        const float ux = float(x) - cx, uy = float(y) - cy;
        if (ux * ux + uy * uy > extent * extent || !wet_[std::size_t(y) * n + x]) continue;
        weightSum += kernel(x,y); ++wetCount;
    }
    if (wetCount < 2) return;
    const float mean = static_cast<float>(weightSum / wetCount);
    const float strength = std::clamp(impulse.velocity, -400.0f, 400.0f);
    for (int y = y0; y <= y1; ++y) for (int x = x0; x <= x1; ++x) {
        const float ux = float(x) - cx, uy = float(y) - cy;
        if (ux * ux + uy * uy > extent * extent || !wet_[std::size_t(y) * n + x]) continue;
        state_[std::size_t(y) * n + x].velocity += strength * (kernel(x,y) - mean);
    }
}

void Surface::laplacian(std::span<const float> in, std::span<float> out) const {
    const int n = settings_.resolution;
    const float invDx2 = 1 / (settings_.spacing * settings_.spacing);
    for (int y = 0; y < n; ++y) for (int x = 0; x < n; ++x) {
        const auto i = std::size_t(y) * n + x;
        if (!wet_[i]) { out[i] = 0; continue; }
        float sum = 0;
        if (x > 0 && wet_[i - 1]) sum += in[i - 1] - in[i];
        if (x + 1 < n && wet_[i + 1]) sum += in[i + 1] - in[i];
        if (y > 0 && wet_[i - n]) sum += in[i - n] - in[i];
        if (y + 1 < n && wet_[i + n]) sum += in[i + n] - in[i];
        out[i] = sum * invDx2;
    }
}

void Surface::step() {
    // World-anchored, deterministic gusts excite the same zero-volume kernel as
    // actors. Schedule on simulation time so rendering FPS cannot change energy.
    // Small footprints create local curvature; the solver spreads and disperses it.
    const auto gustTick = static_cast<std::uint64_t>(std::floor(time_ * 2 + 1e-8));
    const auto previousTick = time_ > 0 ? static_cast<std::uint64_t>(
        std::floor(std::max(0.0, time_ - settings_.timestep()) * 2 + 1e-8)) : gustTick;
    if (settings_.wind > 0 && settings_.gustStrength > 0 && (time_ == 0 || gustTick != previousTick)) {
        constexpr double tile = 360;
        const auto hash = [](std::uint32_t v) {
            v ^= v >> 16; v *= 0x7feb352du; v ^= v >> 15;
            v *= 0x846ca68bu; return v ^ (v >> 16);
        };
        const int x0 = static_cast<int>(std::floor((origin_.x - 270) / tile));
        const int y0 = static_cast<int>(std::floor((origin_.y - 270) / tile));
        const int x1 = static_cast<int>(std::floor((origin_.x + settings_.resolution * settings_.spacing + 270) / tile));
        const int y1 = static_cast<int>(std::floor((origin_.y + settings_.resolution * settings_.spacing + 270) / tile));
        for (int y = y0; y <= y1; ++y) for (int x = x0; x <= x1; ++x) {
            const auto seed = hash(static_cast<std::uint32_t>(x) * 0x9e3779b9u ^
                static_cast<std::uint32_t>(y) * 0x85ebca6bu ^ hash(static_cast<std::uint32_t>(gustTick)));
            if ((seed & 3u) != 0) continue;
            const auto unit = [&](std::uint32_t salt) { return float(hash(seed ^ salt) & 65535u) / 65535.0f; };
            const Vec2 position{static_cast<float>((x + 0.15 + 0.7 * unit(11)) * tile),
                                static_cast<float>((y + 0.15 + 0.7 * unit(23)) * tile)};
            const float radius = 50 + 40 * unit(37);
            const float sign = (seed & 4u) ? 1.0f : -1.0f;
            addImpulse({position, radius, sign * settings_.wind * settings_.gustStrength * (5 + 3 * unit(53))});
        }
    }

    for (std::size_t i = 0; i < state_.size(); ++i) heights_[i] = state_[i].height;
    laplacian(heights_, lap_);
    if (settings_.dispersion > 0) laplacian(lap_, bilap_);
    const float dt = static_cast<float>(settings_.timestep());
    const float c2 = settings_.waveSpeed * settings_.waveSpeed;
    const int n = settings_.resolution;
    // Smooth, deterministic pressure forcing. Time is simulated time, never wall time.
    double windMean = 0; std::size_t wetCount = 0;
    if (settings_.wind > 0) {
        for (int y = 0; y < n; ++y) for (int x = 0; x < n; ++x) {
            const auto i = std::size_t(y) * n + x;
            const double wx = origin_.x + x * settings_.spacing, wy = origin_.y + y * settings_.spacing;
            heights_[i] = static_cast<float>(std::sin(wx * 0.009 + wy * 0.004 - time_ * 1.4) +
                                            0.45 * std::sin(wx * 0.015 - wy * 0.008 - time_ * 2.1));
            if (wet_[i]) { windMean += heights_[i]; ++wetCount; }
        }
        if (wetCount) windMean /= double(wetCount);
    }
    for (std::size_t i = 0; i < state_.size(); ++i) {
        auto& s = state_[i];
        if (!wet_[i]) { s = {}; continue; }
        const float force = settings_.wind > 0 ? settings_.wind * (heights_[i] - static_cast<float>(windMean)) : 0;
        const float acceleration = c2 * lap_[i] - settings_.dispersion * bilap_[i] + force;
        s.velocity = (s.velocity + dt * acceleration) * attenuation_[i];
        s.height = (s.height + dt * s.velocity) * attenuation_[i];
        if (!std::isfinite(s.height) || !std::isfinite(s.velocity)) {
            s = {}; ++diagnostics_.clippedCells;
        } else if (std::abs(s.height) > settings_.maxHeight) {
            s.height = std::clamp(s.height, -settings_.maxHeight, settings_.maxHeight);
            s.velocity = 0; ++diagnostics_.clippedCells;
        }
    }
    time_ += settings_.timestep(); ++diagnostics_.steps;
}

void Surface::advance(double seconds, int maxSteps) {
    if (!std::isfinite(seconds) || seconds <= 0 || maxSteps <= 0) return;
    const double dt = settings_.timestep();
    accumulator_ += seconds;
    const double budget = dt * maxSteps;
    if (accumulator_ > budget + dt) {
        diagnostics_.droppedSeconds += accumulator_ - budget;
        accumulator_ = budget;
    }
    int steps = 0;
    while (accumulator_ + 1e-12 >= dt && steps < maxSteps) {
        step(); accumulator_ -= dt; ++steps;
    }
    accumulator_ = std::max(0.0, accumulator_);
}

float Surface::sample(Vec2 world) const {
    const float fx = (world.x - origin_.x) / settings_.spacing, fy = (world.y - origin_.y) / settings_.spacing;
    const int n = settings_.resolution;
    if (!std::isfinite(fx) || !std::isfinite(fy) || fx < 0 || fy < 0 || fx >= n - 1 || fy >= n - 1) return 0;
    const int x = static_cast<int>(fx), y = static_cast<int>(fy);
    const float tx = fx - float(x), ty = fy - float(y);
    const auto i = std::size_t(y) * n + x;
    return std::lerp(std::lerp(state_[i].height, state_[i + 1].height, tx),
                     std::lerp(state_[i + n].height, state_[i + n + 1].height, tx), ty);
}

Vec2 Surface::gradient(Vec2 world) const {
    const float dx = settings_.spacing;
    return {(sample({world.x + dx,world.y}) - sample({world.x - dx,world.y})) / (2 * dx),
            (sample({world.x,world.y + dx}) - sample({world.x,world.y - dx})) / (2 * dx)};
}

double Surface::meanHeight() const {
    double sum = 0; std::size_t count = 0;
    for (std::size_t i = 0; i < state_.size(); ++i) if (wet_[i]) { sum += state_[i].height; ++count; }
    return count ? sum / double(count) : 0;
}

double Surface::energy() const {
    double result = 0;
    const int n = settings_.resolution;
    const double invDx2 = 1.0 / (settings_.spacing * settings_.spacing);
    for (int y = 0; y < n; ++y) for (int x = 0; x < n; ++x) {
        const auto i = std::size_t(y) * n + x;
        if (!wet_[i]) continue;
        result += 0.5 * double(state_[i].velocity) * state_[i].velocity;
        double lap = 0;
        const auto edge = [&](std::size_t j, bool countEnergy) {
            if (!wet_[j]) return;
            const double d = state_[j].height - state_[i].height;
            lap += d * invDx2;
            if (countEnergy) result += 0.5 * settings_.waveSpeed * settings_.waveSpeed * d * d * invDx2;
        };
        if (x) edge(i - 1, false);
        if (x + 1 < n) edge(i + 1, true);
        if (y) edge(i - n, false);
        if (y + 1 < n) edge(i + n, true);
        result += 0.5 * settings_.dispersion * lap * lap;
    }
    return result * settings_.spacing * settings_.spacing;
}
bool Surface::finite() const {
    return std::all_of(state_.begin(), state_.end(), [](const Cell& c) {
        return std::isfinite(c.height) && std::isfinite(c.velocity);
    });
}

void ContactTracker::reset() { previous_.clear(); }
void ContactTracker::update(std::span<const Contact> contacts, double dt, std::vector<Impulse>& output, float strength, float radiusScale) {
    output.clear();
    if (!std::isfinite(strength) || strength < 0 || strength > 20 ||
        !std::isfinite(radiusScale) || radiusScale < 0.5f || radiusScale > 4)
        throw std::invalid_argument("Invalid interaction strength/radius");
    if (!std::isfinite(dt) || dt <= 0 || dt > 0.25) { reset(); return; }
    std::vector<Previous> next;
    next.reserve(contacts.size());
    for (const auto& c : contacts) {
        if (!std::isfinite(c.position.x) || !std::isfinite(c.position.y) || !std::isfinite(c.baseZ) ||
            !std::isfinite(c.waterLevel) || !std::isfinite(c.radius)) continue;
        const float depth = c.waterLevel - c.baseZ;
        const bool touching = depth >= -6 && depth <= (c.swimming ? 160 : 100);
        const auto old = std::find_if(previous_.begin(), previous_.end(), [&](const Previous& p) { return p.contact.id == c.id; });
        // A newly loaded actor seeds history; spawning or loading is not an impact.
        if (old != previous_.end() && std::abs(old->contact.waterLevel - c.waterLevel) < 8) {
            const float dx = c.position.x - old->contact.position.x, dy = c.position.y - old->contact.position.y;
            const float distance = std::hypot(dx,dy);
            const float speed = distance / static_cast<float>(dt);
            const float downward = (old->contact.baseZ - c.baseZ) / static_cast<float>(dt);
            if (distance < 512 && speed < 2000 && touching) {
                if (!old->touching && downward > 10) output.push_back({c.position, c.radius * 1.4f, std::min(150.0f, downward * 0.3f)});
                if (speed > 8 && distance > 0.001f) {
                    // Deposit continuously along the traversed segment; prevents gaps at low FPS.
                    const int samples = std::clamp(static_cast<int>(std::ceil(distance / std::max(8.0f,c.radius))), 1, 16);
                    const float impulse = std::min(100.0f, speed * 0.8f) * static_cast<float>(dt) / float(samples);
                    for (int k = 1; k <= samples; ++k) {
                        const float t = float(k) / float(samples);
                        output.push_back({{std::lerp(old->contact.position.x,c.position.x,t), std::lerp(old->contact.position.y,c.position.y,t)}, c.radius, impulse});
                    }
                }
            }
        }
        next.push_back({c,touching});
    }
    previous_.swap(next);
    if (strength == 0) { output.clear(); return; }
    for (auto& impulse : output) { impulse.velocity *= strength; impulse.radius *= radiusScale; }
}
} // namespace st
