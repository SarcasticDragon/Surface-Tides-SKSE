#include "surfacetides/FloeMotion.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>

namespace st {
namespace {
bool finite(Vec2 v) { return std::isfinite(v.x) && std::isfinite(v.y); }
bool validField(const SurfaceFieldView& f, float level, std::uint64_t area) {
    if (!f.active || !area || area != f.area || f.resolution < 2 || f.resolution > 512 ||
        !finite(f.origin) || !std::isfinite(f.spacing) || f.spacing <= 0 ||
        !std::isfinite(f.restLevel) || !std::isfinite(level) ||
        !(std::abs(level-f.restLevel) < 2.0f) ||
        !std::isfinite(f.displacementStrength) || f.displacementStrength < 0) return false;
    const auto n=static_cast<std::size_t>(f.resolution);
    return f.texels.size() == n*n;
}
bool finite(FloePose p) { return std::isfinite(p.heave) && finite(p.slope); }
}
SurfaceHeight sampleSurfaceHeight(const SurfaceFieldView& f, Vec2 world, float level, std::uint64_t area) noexcept {
    if (!validField(f,level,area) || !finite(world)) return {};
    const float gx=(world.x-f.origin.x)/f.spacing, gy=(world.y-f.origin.y)/f.spacing;
    const float last=static_cast<float>(f.resolution-1);
    // Also handles overflow in coordinate conversion without integer casts.
    if (!(gx >= 0 && gy >= 0 && gx <= last && gy <= last)) return {0,0,true};
    const int x0=static_cast<int>(gx), y0=static_cast<int>(gy);
    const int x1=std::min(x0+1,f.resolution-1), y1=std::min(y0+1,f.resolution-1);
    const float u=gx-static_cast<float>(x0), v=gy-static_cast<float>(y0);
    auto at=[&](int x,int y) -> const SurfaceTexel& { return f.texels[static_cast<std::size_t>(y*f.resolution+x)]; };
    const std::array<const SurfaceTexel*,4> samples{&at(x0,y0),&at(x1,y0),&at(x0,y1),&at(x1,y1)};
    for (const auto* s : samples)
        if (!std::isfinite(s->height) || !std::isfinite(s->wet) || s->wet < 0 || s->wet > 1) return {};
    auto bilinear=[&](auto member) {
        const float a=std::lerp(samples[0]->*member,samples[1]->*member,u);
        const float b=std::lerp(samples[2]->*member,samples[3]->*member,u);
        return std::lerp(a,b,v);
    };
    const float edge=std::min({gx,gy,last-gx,last-gy});
    const float t=std::clamp(edge/std::max(1.0f,static_cast<float>(f.edgeFadeCells)),0.0f,1.0f);
    const float coverage=t*t*(3-2*t)*bilinear(&SurfaceTexel::wet);
    const float displacement=bilinear(&SurfaceTexel::height)*coverage*f.displacementStrength;
    if (!std::isfinite(displacement)) return {};
    return {displacement,coverage,true};
}

FloeTarget fitFloeTarget(const SurfaceFieldView& field, const FloeFootprint& p, FloeLimits limits) noexcept {
    if (!finite(p.center) || !finite(p.halfExtent) || p.halfExtent.x <= 0 || p.halfExtent.y <= 0 ||
        !std::isfinite(p.yawRadians) || !std::isfinite(limits.maxHeave) || limits.maxHeave < 0 ||
        !std::isfinite(limits.maxTiltRadians) || limits.maxTiltRadians < 0 || limits.maxTiltRadians > 1.0f) return {};
    const double c=std::cos(static_cast<double>(p.yawRadians)), s=std::sin(static_cast<double>(p.yawRadians));
    double height=0, coverage=0, xu=0, yv=0;
    for (int y=-1;y<=1;++y) for (int x=-1;x<=1;++x) {
        const double u=x*static_cast<double>(p.halfExtent.x), v=y*static_cast<double>(p.halfExtent.y);
        const Vec2 world{static_cast<float>(p.center.x+c*u-s*v),static_cast<float>(p.center.y+s*u+c*v)};
        const auto sample=sampleSurfaceHeight(field,world,p.waterLevel,p.area);
        if (!sample.valid) return {};
        height+=sample.displacement; coverage+=sample.coverage;
        xu+=u*sample.displacement; yv+=v*sample.displacement;
    }
    // Sum(u)=sum(v)=sum(uv)=0; sum(u*u)=6*halfExtent.x^2.
    const double a=xu/(6.0*static_cast<double>(p.halfExtent.x)*p.halfExtent.x);
    const double b=yv/(6.0*static_cast<double>(p.halfExtent.y)*p.halfExtent.y);
    double sx=c*a-s*b, sy=s*a+c*b;
    const double magnitude=std::hypot(sx,sy), maxSlope=std::tan(static_cast<double>(limits.maxTiltRadians));
    if (magnitude > maxSlope) { sx*=maxSlope/magnitude; sy*=maxSlope/magnitude; }
    FloePose pose{static_cast<float>(std::clamp(height/9.0,-static_cast<double>(limits.maxHeave),static_cast<double>(limits.maxHeave))),
                  {static_cast<float>(sx),static_cast<float>(sy)}};
    if (!finite(pose)) return {};
    return {pose,static_cast<float>(coverage/9.0),true};
}

FloeCrestTarget fitFloeCrestTarget(const SurfaceFieldView& field, const FloeFootprint& p,
    FloeLimits limits, float strength, float extraLift) noexcept {
    if (!std::isfinite(strength) || strength<0 || strength>1 ||
        !std::isfinite(extraLift) || extraLift<0 || extraLift>32) return {};
    FloeCrestTarget out;
    out.target=fitFloeTarget(field,p,limits);
    if (!out.target.valid) return out;
    out.meanHeave=out.target.pose.heave;
    if (strength==0 || field.displacementStrength==0) return out;
    const auto intervals=[&](float half) {
        return static_cast<int>(std::clamp(std::ceil(2.0*half/field.spacing),2.0,64.0));
    };
    const int nx=intervals(p.halfExtent.x), ny=intervals(p.halfExtent.y);
    const double c=std::cos(static_cast<double>(p.yawRadians)), s=std::sin(static_cast<double>(p.yawRadians));
    double requiredHeave=-std::numeric_limits<double>::infinity(), peak=requiredHeave, amplitude=0, coverage=0;
    for (int y=0;y<=ny;++y) for (int x=0;x<=nx;++x) {
        const double u=(2.0*x/nx-1)*p.halfExtent.x, v=(2.0*y/ny-1)*p.halfExtent.y;
        const double dx=c*u-s*v, dy=s*u+c*v;
        const Vec2 point{static_cast<float>(p.center.x+dx),static_cast<float>(p.center.y+dy)};
        const auto sample=sampleSurfaceHeight(field,point,p.waterLevel,p.area);
        if (!sample.valid) return {}; // never propagate a poisoned field into motion
        ++out.samples; coverage+=sample.coverage;
        if (sample.coverage<=0) continue;
        peak=std::max(peak,static_cast<double>(sample.displacement));
        amplitude=std::max(amplitude,std::abs(static_cast<double>(sample.displacement)));
        // Account for the fitted tilt. Maximum height alone could leave a
        // crest piercing the low side of the tilted plane.
        requiredHeave=std::max(requiredHeave,sample.displacement-
            out.target.pose.slope.x*dx-out.target.pose.slope.y*dy);
    }
    out.target.coverage=static_cast<float>(coverage/out.samples);
    if (!std::isfinite(requiredHeave)) return out; // no wet samples: settle normally
    out.peakDisplacement=static_cast<float>(peak);
    // No permanent levitation in calm water, when displacement is zero, or
    // outside the local field. The clearance margin reaches full size at four
    // units of sampled wave amplitude, fading continuously below that.
    const double margin=extraLift*std::min(1.0,amplitude/4.0);
    const double wanted=out.meanHeave+strength*(std::max(0.0,requiredHeave-out.meanHeave)+margin);
    const double bounded=std::clamp(wanted,-static_cast<double>(limits.maxHeave),static_cast<double>(limits.maxHeave));
    out.limited=wanted>bounded;
    out.target.pose.heave=static_cast<float>(bounded);
    out.addedLift=out.target.pose.heave-out.meanHeave;
    return out;
}

FloePose approachFloeTarget(FloePose prior, const FloeTarget& target, float dt, float response) noexcept {
    if (!finite(prior)) prior={};
    if (!std::isfinite(dt) || dt <= 0 || !std::isfinite(response) || response < 0) return prior;
    const FloePose goal=target.valid && finite(target.pose) ? target.pose : FloePose{};
    const float blend=response == 0 ? 1.0f : static_cast<float>(-std::expm1(-static_cast<double>(dt)/response));
    return {std::lerp(prior.heave,goal.heave,blend),
            {std::lerp(prior.slope.x,goal.slope.x,blend),std::lerp(prior.slope.y,goal.slope.y,blend)}};
}
std::array<float,9> floeTiltRotation(FloePose pose) noexcept {
    if (!finite(pose)) return {1,0,0,0,1,0,0,0,1};
    const double x=-static_cast<double>(pose.slope.x), y=-static_cast<double>(pose.slope.y);
    const double inv=1/std::sqrt(x*x+y*y+1), nz=inv;
    const double denom=std::sqrt(2*(1+nz));
    const double qx=-y*inv/denom, qy=x*inv/denom, qw=denom/2;
    return {static_cast<float>(1-2*qy*qy),static_cast<float>(2*qx*qy),static_cast<float>(2*qy*qw),
            static_cast<float>(2*qx*qy),static_cast<float>(1-2*qx*qx),static_cast<float>(-2*qx*qw),
            static_cast<float>(-2*qy*qw),static_cast<float>(2*qx*qw),static_cast<float>(1-2*(qx*qx+qy*qy))};
}
FloePose limitFloeStep(FloePose prior, FloePose next, float radius, float maxTravel) noexcept {
    if (!finite(prior)) prior={};
    if (!finite(next) || !std::isfinite(radius) || radius < 0 || !std::isfinite(maxTravel) || maxTravel <= 0) return prior;
    // Conservative rotation bound via Frobenius norm (bounds spectral norm).
    const auto a=floeTiltRotation(prior), b=floeTiltRotation(next);
    double sum=0;
    for (unsigned i=0;i<9;++i) { const double d=double(b[i])-a[i]; sum+=d*d; }
    const double travel=std::abs(double(next.heave)-prior.heave)+radius*std::sqrt(sum);
    if (travel <= maxTravel) return next;
    // Bisection also covers nonlinearity of the slope -> rotation mapping.
    float lo=0, hi=1;
    auto mix=[&](float t) -> FloePose { return {std::lerp(prior.heave,next.heave,t),
        {std::lerp(prior.slope.x,next.slope.x,t),std::lerp(prior.slope.y,next.slope.y,t)}}; };
    for (unsigned iteration=0;iteration<16;++iteration) {
        const float t=(lo+hi)*0.5f;
        const auto pose=mix(t); const auto rotation=floeTiltRotation(pose);
        sum=0;
        for (unsigned i=0;i<9;++i) { const double d=double(rotation[i])-a[i]; sum+=d*d; }
        if (std::abs(double(pose.heave)-prior.heave)+radius*std::sqrt(sum) <= maxTravel) lo=t;
        else hi=t;
    }
    return mix(lo);
}
} // namespace st
