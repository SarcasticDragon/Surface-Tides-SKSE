#include "RippleTrace.hpp"
#include "Bridge.hpp"
#include <algorithm>
#include <chrono>
#include <cstring>

namespace st::plugin {
namespace {
// Fixed lifetime budget: eight scopes per family, no faster than once per five
// seconds per family, and at most eight native rows per scope. No unbounded map.
std::array<unsigned,4> used{};
std::array<std::chrono::steady_clock::time_point,4> next{};
auto frameTime=std::chrono::steady_clock::time_point{};
std::uint32_t serial{};
std::uint64_t frameSerial{};
bool failed{};

// Device/context getters and descriptors only: no Map, Copy, Flush, query wait,
// or shader-bytecode access. Raw identities are logged, never retained here.
void resourceMetadata(std::uint32_t id,const char* role,unsigned slot,
    ID3D11View* view,DXGI_FORMAT format,unsigned viewDimension) {
    if (!view) return;
    ComPtr<ID3D11Resource> resource;
    view->GetResource(&resource);
    D3D11_RESOURCE_DIMENSION dimension{};
    if (resource) resource->GetType(&dimension);
    ComPtr<ID3D11Texture2D> texture;
    D3D11_TEXTURE2D_DESC desc{};
    if (resource && SUCCEEDED(resource.As(&texture))) texture->GetDesc(&desc);
    SKSE::log::info("Ripple resource scope={} role={} slot={} view={} resource={} dimension={} viewDimension={} viewFormat={} textureFormat={} size={}x{} array={} mips={} samples={}:{} usage={} bind={:X}",
        id,role,slot,static_cast<void*>(view),static_cast<void*>(resource.Get()),static_cast<unsigned>(dimension),viewDimension,
        static_cast<unsigned>(format),static_cast<unsigned>(desc.Format),desc.Width,desc.Height,desc.ArraySize,desc.MipLevels,
        desc.SampleDesc.Count,desc.SampleDesc.Quality,static_cast<unsigned>(desc.Usage),desc.BindFlags);
}
void bufferMetadata(std::uint32_t id,const char* role,unsigned slot,
    ID3D11Buffer* buffer,UINT stride=0,UINT offset=0) {
    if (!buffer) return;
    D3D11_BUFFER_DESC desc{}; buffer->GetDesc(&desc);
    SKSE::log::info("Ripple buffer scope={} role={} slot={} object={} bytes={} stride={} offset={} usage={} bind={:X} cpu={:X} misc={:X}",
        id,role,slot,static_cast<void*>(buffer),desc.ByteWidth,stride,offset,static_cast<unsigned>(desc.Usage),desc.BindFlags,desc.CPUAccessFlags,desc.MiscFlags);
}
}
bool rippleTraceEnabled() noexcept {
    return config.rippleTrace && config.diagnostics && !failed &&
        (used[0]<8 || used[1]<8 || used[2]<8 || used[3]<8);
}
void nextRippleTraceFrame() noexcept {
    if (rippleTraceEnabled()) { frameTime=std::chrono::steady_clock::now(); ++frameSerial; }
}
RippleGeometry captureRippleGeometry(RE::BSRenderPass* pass) noexcept {
    RippleGeometry info;
    if (!rippleTraceEnabled() || !pass || !pass->geometry) return info;
    // Avoid extra scene inspection between scheduled samples and after exhaustion.
    bool due=false;
    for (unsigned i=0;i<4;++i) due|=used[i]<8 && frameTime>=next[i];
    if (!due) return info;
    try {
        auto* g=pass->geometry;
        info.known=true; info.identity=reinterpret_cast<std::uintptr_t>(g);
        if (const char* name=g->name.c_str()) {
            const auto n=std::min(std::strlen(name),info.name.size()-1);
            std::memcpy(info.name.data(),name,n);
            for (std::size_t i=0;i<n;++i) if (static_cast<unsigned char>(info.name[i])<32) info.name[i]=' ';
        }
        info.type=static_cast<std::uint32_t>(g->GetType().underlying());
        info.pass=pass->passEnum;
        if (auto* tri=g->AsTriShape()) {
            const auto& data=tri->GetTrishapeRuntimeData();
            info.vertices=data.vertexCount; info.triangles=data.triangleCount;
        }
        const auto& model=g->GetModelData().modelBound;
        info.center=g->world*model.center;
        info.radius=model.radius*std::abs(g->world.scale);
        info.modelZ=model.center.z; info.localZ=g->local.translate.z;
        info.worldZ=g->world.translate.z; info.scale=g->world.scale;
        info.stationary=std::memcmp(&g->world,&g->previousWorld,sizeof(RE::NiTransform))==0;
    } catch (...) { failed=true; info={}; }
    return info;
}
std::uint32_t startRippleTrace(std::uint32_t vs,std::uint32_t ps,
    const st::DrawSignature& draw,const RippleGeometry& g,const Frame* rendered) noexcept {
    if (!rippleTraceEnabled()) return 0;
    const auto technique=(vs>>11)&15u;
    if (technique>=8 && technique!=10 && technique!=8) return 0;
    const unsigned family=technique==8 ? 3u : (technique==10 ? 2u : ((vs|ps)&0x40u ? 1u : 0u));
    if (used[family]>=8 || frameTime<next[family]) return 0;
    try {
        const auto published=rendered ? std::shared_ptr<const Frame>{} : exchange.read();
        const auto* f=rendered ? rendered : published.get();
        if (!f || !f->active) return 0;
        // Prefer nearby, plausibly same-level water. This filter affects logging
        // ONLY. The center is not proof of every source vertex's resting height.
        if (g.known && (!std::isfinite(g.center.z) || std::abs(g.center.z-f->level)>32 ||
            g.center.x+g.radius<f->origin.x || g.center.y+g.radius<f->origin.y ||
            g.center.x-g.radius>f->origin.x+(f->resolution-1)*f->spacing ||
            g.center.y-g.radius>f->origin.y+(f->resolution-1)*f->spacing)) return 0;
        ++used[family];
        next[family]=frameTime+std::chrono::seconds(5);
        const auto id=++serial;
        SKSE::log::info("Ripple scope={} frame={} family={} VS={:X} PS={:X} kind={} args=[{},{},{},{},{}] topology={} fieldSeq={} rest={:.4f} origin=({:.1f},{:.1f}) spacing={} targetEdge={} levelTolerance=2 fieldSource={} [raw API args; kinds4..6 counts unknown]",
            id,frameSerial,family==3?"underwater":(family==2?"stencil":(family==1?"wading":"base")),vs,ps,draw.kind,draw.arguments[0],draw.arguments[1],draw.arguments[2],draw.arguments[3],draw.arguments[4],draw.topology,
            f->sequence,f->level,f->origin.x,f->origin.y,f->spacing,tuning.read().values.tessellationSpacing,rendered?"uploaded":"published");
        SKSE::log::info("Ripple geometry scope={} known={} object={:X} name='{}' type={} pass={:X} vertices={} triangles={} stationary={} center=({:.3f},{:.3f},{:.4f}) radius={:.2f} modelCenterZ={:.4f} localZ={:.4f} worldZ={:.4f} scale={:.4f} centerLevelDelta={:.4f} centerInHeightBand={} [center is a bound estimate, not vertex data]",
            id,g.known,g.identity,g.name.data(),g.type,g.pass,g.vertices,g.triangles,g.stationary,g.center.x,g.center.y,g.center.z,g.radius,g.modelZ,g.localZ,g.worldZ,g.scale,
            g.known?g.center.z-f->level:0.0f,g.known && std::abs(g.center.z-f->level)<2);
        return id;
    } catch (...) { failed=true; return 0; }
}
void traceRippleNative(ID3D11DeviceContext* c,std::uint32_t id,unsigned ordinal,
    const st::DrawSignature& draw,bool candidate) noexcept {
    if (!id || ordinal>8 || failed) return;
    try {
        ComPtr<ID3D11HullShader> hs; ComPtr<ID3D11DomainShader> ds;
        ComPtr<ID3D11PixelShader> ps;
        ComPtr<ID3D11DepthStencilState> depth;
        ComPtr<ID3D11BlendState> blend; ComPtr<ID3D11RasterizerState> raster;
        ComPtr<ID3D11RenderTargetView> rt; ComPtr<ID3D11DepthStencilView> dsv;
        UINT stencilRef{},mask{}; FLOAT factors[4]{};
        c->HSGetShader(&hs,nullptr,nullptr); c->DSGetShader(&ds,nullptr,nullptr);
        c->PSGetShader(&ps,nullptr,nullptr);
        c->OMGetDepthStencilState(&depth,&stencilRef);
        c->OMGetBlendState(&blend,factors,&mask);
        c->RSGetState(&raster); c->OMGetRenderTargets(1,&rt,&dsv);
        D3D11_DEPTH_STENCIL_DESC dd=CD3D11_DEPTH_STENCIL_DESC(D3D11_DEFAULT); if (depth) depth->GetDesc(&dd);
        D3D11_BLEND_DESC bd=CD3D11_BLEND_DESC(D3D11_DEFAULT); if (blend) blend->GetDesc(&bd);
        D3D11_RASTERIZER_DESC rd=CD3D11_RASTERIZER_DESC(D3D11_DEFAULT); if (raster) raster->GetDesc(&rd);
        SKSE::log::info("Ripple native scope={} n={} kind={} count={} topology={} candidate={} HS={} DS={} PS={} RT0={} DSV={} depthState={} depthEnable={} depthWrite={} depthFunc={} stencil={} ref={} blendState={} blend0={} src={} dst={} writeMask={} rasterState={} depthBias={} slopeBias={} cull={} frontCCW={} depthClip={} [null state uses D3D defaults]",
            id,ordinal,draw.kind,draw.arguments[0],draw.topology,candidate,bool(hs),bool(ds),static_cast<void*>(ps.Get()),static_cast<void*>(rt.Get()),static_cast<void*>(dsv.Get()),
            bool(depth),dd.DepthEnable,static_cast<unsigned>(dd.DepthWriteMask),static_cast<unsigned>(dd.DepthFunc),dd.StencilEnable,stencilRef,
            bool(blend),bd.RenderTarget[0].BlendEnable,static_cast<unsigned>(bd.RenderTarget[0].SrcBlend),static_cast<unsigned>(bd.RenderTarget[0].DestBlend),bd.RenderTarget[0].RenderTargetWriteMask,
            bool(raster),rd.DepthBias,rd.SlopeScaledDepthBias,static_cast<unsigned>(rd.CullMode),rd.FrontCounterClockwise,rd.DepthClipEnable);
        SKSE::log::info("Ripple state scope={} n={} stencilRead={:X} stencilWrite={:X} front=[{},{},{},{}] back=[{},{},{},{}] blendOp={} alpha=[{},{},{}] alphaToCoverage={} independentBlend={} sampleMask={:X} blendFactors=[{},{},{},{}] fill={} biasClamp={} scissor={} multisample={}",
            id,ordinal,dd.StencilReadMask,dd.StencilWriteMask,
            static_cast<unsigned>(dd.FrontFace.StencilFailOp),static_cast<unsigned>(dd.FrontFace.StencilDepthFailOp),static_cast<unsigned>(dd.FrontFace.StencilPassOp),static_cast<unsigned>(dd.FrontFace.StencilFunc),
            static_cast<unsigned>(dd.BackFace.StencilFailOp),static_cast<unsigned>(dd.BackFace.StencilDepthFailOp),static_cast<unsigned>(dd.BackFace.StencilPassOp),static_cast<unsigned>(dd.BackFace.StencilFunc),
            static_cast<unsigned>(bd.RenderTarget[0].BlendOp),static_cast<unsigned>(bd.RenderTarget[0].SrcBlendAlpha),static_cast<unsigned>(bd.RenderTarget[0].DestBlendAlpha),static_cast<unsigned>(bd.RenderTarget[0].BlendOpAlpha),
            bd.AlphaToCoverageEnable,bd.IndependentBlendEnable,mask,factors[0],factors[1],factors[2],factors[3],static_cast<unsigned>(rd.FillMode),rd.DepthBiasClamp,rd.ScissorEnable,rd.MultisampleEnable);
    } catch (...) { failed=true; }
}
void traceStandaloneWater(ID3D11DeviceContext* c,std::uint32_t vs,std::uint32_t ps,
    const st::DrawSignature& draw,const RippleGeometry& geometry,const Frame* rendered) noexcept {
    const auto id=startRippleTrace(vs,ps,draw,geometry,rendered);
    if (!id) return;
    traceRippleNative(c,id,1,draw,true);
    if (failed) return;
    try {
        // Read one slot at a time so each COM reference has an RAII owner even
        // if a logging allocation throws. No pipeline setters occur here.
        for (UINT i=0;i<D3D11_IA_VERTEX_INPUT_RESOURCE_SLOT_COUNT;++i) {
            ComPtr<ID3D11Buffer> buffer; UINT stride{},offset{};
            c->IAGetVertexBuffers(i,1,&buffer,&stride,&offset);
            bufferMetadata(id,"VB",i,buffer.Get(),stride,offset);
        }
        ComPtr<ID3D11Buffer> indices; DXGI_FORMAT indexFormat{}; UINT indexOffset{};
        c->IAGetIndexBuffer(&indices,&indexFormat,&indexOffset);
        bufferMetadata(id,"IB",0,indices.Get(),0,indexOffset);
        ComPtr<ID3D11InputLayout> layout; c->IAGetInputLayout(&layout);
        SKSE::log::info("Ripple input scope={} layout={} indexFormat={} [IB may be bound for a non-indexed draw]",id,static_cast<void*>(layout.Get()),static_cast<unsigned>(indexFormat));
        for (UINT i=0;i<3;++i) {
            ComPtr<ID3D11Buffer> vertex,pixel;
            c->VSGetConstantBuffers(i,1,&vertex); c->PSGetConstantBuffers(i,1,&pixel);
            bufferMetadata(id,"VS-CB",i,vertex.Get()); bufferMetadata(id,"PS-CB",i,pixel.Get());
        }
        std::array<D3D11_VIEWPORT,D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE> viewports{};
        UINT viewportCount=static_cast<UINT>(viewports.size()); c->RSGetViewports(&viewportCount,viewports.data());
        for (UINT i=0;i<std::min(viewportCount,static_cast<UINT>(viewports.size()));++i) {
            const auto& v=viewports[i];
            SKSE::log::info("Ripple viewport scope={} slot={} xy=[{},{}] size=[{},{}] depth=[{},{}]",id,i,v.TopLeftX,v.TopLeftY,v.Width,v.Height,v.MinDepth,v.MaxDepth);
        }
        std::array<D3D11_RECT,D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE> scissors{};
        UINT scissorCount=static_cast<UINT>(scissors.size()); c->RSGetScissorRects(&scissorCount,scissors.data());
        for (UINT i=0;i<std::min(scissorCount,static_cast<UINT>(scissors.size()));++i) {
            const auto& r=scissors[i];
            SKSE::log::info("Ripple scissor scope={} slot={} rect=[{},{},{},{}]",id,i,r.left,r.top,r.right,r.bottom);
        }
        // OMGetRenderTargets has no start-slot parameter. Acquire all eight
        // views, immediately adopting every returned reference before logging.
        std::array<ID3D11RenderTargetView*,D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT> raw{};
        std::array<ComPtr<ID3D11RenderTargetView>,D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT> targets;
        ComPtr<ID3D11DepthStencilView> depthView;
        c->OMGetRenderTargets(static_cast<UINT>(raw.size()),raw.data(),&depthView);
        for (UINT i=0;i<raw.size();++i) targets[i].Attach(raw[i]);
        for (UINT i=0;i<targets.size();++i) if (targets[i]) {
            D3D11_RENDER_TARGET_VIEW_DESC d{}; targets[i]->GetDesc(&d);
            resourceMetadata(id,"RT",i,targets[i].Get(),d.Format,static_cast<unsigned>(d.ViewDimension));
        }
        if (depthView) {
            D3D11_DEPTH_STENCIL_VIEW_DESC d{}; depthView->GetDesc(&d);
            resourceMetadata(id,"DSV",0,depthView.Get(),d.Format,static_cast<unsigned>(d.ViewDimension));
            SKSE::log::info("Ripple depthView scope={} flags={:X}",id,d.Flags);
        }
        // Includes the game's normal/ripple, refraction and depth inputs. Only
        // object identity and shape are inspected; sampled pixels stay on GPU.
        for (UINT i=0;i<12;++i) {
            ComPtr<ID3D11ShaderResourceView> view; c->PSGetShaderResources(i,1,&view);
            if (view) {
                D3D11_SHADER_RESOURCE_VIEW_DESC d{}; view->GetDesc(&d);
                resourceMetadata(id,"PS-SRV",i,view.Get(),d.Format,static_cast<unsigned>(d.ViewDimension));
            }
        }
        SKSE::log::info("Ripple standalone end scope={} stage=before-water-replacement metadataOnly=true",id);
    } catch (...) { failed=true; }
}
void finishRippleTrace(std::uint32_t id,unsigned native,unsigned selected,unsigned prepared,unsigned patches) noexcept {
    if (!id || failed) return;
    try { SKSE::log::info("Ripple end scope={} nativeCalls={} selected={} prepared={} nativePatches={} rowsOmitted={}",id,native,selected,prepared,patches,native>8?native-8:0); }
    catch (...) { failed=true; }
}
}
