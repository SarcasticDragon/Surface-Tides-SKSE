#include "Renderer.hpp"
#include "RippleTrace.hpp"
#include <d3d11_3.h>
#include "surfacetides/ShaderReflection.hpp"
#include "surfacetides/ShaderIdentity.hpp"
#include "surfacetides/ConstantBinding.hpp"
#include <cstring>
#include <sstream>

namespace st::plugin {
namespace {
// Application-owned metadata only. A conforming forwarding wrapper can expose
// the same tag through its underlying device-child object without code inspection.
constexpr GUID waterIdentityGUID{0x21fb12d8,0x74c3,0x4b42,{0x8f,0x61,0xa6,0xc5,0x29,0x7e,0x09,0x31}};
using WaterIdentity = st::ShaderIdentity;
bool readIdentity(ID3D11DeviceChild* object, WaterIdentity& tag) {
    UINT bytes = sizeof(tag);
    return object && SUCCEEDED(object->GetPrivateData(waterIdentityGUID,&bytes,&tag)) && bytes == sizeof(tag);
}
bool tagIdentity(ID3D11DeviceChild* object, WaterIdentity tag, std::size_t& ambiguous) {
    WaterIdentity existing;
    if (readIdentity(object,existing)) {
        tag = st::mergeShaderIdentity(tag,&existing);
        if (tag.index == st::ambiguousShaderIdentity) ++ambiguous;
    }
    return SUCCEEDED(object->SetPrivateData(waterIdentityGUID,sizeof(tag),&tag));
}
template<class Object, class NativeMap, class Cache, class Records>
auto resolveIdentity(Object* object, const NativeMap& native, Cache& cache, const Records& records,
    std::uint64_t generation, std::uint32_t stage, bool enabled,
    std::uint64_t& reads, std::uint64_t& matches) -> typename NativeMap::mapped_type {
    if (const auto it = native.find(object); it != native.end()) return it->second;
    if (!object || !enabled) return nullptr;
    if (const auto it = cache.find(object); it != cache.end()) return it->second.metadata;
    typename NativeMap::mapped_type metadata = nullptr;
    WaterIdentity tag;
    ++reads;
    if (readIdentity(object,tag) && st::validShaderIdentity(tag,generation,stage,records.size())) {
        metadata = records[tag.index]; ++matches;
    }
    // Bounded per-generation cache keeps GetPrivateData off the hot draw path.
    if (cache.size() >= 4096) cache.clear();
    typename Cache::mapped_type entry;
    entry.object = object; entry.metadata = metadata;
    cache.emplace(object,std::move(entry));
    return metadata;
}
constexpr UINT slots[] = {0,1,2,11,12};
using GetCB = void (STDMETHODCALLTYPE ID3D11DeviceContext::*)(UINT,UINT,ID3D11Buffer**);
using SetCB = void (STDMETHODCALLTYPE ID3D11DeviceContext::*)(UINT,UINT,ID3D11Buffer* const*);
using GetSRV = void (STDMETHODCALLTYPE ID3D11DeviceContext::*)(UINT,UINT,ID3D11ShaderResourceView**);
using SetSRV = void (STDMETHODCALLTYPE ID3D11DeviceContext::*)(UINT,UINT,ID3D11ShaderResourceView* const*);
using GetS = void (STDMETHODCALLTYPE ID3D11DeviceContext::*)(UINT,UINT,ID3D11SamplerState**);
using SetS = void (STDMETHODCALLTYPE ID3D11DeviceContext::*)(UINT,UINT,ID3D11SamplerState* const*);
constexpr GetCB getCB[] = {&ID3D11DeviceContext::VSGetConstantBuffers,&ID3D11DeviceContext::PSGetConstantBuffers,&ID3D11DeviceContext::HSGetConstantBuffers,&ID3D11DeviceContext::DSGetConstantBuffers};
constexpr SetCB setCB[] = {&ID3D11DeviceContext::VSSetConstantBuffers,&ID3D11DeviceContext::PSSetConstantBuffers,&ID3D11DeviceContext::HSSetConstantBuffers,&ID3D11DeviceContext::DSSetConstantBuffers};
constexpr GetSRV getSRV[] = {&ID3D11DeviceContext::VSGetShaderResources,&ID3D11DeviceContext::PSGetShaderResources,&ID3D11DeviceContext::HSGetShaderResources,&ID3D11DeviceContext::DSGetShaderResources};
constexpr SetSRV setSRV[] = {&ID3D11DeviceContext::VSSetShaderResources,&ID3D11DeviceContext::PSSetShaderResources,&ID3D11DeviceContext::HSSetShaderResources,&ID3D11DeviceContext::DSSetShaderResources};
constexpr GetS getS[] = {&ID3D11DeviceContext::VSGetSamplers,&ID3D11DeviceContext::PSGetSamplers,&ID3D11DeviceContext::HSGetSamplers,&ID3D11DeviceContext::DSGetSamplers};
constexpr SetS setS[] = {&ID3D11DeviceContext::VSSetSamplers,&ID3D11DeviceContext::PSSetSamplers,&ID3D11DeviceContext::HSSetSamplers,&ID3D11DeviceContext::DSSetSamplers};

UINT bufferBytes(ID3D11Buffer* buffer) {
    D3D11_BUFFER_DESC desc{}; if (buffer) buffer->GetDesc(&desc); return desc.ByteWidth;
}

std::string readText(const std::filesystem::path& path) {
    std::ifstream f(path,std::ios::binary);
    if (!f) throw std::runtime_error("Missing shader: " + path.string());
    return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};
}
class Includes : public ID3DInclude {
public:
    std::string vs, ps;
    HRESULT STDMETHODCALLTYPE Open(D3D_INCLUDE_TYPE, LPCSTR filename, LPCVOID, LPCVOID* data, UINT* bytes) noexcept override {
        try {
            std::string contents;
            if (std::string_view(filename) == "EngineVS.hlsli") contents = vs;
            else if (std::string_view(filename) == "EnginePS.hlsli") contents = ps;
            else contents = readText(std::filesystem::path("Data/Shaders/SurfaceTides") / filename);
            auto block = std::make_unique<std::string>(std::move(contents));
            *data = block->data(); *bytes = static_cast<UINT>(block->size());
            blocks_.emplace(*data,std::move(block)); return S_OK;
        } catch (...) { return E_FAIL; }
    }
    HRESULT STDMETHODCALLTYPE Close(LPCVOID data) noexcept override { blocks_.erase(data); return S_OK; }
private:
    std::unordered_map<const void*,std::unique_ptr<std::string>> blocks_;
};
ComPtr<ID3DBlob> compileBlob(const std::string& source, Includes& includes, std::uint32_t descriptor,
                            std::uint32_t pixelDescriptor, const char* stage, const char* target) {
    auto values = shaderDefines(descriptor,stage,pixelDescriptor);
    std::vector<D3D_SHADER_MACRO> defines;
    for (auto& [key,value] : values) defines.push_back({key.c_str(),value.c_str()});
    defines.push_back({nullptr,nullptr});
    ComPtr<ID3DBlob> blob, errors;
    const auto hr = D3DCompile(source.data(),source.size(),"SurfaceTides/Water.hlsl",defines.data(),&includes,
                              "main",target,D3DCOMPILE_ENABLE_STRICTNESS | D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&blob,&errors);
    if (FAILED(hr)) {
        const auto message = errors ? std::string(static_cast<const char*>(errors->GetBufferPointer()),errors->GetBufferSize()) : "No compiler diagnostics";
        throw std::runtime_error(std::string(target) + ": " + message);
    }
    return blob;
}
// Mesh preparation touches no VS/PS resources and only three HS/DS CB slots.
// Keep a dedicated snapshot instead of restoring the full replacement pipeline.
class MeshPipelineState {
public:
    ID3D11DeviceContext* c;
    ComPtr<ID3D11VertexShader> vs;
    ComPtr<ID3D11PixelShader> ps;
    ComPtr<ID3D11HullShader> hs;
    ComPtr<ID3D11DomainShader> ds;
    std::array<ComPtr<ID3D11Buffer>,2> source;
    std::array<std::array<ComPtr<ID3D11Buffer>,3>,2> saved;
    std::array<ComPtr<ID3D11ShaderResourceView>,2> resources;
    ComPtr<ID3D11SamplerState> sampler;
    D3D11_PRIMITIVE_TOPOLOGY topology{};
    unsigned incompatibilityMask{};
    bool changed{}, motionChanged{};
    static constexpr UINT cbSlots[3]={2,11,12};
    explicit MeshPipelineState(ID3D11DeviceContext* ctx):c(ctx) {
        UINT v=0,p=0,h=0,d=0;
        c->VSGetShader(&vs,nullptr,&v); c->PSGetShader(&ps,nullptr,&p);
        c->HSGetShader(&hs,nullptr,&h); c->DSGetShader(&ds,nullptr,&d);
        ComPtr<ID3D11GeometryShader> gs; c->GSGetShader(&gs,nullptr,nullptr);
        c->IAGetPrimitiveTopology(&topology);
        incompatibilityMask=(hs?1u:0u)|(ds?2u:0u)|(gs?4u:0u)|((v||p||h||d)?8u:0u);
        if (incompatibilityMask&12) return;
        c->VSGetConstantBuffers(2,1,&source[0]); c->VSGetConstantBuffers(12,1,&source[1]);
        for (UINT i=0;i<3;++i) {
            c->HSGetConstantBuffers(cbSlots[i],1,&saved[0][i]);
            c->DSGetConstantBuffers(cbSlots[i],1,&saved[1][i]);
        }
        ID3D11ShaderResourceView* raw[2]{}; c->DSGetShaderResources(96,2,raw);
        for (int i=0;i<2;++i) resources[i].Attach(raw[i]);
        c->DSGetSamplers(15,1,&sampler);
    }
    ID3D11Buffer* vertexBuffer(UINT i) const { return i==2 ? source[0].Get() : (i==4 ? source[1].Get() : nullptr); }
    void restore() {
        if (!changed) return;
        c->VSSetShader(vs.Get(),nullptr,0); c->PSSetShader(ps.Get(),nullptr,0);
        c->HSSetShader(hs.Get(),nullptr,0); c->DSSetShader(ds.Get(),nullptr,0);
        c->IASetPrimitiveTopology(topology);
        for (UINT i=0;i<3;++i) {
            auto* h=saved[0][i].Get(); auto* d=saved[1][i].Get();
            c->HSSetConstantBuffers(cbSlots[i],1,&h); c->DSSetConstantBuffers(cbSlots[i],1,&d);
        }
        ID3D11ShaderResourceView* raw[]={resources[0].Get(),resources[1].Get()};
        c->DSSetShaderResources(96,2,raw);
        auto* s=sampler.Get(); c->DSSetSamplers(15,1,&s);
        changed=false;
    }
    ~MeshPipelineState() {
        restore();
        if (motionChanged) c->VSSetShader(vs.Get(),nullptr,0);
    }
};
}

DrawState::DrawState(ID3D11DeviceContext* context) : context_(context) {
    UINT vertexClasses = 0, pixelClasses = 0, hullClasses = 0, domainClasses = 0;
    context_->VSGetShader(&vs,nullptr,&vertexClasses); context_->PSGetShader(&ps,nullptr,&pixelClasses);
    context_->HSGetShader(&hs_,nullptr,&hullClasses); context_->DSGetShader(&ds_,nullptr,&domainClasses);
    context_->IAGetPrimitiveTopology(&topology);
    ComPtr<ID3D11GeometryShader> gs;
    context_->GSGetShader(&gs,nullptr,nullptr);
    incompatibilityMask = (hs_ ? 1u : 0u) | (ds_ ? 2u : 0u) | (gs ? 4u : 0u) | ((vertexClasses || pixelClasses || hullClasses || domainClasses) ? 8u : 0u);
    compatible = incompatibilityMask == 0;
    for (int stage = 0; stage < 4; ++stage) {
        for (int i = 0; i < 5; ++i) (context_->*getCB[stage])(slots[i],1,stages_[stage].buffers[i].GetAddressOf());
        for (int i = 0; i < 2; ++i) (context_->*getSRV[stage])(96 + i,1,stages_[stage].textures[i].GetAddressOf());
        (context_->*getS[stage])(15,1,stages_[stage].sampler.GetAddressOf());
    }
}
DrawState::~DrawState() {
    restore();
}
void DrawState::restore() {
    if (!changed) return;
    context_->VSSetShader(vs.Get(),nullptr,0); context_->PSSetShader(ps.Get(),nullptr,0);
    context_->HSSetShader(hs_.Get(),nullptr,0); context_->DSSetShader(ds_.Get(),nullptr,0);
    context_->IASetPrimitiveTopology(topology);
    for (int stage = 0; stage < 4; ++stage) {
        for (int i = 0; i < 5; ++i) { auto* p = stages_[stage].buffers[i].Get(); (context_->*setCB[stage])(slots[i],1,&p); }
        for (int i = 0; i < 2; ++i) { auto* p = stages_[stage].textures[i].Get(); (context_->*setSRV[stage])(96 + i,1,&p); }
        auto* p = stages_[stage].sampler.Get(); (context_->*setS[stage])(15,1,&p);
    }
    changed = false;
}

Renderer& Renderer::get() { static Renderer instance; return instance; }
void Renderer::afterDraw(const DrawState& state) {
    if (!state.probe) return;
    auto* c = state.probeContext;
    ComPtr<ID3D11VertexShader> vs; ComPtr<ID3D11PixelShader> ps;
    ComPtr<ID3D11HullShader> hs; ComPtr<ID3D11DomainShader> ds;
    ComPtr<ID3D11ShaderResourceView> fieldPS, fieldDS;
    D3D11_PRIMITIVE_TOPOLOGY topology;
    c->VSGetShader(&vs,nullptr,nullptr); c->PSGetShader(&ps,nullptr,nullptr);
    c->HSGetShader(&hs,nullptr,nullptr); c->DSGetShader(&ds,nullptr,nullptr);
    c->IAGetPrimitiveTopology(&topology);
    c->PSGetShaderResources(96,1,&fieldPS); c->DSGetShaderResources(96,1,&fieldDS);
    const unsigned mask = (vs.Get()!=state.expectedVS ? 1u : 0u) |
        (ps.Get()!=state.expectedPS ? 2u : 0u) | (hs.Get()!=state.expectedHS ? 4u : 0u) |
        (ds.Get()!=state.expectedDS ? 8u : 0u) | (topology!=state.expectedTopology ? 16u : 0u) |
        (fieldPS.Get()!=state.expectedField ? 32u : 0u) | (fieldDS.Get()!=state.expectedField ? 64u : 0u);
    ++probedDraws_; if (mask) ++changedDraws_; changedMask_ |= mask;
}
void Renderer::nextFrame() {
    consumed_ = false;
    meshPolled_ = false;
    ++meshStats_[9];
    if (config.diagnostics && std::chrono::steady_clock::now() >= nextStats_) {
        nextStats_ = std::chrono::steady_clock::now() + std::chrono::seconds(5);
        SKSE::log::info("Draw scan since report: attempts={} inactive={} incompatible={} nonWaterShader={} lod={} bound={} tessellated={} failed={} uploadedSeq={} debugView={}",
            stats_[0],stats_[1],stats_[2],stats_[3],stats_[4],stats_[5],stats_[6],failedDraws_,gpuFrame_ ? gpuFrame_->sequence : 0,renderTuning_.debugView);
        if (rendererCoexistence()) {
            SKSE::log::info("Coexistence probe: sampledDraws={} changedAfterDraw={} changeMask={:02X} [VS=01 PS=02 HS=04 DS=08 topology=10 PSfield=20 DSfield=40]",probedDraws_,changedDraws_,changedMask_);
            SKSE::log::info("Water identity: tagReads={} newTagMatches={} unmatchedVS={} unmatchedPS={} cacheVS={} cachePS={}",
                tagReads_,tagMatches_,unmatchedVS_,unmatchedPS_,identityVS_.size(),identityPS_.size());
            if (incompatibleMask_) SKSE::log::info("Water pipeline rejection mask={:02X} [HS=01 DS=02 GS=04 dynamicClasses=08]",incompatibleMask_);
            SKSE::log::info("Water constant repair: remappedDraws={} unrecognizedLargePrefix={} enabled={}",
                shiftedConstantDraws_,unrecognizedConstantDraws_,config.restoreWaterConstants);
            shiftedConstantDraws_=unrecognizedConstantDraws_=0;
            incompatibleMask_ = 0;
            tagReads_ = tagMatches_ = unmatchedVS_ = unmatchedPS_ = 0;
            probedDraws_ = changedDraws_ = 0; changedMask_ = 0;
        }
        if (config.enbMeshInput) {
            SKSE::log::info("Mesh-input report: draws={} nativePatchDraws={} skips={} preparationFailures={} sampledSOPrimitives={} capacityBytes={} suspended={} boundsKnown={} outsideField={} queryPolls={} motionDraws={} presentFrames={} twoSidedDraws={} maxFactor={}",
                meshStats_[0],meshStats_[1],meshStats_[2],meshStats_[3],meshStats_[4],meshCapacity_,meshOverflow_,meshStats_[5],meshStats_[6],meshStats_[7],meshStats_[8],meshStats_[9],meshTwoSidedDraws_,config.meshTessellationMax);
            meshTwoSidedDraws_=0;
            meshStats_.fill(0);
        }
        stats_.fill(0); failedDraws_ = 0;
    }
}
void Renderer::prepare(ID3D11DeviceContext* context) {
    if (consumed_) return;
    consumed_ = true;
    renderTuning_ = tuning.read().values;
    const auto f = exchange.read();
    active_ = f && f->active && renderTuning_.previewEnabled;
    if (!active_) { gpuFrame_.reset(); return; }
    if (!device_) context->GetDevice(&device_);
    if (device_->GetFeatureLevel() < D3D_FEATURE_LEVEL_11_0) throw std::runtime_error("Direct3D feature level 11_0 is required");
    if (textureSize_ != f->resolution) {
        D3D11_TEXTURE2D_DESC desc{};
        desc.Width = desc.Height = f->resolution; desc.MipLevels = desc.ArraySize = 1;
        desc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT; desc.SampleDesc.Count = 1;
        desc.Usage = D3D11_USAGE_DYNAMIC; desc.BindFlags = D3D11_BIND_SHADER_RESOURCE; desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        for (int i = 0; i < 2; ++i) {
            views_[i].Reset(); textures_[i].Reset();
            check(device_->CreateTexture2D(&desc,nullptr,&textures_[i]),"Create field texture");
            check(device_->CreateShaderResourceView(textures_[i].Get(),nullptr,&views_[i]),"Create field SRV");
        }
        textureSize_ = f->resolution; gpuFrame_.reset();
    }
    if (!constants_) {
        D3D11_BUFFER_DESC desc{}; desc.ByteWidth = sizeof(parameters_); desc.Usage = D3D11_USAGE_DYNAMIC;
        desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER; desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        check(device_->CreateBuffer(&desc,nullptr,&constants_),"Create surface constants");
        D3D11_SAMPLER_DESC samp{}; samp.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
        samp.AddressU = samp.AddressV = samp.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
        samp.MaxLOD = D3D11_FLOAT32_MAX; samp.ComparisonFunc = D3D11_COMPARISON_NEVER;
        check(device_->CreateSamplerState(&samp,&sampler_),"Create field sampler");
    }
    auto old = gpuFrame_;
    previous_ = current_;
    const bool history = old && old->epoch == f->epoch;
    if (!old || old->sequence != f->sequence) {
        current_ = 1 - current_;
        D3D11_MAPPED_SUBRESOURCE mapped{};
        check(context->Map(textures_[current_].Get(),0,D3D11_MAP_WRITE_DISCARD,0,&mapped),"Map surface field");
        for (int y = 0; y < f->resolution; ++y)
            std::memcpy(static_cast<std::uint8_t*>(mapped.pData) + std::size_t(y) * mapped.RowPitch,
                        f->texels.data() + std::size_t(y) * f->resolution,std::size_t(f->resolution) * sizeof(Texel));
        context->Unmap(textures_[current_].Get(),0);
        gpuFrame_ = f;
    }
    if (!history) { previous_ = current_; old = f; }
    parameters_ = {f->origin.x,f->origin.y,f->spacing,f->level,
                   old->origin.x,old->origin.y,old->spacing,old->level,
                   float(f->resolution),renderTuning_.normalStrength,renderTuning_.displacementStrength,renderTuning_.tessellationMax,
                   1.0f,history ? 1.0f : 0.0f,float(f->spongeCells),2.0f,
                   float(renderTuning_.debugView),renderTuning_.tessellationSpacing,0,0};
    D3D11_MAPPED_SUBRESOURCE mapped{};
    check(context->Map(constants_.Get(),0,D3D11_MAP_WRITE_DISCARD,0,&mapped),"Map constants");
    std::memcpy(mapped.pData,parameters_.data(),sizeof(parameters_)); context->Unmap(constants_.Get(),0);
}

Renderer::Bundle Renderer::compile(RE::BSGraphics::VertexShader* v, RE::BSGraphics::PixelShader* p) {
    Includes includes;
    const auto source = readText("Data/Shaders/SurfaceTides/Water.hlsl");
    // Unused native table entries may alias offset zero. Reflect live constants first.
    includes.vs = engineConstantHeader(ShaderStage::Vertex,referenceConstantTable(ShaderStage::Vertex));
    includes.ps = engineConstantHeader(ShaderStage::Pixel,referenceConstantTable(ShaderStage::Pixel));
    const auto referenceVS = compileBlob(source,includes,v->id,p->id,"VSHADER","vs_5_0");
    const auto referencePS = compileBlob(source,includes,p->id,p->id,"PSHADER","ps_5_0");
    const auto liveVS = activeEngineConstants(referenceVS.Get()), livePS = activeEngineConstants(referencePS.Get());
    includes.vs = engineConstantHeader(ShaderStage::Vertex,v->constantTable,std::span<const std::string>(liveVS));
    includes.ps = engineConstantHeader(ShaderStage::Pixel,p->constantTable,std::span<const std::string>(livePS));
    Bundle result;
    auto vs = compileBlob(source,includes,v->id,p->id,"VSHADER","vs_5_0");
    auto ps = compileBlob(source,includes,p->id,p->id,"PSHADER","ps_5_0");
    result.requiredPSBytes = engineBufferRequirements(ps.Get());
    validateVertexInputs(v->rawBytecode,v->byteCodeSize,vs.Get());
    check(device_->CreateVertexShader(vs->GetBufferPointer(),vs->GetBufferSize(),nullptr,&result.vs),"Create VS");
    check(device_->CreatePixelShader(ps->GetBufferPointer(),ps->GetBufferSize(),nullptr,&result.ps),"Create PS");
    if (config.tessellation) {
        auto control = compileBlob(source,includes,v->id,p->id,"CONTROL_SHADER","vs_5_0");
        validateVertexInputs(v->rawBytecode,v->byteCodeSize,control.Get());
        auto hs = compileBlob(source,includes,v->id,p->id,"HSHADER","hs_5_0");
        auto ds = compileBlob(source,includes,v->id,p->id,"DSHADER","ds_5_0");
        check(device_->CreateVertexShader(control->GetBufferPointer(),control->GetBufferSize(),nullptr,&result.control),"Create control VS");
        check(device_->CreateHullShader(hs->GetBufferPointer(),hs->GetBufferSize(),nullptr,&result.hs),"Create HS");
        check(device_->CreateDomainShader(ds->GetBufferPointer(),ds->GetBufferSize(),nullptr,&result.ds),"Create DS");
    }
    result.valid = true;
    SKSE::log::info("Compiled independent water VS {:X}, PS {:X}",v->id,p->id);
    return result;
}

Renderer::MeshBundle Renderer::compileMesh(RE::BSGraphics::VertexShader* v, bool tryMotion) {
    Includes includes;
    const bool history=tryMotion && config.meshMotionVectors && ((v->id>>11)&15)==10;
    const std::vector<std::string> live=history ? std::vector<std::string>{"World","PreviousWorld","WorldViewProj"} : std::vector<std::string>{"World"};
    includes.vs=engineConstantHeader(ShaderStage::Vertex,v->constantTable,std::span<const std::string>(live));
    std::string prefix="#define ST_MESH_MAX_FACTOR "+std::to_string(config.meshTessellationMax)+"\n";
    std::vector<D3D11_INPUT_ELEMENT_DESC> elements;
    bool position=false;
    for (const auto& input : originalVertexInputs(v->rawBytecode,v->byteCodeSize)) {
        if (input.system || input.index || input.component!=D3D_REGISTER_COMPONENT_FLOAT32)
            throw std::runtime_error("Unsupported mesh input system value/type/index");
        if (!_stricmp(input.semantic.c_str(),"POSITION") && (input.mask & 7)==7) {
            position=true;
            elements.push_back({"POSITION",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0});
        } else if (!_stricmp(input.semantic.c_str(),"TEXCOORD") && input.mask==3) {
            prefix+="#define ST_MESH_UV 1\n";
            elements.push_back({"TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,16,D3D11_INPUT_PER_VERTEX_DATA,0});
        } else if (!_stricmp(input.semantic.c_str(),"COLOR") && input.mask==15) {
            prefix+="#define ST_MESH_COLOR 1\n";
            elements.push_back({"COLOR",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,24,D3D11_INPUT_PER_VERTEX_DATA,0});
        } else throw std::runtime_error("Unsupported mesh vertex attribute: "+input.semantic);
    }
    if (!position) throw std::runtime_error("Mesh input lacks position");
    if (history) prefix+="#define ST_MESH_HISTORY 1\n";
    const auto source=prefix+readText("Data/Shaders/SurfaceTides/MeshInput.hlsl");
    MeshBundle b;
    ComPtr<ID3DBlob> motion;
    if (history) {
        motion=compileBlob(source,includes,v->id,v->id,"MESH_MOTION_VS","vs_5_0");
        const auto expected=originalVertexInputs(v->rawBytecode,v->byteCodeSize,true);
        if (config.diagnostics) {
            std::ostringstream contract;
            for (const auto& e:expected) contract<<e.semantic<<e.index<<"@"<<e.registerIndex<<"/"<<unsigned(e.mask)<<" ";
            SKSE::log::info("Game stencil output contract VS={:X}: {}",v->id,contract.str());
        }
        const auto reflected=reflectShader(motion->GetBufferPointer(),motion->GetBufferSize());
        D3D11_SHADER_DESC desc{}; check(reflected->GetDesc(&desc),"Motion output signature");
        if (desc.OutputParameters!=expected.size()) throw std::runtime_error("Motion output count differs from game stencil VS");
        for (UINT i=0;i<desc.OutputParameters;++i) {
            D3D11_SIGNATURE_PARAMETER_DESC output{};
            check(reflected->GetOutputParameterDesc(i,&output),"Motion output parameter");
            bool matched=false;
            for (const auto& e:expected) if (!_stricmp(e.semantic.c_str(),output.SemanticName) && e.index==output.SemanticIndex &&
                e.component==output.ComponentType && e.system==output.SystemValueType && e.mask==output.Mask && e.registerIndex==output.Register) matched=true;
            if (!matched) throw std::runtime_error("Motion output differs from game stencil VS");
        }
        check(device_->CreateVertexShader(motion->GetBufferPointer(),motion->GetBufferSize(),nullptr,&b.motionVS),"Motion VS");
        b.stride=56;
    }
    const auto vs=compileBlob(source,includes,v->id,v->id,"MESH_VS","vs_5_0");
    const auto hs=compileBlob(source,includes,v->id,v->id,"MESH_HS","hs_5_0");
    const auto ds=compileBlob(source,includes,v->id,v->id,"MESH_DS","ds_5_0");
    const auto gs=compileBlob(source,includes,v->id,v->id,"MESH_GS","gs_5_0");
    validateVertexInputs(v->rawBytecode,v->byteCodeSize,vs.Get());
    // The preparation pass reuses the bound source layout: register assignments
    // must agree as well as semantic names/types. Inspect only our compiled VS
    // and the original game input signature, never a renderer's shader bytecode.
    const auto available=originalVertexInputs(v->rawBytecode,v->byteCodeSize);
    const auto reflection=reflectShader(vs->GetBufferPointer(),vs->GetBufferSize());
    D3D11_SHADER_DESC desc{}; check(reflection->GetDesc(&desc),"Mesh VS signature");
    for (UINT i=0;i<desc.InputParameters;++i) {
        D3D11_SIGNATURE_PARAMETER_DESC needed{};
        check(reflection->GetInputParameterDesc(i,&needed),"Mesh input register");
        bool match=false;
        for (const auto& input:available) if (!_stricmp(input.semantic.c_str(),needed.SemanticName) &&
            input.index==needed.SemanticIndex && input.registerIndex==needed.Register) match=true;
        if (!match) throw std::runtime_error("Source input layout register mismatch");
    }
    b.requiredBytes=engineBufferRequirements(ds.Get());
    if (motion) {
        const auto required=engineBufferRequirements(motion.Get());
        for (int i=0;i<3;++i) b.requiredBytes[i]=std::max(b.requiredBytes[i],required[i]);
    }
    check(device_->CreateVertexShader(vs->GetBufferPointer(),vs->GetBufferSize(),nullptr,&b.vs),"Mesh VS");
    check(device_->CreateHullShader(hs->GetBufferPointer(),hs->GetBufferSize(),nullptr,&b.hs),"Mesh HS");
    check(device_->CreateDomainShader(ds->GetBufferPointer(),ds->GetBufferSize(),nullptr,&b.ds),"Mesh DS");
    const D3D11_SO_DECLARATION_ENTRY stream[]={{0,"POSITION",0,0,4,0},{0,"TEXCOORD",0,0,2,0},{0,"COLOR",0,0,4,0},{0,"POSITION",1,0,4,0}};
    const UINT stride=b.stride;
    check(device_->CreateGeometryShaderWithStreamOutput(gs->GetBufferPointer(),gs->GetBufferSize(),stream,history ? 4 : 3,
        &stride,1,D3D11_SO_NO_RASTERIZED_STREAM,nullptr,&b.so),"Mesh stream-output GS");
    // This is original GAME vertex bytecode, used only for its input layout.
    if (history) {
        const D3D11_INPUT_ELEMENT_DESC motionElements[]={{"POSITION",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0},
            {"POSITION",1,DXGI_FORMAT_R32G32B32A32_FLOAT,0,40,D3D11_INPUT_PER_VERTEX_DATA,0}};
        check(device_->CreateInputLayout(motionElements,2,motion->GetBufferPointer(),motion->GetBufferSize(),&b.layout),"Motion mesh layout");
    } else check(device_->CreateInputLayout(elements.data(),static_cast<UINT>(elements.size()),v->rawBytecode,v->byteCodeSize,&b.layout),"Mesh output layout");
    b.valid=true;
    SKSE::log::info("Compiled mesh-input preparation VS={:X} attributes={} stride={} maxFactor={} motionHistory={}; native color/tessellation shaders retained",v->id,elements.size(),b.stride,config.meshTessellationMax,history);
    return b;
}

bool Renderer::drawMesh(ID3D11DeviceContext* c, const WaterPair& water, const st::DrawSignature& actual, const st::MeshBounds& bounds,
    const std::function<void()>& sourceDraw, const std::function<void()>& meshDraw) {
    auto skip=[&](const char* reason) {
        if (meshStats_[2]++==0 && config.diagnostics) SKSE::log::info("Mesh-input skip: {} VS={:X} topology={} count={}",reason,water.vs->id,actual.topology,actual.arguments[0]);
        return false;
    };
    if (disabled.load() || !water || !config.enbMeshInput || !config.allowENB) return false;
    const auto technique=(water.vs->id>>11)&15;
    if (technique==9 || ((water.ps->id>>11)&15)==9) return false;
    prepare(c);
    if (!active_) return false;
    // Poll sampled output statistics without flushing or blocking the GPU.
    if (!meshPolled_) {
        meshPolled_=true;
        for (auto& sample:meshQueries_) if (sample.pending) {
            ++meshStats_[7];
            D3D11_QUERY_DATA_SO_STATISTICS stats{};
            if (c->GetData(sample.query.Get(),&stats,sizeof(stats),D3D11_ASYNC_GETDATA_DONOTFLUSH)==S_OK) {
                sample.pending=false; meshStats_[4]+=stats.NumPrimitivesWritten;
                if (stats.PrimitivesStorageNeeded>stats.NumPrimitivesWritten) {
                    meshOverflow_=true;
                    SKSE::log::error("Mesh stream overflow: written={} needed={}; mesh mode suspended",stats.NumPrimitivesWritten,stats.PrimitivesStorageNeeded);
                }
            }
        }
    }
    if (meshOverflow_) return skip("prior stream overflow");
    if (config.meshBounds && bounds.valid) {
        ++meshStats_[5];
        const float span=(parameters_[8]-1)*parameters_[2];
        const float oldSpan=(parameters_[8]-1)*parameters_[6];
        if (st::outsideMeshField(bounds,parameters_[0],parameters_[1],span,parameters_[3]) &&
            st::outsideMeshField(bounds,parameters_[4],parameters_[5],oldSpan,parameters_[7])) {
            ++meshStats_[6]; return false; // untouched native draw; no simulation can reach it
        }
    }
    MeshPipelineState pipeline(c);
    const bool patch=actual.topology==D3D11_PRIMITIVE_TOPOLOGY_3_CONTROL_POINT_PATCHLIST;
    // Paired HS/DS are expected for native patches; dynamic linkage/GS are not.
    if ((pipeline.incompatibilityMask&12) || (patch ? (pipeline.incompatibilityMask&3)!=3 : (pipeline.incompatibilityMask&3)!=0))
        return skip("shader stages or dynamic linkage");
    std::array<ComPtr<ID3D11Buffer>,4> so;
    ID3D11Buffer* targets[4]{}; c->SOGetTargets(4,targets);
    bool occupied=false;
    for (UINT i=0;i<4;++i) { so[i].Attach(targets[i]); occupied|=targets[i]!=nullptr; }
    if (occupied) return skip("existing stream-output target");
    if (!pipeline.vs || !pipeline.ps) return skip("missing native shader");
    std::string key=std::to_string(water.vs->id)+":";
    key.append(reinterpret_cast<const char*>(water.vs->constantTable),sizeof(water.vs->constantTable));
    if (technique==10 && patch) key+=":patch";
    auto found=meshShaders_.find(key);
    if (found==meshShaders_.end()) {
        MeshBundle bundle;
        try {
            try { bundle=compileMesh(water.vs,!patch); }
            catch (const std::exception& e) {
                if (((water.vs->id>>11)&15)!=10 || !config.meshMotionVectors) throw;
                SKSE::log::warn("Mesh motion VS={:X} unavailable; retaining native stencil VS: {}",water.vs->id,e.what());
                bundle=compileMesh(water.vs,false);
            }
        }
        catch (const std::exception& e) { SKSE::log::error("Mesh input VS={:X} unavailable: {}",water.vs->id,e.what()); }
        found=meshShaders_.emplace(std::move(key),std::move(bundle)).first;
    }
    auto& b=found->second;
    if (!b.valid) { ++meshStats_[3]; return false; }
    // Engine constants come from the game VS stage, never ENB's HS/DS b0.
    for (UINT i=0;i<3;++i) if (b.requiredBytes[i] && bufferBytes(pipeline.vertexBuffer(i))<b.requiredBytes[i])
        return skip("short game transform buffer");
    if (bufferBytes(pipeline.vertexBuffer(4))<656) return skip("short game frame buffer");
    const UINT needed=st::meshStreamBytes(actual.arguments[0],b.stride,static_cast<UINT>(config.meshTessellationMax));
    if (!needed) return skip("stream capacity bound");
    if (needed>meshCapacity_) {
        ComPtr<ID3D11Buffer> next;
        D3D11_BUFFER_DESC desc{}; desc.ByteWidth=needed; desc.Usage=D3D11_USAGE_DEFAULT;
        desc.BindFlags=D3D11_BIND_VERTEX_BUFFER|D3D11_BIND_STREAM_OUTPUT;
        check(device_->CreateBuffer(&desc,nullptr,&next),"Mesh stream buffer");
        meshStream_=std::move(next); meshCapacity_=needed;
    }
    // DrawAuto requires exactly one input buffer. Preserve all slots, including
    // unused engine bindings, and restore them even on an exception.
    struct InputState {
        ID3D11DeviceContext* c;
        ComPtr<ID3D11InputLayout> layout;
        std::array<ComPtr<ID3D11Buffer>,32> buffers;
        std::array<UINT,32> strides{}, offsets{};
        bool changed{}, preparing{};
        UINT slotsChanged=1;
        explicit InputState(ID3D11DeviceContext* ctx):c(ctx) {
            c->IAGetInputLayout(&layout);
            ID3D11Buffer* raw[32]{};
            c->IAGetVertexBuffers(0,32,raw,strides.data(),offsets.data());
            for (int i=0;i<32;++i) { buffers[i].Attach(raw[i]); if (raw[i]) slotsChanged=static_cast<UINT>(i+1); }
        }
        ~InputState() {
            if (!changed) return;
            if (preparing) { c->SOSetTargets(0,nullptr,nullptr); c->GSSetShader(nullptr,nullptr,0); }
            ID3D11Buffer* raw[32]{};
            for (int i=0;i<32;++i) raw[i]=buffers[i].Get();
            c->IASetVertexBuffers(0,slotsChanged,raw,strides.data(),offsets.data());
            c->IASetInputLayout(layout.Get());
        }
    } input(c);
    if (!input.layout) return skip("missing input layout");
    MeshQuery* query=nullptr;
    if ((meshSerial_++%128)==0) for (auto& sample:meshQueries_) if (!sample.pending) {
        if (!sample.query) {
            D3D11_QUERY_DESC desc{D3D11_QUERY_SO_STATISTICS,0};
            check(device_->CreateQuery(&desc,&sample.query),"Mesh statistics query");
        }
        query=&sample; break;
    }
    pipeline.changed=true; input.changed=true; input.preparing=true;
    c->VSSetShader(b.vs.Get(),nullptr,0); c->HSSetShader(b.hs.Get(),nullptr,0);
    c->DSSetShader(b.ds.Get(),nullptr,0); c->GSSetShader(b.so.Get(),nullptr,0);
    c->PSSetShader(nullptr,nullptr,0);
    c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_3_CONTROL_POINT_PATCHLIST);
    for (const UINT slot:MeshPipelineState::cbSlots) {
        auto* cb=slot==11 ? constants_.Get() : pipeline.vertexBuffer(slot==2 ? 2 : 4);
        c->HSSetConstantBuffers(slot,1,&cb); c->DSSetConstantBuffers(slot,1,&cb);
    }
    ID3D11ShaderResourceView* textures[]={views_[current_].Get(),views_[previous_].Get()};
    c->DSSetShaderResources(96,2,textures);
    auto* sampler=sampler_.Get(); c->DSSetSamplers(15,1,&sampler);
    auto* stream=meshStream_.Get(); UINT offset=0;
    c->SOSetTargets(1,&stream,&offset);
    if (query) c->Begin(query->query.Get());
    sourceDraw();
    if (query) { c->End(query->query.Get()); query->pending=true; }
    c->SOSetTargets(0,nullptr,nullptr); c->GSSetShader(nullptr,nullptr,0);
    input.preparing=false;
    pipeline.restore(); // exact native ENB/game shaders, constants, textures, topology
    ID3D11Buffer* raw[32]{}; raw[0]=stream;
    UINT strides[32]{}; strides[0]=b.stride; UINT offsets[32]{};
    c->IASetInputLayout(b.layout.Get());
    c->IASetVertexBuffers(0,input.slotsChanged,raw,strides,offsets);
    if (b.motionVS && !patch) {
        c->VSSetShader(b.motionVS.Get(),nullptr,0); pipeline.motionChanged=true;
        ++meshStats_[8];
    }
    // Only the visible prepared draw becomes two-sided. Retain every other
    // raster/depth/stencil setting, and restore even if the draw throws.
    struct RasterRestore {
        ID3D11DeviceContext* context;
        ComPtr<ID3D11RasterizerState> original;
        bool changed{};
        ~RasterRestore() { if (changed) context->RSSetState(original.Get()); }
    } raster{c,{},false};
    if (config.meshTwoSided) {
        c->RSGetState(&raster.original);
        auto* selected=twoSidedRasterizer(raster.original.Get());
        if (selected!=raster.original.Get()) {
            c->RSSetState(selected); raster.changed=true; ++meshTwoSidedDraws_;
        }
    }
    meshDraw();
    ++meshStats_[0]; if (patch) ++meshStats_[1];
    return true;
}

ID3D11RasterizerState* Renderer::twoSidedRasterizer(ID3D11RasterizerState* original) {
    if (const auto found=meshRasterStates_.find(original); found!=meshRasterStates_.end()) return found->second.twoSided.Get();
    // Retain originals so cached COM addresses cannot be reused for another state.
    // Bound memory; an unusually large state population retains native behavior.
    if (meshRasterStates_.size()>=64) return original;
    RasterVariant variant; variant.original=original; variant.twoSided=original;
    try {
        ComPtr<ID3D11RasterizerState2> r2;
        ComPtr<ID3D11RasterizerState1> r1;
        if (original && SUCCEEDED(original->QueryInterface(IID_PPV_ARGS(&r2)))) {
            D3D11_RASTERIZER_DESC2 desc{}; r2->GetDesc2(&desc);
            if (desc.CullMode!=D3D11_CULL_NONE) {
                desc.CullMode=D3D11_CULL_NONE;
                ComPtr<ID3D11Device3> device3; check(device_.As(&device3),"Rasterizer device3");
                ComPtr<ID3D11RasterizerState2> next;
                check(device3->CreateRasterizerState2(&desc,&next),"Two-sided rasterizer2");
                variant.twoSided=next;
            }
        } else if (original && SUCCEEDED(original->QueryInterface(IID_PPV_ARGS(&r1)))) {
            D3D11_RASTERIZER_DESC1 desc{}; r1->GetDesc1(&desc);
            if (desc.CullMode!=D3D11_CULL_NONE) {
                desc.CullMode=D3D11_CULL_NONE;
                ComPtr<ID3D11Device1> device1; check(device_.As(&device1),"Rasterizer device1");
                ComPtr<ID3D11RasterizerState1> next;
                check(device1->CreateRasterizerState1(&desc,&next),"Two-sided rasterizer1");
                variant.twoSided=next;
            }
        } else {
            D3D11_RASTERIZER_DESC desc{};
            if (original) original->GetDesc(&desc);
            else { desc.FillMode=D3D11_FILL_SOLID; desc.CullMode=D3D11_CULL_BACK; desc.DepthClipEnable=TRUE; }
            if (desc.CullMode!=D3D11_CULL_NONE) {
                desc.CullMode=D3D11_CULL_NONE;
                check(device_->CreateRasterizerState(&desc,variant.twoSided.ReleaseAndGetAddressOf()),"Two-sided rasterizer");
            }
        }
    } catch (const std::exception& e) {
        variant.twoSided=original;
        SKSE::log::warn("Two-sided water unavailable for this state; native culling retained: {}",e.what());
    }
    return meshRasterStates_.emplace(original,std::move(variant)).first->second.twoSided.Get();
}

void Renderer::indexWaterShaders(RE::BSShader* shader) {
    waterVS_.clear(); waterPS_.clear(); identityVS_.clear(); identityPS_.clear();
    taggedVS_.clear(); taggedPS_.clear(); ++tagGeneration_;
    std::size_t taggedVertex=0, taggedPixel=0, failed=0, ambiguous=0;
    for (auto* candidate : shader->vertexShaders) if (candidate && candidate->shader) {
        auto* object = reinterpret_cast<ID3D11VertexShader*>(candidate->shader);
        if (!waterVS_.emplace(object,candidate).second) continue;
        const auto index = static_cast<std::uint32_t>(taggedVS_.size());
        taggedVS_.push_back(candidate);
        if (rendererCoexistence()) {
            if (tagIdentity(object,{tagGeneration_,index,0},ambiguous)) ++taggedVertex; else ++failed;
        }
    }
    for (auto* candidate : shader->pixelShaders) if (candidate && candidate->shader) {
        auto* object = reinterpret_cast<ID3D11PixelShader*>(candidate->shader);
        if (!waterPS_.emplace(object,candidate).second) continue;
        const auto index = static_cast<std::uint32_t>(taggedPS_.size());
        taggedPS_.push_back(candidate);
        if (rendererCoexistence()) {
            if (tagIdentity(object,{tagGeneration_,index,1},ambiguous)) ++taggedPixel; else ++failed;
        }
    }
    if (config.diagnostics && indexedOwner_ != shader)
        SKSE::log::info("Bound-shader water detection enabled: indexed {} VS and {} PS; geometry-scope gate removed",waterVS_.size(),waterPS_.size());
    if (config.diagnostics && rendererCoexistence())
        SKSE::log::info("Water identity tagging: generation={} VS={} PS={} failed={} ambiguous={}",tagGeneration_,taggedVertex,taggedPixel,failed,ambiguous);
    indexedOwner_ = shader;
    nextIndex_ = std::chrono::steady_clock::now() + std::chrono::seconds(5);
}

Renderer::WaterPair Renderer::identify(RE::BSShader* owner, ID3D11VertexShader* vs, ID3D11PixelShader* ps) {
    if (!owner || !vs || !ps) return {};
    if (indexedOwner_ != owner || std::chrono::steady_clock::now() >= nextIndex_) indexWaterShaders(owner);
    const auto v = waterVS_.find(vs), vend = waterVS_.end();
    const auto p = waterPS_.find(ps), pend = waterPS_.end();
    if (v == vend || p == pend) return {};
    return {v->second,p->second};
}

std::unique_ptr<DrawState> Renderer::begin(ID3D11DeviceContext* context, RE::BSShader* waterShader, const WaterPair* forwarded,
    const st::DrawSignature* traceDraw, const RippleGeometry* traceGeometry) {
    if (disabled.load() || !waterShader || context->GetType() != D3D11_DEVICE_CONTEXT_IMMEDIATE) return {};
    ++stats_[0]; // all immediate draws, including non-water
    if (indexedOwner_ != waterShader || std::chrono::steady_clock::now() >= nextIndex_)
        indexWaterShaders(waterShader);
    RE::BSGraphics::VertexShader* v{};
    RE::BSGraphics::PixelShader* p{};
    if (forwarded && *forwarded) {
        // Supplied only by a synchronous, argument-matched game-context draw.
        // These are known engine records, never inferred from an unknown shader.
        v = forwarded->vs; p = forwarded->ps;
    } else {
        ComPtr<ID3D11VertexShader> boundVS;
        context->VSGetShader(&boundVS,nullptr,nullptr);
        v = resolveIdentity(boundVS.Get(),waterVS_,identityVS_,taggedVS_,tagGeneration_,0,rendererCoexistence(),tagReads_,tagMatches_);
        if (!v) { ++stats_[3]; ++unmatchedVS_; return {}; }
        ComPtr<ID3D11PixelShader> boundPS;
        context->PSGetShader(&boundPS,nullptr,nullptr);
        p = resolveIdentity(boundPS.Get(),waterPS_,identityPS_,taggedPS_,tagGeneration_,1,rendererCoexistence(),tagReads_,tagMatches_);
        if (!p) { ++stats_[3]; ++unmatchedPS_; return {}; }
    }
    prepare(context);
    if (!active_) { ++stats_[1]; return {}; }
    auto state = std::make_unique<DrawState>(context);
    if (!state->compatible) { ++stats_[2]; incompatibleMask_ |= state->incompatibilityMask; return {}; }
    if (((v->id >> 11) & 15) == 9 || ((p->id >> 11) & 15) == 9) { ++stats_[4]; return {}; } // distant LOD is retained
    std::string key = std::to_string(v->id) + ":" + std::to_string(p->id) + ":";
    key.append(reinterpret_cast<const char*>(v->constantTable),sizeof(v->constantTable));
    key.append(reinterpret_cast<const char*>(p->constantTable),sizeof(p->constantTable));
    auto found = shaders_.find(key);
    if (found == shaders_.end()) {
        Bundle bundle;
        try { bundle = compile(v,p); }
        catch (const std::exception& e) { SKSE::log::error("Water permutation {:X}/{:X} left unchanged: {}",v->id,p->id,e.what()); }
        found = shaders_.emplace(std::move(key),std::move(bundle)).first;
    }
    auto& bundle = found->second;
    if (!bundle.valid) { ++failedDraws_; return {}; }
    // Metadata only, after positive water identification and before replacing
    // any draw binding. The forwarding path already has its own scoped trace.
    if (!forwarded && traceDraw && traceGeometry && rippleTraceEnabled()) {
        auto actual=*traceDraw;
        actual.topology=static_cast<UINT>(state->topology);
        traceStandaloneWater(context,v->id,p->id,actual,*traceGeometry,gpuFrame_.get());
    }
    // ENB-on trace shows an extra native PS constant buffer inserted ahead of
    // the game's three groups. Our shader still expects the original slots.
    // Validate against this engine shader's public buffer descriptors and our
    // own reflected requirements, not ENB bytecode or fixed ENB buffer sizes.
    std::array<ID3D11Buffer*,3> correctedPS{};
    ComPtr<ID3D11Buffer> fourthPS;
    bool shiftedPS=false;
    if (forwarded && *forwarded && config.allowENB && config.restoreWaterConstants) {
        std::array<std::uint32_t,3> engineBytes{};
        std::array<std::uint32_t,4> nativeBytes{};
        for (unsigned i=0;i<3;++i) {
            engineBytes[i]=bufferBytes(reinterpret_cast<ID3D11Buffer*>(p->constantBuffers[i].buffer));
            nativeBytes[i]=bufferBytes(state->pixelBuffer(i));
        }
        context->PSGetConstantBuffers(3,1,&fourthPS);
        nativeBytes[3]=bufferBytes(fourthPS.Get());
        shiftedPS=st::shiftedWaterConstants(engineBytes,bundle.requiredPSBytes,nativeBytes);
        const bool largePrefix=nativeBytes[0]>*std::max_element(engineBytes.begin(),engineBytes.end());
        if (shiftedPS) {
            correctedPS={state->pixelBuffer(1),state->pixelBuffer(2),fourthPS.Get()};
            ++shiftedConstantDraws_;
        } else if (largePrefix) ++unrecognizedConstantDraws_;
        const unsigned mode=shiftedPS ? 2u : (largePrefix ? 4u : 1u);
        if (config.diagnostics && !(bundle.loggedConstantModes & mode)) {
            bundle.loggedConstantModes |= mode;
            SKSE::log::info("Water constant layout VS={:X} PS={:X} engine=[{},{},{}] required=[{},{},{}] nativePS0to3=[{},{},{},{}] shifted={}",
                v->id,p->id,engineBytes[0],engineBytes[1],engineBytes[2],
                bundle.requiredPSBytes[0],bundle.requiredPSBytes[1],bundle.requiredPSBytes[2],
                nativeBytes[0],nativeBytes[1],nativeBytes[2],nativeBytes[3],shiftedPS);
        }
    }
    const bool tessellate = config.tessellation && state->topology == D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
    if (config.diagnostics && !bundle.loggedBindings) {
        bundle.loggedBindings = true;
        std::array<UINT,10> bytes{};
        for (int stage = 0; stage < 2; ++stage) for (int i = 0; i < 5; ++i) {
            ComPtr<ID3D11Buffer> cb;
            (context->*getCB[stage])(slots[i],1,&cb);
            if (cb) { D3D11_BUFFER_DESC desc{}; cb->GetDesc(&desc); bytes[stage * 5 + i] = desc.ByteWidth; }
        }
        SKSE::log::info("Water bind VS={:X} PS={:X} topology={} tessellated={} nativeCBBytes[b0,b1,b2,b11,b12] VS=[{},{},{},{},{}] PS=[{},{},{},{},{}]",
            v->id,p->id,static_cast<unsigned>(state->topology),tessellate,
            bytes[0],bytes[1],bytes[2],bytes[3],bytes[4],bytes[5],bytes[6],bytes[7],bytes[8],bytes[9]);
    }
    ++stats_[5]; if (tessellate) ++stats_[6];
    state->changed = true;
    if (shiftedPS) context->PSSetConstantBuffers(0,3,correctedPS.data());
    context->VSSetShader(tessellate ? bundle.control.Get() : bundle.vs.Get(),nullptr,0);
    context->PSSetShader(bundle.ps.Get(),nullptr,0);
    if (tessellate) {
        context->HSSetShader(bundle.hs.Get(),nullptr,0); context->DSSetShader(bundle.ds.Get(),nullptr,0);
        context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_3_CONTROL_POINT_PATCHLIST);
        // The engine populates VS constants. Hull/domain stages read exactly that same layout.
        for (const UINT slot : {0u,1u,2u,12u}) {
            ComPtr<ID3D11Buffer> cb; context->VSGetConstantBuffers(slot,1,&cb);
            auto* ptr = cb.Get(); context->HSSetConstantBuffers(slot,1,&ptr); context->DSSetConstantBuffers(slot,1,&ptr);
        }
    }
    for (int stage = 0; stage < 4; ++stage) {
        auto* cb = constants_.Get(); (context->*setCB[stage])(11,1,&cb);
        ID3D11ShaderResourceView* textures[] = {views_[current_].Get(),views_[previous_].Get()};
        (context->*setSRV[stage])(96,2,textures);
        auto* sampler = sampler_.Get(); (context->*setS[stage])(15,1,&sampler);
    }
    // Sample one in128 bound water draws. This detects retained changes after the
    // downstream hook returns, not temporary swaps restored inside that hook.
    state->probe = rendererCoexistence() && config.diagnostics && (probeSerial_++ % 128 == 0);
    if (state->probe) {
        state->probeContext = context;
        state->expectedVS = tessellate ? bundle.control.Get() : bundle.vs.Get();
        state->expectedPS = bundle.ps.Get();
        state->expectedHS = tessellate ? bundle.hs.Get() : nullptr;
        state->expectedDS = tessellate ? bundle.ds.Get() : nullptr;
        state->expectedTopology = tessellate ? D3D11_PRIMITIVE_TOPOLOGY_3_CONTROL_POINT_PATCHLIST : state->topology;
        state->expectedField = views_[current_].Get();
    }
    return state;
}
}
