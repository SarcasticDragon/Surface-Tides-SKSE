#include "PCH.hpp"
#include "Bridge.hpp"
#include "surfacetides/FloeManagement.hpp"
#include "surfacetides/FloeRider.hpp"
#include <unordered_set>
#include <chrono>
#include <numbers>

namespace st::plugin {
namespace {
constexpr unsigned maxCandidates=128, maxCells=128, acquisitionsPerFrame=2;
constexpr unsigned maxNodes=128, maxRiders=48;
using Motion=RE::hkpMotion::MotionType;
struct PhysicsState { RE::NiTransform world; Motion motion=Motion::kInvalid; bool valid{}; };
struct Entry {
    RE::ObjectRefHandle reference;
    RE::FormID id{};
    int profile{};
    RE::NiPointer<RE::NiAVObject> root;
    RE::NiPointer<RE::NiNode> parent;
    RE::NiPointer<RE::bhkNiCollisionObject> collision;
    RE::NiPointer<RE::bhkRigidBody> body;
    RE::NiPointer<RE::bhkWorld> physicsWorld;
    RE::hkpRigidBody* native{}; // read only while body still owns this object
    RE::NiTransform restLocal, restWorld, restParent, expectedLocal, restPhysics;
    RE::NiPoint3 authoredPosition, authoredAngle, pivot;
    FloeFootprint footprint;
    FloePose pose;
    std::uint32_t rootFlags{}, collisionFlags{}, rootMask{}, collisionMask{};
    float radius{}, inverseHavokScale{}, mismatchSeconds{};
    FloeCrestTarget goal;
    float goalAge{}, positionError{}, rotationError{};
    unsigned carried{};
    bool keyframed{}, goalReady{};
};
std::vector<std::unique_ptr<Entry>> entries;
struct Candidate { RE::ObjectRefHandle reference; RE::FormID id{}; float distance{}; };
std::vector<Candidate> candidates;
std::unordered_set<RE::FormID> blocked;
bool failed=false;
auto nextScan=std::chrono::steady_clock::time_point{}, nextReport=nextScan;
std::size_t scanCursor{};
bool scanInProgress{};
unsigned loggedAcquisitions{}, loggedSkips{}, fitsSinceReport{}, samplesSinceReport{};
std::array<bool,5> profileReported{};
std::array<unsigned,5> reportCursor{};
enum class Skip : unsigned { Area, Water, Structure, Bounds, Wet, Owned, Count };
std::array<unsigned,static_cast<unsigned>(Skip::Count)> skips{};
std::uint64_t scanArea{}, goalEpoch{};
float goalLevel{}, goalDisplacement{}, goalFollow{}, goalLift{};
FloeRiderStats riderStats;
struct RiderGate {
    RE::ActorHandle actor;
    RE::bhkCharacterController* controller{}; // identity only; never dereferenced
    RE::hkpRigidBody* support{}; // identity only; never dereferenced
    FloeRiderTakeoff takeoff;
    double lastSeen{};
};
std::array<RiderGate,maxRiders+1> riderGates{};
std::atomic<double> playerJumpRequest{-1};
double riderTime() noexcept {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
void quarantine(RE::FormID id) {
    if (blocked.size()<512) blocked.insert(id);
    else { failed=true; SKSE::log::error("Floes: rejection cache full; stopping floe motion for this session"); }
}
int profileOf(RE::TESObjectREFR* ref) {
    auto* base=ref ? ref->GetBaseObject() : nullptr;
    auto* fixed=base ? base->As<RE::TESObjectSTAT>() : nullptr;
    const auto* model=fixed ? fixed->GetModel() : nullptr;
    const int profile=model ? foam::modelProfile(model) : -1;
    return isFloeProfile(profile) ? profile : -1;
}
bool skip(RE::TESObjectREFR* ref, Skip kind, const char* reason) {
    ++skips[static_cast<unsigned>(kind)];
    if (loggedSkips<24 && (kind==Skip::Structure || kind==Skip::Owned || kind==Skip::Water || kind==Skip::Bounds)) {
        ++loggedSkips;
        SKSE::log::info("Floes: skipped ref={:08X} ({})",ref->GetFormID(),reason);
        return true;
    }
    return false;
}

bool finite(const RE::NiPoint3& p) { return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z); }
bool finite(const RE::NiTransform& t) {
    if (!finite(t.translate) || !std::isfinite(t.scale) || t.scale <= 0) return false;
    for (auto& row : t.rotate.entry) for (auto x : row) if (!std::isfinite(x)) return false;
    return true;
}
float distance(RE::NiPoint3 a, RE::NiPoint3 b) { return (a-b).Length(); }
bool sameTransform(const RE::NiTransform& a,const RE::NiTransform& b) {
    if (!finite(a) || !finite(b) || distance(a.translate,b.translate)>0.02f || std::abs(a.scale-b.scale)>1e-5f) return false;
    for (unsigned r=0;r<3;++r) for (unsigned c=0;c<3;++c)
        if (std::abs(a.rotate.entry[r][c]-b.rotate.entry[r][c])>1e-5f) return false;
    return true;
}
RE::NiPoint3 vector(const RE::hkVector4& v) {
    float components[4]; _mm_storeu_ps(components,v.quad);
    return {components[0],components[1],components[2]};
}
PhysicsState physics(const Entry& e) {
    if (!e.body || !e.physicsWorld || !e.native || e.body->referencedObject.get()!=e.native) return {};
    // Read a coherent snapshot; release before engine methods take their own locks.
    RE::BSReadLockGuard lock(e.physicsWorld->worldLock);
    if (!e.native->world || e.native->world!=e.physicsWorld->GetWorld1()) return {};
    const auto& source=e.native->motion.motionState.transform;
    PhysicsState out;
    out.world.translate=vector(source.translation)*e.inverseHavokScale;
    const std::array columns{vector(source.rotation.col0),vector(source.rotation.col1),vector(source.rotation.col2)};
    for (unsigned c=0;c<3;++c) {
        out.world.rotate.entry[0][c]=columns[c].x;
        out.world.rotate.entry[1][c]=columns[c].y;
        out.world.rotate.entry[2][c]=columns[c].z;
    }
    out.motion=e.native->motion.type.get(); out.valid=finite(out.world);
    return out;
}
RE::NiMatrix3 rotation(FloePose p) {
    RE::NiMatrix3 out;
    const auto values=floeTiltRotation(p);
    for (unsigned r=0;r<3;++r) for (unsigned c=0;c<3;++c) out.entry[r][c]=values[r*3+c];
    return out;
}
RE::NiTransform posed(const Entry& e, const RE::NiTransform& rest, FloePose p) {
    auto out=rest;
    const auto tilt=rotation(p);
    out.rotate=tilt*rest.rotate;
    out.translate=e.pivot+tilt*(rest.translate-e.pivot)+RE::NiPoint3{0,0,p.heave};
    return out;
}
float angleError(const RE::NiMatrix3& a, const RE::NiMatrix3& b) {
    double trace=0;
    for (unsigned r=0;r<3;++r) for (unsigned c=0;c<3;++c) trace+=double(a.entry[r][c])*b.entry[r][c];
    return static_cast<float>(std::acos(std::clamp((trace-1)*0.5,-1.0,1.0))*180/std::numbers::pi);
}
RE::BSGeometry* solidGeometry(RE::NiAVObject* root, int profile) {
    std::array<RE::NiAVObject*,maxNodes> stack{},seen{};
    unsigned pending=1,visited=0; stack[0]=root;
    RE::BSGeometry* solid=nullptr;
    while (pending) {
        auto* object=stack[--pending];
        if (visited==maxNodes || std::find(seen.begin(),seen.begin()+visited,object)!=seen.begin()+visited ||
            object->GetControllers() || (object!=root && object->collisionObject)) return nullptr;
        seen[visited++]=object;
        if (auto* geometry=object->AsGeometry()) {
            if (geometry->GetGeometryRuntimeData().skinInstance) return nullptr;
            const char* name=object->name.c_str();
            if (name && foam::equal(name,foam::profiles[profile].rock)) {
                if (solid) return nullptr;
                solid=geometry;
            }
        }
        if (auto* node=object->AsNode()) for (const auto& child : node->children) {
            if (!child) continue;
            if (pending==maxNodes) return nullptr;
            stack[pending++]=child.get();
        }
    }
    return solid;
}
bool current(const Entry& e) {
    const auto ref=e.reference.get();
    const auto* cell=ref ? ref->GetParentCell() : nullptr;
    return ref && cell && cell->IsAttached() && !ref->IsDisabled() && !ref->IsDeleted() &&
        profileOf(ref.get())==e.profile && ref->Get3D()==e.root.get() && e.root->parent==e.parent.get() &&
        e.root->collisionObject.get()==e.collision.get() && e.collision->body.get()==e.body.get() &&
        e.body->referencedObject.get()==e.native && sameTransform(e.parent->world,e.restParent) &&
        distance(ref->GetPosition(),e.authoredPosition)<0.02f && distance(ref->GetAngle(),e.authoredAngle)<1e-5f;
}
bool canCarryRider(RE::Actor* actor) {
    if (!actor || !actor->Is3DLoaded()) return false;
    auto* cc=actor->GetCharController();
    if (!cc) return false;
    auto* support=cc->supportBody.get();
    const bool managed=support && std::any_of(entries.begin(),entries.end(),[&](const auto& e){return e && e->native==support;});
    const auto handle=actor->GetHandle();
    const double now=riderTime();
    auto found=std::find_if(riderGates.begin(),riderGates.end(),[&](const auto& g){return g.controller && g.actor==handle;});
    if (found==riderGates.end()) {
        if (!managed) return false;
        found=std::find_if(riderGates.begin(),riderGates.end(),[&](const auto& g){return !g.controller || now-g.lastSeen>2;});
        if (found==riderGates.end()) return false; // never evict a live takeoff guard
        *found={}; found->actor=handle;
    }
    if (found->controller!=cc) { found->takeoff={}; found->controller=cc; }
    if (managed && found->support!=support) found->takeoff.groundSince=found->takeoff.lastGround=-1;
    if (managed) found->support=support;
    found->lastSeen=now;
    constexpr auto ground=RE::hkpCharacterStateType::kOnGround;
    constexpr auto jump=RE::hkpCharacterStateType::kJumping;
    const bool leaving=cc->wantState==jump || cc->context.currentState==jump || cc->flags.any(RE::CHARACTER_FLAGS::kJumping);
    const bool grounded=managed && cc->context.currentState==ground && cc->wantState==ground &&
        !leaving && !actor->IsInMidair() && !actor->AsActorState()->IsSwimming();
    const double request=playerJumpRequest.load(std::memory_order_relaxed);
    const bool requested=actor==RE::PlayerCharacter::GetSingleton() && request>=0 && now>=request && now-request<0.25;
    const bool wasSuspended=found->takeoff.suspended;
    const bool allow=found->takeoff.allow(now,grounded,leaving,requested);
    riderStats.takeoffReleases+=!wasSuspended && found->takeoff.suspended;
    riderStats.landingResumes+=wasSuspended && !found->takeoff.suspended;
    riderStats.takeoffSkips+=!allow && found->takeoff.suspended;
    return allow;
}
struct Riders { std::array<RE::ActorHandle,maxRiders> handles{}; unsigned count{}; RE::hkpRigidBody* support{}; };
struct RiderSnapshot {
    struct Contact { RE::ActorHandle actor; RE::hkpRigidBody* support{}; };
    std::array<Contact,maxRiders> contacts{};
    unsigned count{};
};
RiderSnapshot captureRiders() {
    RiderSnapshot out;
    auto capture=[&](RE::Actor* actor) {
        if (out.count==maxRiders || !canCarryRider(actor)) return;
        const auto* cc=actor->GetCharController();
        auto* support=cc ? cc->supportBody.get() : nullptr;
        if (!support || !std::any_of(entries.begin(),entries.end(),[&](const auto& e){return e && e->native==support;})) return;
        const auto handle=actor->GetHandle();
        for (unsigned i=0;i<out.count;++i) if (out.contacts[i].actor==handle) return;
        out.contacts[out.count++]={handle,support};
    };
    auto* player=RE::PlayerCharacter::GetSingleton(); capture(player);
    unsigned checked=0;
    if (const auto* lists=RE::ProcessLists::GetSingleton()) for (const auto& handle : lists->highActorHandles) {
        if (out.count==maxRiders || checked++==128) break;
        const auto actor=handle.get(); if (actor && actor.get()!=player) capture(actor.get());
    }
    return out;
}
Riders riders(const Entry& e, const RiderSnapshot& snapshot) {
    Riders out; out.support=e.native;
    // Capture support identity before ANY floe moves. Two neighbouring floes
    // cannot both claim an actor whose support changes during this update.
    for (unsigned i=0;i<snapshot.count;++i) if (snapshot.contacts[i].support==e.native)
        out.handles[out.count++]=snapshot.contacts[i].actor;
    return out;
}
struct RiderController {
    RE::bhkCharacterController& controller;
    std::array<float,4> position() const {
        RE::hkVector4 value; controller.GetPositionImpl(value,false);
        std::array<float,4> result; _mm_storeu_ps(result.data(),value.quad); return result;
    }
    std::array<float,4> velocity() const {
        RE::hkVector4 value; controller.GetLinearVelocityImpl(value);
        std::array<float,4> result; _mm_storeu_ps(result.data(),value.quad); return result;
    }
    void moveWithoutWarp(const std::array<float,4>& position) {
        RE::hkVector4 value; value.quad=_mm_loadu_ps(position.data());
        // Same center convention as GetPositionImpl. Do not force a warp or
        // invoke Actor::SetPosition: that can reset pending locomotion.
        controller.SetPositionImpl(value,false,false);
    }
    void restoreVelocity(const std::array<float,4>& velocity) {
        RE::hkVector4 value; value.quad=_mm_loadu_ps(velocity.data());
        controller.SetLinearVelocityImpl(value);
    }
};
unsigned carry(const Riders& people, const RE::NiTransform& before, const RE::NiTransform& after,
    float inverseHavokScale) {
    unsigned count=0;
    const auto convert=[](const RE::NiTransform& t) {
        FloeRiderTransform result;
        result.position={t.translate.x,t.translate.y,t.translate.z}; result.scale=t.scale;
        for (unsigned row=0;row<3;++row) for (unsigned col=0;col<3;++col)
            result.rotation[row*3+col]=t.rotate.entry[row][col];
        return result;
    };
    const auto from=convert(before),to=convert(after);
    for (unsigned i=0;i<people.count;++i) {
        const auto actor=people.handles[i].get();
        if (!canCarryRider(actor.get())) continue;
        RE::NiPointer<RE::bhkCharacterController> controller{actor->GetCharController()};
        if (!controller || controller->supportBody.get()!=people.support) continue;
        const auto feet=actor->GetPosition();
        const auto delta=floeRiderDelta({feet.x,feet.y,feet.z},from,to);
        // Reference feet locate the point on the tilting floe only. Add this
        // delta to the LIVE controller position, preserving any walking that
        // has advanced beyond the actor's cached reference position.
        RiderController adapter{*controller};
        if (offsetFloeRider(adapter,delta,inverseHavokScale,&riderStats)) ++count;
    }
    return count;
}
void updateNode(RE::NiAVObject* root, bool collision) {
    RE::NiUpdateData data{}; // zero-time transform update, no autonomous animation
    data.flags=collision ? RE::NiUpdateData::Flag::kNone : RE::NiUpdateData::Flag::kDisableCollision;
    root->UpdateTransformAndBounds(data);
}
void release(std::unique_ptr<Entry>& slot, bool carryPeople, const RiderSnapshot& snapshot={}) {
    if (!slot) return;
    auto* e=slot.get(); // retain ownership until restoration completes
    if (!sameTransform(e->root->local,e->expectedLocal) || e->root->parent!=e->parent.get()) {
        SKSE::log::warn("Floes: ref={:08X} transform ownership changed; yielding to the other controller",e->id);
        quarantine(e->id); slot.reset(); return;
    }
    const bool attached=current(*e);
    const auto people=carryPeople && attached ? riders(*e,snapshot) : Riders{};
    const auto before=e->root->world;
    const auto state=physics(*e);
    e->root->local=e->restLocal;
    updateNode(e->root.get(),state.valid);
    if (carryPeople && attached) e->carried+=carry(people,before,e->root->world,e->inverseHavokScale);
    // Keep the accepted scene-node operation; do not mark a persistent REFR moved.
    if (e->keyframed && (!state.valid || state.motion==Motion::kKeyframed)) {
        e->root->SetMotionType(static_cast<std::uint32_t>(Motion::kFixed),true,false,true);
        const auto now=e->root->GetFlags().underlying();
        e->root->GetFlags()=static_cast<RE::NiAVObject::Flag>((now&~e->rootMask)|(e->rootFlags&e->rootMask));
        const auto flags=e->collision->flags.underlying();
        e->collision->flags=static_cast<RE::bhkNiCollisionObject::Flag>((flags&~e->collisionMask)|(e->collisionFlags&e->collisionMask));
    }
    const auto restored=physics(*e);
    if (restored.valid && restored.motion!=Motion::kFixed) {
        quarantine(e->id);
        SKSE::log::warn("Floes: ref={:08X} node restored but motion={} (expected 5)",e->id,static_cast<unsigned>(restored.motion));
    }
    slot.reset();
}
void acquire(RE::TESObjectREFR* ref, const SurfaceFieldView& field) {
    auto* cell=ref ? ref->GetParentCell() : nullptr;
    if (!ref || !cell || !cell->IsAttached() || !ref->Get3D() || ref->IsDisabled() || ref->IsDeleted() || blocked.contains(ref->GetFormID())) return;
    const int profile=profileOf(ref);
    if (profile<0) return;
    if (std::any_of(entries.begin(),entries.end(),[&](const auto& e){return e && (e->id==ref->GetFormID() || e->root.get()==ref->Get3D());})) return;
    auto* world=ref->GetWorldspace();
    const auto area=world ? world->GetFormID() : cell->GetFormID();
    const auto position=ref->GetPosition();
    const float referenceWater=ref->GetWaterHeight(); // diagnostic only, not a spatial water query
    const auto reportWater=[&](const char* reason, RE::TESObjectCELL* spatialCell, float queriedWater) {
        if (skip(ref,Skip::Water,reason) && std::isfinite(queriedWater) && queriedWater!=field.restLevel)
            SKSE::log::info("Floes: ref={:08X} ownerCell={:08X} spatialCell={:08X} targetArea={:08X} fieldArea={:08X} referenceWater={:g} spatialWater={:g} fieldWater={:g}",
                ref->GetFormID(),cell->GetFormID(),spatialCell ? spatialCell->GetFormID() : 0,area,field.area,referenceWater,queriedWater,field.restLevel);
    };
    constexpr float unknownWater=std::numeric_limits<float>::quiet_NaN();
    // GetCell uses the active game's spatial grid. Check reference identity
    // against that field BEFORE querying it, then validate the returned cell's
    // world too. A cell at identical coordinates in another world is not valid.
    if (!area || area!=field.area) { skip(ref,Skip::Area,"different active area"); return; }
    auto* tes=RE::TES::GetSingleton();
    if (!tes || !finite(position)) { reportWater("spatial water query unavailable",nullptr,unknownWater); return; }
    auto* waterCell=cell->IsInteriorCell() ? cell : tes->GetCell(position);
    if (!waterCell || !waterCell->IsAttached()) { reportWater("spatial cell not attached",waterCell,unknownWater); return; }
    if (cell->IsInteriorCell() ? waterCell!=cell :
        (!world || !waterCell->IsExteriorCell() || waterCell->GetRuntimeData().worldSpace!=world)) {
        reportWater("spatial cell belongs to another area",waterCell,unknownWater); return;
    }
    // A static's cached relevantWaterHeight (or its owning persistent cell's
    // exterior height) need not describe the water at the placed floe. Resolve
    // the actual position through the same engine API used by our wet mask.
    // Never substitute the player's level to force this qualification to pass.
    const float water=tes->GetWaterHeight(position,waterCell);
    if (!std::isfinite(water) || !std::isfinite(field.restLevel) || std::abs(water-field.restLevel)>=2) {
        reportWater("spatial water differs from active field",waterCell,water); return;
    }
    auto* root=ref->Get3D(); auto* solid=solidGeometry(root,profile);
    auto* collision=root->collisionObject ? root->collisionObject->AsBhkNiCollisionObject() : nullptr;
    auto* body=collision && collision->body ? collision->body->AsBhkRigidBody() : nullptr;
    auto* physicsWorld=cell->GetbhkWorld();
    if (!root->parent || !solid || !body || !body->referencedObject || !physicsWorld ||
        !finite(root->world) || !finite(root->local) || !finite(root->parent->world)) { skip(ref,Skip::Structure,"unsupported scene/collision structure"); return; }
    const auto bounds=solid->worldBound;
    if (!finite(bounds.center) || !std::isfinite(bounds.radius) || bounds.radius<32 || bounds.radius>5000 || root->world.rotate.entry[2][2]<0.95f) { skip(ref,Skip::Bounds,"unsupported floe bounds/orientation"); return; }
    if (std::abs(root->world.translate.z-water)>256*root->world.scale+48) { skip(ref,Skip::Bounds,"authored placement is far above/below the water"); return; }
    if (!floeOverlapsField(field,{bounds.center.x,bounds.center.y},bounds.radius)) return;
    auto* native=static_cast<RE::hkpRigidBody*>(body->referencedObject.get());
    if (std::any_of(entries.begin(),entries.end(),[&](const auto& e){return e && e->native==native;})) {
        skip(ref,Skip::Owned,"collision body already belongs to another managed root"); return;
    }
    auto e=std::make_unique<Entry>();
    e->id=ref->GetFormID(); e->profile=profile;
    e->reference=ref->CreateRefHandle(); if (!e->reference.get()) return;
    e->root.reset(root); e->parent.reset(root->parent); e->collision.reset(collision); e->body.reset(body); e->physicsWorld.reset(physicsWorld);
    e->native=static_cast<RE::hkpRigidBody*>(body->referencedObject.get());
    e->restLocal=root->local; e->expectedLocal=root->local; e->restWorld=root->world; e->restParent=root->parent->world;
    e->authoredPosition=ref->GetPosition(); e->authoredAngle=ref->GetAngle();
    e->pivot={bounds.center.x,bounds.center.y,water}; e->radius=bounds.radius;
    // The live solid bound incorporates the winning mesh and placed scale.
    // A square inscribed in that footprint sphere is a conservative first fit.
    const float half=bounds.radius*0.70710678f;
    const float yaw=std::atan2(solid->world.rotate.entry[1][0],solid->world.rotate.entry[0][0]);
    e->footprint={{e->pivot.x,e->pivot.y},{half,half},yaw,water,area};
    const auto target=fitFloeTarget(field,e->footprint);
    if (!target.valid || target.coverage<=0) { skip(ref,Skip::Wet,"outside active wet simulation coverage"); return; }
    e->inverseHavokScale=RE::bhkWorld::GetWorldScaleInverse();
    if (!std::isfinite(e->inverseHavokScale) || e->inverseHavokScale<1 || e->inverseHavokScale>1000) { skip(ref,Skip::Structure,"invalid Havok unit scale"); return; }
    const auto state=physics(*e);
    if (!state.valid || state.motion!=Motion::kFixed) { skip(ref,Skip::Owned,"body is not a fixed unowned floe"); return; }
    e->restPhysics=state.world;
    e->rootFlags=root->GetFlags().underlying(); e->collisionFlags=collision->flags.underlying();
    // Commit ownership BEFORE any mutation; cleanup can find every converted body.
    entries.push_back(std::move(e));
    auto& slot=entries.back(); auto& stored=*slot; stored.keyframed=true;
    root->SetMotionType(static_cast<std::uint32_t>(Motion::kKeyframed),true,false,true);
    stored.rootMask=stored.rootFlags^root->GetFlags().underlying();
    stored.collisionMask=stored.collisionFlags^collision->flags.underlying();
    const auto converted=physics(stored);
    if (!converted.valid || converted.motion!=Motion::kKeyframed) {
        quarantine(stored.id); release(slot,false);
        SKSE::log::warn("Floes: ref={:08X} keyframe conversion failed; this reference stopped",ref->GetFormID()); return;
    }
    stored.expectedLocal=root->local;
    if (loggedAcquisitions<24 || !profileReported[profile]) {
        ++loggedAcquisitions; profileReported[profile]=true;
        SKSE::log::info("Floes: acquired ref={:08X} model={} area={:08X} water={:.2f} radius={:.2f} coverage={:.3f} motion=5->4 ownerCell={:08X} spatialCell={:08X} referenceWater={:g}",
            stored.id,foam::profiles[profile].model,area,water,stored.radius,target.coverage,cell->GetFormID(),waterCell->GetFormID(),referenceWater);
    }
}

void moveFloe(std::unique_ptr<Entry>& slot, const Tuning& applied, float dt, const RiderSnapshot& snapshot) {
    auto& e=*slot;
    const auto body=physics(e);
    if (!body.valid || body.motion!=Motion::kKeyframed) {
        quarantine(e.id); SKSE::log::warn("Floes: ref={:08X} physics ownership/world changed; this reference stopped",e.id); release(slot,false); return;
    }
    if (!e.goalReady) return; // an invalidated goal cannot drive another field/setting
    const auto& crest=e.goal;
    const auto& target=crest.target;
    const float step=std::min(dt,0.1f);
    // Pick up incoming crests promptly, then settle more slowly as they pass
    // to reduce chatter when the highest wave changes across a large floe.
    const float response=applied.floeResponseSeconds*
        (applied.floeCrestFollow>0 && target.pose.heave<e.pose.heave ? 3.0f : 1.0f);
    auto pose=approachFloeTarget(e.pose,target,step,response);
    pose=limitFloeStep(e.pose,pose,e.radius,64*step);
    const auto before=e.root->world, nextWorld=posed(e,e.restWorld,pose);
    const auto previousPhysics=posed(e,e.restPhysics,e.pose), nextPhysics=posed(e,e.restPhysics,pose);
    const auto people=riders(e,snapshot);
    e.root->local=e.parent->world.Invert()*nextWorld;
    e.expectedLocal=e.root->local;
    updateNode(e.root.get(),true);
    const auto observed=physics(e);
    if (!observed.valid) { quarantine(e.id); release(slot,false); return; }
    // Accept current or previous frame's transform: the engine physics step may
    // consume the graph update later. Persistent mismatch must not silently ship
    // visual-only floe movement with stationary collision.
    const float positionNow=distance(observed.world.translate,nextPhysics.translate);
    const float positionBefore=distance(observed.world.translate,previousPhysics.translate);
    const float rotationNow=angleError(observed.world.rotate,nextPhysics.rotate);
    const float rotationBefore=angleError(observed.world.rotate,previousPhysics.rotate);
    // Compare coherent translation/rotation pairs, not independently chosen
    // halves of two different frame poses.
    const bool useNow=std::max(positionNow,rotationNow*4)<=std::max(positionBefore,rotationBefore*4);
    const float positionError=useNow?positionNow:positionBefore;
    const float rotationError=useNow?rotationNow:rotationBefore;
    e.pose=pose;
    e.positionError=std::max(e.positionError,positionError); e.rotationError=std::max(e.rotationError,rotationError);
    e.carried+=carry(people,before,e.root->world,e.inverseHavokScale);
    if (positionError>1.0f || rotationError>0.25f) e.mismatchSeconds+=step;
    else e.mismatchSeconds=0;
    if (e.mismatchSeconds>=1.0f) {
        SKSE::log::warn("Floes: ref={:08X} collision did not track node (positionError={:.3f}, rotationErrorDeg={:.3f}); restoring this reference",e.id,positionError,rotationError);
        quarantine(e.id); release(slot,true,snapshot); return;
    }
    if (target.coverage==0 && std::abs(pose.heave)<0.001f && std::hypot(pose.slope.x,pose.slope.y)<1e-6f) {
        release(slot,true,snapshot); return;
    }
}
// Cell-local enumeration only. Never use TES::worldSpace or TES::ForEachReference:
// the bundled legacy AE tail accessor caused the accepted 0.1.20 load crash.
std::size_t loadedCells(std::array<RE::TESObjectCELL*,maxCells>& cells) {
    std::size_t count=0;
    auto* player=RE::PlayerCharacter::GetSingleton();
    auto* cell=player ? player->GetParentCell() : nullptr;
    if (!cell || !cell->IsAttached()) return 0;
    auto add=[&](RE::TESObjectCELL* value) {
        if (!value || !value->IsAttached() || count==cells.size()) return;
        if (std::find(cells.begin(),cells.begin()+count,value)==cells.begin()+count) cells[count++]=value;
    };
    add(cell);
    if (cell->IsInteriorCell()) return count;
    if (auto* world=player->GetWorldspace()) add(world->GetSkyCell());
    auto* tes=RE::TES::GetSingleton(); const auto* grid=tes ? tes->gridCells : nullptr;
    if (grid && grid->cells) for (std::uint32_t x=0;x<grid->length && count<maxCells;++x)
        for (std::uint32_t y=0;y<grid->length && count<maxCells;++y) add(grid->GetCell(x,y));
    return count;
}
void discover(const SurfaceFieldView& field) {
    const auto now=std::chrono::steady_clock::now();
    if (scanArea!=field.area) { scanCursor=0; scanInProgress=false; candidates.clear(); nextScan={}; scanArea=field.area; }
    if (!scanInProgress && now>=nextScan) {
        scanCursor=0; scanInProgress=true; nextScan=now+std::chrono::seconds(1);
    }
    if (!scanInProgress) return;
    // Rebuild from current engine-owned cells for each slice. No raw CELL
    // pointer survives this update, and temporary sky cells need not be in the
    // global form-ID lookup map. A changed list is revisited next scan cycle.
    std::array<RE::TESObjectCELL*,maxCells> cells{};
    const auto count=loadedCells(cells);
    // Two cells per update amortize normal loaded-cell enumeration. Reference
    // handles only are queued here; physics conversion occurs OUTSIDE cell locks.
    for (unsigned visited=0;visited<2 && scanCursor<count;++visited) {
        auto* cell=cells[scanCursor++];
        if (!cell || !cell->IsAttached()) continue;
        cell->ForEachReference([&](RE::TESObjectREFR* ref) {
            if (!ref || ref->IsDisabled() || ref->IsDeleted() || profileOf(ref)<0 || blocked.contains(ref->GetFormID())) return RE::BSContainer::ForEachResult::kContinue;
            auto* root=ref->Get3D(); if (!root) return RE::BSContainer::ForEachResult::kContinue;
            const auto& b=root->worldBound;
            if (!floeOverlapsField(field,{b.center.x,b.center.y},b.radius)) return RE::BSContainer::ForEachResult::kContinue;
            const auto id=ref->GetFormID();
            if (std::any_of(entries.begin(),entries.end(),[&](const auto& e){return e && (e->id==id || e->root.get()==root);}) ||
                std::any_of(candidates.begin(),candidates.end(),[&](const auto& c){return c.id==id;})) return RE::BSContainer::ForEachResult::kContinue;
            const float half=0.5f*float(field.resolution-1)*field.spacing;
            const float d=std::hypot(b.center.x-field.origin.x-half,b.center.y-field.origin.y-half);
            auto farthest=candidates.end();
            if (candidates.size()==maxCandidates) {
                farthest=std::max_element(candidates.begin(),candidates.end(),[](const auto& a,const auto& b){return a.distance<b.distance;});
                if (d>=farthest->distance) return RE::BSContainer::ForEachResult::kContinue;
            }
            Candidate item{ref->CreateRefHandle(),id,d};
            if (item.reference.get()) {
                if (farthest==candidates.end()) candidates.push_back(std::move(item)); else *farthest=std::move(item);
            }
            return RE::BSContainer::ForEachResult::kContinue;
        });
    }
    if (scanCursor>=count) scanInProgress=false;
}
void report(const Frame& frame, const RiderSnapshot& snapshot) {
    const auto now=std::chrono::steady_clock::now();
    if (now<nextReport) return;
    nextReport=now+std::chrono::seconds(5);
    std::array<unsigned,5> counts{}; float minHeave=std::numeric_limits<float>::infinity(),maxHeave=-minHeave,maxAge=0,maxError=0,maxRotation=0; unsigned carried=0;
    for (const auto& e:entries) if (e) {
        ++counts[e->profile]; minHeave=std::min(minHeave,e->pose.heave); maxHeave=std::max(maxHeave,e->pose.heave);
        maxAge=std::max(maxAge,e->goalAge); maxError=std::max(maxError,e->positionError); maxRotation=std::max(maxRotation,e->rotationError); carried+=e->carried;
    }
    if (entries.empty()) minHeave=maxHeave=0;
    SKSE::log::info("Floes: seq={} active={}/{} profiles(solid01,ice01,solid02)=({},{},{}) queued={} blocked={} fits={} samples={} maxGoalAge={:.3f} heaveRange=({:.2f},{:.2f}) collisionErrorMax={:.4f} rotationErrorMax={:.4f} riders={} carried={} skips(area,water,structure,bounds,wet,owned)=({},{},{},{},{},{})",
        frame.sequence,entries.size(),maxManagedFloes,counts[2],counts[3],counts[4],candidates.size(),blocked.size(),fitsSinceReport,samplesSinceReport,maxAge,minHeave,maxHeave,maxError,maxRotation,snapshot.count,carried,
        skips[0],skips[1],skips[2],skips[3],skips[4],skips[5]);
    SKSE::log::info("Floes riders: offsets={} velocityRepairs={} invalidPostVelocity={} maxOffset={:.6f} maxVelocityChange={:.8f} takeoffReleases={} landingResumes={} takeoffSkips={} [five-second counters; skips count checks, offset in game units, velocity in native units]",
        riderStats.offsets,riderStats.velocityRepairs,riderStats.invalidPostVelocity,riderStats.maxOffset,riderStats.maxVelocityChange,
        riderStats.takeoffReleases,riderStats.landingResumes,riderStats.takeoffSkips);
    riderStats={};
    // One rotating example per profile, rather than one log line per floe/frame.
    for (int profile=2;profile<5;++profile) if (counts[profile]) {
        unsigned at=reportCursor[profile]++%counts[profile];
        for (const auto& e:entries) if (e && e->profile==profile && at--==0) {
            SKSE::log::info("Floes: ref={:08X} model={} heave={:.3f} target={:.3f} crest={:.3f} addedLift={:.3f} tiltDeg={:.3f} coverage={:.3f} goalAge={:.3f} heaveLimited={}",
                e->id,foam::profiles[profile].model,e->pose.heave,e->goal.target.pose.heave,e->goal.peakDisplacement,e->goal.addedLift,
                std::atan(std::hypot(e->pose.slope.x,e->pose.slope.y))*180/std::numbers::pi_v<float>,e->goal.target.coverage,e->goalAge,e->goal.limited);
            break;
        }
    }
    for (auto& e:entries) if (e) { e->positionError=e->rotationError=0; e->carried=0; }
    fitsSinceReport=samplesSinceReport=0; skips.fill(0);
}
void tick(const Frame& frame, const Tuning& applied, std::uint64_t area, float dt) {
    entries.reserve(maxManagedFloes); candidates.reserve(maxCandidates);
    const SurfaceFieldView field{frame.texels,frame.origin,frame.spacing,frame.level,applied.displacementStrength,
        frame.resolution,frame.spongeCells,area,frame.active};
    discover(field);
    for (unsigned i=0;i<acquisitionsPerFrame && !candidates.empty() && entries.size()<maxManagedFloes;++i) {
        auto closest=std::min_element(candidates.begin(),candidates.end(),[](const auto& a,const auto& b){return a.distance<b.distance;});
        const auto ref=closest->reference.get(); candidates.erase(closest);
        if (ref) acquire(ref.get(),field);
    }
    std::erase_if(entries,[](const auto& e){return !e;});
    const auto snapshot=captureRiders();
    for (auto& e:entries) if (e && (e->footprint.area!=area || std::abs(e->footprint.waterLevel-frame.level)>=2 ||
        !current(*e) || !sameTransform(e->root->local,e->expectedLocal))) release(e,true,snapshot);
    std::erase_if(entries,[](const auto& e){return !e;});
    const bool invalidate=goalEpoch!=frame.epoch || goalLevel!=frame.level || goalDisplacement!=applied.displacementStrength ||
        goalFollow!=applied.floeCrestFollow || goalLift!=applied.floeExtraLift;
    goalEpoch=frame.epoch; goalLevel=frame.level; goalDisplacement=applied.displacementStrength;
    goalFollow=applied.floeCrestFollow; goalLift=applied.floeExtraLift;
    std::array<FloeRefreshRequest,maxManagedFloes> requests{};
    for (std::size_t i=0;i<entries.size();++i) {
        auto& e=*entries[i];
        e.goalAge=std::min(e.goalAge+dt,60.0f);
        if (invalidate) { e.goalReady=false; e.mismatchSeconds=0; }
        // Preserve the accepted every-frame following when the whole fleet fits
        // in one budget; stagger only when more than eight bodies are active.
        requests[i]={e.goalAge,!e.goalReady || entries.size()<=maxFloeRefreshes,riders(e,snapshot).count>0};
    }
    auto refresh=[&](std::size_t i) {
        auto& e=*entries[i];
        e.goal=fitFloeCrestTarget(field,e.footprint,{48,3.0f*std::numbers::pi_v<float>/180},applied.floeCrestFollow,applied.floeExtraLift);
        e.goalReady=true; e.goalAge=0; ++fitsSinceReport; samplesSinceReport+=e.goal.samples;
    };
    if (applied.floeCrestFollow==0 || applied.displacementStrength==0) {
        for (std::size_t i=0;i<entries.size();++i) refresh(i); // cheap original fit, no dense scan
    } else {
        std::array<std::size_t,maxFloeRefreshes> selected{};
        const auto count=selectFloeRefreshes(std::span(requests).first(entries.size()),selected);
        for (std::size_t i=0;i<count;++i) refresh(selected[i]);
    }
    for (auto& e:entries) if (e) moveFloe(e,applied,dt,snapshot);
    std::erase_if(entries,[](const auto& e){return !e;});
    report(frame,snapshot);
}
}
void noteFloeJumpRequest() noexcept {
    playerJumpRequest.store(riderTime(),std::memory_order_relaxed);
}
void resetFloe(bool carryPeople) {
    const auto snapshot=carryPeople ? captureRiders() : RiderSnapshot{};
    unsigned restored=0;
    for (auto& e:entries) if (e) {
        try { release(e,carryPeople,snapshot); if (!e) ++restored; }
        catch (const std::exception& error) { failed=true; SKSE::log::error("Floes: restoration failed: {}",error.what()); }
    }
    std::erase_if(entries,[](const auto& e){return !e;});
    if (restored) SKSE::log::info("Floes: released {} managed floes; authored transforms and owned motion restored where ownership remained",restored);
    candidates.clear(); scanCursor=0; scanInProgress=false; nextScan={}; goalEpoch=0;
    riderGates={}; playerJumpRequest.store(-1,std::memory_order_relaxed);
}
void updateFloe(const Frame& frame, const Tuning& applied, std::uint64_t area, float delta) {
    if (!config.floeBobbing || failed || !frame.active || !applied.previewEnabled) { resetFloe(); return; }
    if (!std::isfinite(delta) || delta<=0) return;
    try { tick(frame,applied,area,delta); }
    catch (const std::exception& error) { failed=true; resetFloe(); SKSE::log::error("Floes: manager stopped: {}. Water remains active.",error.what()); }
}
} // namespace st::plugin
