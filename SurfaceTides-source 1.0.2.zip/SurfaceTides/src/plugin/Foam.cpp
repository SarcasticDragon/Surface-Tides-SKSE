#include "PCH.hpp"
#include "Bridge.hpp"
#include "surfacetides/FoamSelection.hpp"
#include <chrono>

namespace st::plugin {
namespace {
constexpr std::size_t maxReferences = 128, maxObjects = 128;
struct Entry {
    RE::ObjectRefHandle reference;
    RE::NiPointer<RE::NiAVObject> root;
    std::array<RE::NiPointer<RE::NiAVObject>,2> shapes;
    std::array<bool,2> changed{};
    int profile{};
};
std::vector<Entry> entries;
auto nextScan = std::chrono::steady_clock::time_point{};
bool failed = false;
unsigned loggedMatches = 0, loggedMisses = 0;

std::string_view text(const char* value) { return value ? std::string_view(value) : std::string_view{}; }
bool profileEnabled(int profile) {
    return profile >= 0 && unsigned(profile) < foam::profiles.size() &&
        (foam::profiles[profile].iceDecal ? config.hideIceDecals : config.hideAttachedFoam);
}
const char* category(int profile) { return foam::profiles[profile].iceDecal ? "IceDecals" : "AttachedFoam"; }
int profileOf(RE::TESObjectREFR* ref) {
    auto* base = ref ? ref->GetBaseObject() : nullptr;
    if (!base) return -1;
    // FormType dispatch is needed: movable statics inherit TESObjectSTAT but
    // TESForm::As<TESObjectSTAT>() tests the exact Static form type.
    if (auto* movable = base->As<RE::BGSMovableStatic>()) return foam::modelProfile(text(movable->GetModel()));
    if (auto* fixed = base->As<RE::TESObjectSTAT>()) return foam::modelProfile(text(fixed->GetModel()));
    return -1;
}
int slotOf(RE::NiAVObject* object, int profile) {
    auto* geometry = object->AsGeometry();
    if (!geometry || object->collisionObject || object->GetControllers()) return -1;
    if (foam::profiles[profile].standalone)
        for (const auto& property : geometry->GetGeometryRuntimeData().properties)
            if (property && property->GetControllers()) return -1;
    for (const auto& property : geometry->GetGeometryRuntimeData().properties) {
        if (foam::profiles[profile].iceDecal) {
            auto* lighting = netimmerse_cast<RE::BSLightingShaderProperty*>(property.get());
            if (!lighting || !lighting->material || lighting->material->GetType() != RE::BSShaderMaterial::Type::kLighting) continue;
            const auto* material = static_cast<RE::BSLightingShaderMaterialBase*>(lighting->material);
            if (!material->textureSet) continue;
            // Query the loaded material's paths, retaining mesh/texture overrides.
            // No texture replacement and no write to shared shader materials.
            return foam::shapeSlot(profile,text(object->name.c_str()),false,
                text(material->textureSet->GetTexturePath(RE::BSTextureSet::Texture::kDiffuse)),
                text(material->textureSet->GetTexturePath(RE::BSTextureSet::Texture::kNormal)),false,false);
        }
        auto* effect = netimmerse_cast<RE::BSEffectShaderProperty*>(property.get());
        if (!effect || !effect->material || effect->material->GetType() != RE::BSShaderMaterial::Type::kEffect) continue;
        const auto* material = static_cast<RE::BSEffectShaderMaterial*>(effect->material);
        return foam::shapeSlot(profile,text(object->name.c_str()),true,
            text(material->sourceTexturePath.c_str()),text(material->greyscaleTexturePath.c_str()),false,false);
    }
    return -1;
}
bool inspect(RE::NiAVObject* root, int profile, Entry& result) {
    // Bounded iterative traversal; ambiguous/repeated shapes or unusual trees
    // leave the entire reference unchanged. The rock may be a classic NiTriShape.
    std::array<RE::NiAVObject*,maxObjects> stack{}, seen{};
    std::size_t pending=1, visited=0;
    stack[0]=root;
    bool rock=false, unsafeStandaloneNode=false;
    unsigned geometryCount=0, matchedShapes=0;
    while (pending) {
        auto* object=stack[--pending];
        if (visited == seen.size() || std::find(seen.begin(),seen.begin()+visited,object) != seen.begin()+visited) return false;
        seen[visited++]=object;
        const bool geometry=object->AsGeometry() || object->AsNiTriBasedGeom();
        if (geometry) ++geometryCount;
        if (foam::profiles[profile].standalone &&
            (object->collisionObject || object->GetControllers() || (!geometry && !object->AsNode())))
            unsafeStandaloneNode=true;
        if (foam::equal(text(object->name.c_str()),foam::profiles[profile].rock) &&
            (object->AsGeometry() || object->AsNiTriBasedGeom())) rock=true;
        const int slot=slotOf(object,profile);
        if (slot >= 0) {
            if (result.shapes[slot]) return false;
            result.shapes[slot].reset(object);
            ++matchedShapes;
        }
        if (auto* node=object->AsNode()) {
            for (const auto& child : node->children) {
                if (!child) continue;
                if (pending == stack.size()) return false;
                stack[pending++]=child.get();
            }
        }
    }
    if (!foam::sceneComplete(profile,rock,matchedShapes,geometryCount,unsafeStandaloneNode)) return false;
    for (unsigned i=0;i<foam::profiles[profile].count;++i) if (!result.shapes[i]) return false;
    return true;
}
void restore(Entry& entry) {
    for (unsigned i=0;i<entry.shapes.size();++i)
        if (entry.changed[i] && entry.shapes[i]) entry.shapes[i]->SetAppCulled(false);
}
bool belongsTo(RE::NiAVObject* shape, RE::NiAVObject* root) {
    for (unsigned i=0;shape && i<maxObjects;++i,shape=shape->parent) if (shape == root) return true;
    return false;
}
void forEachFoamReference(const std::function<RE::BSContainer::ForEachResult(RE::TESObjectREFR*)>& callback) {
    auto* player=RE::PlayerCharacter::GetSingleton();
    auto* currentCell=player ? player->GetParentCell() : nullptr;
    if (!currentCell || !currentCell->IsAttached()) return;
    bool stopped=false;
    auto visitCell=[&](RE::TESObjectCELL* cell) {
        if (stopped || !cell || !cell->IsAttached()) return;
        cell->ForEachReference([&](RE::TESObjectREFR* ref) {
            const auto result=callback(ref);
            stopped=result == RE::BSContainer::ForEachResult::kStop;
            return result;
        });
    };
    if (currentCell->IsInteriorCell()) {
        visitCell(currentCell);
        return;
    }
    auto* tes=RE::TES::GetSingleton();
    const auto* grid=tes ? tes->gridCells : nullptr;
    if (grid && grid->cells) {
        for (std::uint32_t x=0;x<grid->length && !stopped;++x)
            for (std::uint32_t y=0;y<grid->length && !stopped;++y) visitCell(grid->GetCell(x,y));
    } else {
        visitCell(currentCell);
    }
    // Do not call TES::ForEachReference here. The bundled TES header guards
    // its AE tail layout with SKYRIM_SUPPORT_AE, while this NG build defines
    // ENABLE_SKYRIM_AE. That helper reads TES+0x140 as a worldspace and then
    // calls GetSkyCell on non-pointer data (0.1.20 load crash).
    // GetWorldspace resolves through the player's version-aware parent CELL,
    // the same accessor already used by the accepted simulation path.
    if (!stopped) {
        auto* world=player->GetWorldspace();
        if (world) visitCell(world->GetSkyCell());
    }
}
void tick() {
    for (auto it=entries.begin();it != entries.end();) {
        const auto ref=it->reference.get();
        const auto* cell=ref ? ref->GetParentCell() : nullptr;
        bool valid=ref && cell && cell->IsAttached() && ref->Get3D() == it->root.get() &&
            profileOf(ref.get()) == it->profile && profileEnabled(it->profile);
        for (const auto& shape : it->shapes) if (shape && !belongsTo(shape.get(),it->root.get())) valid=false;
        if (!valid) { restore(*it); it=entries.erase(it); continue; }
        for (unsigned i=0;i<it->shapes.size();++i)
            if (it->changed[i]) it->shapes[i]->SetAppCulled(true);
        ++it;
    }
    const auto now=std::chrono::steady_clock::now();
    if (now < nextScan) return;
    nextScan=now+std::chrono::seconds(1);
    if (entries.size() >= maxReferences) return;
    forEachFoamReference([](RE::TESObjectREFR* ref) {
        if (entries.size() >= maxReferences) return RE::BSContainer::ForEachResult::kStop;
        const int profile=profileOf(ref);
        if (!profileEnabled(profile)) return RE::BSContainer::ForEachResult::kContinue;
        auto* root=ref->Get3D();
        if (!root || !ref->GetParentCell() || !ref->GetParentCell()->IsAttached()) return RE::BSContainer::ForEachResult::kContinue;
        if (std::any_of(entries.begin(),entries.end(),[&](const Entry& e){return e.root.get() == root;}))
            return RE::BSContainer::ForEachResult::kContinue;
        Entry entry;
        entry.root.reset(root); entry.profile=profile;
        if (!inspect(root,profile,entry)) {
            if (loggedMisses < 12) { ++loggedMisses; SKSE::log::info("{}: unchanged ref={:08X} model={} (profile incomplete or ambiguous)",category(profile),ref->GetFormID(),foam::profiles[profile].model); }
            return RE::BSContainer::ForEachResult::kContinue;
        }
        entry.reference=ref->CreateRefHandle();
        if (!entry.reference.get()) return RE::BSContainer::ForEachResult::kContinue;
        for (unsigned i=0;i<entry.shapes.size();++i) entry.changed[i]=entry.shapes[i] && !entry.shapes[i]->GetAppCulled();
        // Allocate/cache ownership BEFORE changing a scene flag, so an allocation
        // failure cannot leave an untracked hidden shape behind.
        entries.push_back(std::move(entry));
        auto& stored=entries.back();
        unsigned changed=0;
        for (unsigned i=0;i<stored.shapes.size();++i) if (stored.changed[i]) { stored.shapes[i]->SetAppCulled(true); ++changed; }
        if (loggedMatches < 24) { ++loggedMatches; SKSE::log::info("{}: ref={:08X} model={} matched={} hidden={} solid geometry retained",category(profile),ref->GetFormID(),foam::profiles[profile].model,foam::profiles[profile].count,changed); }
        return RE::BSContainer::ForEachResult::kContinue;
    });
}
}
void resetAttachedFoam() {
    for (auto& entry : entries) restore(entry);
    entries.clear();
    nextScan={};
}
void updateAttachedFoam(bool active) {
    if (!active || (!config.hideAttachedFoam && !config.hideIceDecals) || failed) { resetAttachedFoam(); return; }
    try { tick(); }
    catch (const std::exception& e) {
        resetAttachedFoam(); failed=true;
        SKSE::log::error("Attached surface filters disabled for this session: {}. Water simulation remains active.",e.what());
    }
    catch (...) {
        resetAttachedFoam(); failed=true;
        SKSE::log::error("Attached surface filters disabled after an unexpected exception. Water simulation remains active.");
    }
}
}
