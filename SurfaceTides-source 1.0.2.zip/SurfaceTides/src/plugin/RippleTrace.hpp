#pragma once
#include "PCH.hpp"
#include "surfacetides/ForwardedDraw.hpp"

namespace st::plugin {
struct Frame;
// A value snapshot made during SetupGeometry. Never retain/dereference an engine
// geometry pointer from a later draw; bounds are diagnostic estimates, not vertices.
struct RippleGeometry {
    bool known{}, stationary{};
    std::uintptr_t identity{};
    std::array<char,64> name{};
    std::uint32_t type{}, vertices{}, triangles{}, pass{};
    RE::NiPoint3 center{};
    float radius{}, modelZ{}, localZ{}, worldZ{}, scale{};
};
bool rippleTraceEnabled() noexcept;
RippleGeometry captureRippleGeometry(RE::BSRenderPass*) noexcept;
void nextRippleTraceFrame() noexcept;
std::uint32_t startRippleTrace(std::uint32_t vs, std::uint32_t ps,
    const st::DrawSignature&, const RippleGeometry&, const Frame* rendered = nullptr) noexcept;
void traceRippleNative(ID3D11DeviceContext*, std::uint32_t id, unsigned ordinal,
    const st::DrawSignature&, bool candidate) noexcept;
void traceStandaloneWater(ID3D11DeviceContext*, std::uint32_t vs, std::uint32_t ps,
    const st::DrawSignature&, const RippleGeometry&, const Frame* rendered) noexcept;
void finishRippleTrace(std::uint32_t id, unsigned native, unsigned selected,
    unsigned prepared, unsigned patches) noexcept;
}
