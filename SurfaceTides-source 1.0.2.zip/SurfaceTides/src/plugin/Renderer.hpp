#pragma once
#include "PCH.hpp"
#include "Bridge.hpp"
#include "surfacetides/ShaderLayout.hpp"
#include <unordered_map>
#include <chrono>
#include <functional>
#include "surfacetides/ForwardedDraw.hpp"
#include "surfacetides/MeshBounds.hpp"

namespace st::plugin {
struct RippleGeometry;
// Restores every D3D binding changed by this plugin. Engine shadow state is never edited.
class DrawState {
public:
    explicit DrawState(ID3D11DeviceContext* context);
    ~DrawState();
    void restore();
    DrawState(const DrawState&) = delete;
    DrawState& operator=(const DrawState&) = delete;
    bool compatible = true;
    unsigned incompatibilityMask{};
    bool changed = false;
    bool probe = false;
    ID3D11DeviceContext* probeContext{};
    ID3D11VertexShader* expectedVS{};
    ID3D11PixelShader* expectedPS{};
    ID3D11HullShader* expectedHS{};
    ID3D11DomainShader* expectedDS{};
    ID3D11ShaderResourceView* expectedField{};
    D3D11_PRIMITIVE_TOPOLOGY expectedTopology{};
    ComPtr<ID3D11VertexShader> vs;
    ComPtr<ID3D11PixelShader> ps;
    ID3D11Buffer* pixelBuffer(unsigned group) const { return stages_[1].buffers[group].Get(); }
    ID3D11Buffer* vertexBuffer(unsigned group) const { return stages_[0].buffers[group].Get(); }
    D3D11_PRIMITIVE_TOPOLOGY topology{};
private:
    struct Stage {
        std::array<ComPtr<ID3D11Buffer>,5> buffers;
        std::array<ComPtr<ID3D11ShaderResourceView>,2> textures;
        ComPtr<ID3D11SamplerState> sampler;
    };
    ID3D11DeviceContext* context_;
    ComPtr<ID3D11HullShader> hs_;
    ComPtr<ID3D11DomainShader> ds_;
    std::array<Stage,4> stages_;
};

class Renderer {
public:
    struct WaterPair {
        RE::BSGraphics::VertexShader* vs{};
        RE::BSGraphics::PixelShader* ps{};
        explicit operator bool() const { return vs && ps; }
    };
    static Renderer& get();
    WaterPair identify(RE::BSShader* owner, ID3D11VertexShader* vs, ID3D11PixelShader* ps);
    void nextFrame();
    void afterDraw(const DrawState& state);
    std::unique_ptr<DrawState> begin(ID3D11DeviceContext* context, RE::BSShader* waterShader, const WaterPair* forwarded = nullptr,
        const st::DrawSignature* traceDraw = nullptr, const RippleGeometry* traceGeometry = nullptr);
    bool drawMesh(ID3D11DeviceContext*, const WaterPair&, const st::DrawSignature&, const st::MeshBounds&,
        const std::function<void()>& sourceDraw, const std::function<void()>& meshDraw);
private:
    struct MeshBundle {
        bool valid{};
        UINT stride=40;
        ComPtr<ID3D11VertexShader> motionVS;
        ComPtr<ID3D11VertexShader> vs;
        ComPtr<ID3D11HullShader> hs;
        ComPtr<ID3D11DomainShader> ds;
        ComPtr<ID3D11GeometryShader> so;
        ComPtr<ID3D11InputLayout> layout;
        std::array<std::uint32_t,3> requiredBytes{};
    };
    MeshBundle compileMesh(RE::BSGraphics::VertexShader*, bool tryMotion=true);
    ID3D11RasterizerState* twoSidedRasterizer(ID3D11RasterizerState*);
    struct RasterVariant { ComPtr<ID3D11RasterizerState> original, twoSided; };
    std::unordered_map<ID3D11RasterizerState*,RasterVariant> meshRasterStates_;
    std::uint64_t meshTwoSidedDraws_{};
    std::unordered_map<std::string,MeshBundle> meshShaders_;
    ComPtr<ID3D11Buffer> meshStream_;
    UINT meshCapacity_{};
    std::array<std::uint64_t,10> meshStats_{}; // draws, patches, skipped, preparation failures, SO primitives
    struct MeshQuery { ComPtr<ID3D11Query> query; bool pending{}; };
    std::array<MeshQuery,4> meshQueries_;
    std::uint64_t meshSerial_{};
    bool meshOverflow_{}, meshPolled_{};
    struct Bundle {
        bool valid{}, loggedBindings{};
        unsigned loggedConstantModes{};
        std::array<std::uint32_t,3> requiredPSBytes{};
        ComPtr<ID3D11VertexShader> vs, control;
        ComPtr<ID3D11HullShader> hs;
        ComPtr<ID3D11DomainShader> ds;
        ComPtr<ID3D11PixelShader> ps;
    };
    Bundle compile(RE::BSGraphics::VertexShader* vs, RE::BSGraphics::PixelShader* ps);
    void prepare(ID3D11DeviceContext* context);
    void indexWaterShaders(RE::BSShader* shader);
    RE::BSShader* indexedOwner_{};
    std::chrono::steady_clock::time_point nextIndex_{};
    std::unordered_map<ID3D11VertexShader*,RE::BSGraphics::VertexShader*> waterVS_;
    std::unordered_map<ID3D11PixelShader*,RE::BSGraphics::PixelShader*> waterPS_;
    template<class Object, class Metadata> struct CachedIdentity {
        ComPtr<Object> object; // retain cached misses too, preventing pointer reuse
        Metadata* metadata{};
    };
    std::unordered_map<ID3D11VertexShader*,CachedIdentity<ID3D11VertexShader,RE::BSGraphics::VertexShader>> identityVS_;
    std::unordered_map<ID3D11PixelShader*,CachedIdentity<ID3D11PixelShader,RE::BSGraphics::PixelShader>> identityPS_;
    std::vector<RE::BSGraphics::VertexShader*> taggedVS_;
    std::vector<RE::BSGraphics::PixelShader*> taggedPS_;
    std::uint64_t tagGeneration_{}, tagReads_{}, tagMatches_{}, unmatchedVS_{}, unmatchedPS_{};
    ComPtr<ID3D11Device> device_;
    std::array<ComPtr<ID3D11Texture2D>,2> textures_;
    std::array<ComPtr<ID3D11ShaderResourceView>,2> views_;
    ComPtr<ID3D11Buffer> constants_;
    ComPtr<ID3D11SamplerState> sampler_;
    std::unordered_map<std::string,Bundle> shaders_;
    std::shared_ptr<const Frame> gpuFrame_;
    Tuning renderTuning_; // captured once per water frame, never mutated by the menu
    std::array<float,20> parameters_{};
    std::array<std::uint64_t,7> stats_{}; // attempts, inactive, incompatible, unknown, LOD, bound, tessellated
    std::uint64_t failedDraws_{};
    std::uint64_t shiftedConstantDraws_{}, unrecognizedConstantDraws_{};
    std::uint64_t probeSerial_{}, probedDraws_{}, changedDraws_{};
    unsigned changedMask_{}, incompatibleMask_{};
    std::chrono::steady_clock::time_point nextStats_{};
    int current_ = 0, previous_ = 0, textureSize_ = 0;
    bool consumed_{}, active_{};
};
}
