#include "PCH.hpp"
#include "Bridge.hpp"

extern "C" __declspec(dllexport) constinit SKSE::PluginVersionData SKSEPlugin_Version = [] {
    SKSE::PluginVersionData v;
    v.PluginName("SurfaceTides"); v.PluginVersion({1,0,2,0}); v.AuthorName("SurfaceTides contributors");
    v.UsesAddressLibrary(true); v.UsesStructsPost629(true);
    v.CompatibleVersions({REL::Version{1,6,1170,0},REL::Version{1,6,1179,0}});
    return v;
}();

namespace {
void reset() {
    st::plugin::resetFloe();
    st::plugin::resetAttachedFoam();
    st::plugin::resetRequested.store(true);
    st::plugin::exchange.publish(std::make_shared<st::plugin::Frame>());
}
// Inspect module paths and user configuration only. No ENB SDK or shader code.
std::filesystem::path modulePath(HMODULE module) {
    std::array<wchar_t,32768> path{};
    const auto size = GetModuleFileNameW(module,path.data(),static_cast<DWORD>(path.size()));
    if (!size || size >= path.size()) throw std::runtime_error("Cannot resolve renderer module path");
    return std::filesystem::path(std::wstring(path.data(),size));
}
bool rendererAllowed() {
    try {
        if (const auto cs = GetModuleHandleW(L"CommunityShaders.dll")) {
            auto& config = st::plugin::config;
            SKSE::log::info("Community Shaders detected: module={} AllowCS={}",modulePath(cs).string(),config.allowCS);
            if (!config.allowCS) {
                SKSE::log::error("CS coexistence is opt-in: set [Compatibility] AllowCS=1 and disable CS Water shader replacement, UnifiedWater and WaterEffects at boot. SurfaceTides disabled.");
                return false;
            }
            if (GetModuleHandleW(L"enbseries.dll")) {
                SKSE::log::error("Both Community Shaders and enbseries.dll are loaded; this combination is outside the coexistence test. SurfaceTides disabled.");
                return false;
            }
            const auto overridePath = modulePath(nullptr).parent_path() / "Data/SKSE/Plugins/CommunityShaders/Overrides/SurfaceTides_Global.json";
            SKSE::log::info("CS water override: file={} present={} (presence only; check CommunityShaders.log for application)",
                overridePath.string(),std::filesystem::is_regular_file(overridePath));
            // A CS installation may retain an old enbseries.ini or use a local
            // graphics proxy. Those alone must not route it into the ENB path.
            config.allowENB=false;
            config.enbMeshInput=false;
            st::plugin::communityShadersActive=true;
            SKSE::log::info("Water renderer: SurfaceTides with CS coexistence. Requires Replace Original Shaders/Water=false and Disable at Boot/UnifiedWater=true, WaterEffects=true. Saved overrides are handled by CS; SurfaceTides does not query live feature state.");
            return true;
        }
        const auto directory = modulePath(nullptr).parent_path();
        bool localProxy = false;
        for (const auto* name : {L"d3d11.dll",L"dxgi.dll",L"enbseries.dll",L"d3dcompiler_46e.dll"}) {
            if (const auto module = GetModuleHandleW(name)) {
                const auto path = modulePath(module);
                SKSE::log::info("Renderer module: {}",path.string());
                if ((!_wcsicmp(name,L"d3d11.dll") || !_wcsicmp(name,L"dxgi.dll")) &&
                    !_wcsicmp(path.parent_path().c_str(),directory.c_str())) localProxy = true;
            }
        }
        const auto ini = directory / "enbseries.ini";
        const bool enbModule = GetModuleHandleW(L"enbseries.dll") != nullptr;
        const bool iniPresent = std::filesystem::is_regular_file(ini);
        // A proxy or leftover INI is evidence of a possible renderer, not proof of ENB.
        const bool possibleENB = enbModule || iniPresent || localProxy;
        SKSE::log::info("Compatibility: AllowENB={} enbModule={} localGraphicsProxy={} enbINI={}",
            st::plugin::config.allowENB,enbModule,localProxy,iniPresent);
        if (!possibleENB) {
            st::plugin::config.enbMeshInput=false;
            SKSE::log::info("Water renderer: SurfaceTides standalone (displacement and simulation normals)");
            return true;
        }
        if (!st::plugin::config.allowENB) {
            SKSE::log::error("ENB or another local renderer may be present. Set [Compatibility] AllowENB=1 for an ENB compatibility test.");
            return false;
        }
        std::array<wchar_t,128> value{};
        const auto count = GetPrivateProfileStringW(L"EFFECT",L"EnableWater",L"",value.data(),
            static_cast<DWORD>(value.size()),ini.c_str());
        std::wstring text(value.data(),count);
        const auto first = text.find_first_not_of(L" \t\r\n");
        const auto last = text.find_last_not_of(L" \t\r\n");
        text = first == std::wstring::npos ? L"" : text.substr(first,last-first+1);
        const bool waterOff = !_wcsicmp(text.c_str(),L"false") || text == L"0";
        SKSE::log::info("ENB config check: file={} [EFFECT] EnableWater={} confirmedOff={}",
            ini.string(),std::string(text.begin(),text.end()),waterOff);
        if ((!waterOff || count == value.size()-1) && !st::plugin::config.enbMeshInput) {
            SKSE::log::error("Coexistence requires saved [EFFECT] EnableWater=false in enbseries.ini beside SkyrimSE.exe, followed by a restart. SurfaceTides disabled.");
            return false;
        }
        if (st::plugin::config.enbMeshInput)
            SKSE::log::info("Water renderer: EXPERIMENTAL ENB mesh-input integration (native water shaders retained; known ripple/underwater defects)");
        else
            SKSE::log::info("Water renderer: SurfaceTides with ENB water OFF (displacement and simulation normals). Keep ENB water OFF for this session; INI check does not query live state.");
        return true;
    } catch (const std::exception& e) {
        SKSE::log::error("Renderer compatibility check failed: {}",e.what());
        return false;
    }
}
void onMessage(SKSE::MessagingInterface::Message* message) {
    if (!message) return;
    switch (message->type) {
    case SKSE::MessagingInterface::kDataLoaded:
        if (!rendererAllowed()) st::plugin::disabled.store(true);
        else if (st::plugin::config.enabled) st::plugin::installHooks();
        st::plugin::registerMenu();
        break;
    case SKSE::MessagingInterface::kPreLoadGame:
    case SKSE::MessagingInterface::kPostLoadGame:
    case SKSE::MessagingInterface::kNewGame: reset(); break;
    default: break;
    }
}
}

extern "C" __declspec(dllexport) bool SKSEPlugin_Load(const SKSE::LoadInterface* skse) {
    if (!skse || skse->IsEditor()) return false;
    const auto runtime = skse->RuntimeVersion();
    // New AE 1.7 uses new engine/shader layouts. Never silently opt into it.
    if (runtime != REL::Version(1,6,1170,0) && runtime != REL::Version(1,6,1179,0)) {
        OutputDebugStringW(L"SurfaceTides: only Skyrim 1.6.1170 / 1.6.1179 are currently targeted.\n");
        return false;
    }
    SKSE::Init(skse);
    try {
        auto directory = SKSE::log::log_directory();
        if (!directory) return false;
        auto sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>((*directory / "SurfaceTides.log").string(),true);
        auto log = std::make_shared<spdlog::logger>("SurfaceTides",std::move(sink));
        spdlog::set_default_logger(std::move(log)); spdlog::set_level(spdlog::level::info); spdlog::flush_on(spdlog::level::info);
        SKSE::log::info("SurfaceTides 1.0.2 (nearby water retention), runtime {}",runtime.string());
        st::plugin::config = st::plugin::Config::read();
        SKSE::log::info("HideAttachedFoam={} (startup-only; 2 reviewed model profiles; no mesh files or collision changes)",st::plugin::config.hideAttachedFoam);
        SKSE::log::info("HideIceDecals={} (startup-only; 12 reviewed ice profiles including 9 Frozen Marsh; solid geometry retained; bobbing limited to original 3)",st::plugin::config.hideIceDecals);
        SKSE::log::info("FloeBobbing={} (startup-only; three reviewed ice models; legacy FloeBobbingTest used only when FloeBobbing is absent; max64 active, max8 dense fits/frame)",st::plugin::config.floeBobbing);
        SKSE::log::info("Floe riders: stable local-delta carry; velocity repair only on observed change; no actor reposition calls");
        SKSE::log::info("Floe jumping: early request/pending-state release and stable-landing reattachment; Ice is Slick incompatible with bobbing for now");
        SKSE::log::info("AttachedFoam discovery: player cell/worldspace and attached grid; legacy TES worldSpace scan bypassed");
        SKSE::log::info("RippleTrace={} (requires LogStats only; standalone supported; max32 scopes, 8 per family at least5seconds apart; scene bounds and D3D metadata only; no GPU readback)",st::plugin::config.rippleTrace);
        SKSE::log::info("MeshBounds={} MeshMotionVectors={}",st::plugin::config.meshBounds,st::plugin::config.meshMotionVectors);
        SKSE::log::info("Experimental ENBWaterIntegration={} MeshTessellationMax={} MeshTwoSided={} (requested; actual water renderer is selected after data load)",st::plugin::config.enbMeshInput,st::plugin::config.meshTessellationMax,st::plugin::config.meshTwoSided);
        SKSE::log::info("RestoreWaterConstants={}",st::plugin::config.restoreWaterConstants);
        SKSE::log::info("WaterPassTrace={} (public D3D metadata; independent periodic/mismatch budgets, max32 pairs each every2seconds, max8 native passes per sample)",st::plugin::config.waterPassTrace);
        if (st::plugin::config.waterPassTrace && !st::plugin::config.diagnostics)
            SKSE::log::warn("WaterPassTrace requires LogStats=1; detailed capture is disabled by the current logging setting.");
        SKSE::log::info("Config: terrainMask={} wind={} gustStrength={} normalStrength={} displacementStrength={} tessellation={} logStats={} debugView={}",
            st::plugin::config.terrainMask,st::plugin::config.simulation.wind,st::plugin::config.simulation.gustStrength,st::plugin::config.normalStrength,
            st::plugin::config.displacementStrength,st::plugin::config.tessellation,st::plugin::config.diagnostics,st::plugin::config.debugView);
        SKSE::log::info("Interaction strength={} radiusScale={} tessellationSpacing={} tessellationMax={}",
            st::plugin::config.interactionStrength,st::plugin::config.interactionRadius,
            st::plugin::config.tessellationSpacing,st::plugin::config.tessellationMax);
        st::plugin::tuning.publish(st::plugin::config);
        if (!st::plugin::config.enabled) SKSE::log::info("Disabled in configuration; menu available for tuning next launch");
        if (auto* serialization = SKSE::GetSerializationInterface()) {
            serialization->SetUniqueID(0x53544944); // STID; no save records are written
            serialization->SetRevertCallback([](SKSE::SerializationInterface*) { reset(); });
        }
        const auto* messaging = SKSE::GetMessagingInterface();
        return messaging && messaging->RegisterListener(onMessage);
    } catch (const std::exception& e) { OutputDebugStringA(e.what()); return false; }
}
