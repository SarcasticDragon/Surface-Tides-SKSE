#include "PCH.hpp"
#include "Bridge.hpp"
#include "Renderer.hpp"
#include <MinHook.h>
#include <cstring>
#include "surfacetides/ForwardedDraw.hpp"
#include "PipelineTrace.hpp"
#include "RippleTrace.hpp"

namespace st::plugin {
namespace {
// Geometry setup can be cached or run outside the immediate draw scope.
// Retain the owner; identify water using the shaders bound at each draw.
std::atomic<RE::BSShader*> waterShaderOwner{nullptr};
ID3D11DeviceContext* gameContext = nullptr;
IDXGISwapChain* gameSwapChain = nullptr;
bool deviceHooksInstalled = false;
ComPtr<ID3D11Device> gameDevice;
ComPtr<ID3D11DeviceContext> ownedContext;
constexpr std::array<std::size_t,7> drawSlots{12,13,20,21,38,39,40};
std::array<void*,7> drawTargets{};
std::array<std::array<unsigned char,8>,7> entryBytes{};
std::array<std::atomic<std::uint64_t>,7> rawDraws{};
std::atomic<std::uint64_t> foreignContext{}, noOwner{}, disabledCalls{};
auto nextHookReport = std::chrono::steady_clock::time_point{};
thread_local unsigned drawDepth = 0;


ComPtr<ID3D11DeviceContext> engineContext;
thread_local unsigned engineCallDepth = 0;
struct LogicalBindings {
    ComPtr<ID3D11VertexShader> vs;
    ComPtr<ID3D11PixelShader> ps;
    bool haveVS{}, havePS{};
    UINT vsClasses{}, psClasses{};
    st::LogicalTopology topology;
};
LogicalBindings logical;
std::mutex logicalMutex;
struct Forwarding {
    Renderer::WaterPair water;
    st::ForwardedDraw gate;
    st::DrawSignature expected;
    st::MeshBounds bounds;
    bool traceActive{};
    std::uint64_t traceId{};
    UINT traceNativeCalls{};
    std::array<ObservedWaterDraw,8> traceHistory{};
    std::uint32_t rippleId{};
    unsigned rippleNative{}, rippleSelected{}, ripplePrepared{}, ripplePatches{};
};
struct GeometryHint { const RE::BSRenderPass* pass{}; st::MeshBounds bounds; RippleGeometry ripple; };
thread_local GeometryHint geometryHint;
thread_local Forwarding* forwarding = nullptr;
struct ForwardScope {
    Forwarding* previous;
    explicit ForwardScope(Forwarding* next) : previous(forwarding) { forwarding = next; }
    ~ForwardScope() { forwarding = previous; }
};
struct EngineCall {
    EngineCall() { ++engineCallDepth; }
    ~EngineCall() { --engineCallDepth; }
};
std::atomic<std::uint64_t> engineDraws{}, engineWater{}, forwardedDraws{}, unforwarded{}, logicalMisses{}, vsSets{}, psSets{};
std::atomic<std::uint64_t> topologySets{}, topologyTracked{}, topologyFallback{}, topologySamples{}, topologyDisagreements{};
std::atomic<bool> loggedTopologyDisagreement{};
constexpr std::array<std::size_t,9> engineSlots{12,13,20,21,11,9,110,58,24};
std::array<void*,9> engineReplacements{};

struct Patch { void** slot{}; void* previous{}; void* replacement{}; };
std::vector<Patch> patches;

// Only pointer-sized vtable entries are changed; no guessed instruction offsets or code patches.
template<class F> F patch(void* tableAddress, std::size_t index, F replacement) {
    auto** slot = reinterpret_cast<void**>(tableAddress) + index;
    MEMORY_BASIC_INFORMATION info{};
    if (!VirtualQuery(*slot,&info,sizeof(info)) || info.State != MEM_COMMIT ||
        !(info.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)))
        throw std::runtime_error("Vtable target is not executable");
    DWORD old{};
    if (!VirtualProtect(slot,sizeof(void*),PAGE_READWRITE,&old)) throw std::runtime_error("Cannot write vtable entry");
    auto* previous = InterlockedExchangePointer(slot,reinterpret_cast<void*>(replacement));
    DWORD ignored{};
    VirtualProtect(slot,sizeof(void*),old,&ignored);
    patches.push_back({slot,previous,reinterpret_cast<void*>(replacement)});
    return reinterpret_cast<F>(previous);
}
void rollback(std::size_t checkpoint) {
    while (patches.size() > checkpoint) {
        const auto p = patches.back(); patches.pop_back();
        DWORD old{};
        if (VirtualProtect(p.slot,sizeof(void*),PAGE_READWRITE,&old)) {
            InterlockedCompareExchangePointer(p.slot,p.previous,p.replacement);
            DWORD ignored{}; VirtualProtect(p.slot,sizeof(void*),old,&ignored);
        }
    }
}

using DrawIndexedFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT,INT);
using DrawFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT);
using DrawIndexedInstancedFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT,UINT,INT,UINT);
using DrawInstancedFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,UINT,UINT,UINT,UINT);
using DrawAutoFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*);
using DrawIndirectFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11Buffer*,UINT);
using PresentFn = HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT);
DrawIndexedFn originalDrawIndexed{};
DrawFn originalDraw{};
DrawIndexedInstancedFn originalDrawIndexedInstanced{};
DrawInstancedFn originalDrawInstanced{};
PresentFn originalPresent{};
DrawAutoFn originalDrawAuto{};
DrawIndirectFn originalDrawIndexedIndirect{}, originalDrawIndirect{};

std::unique_ptr<DrawState> beforeDraw(ID3D11DeviceContext* context, const Renderer::WaterPair* water,
    const st::DrawSignature& traceDraw) noexcept {
    if (context != gameContext) {
        const auto count = foreignContext.fetch_add(1,std::memory_order_relaxed);
        if (count == 0 && config.diagnostics)
            SKSE::log::info("Draw hook saw foreign context={} expected={} type={}",static_cast<void*>(context),static_cast<void*>(gameContext),static_cast<unsigned>(context->GetType()));
        return {};
    }
    if (disabled.load()) { ++disabledCalls; return {}; }
    auto* shader = waterShaderOwner.load(std::memory_order_acquire);
    if (!shader) { ++noOwner; return {}; }
    try { return Renderer::get().begin(context,shader,water,
        forwarding ? nullptr : &traceDraw,forwarding ? nullptr : &geometryHint.ripple); }
    catch (const std::exception& e) {
        disabled.store(true);
        SKSE::log::error("SurfaceTides rendering disabled for this session: {}",e.what());
        return {};
    }
}
template<class Call> void intercept(ID3D11DeviceContext* c, std::size_t kind, std::array<UINT,5> args, Call&& call) {
    rawDraws[kind].fetch_add(1,std::memory_order_relaxed);
    struct Depth { Depth() { ++drawDepth; } ~Depth() { --drawDepth; } } depth;
    const Renderer::WaterPair* hint = nullptr;
    bool meshCandidate=false;
    st::DrawSignature meshSignature{};
    UINT traceOrdinal=0;
    if (drawDepth == 1 && forwarding && forwarding->water && (c == gameContext || forwarding->traceActive)) {
        D3D11_PRIMITIVE_TOPOLOGY topology;
        c->IAGetPrimitiveTopology(&topology);
        const st::DrawSignature actual{static_cast<UINT>(kind),args,static_cast<UINT>(topology)};
        meshCandidate=c==gameContext && st::meshInputDraw(forwarding->expected,actual);
        meshSignature=actual;
        if (forwarding->rippleId) {
            const auto ordinal=++forwarding->rippleNative;
            if (meshCandidate) ++forwarding->rippleSelected;
            if (actual.topology==35) ++forwarding->ripplePatches;
            traceRippleNative(c,forwarding->rippleId,ordinal,actual,meshCandidate);
        }
        if (c == gameContext && forwarding->gate.consume(actual)) {
            hint = &forwarding->water; ++forwardedDraws;
        }
        if (forwarding->traceActive) {
            const auto ordinal=++forwarding->traceNativeCalls;
            if (ordinal<=forwarding->traceHistory.size()) {
                forwarding->traceHistory[ordinal-1]={actual,c==gameContext};
                // Capture metadata now, before ENB restores temporary bindings.
                // This only affects logging; the exact-match gate above is unchanged.
                if (!forwarding->traceId && !forwarding->gate.used())
                    forwarding->traceId=startWaterTrace(forwarding->water.vs->id,forwarding->water.ps->id,forwarding->expected,true);
            }
            if (forwarding->traceId) {
                traceOrdinal=ordinal;
                traceWaterPass(c,forwarding->traceId,traceOrdinal,actual,c==gameContext,hint!=nullptr);
            }
        }
    }
    if (drawDepth==1 && config.allowENB && config.enbMeshInput) {
        bool handled=false;
        if (meshCandidate && !disabled.load()) {
            try {
                handled=Renderer::get().drawMesh(c,forwarding->water,meshSignature,forwarding->bounds,
                    [&]{call();},[&]{originalDrawAuto(c);});
            } catch (const std::exception& e) {
                disabled.store(true);
                SKSE::log::error("Mesh-input rendering disabled for session: {}",e.what());
            }
        }
        if (traceOrdinal) traceWaterResult(forwarding->traceId,traceOrdinal,handled);
        if (handled && forwarding && forwarding->rippleId) ++forwarding->ripplePrepared;
        if (!handled) call();
        return; // never mix the old shader replacement into this mode
    }
    const st::DrawSignature traceDraw{static_cast<UINT>(kind),args,0};
    auto state = drawDepth == 1 ? beforeDraw(c,hint,traceDraw) : std::unique_ptr<DrawState>{};
    if (traceOrdinal) traceWaterResult(forwarding->traceId,traceOrdinal,state && state->changed);
    call();
    if (state) Renderer::get().afterDraw(*state);
}
void STDMETHODCALLTYPE drawIndexed(ID3D11DeviceContext* c, UINT count, UINT start, INT base) {
    intercept(c,0,{count,start,static_cast<UINT>(base),0,0},[&] { originalDrawIndexed(c,count,start,base); });
}
void STDMETHODCALLTYPE draw(ID3D11DeviceContext* c, UINT count, UINT start) {
    intercept(c,1,{count,start,0,0,0},[&] { originalDraw(c,count,start); });
}
void STDMETHODCALLTYPE drawIndexedInstanced(ID3D11DeviceContext* c, UINT count, UINT instances, UINT start, INT base, UINT firstInstance) {
    intercept(c,2,{count,instances,start,static_cast<UINT>(base),firstInstance},[&] { originalDrawIndexedInstanced(c,count,instances,start,base,firstInstance); });
}
void STDMETHODCALLTYPE drawInstanced(ID3D11DeviceContext* c, UINT count, UINT instances, UINT start, UINT firstInstance) {
    intercept(c,3,{count,instances,start,firstInstance,0},[&] { originalDrawInstanced(c,count,instances,start,firstInstance); });
}
void STDMETHODCALLTYPE drawAuto(ID3D11DeviceContext* c) {
    intercept(c,4,{},[&] { originalDrawAuto(c); });
}
void STDMETHODCALLTYPE drawIndexedIndirect(ID3D11DeviceContext* c, ID3D11Buffer* args, UINT offset) {
    intercept(c,5,{},[&] { originalDrawIndexedIndirect(c,args,offset); });
}
void STDMETHODCALLTYPE drawIndirect(ID3D11DeviceContext* c, ID3D11Buffer* args, UINT offset) {
    intercept(c,6,{},[&] { originalDrawIndirect(c,args,offset); });
}

// Game-facing COM method hooks capture only the public API arguments. Actual
// drawing still goes through the original wrapper and the existing native hook.
DrawIndexedFn engineDrawIndexedOriginal{};
DrawFn engineDrawOriginal{};
DrawIndexedInstancedFn engineIndexedInstancedOriginal{};
DrawInstancedFn engineInstancedOriginal{};
using VSSetFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11VertexShader*,ID3D11ClassInstance* const*,UINT);
using PSSetFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11PixelShader*,ID3D11ClassInstance* const*,UINT);
using ClearFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*);
using ExecuteFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,ID3D11CommandList*,BOOL);
using TopologyFn = void (STDMETHODCALLTYPE*)(ID3D11DeviceContext*,D3D11_PRIMITIVE_TOPOLOGY);
VSSetFn engineVSOriginal{}; PSSetFn enginePSOriginal{};
ClearFn engineClearOriginal{}; ExecuteFn engineExecuteOriginal{};
TopologyFn engineTopologyOriginal{};
void STDMETHODCALLTYPE engineVS(ID3D11DeviceContext* c, ID3D11VertexShader* v, ID3D11ClassInstance* const* classes, UINT count) {
    if (c == engineContext.Get() && !engineCallDepth) { std::lock_guard lock(logicalMutex); logical.vs=v; logical.haveVS=true; logical.vsClasses=count; ++vsSets; }
    EngineCall guard; engineVSOriginal(c,v,classes,count);
}
void STDMETHODCALLTYPE enginePS(ID3D11DeviceContext* c, ID3D11PixelShader* p, ID3D11ClassInstance* const* classes, UINT count) {
    if (c == engineContext.Get() && !engineCallDepth) { std::lock_guard lock(logicalMutex); logical.ps=p; logical.havePS=true; logical.psClasses=count; ++psSets; }
    EngineCall guard; enginePSOriginal(c,p,classes,count);
}
void STDMETHODCALLTYPE engineTopology(ID3D11DeviceContext* c, D3D11_PRIMITIVE_TOPOLOGY topology) {
    if (c == engineContext.Get()) {
        std::lock_guard lock(logicalMutex);
        if (logical.topology.observe(static_cast<UINT>(topology),engineCallDepth != 0)) ++topologySets;
    }
    EngineCall guard; engineTopologyOriginal(c,topology);
}
void STDMETHODCALLTYPE engineClear(ID3D11DeviceContext* c) {
    if (c==engineContext.Get() && !engineCallDepth) geometryHint={};
    if (c == engineContext.Get() && !engineCallDepth) {
        std::lock_guard lock(logicalMutex); logical = {}; logical.topology.clear();
    }
    EngineCall guard; engineClearOriginal(c);
}
void STDMETHODCALLTYPE engineExecute(ID3D11DeviceContext* c, ID3D11CommandList* list, BOOL restore) {
    if (c==engineContext.Get() && !engineCallDepth) geometryHint={};
    const bool outside = !engineCallDepth;
    { EngineCall guard; ForwardScope noHint(nullptr); engineExecuteOriginal(c,list,restore); }
    if (c == engineContext.Get() && outside && !restore) {
        std::lock_guard lock(logicalMutex); logical = {}; logical.topology.clear();
    }
}
template<class Call> void engineDrawScope(ID3D11DeviceContext* c, UINT kind, std::array<UINT,5> args, Call&& call) {
    if (c != engineContext.Get() || engineCallDepth || disabled.load()) { call(); return; }
    ++engineDraws;
    Renderer::WaterPair water;
    D3D11_PRIMITIVE_TOPOLOGY topology = D3D11_PRIMITIVE_TOPOLOGY_UNDEFINED;
    try {
        LogicalBindings snapshot;
        { std::lock_guard lock(logicalMutex); snapshot = logical; }
        auto vs = snapshot.vs; auto ps = snapshot.ps;
        UINT vsClasses = snapshot.vsClasses, psClasses = snapshot.psClasses;
        // Initial bindings can precede hook installation. Query only until their
        // first observed game setter; do not infer water from setup-scope alone.
        if (!snapshot.haveVS) c->VSGetShader(vs.ReleaseAndGetAddressOf(),nullptr,&vsClasses);
        if (!snapshot.havePS) c->PSGetShader(ps.ReleaseAndGetAddressOf(),nullptr,&psClasses);
        if (!vsClasses && !psClasses) water = Renderer::get().identify(waterShaderOwner.load(std::memory_order_acquire),vs.Get(),ps.Get());
        if (water) {
            ++engineWater;
            // A wrapper getter can expose a previous SurfaceTides patch draw,
            // although the game's unchanged request is still TRIANGLELIST.
            // Preserve exact native matching by fixing the expected signature,
            // never by accepting a 35->4 conversion or changing draw arguments.
            if (snapshot.topology.known()) {
                topology=static_cast<D3D11_PRIMITIVE_TOPOLOGY>(snapshot.topology.resolve(0));
                ++topologyTracked;
                if (config.diagnostics && ((water.vs->id >> 11) & 15u)==8) {
                    D3D11_PRIMITIVE_TOPOLOGY reported{}; c->IAGetPrimitiveTopology(&reported);
                    ++topologySamples;
                    if (reported!=topology) {
                        ++topologyDisagreements;
                        if (!loggedTopologyDisagreement.exchange(true))
                            SKSE::log::info("Game topology disagreement VS={:X} PS={:X} requested={} getter={} [using observed game request; native match remains exact]",
                                water.vs->id,water.ps->id,static_cast<UINT>(topology),static_cast<UINT>(reported));
                    }
                }
            } else { c->IAGetPrimitiveTopology(&topology); ++topologyFallback; }
        }
        else ++logicalMisses;
    } catch (const std::exception& e) {
        disabled.store(true); SKSE::log::error("Game-context identification disabled: {}",e.what());
    }
    const st::DrawSignature expected{kind,args,static_cast<UINT>(topology)};
    Forwarding pending{water,st::ForwardedDraw(expected),expected,geometryHint.bounds};
    if (water) pending.rippleId=startRippleTrace(water.vs->id,water.ps->id,expected,geometryHint.ripple);
    pending.traceActive=water && rendererCoexistence() && config.diagnostics && config.waterPassTrace;
    if (pending.traceActive) pending.traceId=startWaterTrace(water.vs->id,water.ps->id,expected);
    { ForwardScope scope(&pending); EngineCall guard; call(); }
    if (pending.traceActive && !pending.gate.used()) {
        if (!pending.traceId) pending.traceId=startWaterTrace(water.vs->id,water.ps->id,expected,true);
        traceUnmatchedHistory(pending.traceId,pending.traceHistory,pending.traceNativeCalls);
    }
    finishWaterTrace(pending.traceId,pending.traceNativeCalls,pending.gate.used());
    finishRippleTrace(pending.rippleId,pending.rippleNative,pending.rippleSelected,pending.ripplePrepared,pending.ripplePatches);
    if (water && !pending.gate.used()) ++unforwarded;
}
void STDMETHODCALLTYPE engineDrawIndexed(ID3D11DeviceContext* c, UINT count, UINT start, INT base) {
    engineDrawScope(c,0,{count,start,static_cast<UINT>(base),0,0},[&]{engineDrawIndexedOriginal(c,count,start,base);});
}
void STDMETHODCALLTYPE engineDraw(ID3D11DeviceContext* c, UINT count, UINT start) {
    engineDrawScope(c,1,{count,start,0,0,0},[&]{engineDrawOriginal(c,count,start);});
}
void STDMETHODCALLTYPE engineIndexedInstanced(ID3D11DeviceContext* c, UINT count, UINT instances, UINT start, INT base, UINT first) {
    engineDrawScope(c,2,{count,instances,start,static_cast<UINT>(base),first},[&]{engineIndexedInstancedOriginal(c,count,instances,start,base,first);});
}
void STDMETHODCALLTYPE engineInstanced(ID3D11DeviceContext* c, UINT count, UINT instances, UINT start, UINT first) {
    engineDrawScope(c,3,{count,instances,start,first,0},[&]{engineInstancedOriginal(c,count,instances,start,first);});
}
void installEngineContext(ID3D11DeviceContext* c) {
    if (!rendererCoexistence() || !c || c == gameContext) return;
    // Do not patch a shared native table (that would observe two layers as one).
    auto** table = *reinterpret_cast<void***>(c);
    if (table == *reinterpret_cast<void***>(gameContext)) {
        SKSE::log::warn("Game-context bridge skipped: context shares native method table"); return;
    }
    engineContext = c;
    engineDrawIndexedOriginal = patch(table,12,&engineDrawIndexed);
    engineDrawOriginal = patch(table,13,&engineDraw);
    engineIndexedInstancedOriginal = patch(table,20,&engineIndexedInstanced);
    engineInstancedOriginal = patch(table,21,&engineInstanced);
    engineVSOriginal = patch(table,11,&engineVS);
    enginePSOriginal = patch(table,9,&enginePS);
    engineClearOriginal = patch(table,110,&engineClear);
    engineExecuteOriginal = patch(table,58,&engineExecute);
    engineTopologyOriginal = patch(table,24,&engineTopology);
    for (std::size_t i=0;i<engineSlots.size();++i) engineReplacements[i]=table[engineSlots[i]];
    SKSE::log::info("Installed game-context bridge: four direct draw methods, VS/PS/topology setters, ClearState and ExecuteCommandList; context={}",static_cast<void*>(c));
}
void reportHooks() {
    if (!config.diagnostics || std::chrono::steady_clock::now() < nextHookReport) return;
    nextHookReport = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    auto** table = *reinterpret_cast<void***>(gameContext);
    unsigned sameTargets = 0, stableEntries = 0;
    for (std::size_t i = 0; i < drawSlots.size(); ++i) {
        if (table[drawSlots[i]] == drawTargets[i]) sameTargets |= 1u << i;
        if (std::memcmp(drawTargets[i],entryBytes[i].data(),entryBytes[i].size()) == 0) stableEntries |= 1u << i;
    }
    ComPtr<ID3D11DeviceContext> current;
    gameDevice->GetImmediateContext(&current);
    SKSE::log::info("Hook health: raw[Indexed,Draw,IndexedInstanced,Instanced,Auto,IndexedIndirect,Indirect]=[{},{},{},{},{},{},{}] foreign={} noOwner={} disabled={} targetMask={:02X} entryMask={:02X} immediateContextSame={}",
        rawDraws[0].exchange(0),rawDraws[1].exchange(0),rawDraws[2].exchange(0),rawDraws[3].exchange(0),rawDraws[4].exchange(0),rawDraws[5].exchange(0),rawDraws[6].exchange(0),
        foreignContext.exchange(0),noOwner.exchange(0),disabledCalls.exchange(0),sameTargets,stableEntries,current.Get() == gameContext);
    if (engineContext) {
        unsigned intact = 0; auto** logicalTable = *reinterpret_cast<void***>(engineContext.Get());
        for (std::size_t i=0;i<engineSlots.size();++i) if (logicalTable[engineSlots[i]]==engineReplacements[i]) intact |= 1u<<i;
        SKSE::log::info("Game-context bridge: draws={} identifiedWater={} matchedNative={} noMatchingNative={} unknownPair={} VSsets={} PSsets={} methodMask={:02X}",
            engineDraws.exchange(0),engineWater.exchange(0),forwardedDraws.exchange(0),unforwarded.exchange(0),logicalMisses.exchange(0),vsSets.exchange(0),psSets.exchange(0),intact);
        SKSE::log::info("Game topology: setters={} trackedWater={} getterFallback={} underwaterSamples={} getterDisagreements={} [five-second counters; requested topology used when observed]",
            topologySets.exchange(0),topologyTracked.exchange(0),topologyFallback.exchange(0),topologySamples.exchange(0),topologyDisagreements.exchange(0));
    }

}
HRESULT STDMETHODCALLTYPE present(IDXGISwapChain* chain, UINT interval, UINT flags) {
    const auto hr = originalPresent(chain,interval,flags);
    if (chain == gameSwapChain && !(flags & DXGI_PRESENT_TEST)) { geometryHint={}; nextRippleTraceFrame(); reportHooks(); Renderer::get().nextFrame(); }
    return hr;
}

void tryDeviceHooks() {
    if (deviceHooksInstalled || disabled.load()) return;
    auto* renderer = RE::BSGraphics::Renderer::GetSingleton();
    if (!renderer) return;
    // Only legacy 1.6.1170 / 1.6.1179 are accepted by Main.cpp before this layout is used.
    gameSwapChain = reinterpret_cast<IDXGISwapChain*>(renderer->data.renderWindows[0].swapChain);
    if (!gameSwapChain) return;
    check(gameSwapChain->GetDevice(IID_PPV_ARGS(gameDevice.ReleaseAndGetAddressOf())),"Get swapchain device");
    gameDevice->GetImmediateContext(ownedContext.ReleaseAndGetAddressOf());
    gameContext = ownedContext.Get();
    if (!gameContext) return;
    SKSE::log::info("Canonical immediate context={} rendererContext={} same={}",static_cast<void*>(gameContext),
        static_cast<void*>(renderer->data.context),gameContext == reinterpret_cast<ID3D11DeviceContext*>(renderer->data.context));
    const auto checkpoint = patches.size();
    try {
        patches.reserve(patches.size() + 9);
        const auto init = MH_Initialize();
        if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED)
            throw std::runtime_error(std::string("MinHook init: ") + MH_StatusToString(init));
        void** table = *reinterpret_cast<void***>(gameContext);
        void* replacements[] = {reinterpret_cast<void*>(&drawIndexed),reinterpret_cast<void*>(&draw),
            reinterpret_cast<void*>(&drawIndexedInstanced),reinterpret_cast<void*>(&drawInstanced),
            reinterpret_cast<void*>(&drawAuto),reinterpret_cast<void*>(&drawIndexedIndirect),reinterpret_cast<void*>(&drawIndirect)};
        void** originals[] = {reinterpret_cast<void**>(&originalDrawIndexed),reinterpret_cast<void**>(&originalDraw),
            reinterpret_cast<void**>(&originalDrawIndexedInstanced),reinterpret_cast<void**>(&originalDrawInstanced),
            reinterpret_cast<void**>(&originalDrawAuto),reinterpret_cast<void**>(&originalDrawIndexedIndirect),reinterpret_cast<void**>(&originalDrawIndirect)};
        for (std::size_t i = 0; i < drawSlots.size(); ++i) {
            MEMORY_BASIC_INFORMATION owner{};
            std::array<wchar_t,32768> ownerPath{};
            if (VirtualQuery(table[drawSlots[i]],&owner,sizeof(owner))) {
                const auto length = GetModuleFileNameW(static_cast<HMODULE>(owner.AllocationBase),ownerPath.data(),static_cast<DWORD>(ownerPath.size()));
                if (length && length < ownerPath.size())
                    SKSE::log::info("Draw entry slot={} address={} module={}",drawSlots[i],table[drawSlots[i]],std::filesystem::path(ownerPath.data()).string());
            }
            const auto status = MH_CreateHook(table[drawSlots[i]],replacements[i],originals[i]);
            if (status != MH_OK) throw std::runtime_error("Create draw hook slot " + std::to_string(drawSlots[i]) + ": " + MH_StatusToString(status));
            drawTargets[i] = table[drawSlots[i]];
            const auto queued = MH_QueueEnableHook(drawTargets[i]);
            if (queued != MH_OK) throw std::runtime_error(std::string("Queue draw hook: ") + MH_StatusToString(queued));
        }
        const auto enabled = MH_ApplyQueued();
        if (enabled != MH_OK) throw std::runtime_error(std::string("Enable draw hooks: ") + MH_StatusToString(enabled));
        for (std::size_t i = 0; i < drawSlots.size(); ++i)
            std::memcpy(entryBytes[i].data(),drawTargets[i],entryBytes[i].size());
        originalPresent = patch(*reinterpret_cast<void**>(gameSwapChain),8,&present);
        installEngineContext(reinterpret_cast<ID3D11DeviceContext*>(renderer->data.context));
        deviceHooksInstalled = true;
        SKSE::log::info("Installed seven D3D11 draw-entry detours and DXGI frame boundary");
    } catch (...) {
        for (auto*& target : drawTargets) if (target) {
            MH_DisableHook(target); MH_RemoveHook(target); target = nullptr;
        }
        rollback(checkpoint); throw;
    }
}

using GeometryFn = void (*)(RE::BSShader*,RE::BSRenderPass*,std::uint32_t);
GeometryFn originalSetup{}, originalRestore{};
void setupGeometry(RE::BSShader* shader, RE::BSRenderPass* pass, std::uint32_t flags) {
    geometryHint={};
    originalSetup(shader,pass,flags);
    try {
        if (pass && pass->geometry) {
            const auto* geometry=pass->geometry;
            const auto& b=geometry->worldBound;
            // Only an active setup/restore scope, never historical geometry.
            const bool stationary=std::memcmp(&geometry->world,&geometry->previousWorld,sizeof(RE::NiTransform))==0;
            geometryHint={pass,{b.center.x,b.center.y,b.center.z,b.radius,stationary}};
            geometryHint.ripple=captureRippleGeometry(pass);
        }
        waterShaderOwner.store(shader,std::memory_order_release);
        tryDeviceHooks();
    }
    catch (const std::exception& e) { disabled.store(true); SKSE::log::error("Water hook initialization failed: {}",e.what()); }
}
void restoreGeometry(RE::BSShader* shader, RE::BSRenderPass* pass, std::uint32_t flags) {
    geometryHint={};
    originalRestore(shader,pass,flags);
}

using UpdateFn = void (*)(RE::PlayerCharacter*,float);
using JumpButtonFn = void (*)(RE::JumpHandler*,RE::ButtonEvent*,RE::PlayerControlsData*);
JumpButtonFn originalJumpButton{};
void jumpButton(RE::JumpHandler* handler, RE::ButtonEvent* event, RE::PlayerControlsData* data) {
    // Observe the engine-routed jump action, so rebound keyboard/controller
    // buttons work. Preserve the existing handler chain and event unmodified.
    if (event && event->IsDown()) noteFloeJumpRequest();
    originalJumpButton(handler,event,data);
}
UpdateFn originalUpdate{};
void update(RE::PlayerCharacter* player, float delta) {
    originalUpdate(player,delta);
    try { updateGame(delta); }
    catch (const std::exception& e) { disabled.store(true); resetFloe(); SKSE::log::error("Simulation disabled for this session: {}",e.what()); }
}
}
bool installHooks() {
    const auto checkpoint = patches.size();
    try {
        patches.reserve(patches.size() + 8);
        REL::Relocation<std::uintptr_t> water(RE::VTABLE_BSWaterShader[0]);
        REL::Relocation<std::uintptr_t> player(RE::VTABLE_PlayerCharacter[0]);
        originalSetup = patch(reinterpret_cast<void*>(water.address()),0x6,&setupGeometry);
        originalRestore = patch(reinterpret_cast<void*>(water.address()),0x7,&restoreGeometry);
        originalUpdate = patch(reinterpret_cast<void*>(player.address()),0xAD,&update);
        if (config.floeBobbing) {
            REL::Relocation<std::uintptr_t> jump(RE::VTABLE_JumpHandler[0]);
            originalJumpButton = patch(reinterpret_cast<void*>(jump.address()),0x4,&jumpButton);
            SKSE::log::info("Floe jump observer installed: forwards the engine jump handler unchanged");
        }
        SKSE::log::info("Installed BSWaterShader and PlayerCharacter virtual hooks");
        return true;
    } catch (const std::exception& e) {
        rollback(checkpoint); disabled.store(true); SKSE::log::error("Hook installation rolled back: {}",e.what()); return false;
    }
}
}
