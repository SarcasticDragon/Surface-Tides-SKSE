#include "PCH.hpp"
#include "Bridge.hpp"
#include "surfacetides/WaterSelection.hpp"
#include <chrono>

namespace st::plugin {
Config Config::read() {
    Config c;
    const auto path = std::filesystem::absolute("Data/SKSE/Plugins/SurfaceTides.ini").wstring();
    auto number = [&](const wchar_t* section, const wchar_t* key, float fallback) {
        wchar_t value[64]{};
        if (!GetPrivateProfileStringW(section,key,L"",value,64,path.c_str())) return fallback;
        wchar_t* end = nullptr;
        const float result = std::wcstof(value,&end);
        if (end == value || *end != 0 || !std::isfinite(result)) throw std::runtime_error("Invalid numeric value in SurfaceTides.ini");
        return result;
    };
    c.diagnostics = number(L"Diagnostics",L"LogStats",1) != 0;
    c.waterPassTrace = number(L"Diagnostics",L"WaterPassTrace",0) != 0;
    c.rippleTrace = number(L"Diagnostics",L"RippleTrace",0) != 0;
    c.debugView = static_cast<int>(std::clamp(number(L"Diagnostics",L"DebugView",0),0.0f,1.0f));
    c.allowENB = number(L"Compatibility",L"AllowENB",0) != 0;
    c.allowCS = number(L"Compatibility",L"AllowCS",0) != 0;
    c.hideAttachedFoam = number(L"Objects",L"HideAttachedFoam",0) != 0;
    c.hideIceDecals = number(L"Objects",L"HideIceDecals",0) != 0;
    // Preserve existing testers' opt-in; the explicit new key takes precedence.
    wchar_t explicitFloeMode[64]{};
    const bool hasFloeMode=GetPrivateProfileStringW(L"Objects",L"FloeBobbing",L"",explicitFloeMode,64,path.c_str())!=0;
    c.floeBobbing = number(L"Objects",hasFloeMode ? L"FloeBobbing" : L"FloeBobbingTest",0) != 0;
    c.floeCrestFollow = number(L"Objects",L"FloeCrestFollow",c.floeCrestFollow);
    c.floeExtraLift = number(L"Objects",L"FloeExtraLift",c.floeExtraLift);
    c.floeResponseSeconds = number(L"Objects",L"FloeResponseSeconds",c.floeResponseSeconds);
    c.restoreWaterConstants = number(L"Compatibility",L"RestoreWaterConstants",1) != 0;
    c.meshBounds = number(L"Experimental",L"MeshBounds",1) != 0;
    c.meshMotionVectors = number(L"Experimental",L"MeshMotionVectors",0) != 0;
    c.meshTwoSided = number(L"Experimental",L"MeshTwoSided",0) != 0;
    c.meshTessellationMax = static_cast<int>(std::clamp(number(L"Experimental",L"MeshTessellationMax",8),8.0f,16.0f));
    // New explicit opt-in: an old test INI must not silently select native-water integration.
    c.enbMeshInput = number(L"Experimental",L"ENBWaterIntegration",0) != 0;
    wchar_t legacyMeshMode[64]{};
    if (GetPrivateProfileStringW(L"Compatibility",L"ENBMeshInput",L"",legacyMeshMode,64,path.c_str()))
        SKSE::log::warn("Legacy [Compatibility] ENBMeshInput is ignored. Experimental integration now requires [Experimental] ENBWaterIntegration=1; use the supplied current INI.");
    c.enabled = number(L"General",L"Enabled",1) != 0;
    c.tessellation = number(L"Rendering",L"Tessellation",1) != 0;
    c.terrainMask = number(L"Simulation",L"TerrainMask",1) != 0;
    c.simulation.resolution = static_cast<int>(std::clamp(number(L"Simulation",L"Resolution",192),16.0f,512.0f));
    c.simulation.spacing = number(L"Simulation",L"Spacing",20);
    c.simulation.waveSpeed = number(L"Simulation",L"WaveSpeed",210);
    c.simulation.dispersion = number(L"Simulation",L"Dispersion",180000);
    c.simulation.damping = number(L"Simulation",L"Damping",0.32f);
    c.simulation.wind = number(L"Simulation",L"Wind",5);
    c.simulation.gustStrength = std::clamp(number(L"Simulation",L"GustStrength",1.0f),0.0f,4.0f);
    c.simulation.maxHeight = number(L"Simulation",L"MaxHeight",24);
    c.simulation.spongeCells = std::min(16,c.simulation.resolution / 4);
    c.tessellationMax = std::clamp(number(L"Rendering",L"TessellationMax",c.tessellationMax),1.0f,64.0f);
    c.normalStrength = std::clamp(number(L"Rendering",L"NormalStrength",c.normalStrength),0.0f,3.0f);
    c.displacementStrength = std::clamp(number(L"Rendering",L"DisplacementStrength",c.displacementStrength),0.0f,2.0f);
    c.interactionStrength = std::clamp(number(L"Interaction",L"Strength",4),0.0f,20.0f);
    c.interactionRadius = std::clamp(number(L"Interaction",L"RadiusScale",1.5f),0.5f,4.0f);
    c.tessellationSpacing = std::clamp(number(L"Rendering",L"TessellationSpacing",20),8.0f,128.0f);
    c.maxActors = static_cast<int>(std::clamp(number(L"Interaction",L"MaxActors",48),1.0f,128.0f));
    c.terrainQueriesPerUpdate = static_cast<int>(std::clamp(number(L"Simulation",L"TerrainQueriesPerUpdate",96),1.0f,512.0f));
    c.validate();
    return c;
}

namespace {
std::unique_ptr<Surface> surface;
WaterSelection waterSelection;
ContactTracker contacts;
std::vector<Impulse> impulses;
std::uint64_t sequence = 0, epoch = 0;
RE::FormID area = 0;
std::size_t terrainCursor = 0;
bool wasActive = false;
Tuning gameTuning;
std::uint64_t gameRevision = 0;
std::uint64_t intervalImpulses = 0;
auto nextStats = std::chrono::steady_clock::time_point{};

void publishInactive() {
    waterSelection.reset();
    resetFloe(true);
    if (!wasActive) return;
    auto f = std::make_shared<Frame>();
    f->sequence = ++sequence; f->epoch = ++epoch;
    exchange.publish(f); wasActive = false;
    if (config.diagnostics) SKSE::log::info("Simulation inactive: preview disabled or player/cell/3D/water unavailable");
    contacts.reset();
}

float queryWater(RE::TESObjectCELL* playerCell, RE::TESWorldSpace* world, Vec2 xy, float z) {
    auto* tes = RE::TES::GetSingleton();
    const float unavailable = -std::numeric_limits<float>::infinity();
    if (!tes || !playerCell) return unavailable;
    const RE::NiPoint3 position{xy.x,xy.y,z};
    auto* cell = playerCell->IsInteriorCell() ? playerCell : tes->GetCell(position);
    if (!cell || !cell->IsAttached()) return unavailable;
    if (!playerCell->IsInteriorCell() && (!world || !cell->IsExteriorCell() ||
        cell->GetRuntimeData().worldSpace != world)) return unavailable;
    return tes->GetWaterHeight(position,cell);
}

void refreshTerrain(RE::TESObjectCELL* playerCell) {
    auto* tes = RE::TES::GetSingleton();
    if (!tes || !playerCell || !surface) return;
    const int n = surface->settings().resolution;
    constexpr int block = 4;
    const int coarse = (n + block - 1) / block;
    std::vector<std::uint8_t> mask(surface->wetMask().begin(),surface->wetMask().end());
    const auto origin = surface->origin();
    const float dx = surface->settings().spacing;
    for (int query = 0; query < gameTuning.terrainQueriesPerUpdate; ++query) {
        const auto index = terrainCursor++ % (std::size_t(coarse) * coarse);
        const int x0 = static_cast<int>(index % coarse) * block;
        const int y0 = static_cast<int>(index / coarse) * block;
        const RE::NiPoint3 position{origin.x + (float(x0) + 1.5f) * dx,
                                    origin.y + (float(y0) + 1.5f) * dx,surface->level()};
        auto* cell = playerCell->IsInteriorCell() ? playerCell : tes->GetCell(position);
        bool wet = false;
        if (cell && cell->IsAttached()) {
            const float water = tes->GetWaterHeight(position,cell);
            wet = std::isfinite(water) && std::abs(water - surface->level()) < 2;
            if (wet && !cell->IsInteriorCell()) {
                float ground{};
                wet = tes->GetLandHeight(position,ground) && ground < surface->level() - 1;
            }
        }
        for (int y = y0; y < std::min(n,y0 + block); ++y)
            for (int x = x0; x < std::min(n,x0 + block); ++x) mask[std::size_t(y) * n + x] = wet;
    }
    surface->setWetMask(mask);
}
}

void updateGame(float delta) {
    const auto requested = tuning.read();
    if (requested.revision != gameRevision) {
        const bool rebuild = needsSurfaceReset(gameTuning,requested.values);
        // Commit on the simulation thread. No GUI callback mutates Surface or game objects.
        if (surface && rebuild) {
            auto replacement = std::make_unique<Surface>(requested.values.simulation);
            surface = std::move(replacement);
            resetRequested.store(true);
        } else if (surface && surface->settings() != requested.values.simulation)
            surface->retune(requested.values.simulation);
        gameTuning = requested.values;
        gameRevision = requested.revision;
        appliedTuningRevision.store(gameRevision);
    }
    const auto& live = gameTuning;
    if (disabled.load() || !config.enabled || !live.previewEnabled) { updateAttachedFoam(false); publishInactive(); return; }
    auto* player = RE::PlayerCharacter::GetSingleton();
    auto* ui = RE::UI::GetSingleton();
    if (!player || !player->GetParentCell() || !player->Is3DLoaded()) { updateAttachedFoam(false); publishInactive(); return; }
    if (ui && ui->GameIsPaused()) return;
    updateAttachedFoam(true);
    const auto p = player->GetPosition();
    if (!std::isfinite(delta) || delta <= 0) return;
    auto* world = player->GetWorldspace();
    const auto currentArea = world ? world->GetFormID() : player->GetParentCell()->GetFormID();
    const bool explicitReset = resetRequested.exchange(false);
    if (explicitReset || !wasActive || area != currentArea) waterSelection.reset();
    const float span = live.simulation.spacing * float(live.simulation.resolution);
    const float actorWater = player->GetWaterHeight();
    const auto selected = waterSelection.select(currentArea,{p.x,p.y},p.z,actorWater,span * 0.45f,
        [&](Vec2 xy, float z) { return queryWater(player->GetParentCell(),world,xy,z); });
    if (!selected) { publishInactive(); return; }
    const float level = selected->level;
    bool reset = explicitReset || !wasActive || area != currentArea;
    if (!surface) { surface = std::make_unique<Surface>(live.simulation); reset = true; }
    if (std::abs(surface->level() - level) >= 2) reset = true;
    const auto oldOrigin = surface->origin();
    if (std::hypot(p.x - (oldOrigin.x + span * 0.5f),p.y - (oldOrigin.y + span * 0.5f)) > span * 0.45f) reset = true;
    if (reset) {
        surface->reset({p.x,p.y},level); contacts.reset(); terrainCursor = 0;
        area = currentArea; ++epoch;
        if (live.terrainMask) surface->setWetMask(std::vector<std::uint8_t>(surface->cells().size(),0));
    } else {
        // Scroll in four-cell increments to limit CPU copies and terrain-cache churn.
        const float quantum = live.simulation.spacing * 4;
        surface->recenter({std::floor(p.x / quantum) * quantum,std::floor(p.y / quantum) * quantum});
    }
    if (live.terrainMask) refreshTerrain(player->GetParentCell());
    else surface->setWetMask(std::vector<std::uint8_t>(surface->cells().size(),1));

    std::vector<Contact> nearby;
    nearby.reserve(live.maxActors);
    auto capture = [&](RE::Actor* actor) {
        if (!actor || !actor->Is3DLoaded() || nearby.size() >= static_cast<std::size_t>(live.maxActors)) return;
        const auto pos = actor->GetPosition();
        if (std::hypot(pos.x - p.x,pos.y - p.y) > span * 0.45f) return;
        const float water = actor->GetWaterHeight();
        if (!std::isfinite(water) || std::abs(water - level) >= 2) return;
        nearby.push_back({actor->GetFormID(),{pos.x,pos.y},pos.z,water,
                          std::clamp(25.0f * actor->GetScale(),12.0f,80.0f),actor->AsActorState()->IsSwimming()});
    };
    capture(player);
    if (auto* processes = RE::ProcessLists::GetSingleton()) {
        for (const auto& handle : processes->highActorHandles) {
            const auto actor = handle.get();
            if (actor && actor.get() != player) capture(actor.get());
        }
    }
    contacts.update(nearby,delta,impulses,live.interactionStrength,live.interactionRadius);
    intervalImpulses += impulses.size();
    for (const auto& impulse : impulses) surface->addImpulse(impulse);
    surface->advance(delta,16);

    auto frame = std::make_shared<Frame>();
    frame->sequence = ++sequence; frame->epoch = epoch;
    frame->origin = surface->origin(); frame->spacing = live.simulation.spacing;
    frame->spongeCells = live.simulation.spongeCells;
    frame->level = level; frame->resolution = live.simulation.resolution; frame->active = true;
    frame->texels.resize(surface->cells().size());
    const auto values = surface->cells(); const auto wet = surface->wetMask();
    const int n = live.simulation.resolution;
    const float inv2dx = 0.5f / live.simulation.spacing;
    for (int y = 0; y < n; ++y) for (int x = 0; x < n; ++x) {
        const auto i = std::size_t(y) * n + x;
        const float h = values[i].height;
        const float left = x && wet[i - 1] ? values[i - 1].height : h;
        const float right = x + 1 < n && wet[i + 1] ? values[i + 1].height : h;
        const float down = y && wet[i - n] ? values[i - n].height : h;
        const float up = y + 1 < n && wet[i + n] ? values[i + n].height : h;
        frame->texels[i] = {h,(right - left) * inv2dx,(up - down) * inv2dx,wet[i] ? 1.0f : 0.0f};
    }
    if (config.diagnostics && std::chrono::steady_clock::now() >= nextStats) {
        nextStats = std::chrono::steady_clock::now() + std::chrono::seconds(5);
        std::size_t wetCount = 0;
        float maxHeight = 0, maxVelocity = 0, maxSlope = 0;
        for (std::size_t i = 0; i < values.size(); ++i) {
            wetCount += wet[i] != 0;
            maxHeight = std::max(maxHeight,std::abs(values[i].height));
            maxVelocity = std::max(maxVelocity,std::abs(values[i].velocity));
            maxSlope = std::max(maxSlope,std::hypot(frame->texels[i].slopeX,frame->texels[i].slopeY));
        }
        const auto& d = surface->diagnostics();
        SKSE::log::info("Simulation seq={} epoch={} cell={:08X} player=({:.1f},{:.1f},{:.1f}) water={:.2f} origin=({:.1f},{:.1f}) wet={}/{} maxHeight={:.4f} maxVelocity={:.4f} maxSlope={:.5f} actors={} impulsesSinceReport={} steps={} clipped={} droppedSeconds={:.3f}",
            sequence,epoch,player->GetParentCell()->GetFormID(),p.x,p.y,p.z,level,frame->origin.x,frame->origin.y,
            wetCount,values.size(),maxHeight,maxVelocity,maxSlope,nearby.size(),intervalImpulses,d.steps,d.clippedCells,d.droppedSeconds);
        const char* waterSource = selected->source == WaterSource::actor ? "actor" :
            selected->source == WaterSource::spatial ? "spatial" : "retained";
        SKSE::log::info("Water selection source={} actorWater={:.2f} selectedWater={:.2f}",waterSource,actorWater,level);
        intervalImpulses = 0;
    }
    // Consume this exact field and applied tuning on the game thread. No stale
    // exchange read or independent menu snapshot enters the floe calculation.
    updateFloe(*frame,live,currentArea,delta);
    exchange.publish(frame); wasActive = true;
}
}
