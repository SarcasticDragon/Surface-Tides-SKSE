#include "PCH.hpp"
#include "Bridge.hpp"
#include <charconv>
#include <limits>
#include "../../vendor/SKSEMenuFramework/SKSEMenuFramework.h"

namespace st::plugin {
namespace ui = ImGuiMCP;

void saveTuning(const Tuning& values) {
    values.validate();
    const auto target = std::filesystem::absolute("Data/SKSE/Plugins/SurfaceTides.ini");
    auto temporary = target;
    temporary += L".menu-tmp";
    std::filesystem::create_directories(target.parent_path());
    // Stage edits in the same directory. A failed write leaves the original INI intact.
    // Profile APIs preserve other sections/keys and support existing UTF-16 INIs too.
    try {
        if (std::filesystem::exists(target))
            std::filesystem::copy_file(target,temporary,std::filesystem::copy_options::overwrite_existing);
        else {
            std::ofstream empty(temporary,std::ios::binary | std::ios::trunc);
            if (!empty) throw std::runtime_error("Cannot create settings file");
        }
        auto write = [&](const wchar_t* section, const wchar_t* key, auto value) {
            std::array<char,64> text{};
            auto result = std::to_chars(text.data(),text.data()+text.size(),value);
            if (result.ec != std::errc{}) throw std::runtime_error("Cannot format settings value");
            const std::wstring wide(text.data(),result.ptr);
            if (!WritePrivateProfileStringW(section,key,wide.c_str(),temporary.c_str()))
                throw std::runtime_error("Cannot write settings; Windows error " + std::to_string(GetLastError()));
        };
        const auto& s = values.simulation;
        write(L"Simulation",L"Resolution",s.resolution);
        write(L"Simulation",L"Spacing",s.spacing);
        write(L"Simulation",L"WaveSpeed",s.waveSpeed);
        write(L"Simulation",L"Dispersion",s.dispersion);
        write(L"Simulation",L"Damping",s.damping);
        write(L"Simulation",L"Wind",s.wind);
        write(L"Simulation",L"GustStrength",s.gustStrength);
        write(L"Simulation",L"MaxHeight",s.maxHeight);
        write(L"Simulation",L"TerrainMask",int(values.terrainMask));
        write(L"Simulation",L"TerrainQueriesPerUpdate",values.terrainQueriesPerUpdate);
        write(L"Interaction",L"MaxActors",values.maxActors);
        write(L"Interaction",L"Strength",values.interactionStrength);
        write(L"Interaction",L"RadiusScale",values.interactionRadius);
        write(L"Rendering",L"TessellationMax",values.tessellationMax);
        write(L"Rendering",L"TessellationSpacing",values.tessellationSpacing);
        write(L"Rendering",L"NormalStrength",values.normalStrength);
        write(L"Rendering",L"DisplacementStrength",values.displacementStrength);
        write(L"Diagnostics",L"DebugView",values.debugView);
        write(L"Objects",L"FloeCrestFollow",values.floeCrestFollow);
        write(L"Objects",L"FloeExtraLift",values.floeExtraLift);
        write(L"Objects",L"FloeResponseSeconds",values.floeResponseSeconds);
        // Unlike a key write, the cache-flush form returns zero even when it flushes
        // successfully. Do not apply the ordinary BOOL success check here.
        // https://learn.microsoft.com/windows/win32/api/winbase/nf-winbase-writeprivateprofilestringw
        WritePrivateProfileStringW(nullptr,nullptr,nullptr,temporary.c_str());
        if (!MoveFileExW(temporary.c_str(),target.c_str(),MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
            throw std::runtime_error("Cannot replace SurfaceTides.ini; Windows error " + std::to_string(GetLastError()));
        WritePrivateProfileStringW(nullptr,nullptr,nullptr,target.c_str());
        SKSE::log::info("Live tuning saved to {} (startup/compatibility settings preserved)",target.string());
    } catch (...) {
        std::error_code ignored;
        std::filesystem::remove(temporary,ignored);
        throw;
    }
}

namespace {
Tuning draft;
int gridResolution = 192;
float gridSpacing = 20;
bool gridTerrain = true;
std::string status = "Changes are temporary until you choose Save tuning to INI.";
constexpr auto clampInput = ui::ImGuiSliderFlags_AlwaysClamp;

void syncGrid() {
    gridResolution = draft.simulation.resolution;
    gridSpacing = draft.simulation.spacing;
    gridTerrain = draft.terrainMask;
}
void submit(const char* message) {
    tuning.publish(draft);
    status = message;
}
void help(const char* text) {
    if (ui::IsItemHovered() && ui::BeginTooltip()) {
        ui::TextUnformatted(text);
        ui::EndTooltip();
    }
}
bool slider(const char* name, float& value, float lo, float hi, const char* description,
    const char* format = "%.2f", bool logarithmic = false) {
    const bool changed = ui::SliderFloat(name,&value,lo,hi,format,
        clampInput | (logarithmic ? ui::ImGuiSliderFlags_Logarithmic : 0));
    help(description);
    return changed;
}

void renderBody() {
    ui::TextUnformatted("Surface Tides 1.0.2 - live tuning / floating ice");
    ui::TextWrapped("Use the framework's Options / Resume Game to watch waves while this panel is open, or close the menu to resume. Hover a setting for its description.");
    if (disabled.load()) ui::TextWrapped("Surface Tides is inactive because a compatibility check or runtime error stopped it. See SurfaceTides.log. Changing tuning does not bypass that check.");
    else if (!config.enabled) ui::TextWrapped("General.Enabled=0 at startup. Set it to 1 in the INI and restart to enable the simulation.");
    if (config.enbMeshInput) ui::TextWrapped("Experimental ENB integration is active. Some shading controls below belong to the standalone water renderer.");

    bool changed = ui::Checkbox("Preview Surface Tides (this session)",&draft.previewEnabled);
    help("Uncheck to compare with native water. Re-enabling starts a fresh local simulation. This does not change General.Enabled.");

    if (ui::CollapsingHeader("Waves and wakes",ui::ImGuiTreeNodeFlags_DefaultOpen)) {
        changed |= slider("Wind",draft.simulation.wind,0,50,"Continuous surface forcing. Zero stops new idle forcing; existing waves keep propagating.");
        changed |= slider("Gust strength",draft.simulation.gustStrength,0,4,"Localized idle crests and troughs. Requires nonzero Wind.");
        changed |= slider("Wave speed",draft.simulation.waveSpeed,1,1000,"Propagation speed in world units per second. Very high values increase solver work.","%.1f");
        changed |= slider("Dispersion",draft.simulation.dispersion,0,1e8f,"Capillary stiffness: changes how wavelengths travel. High values can increase solver work substantially.","%.0f",true);
        changed |= slider("Damping",draft.simulation.damping,0,10,"How quickly wave energy decays. Lower values give longer-lived wakes and interference.","%.3f");
        changed |= slider("Maximum height",draft.simulation.maxHeight,0.1f,128,"Simulation height limiter in world units, before Displacement strength. Frequent limiting can flatten crests.","%.1f");
        changed |= slider("Wake strength",draft.interactionStrength,0,20,"Character movement and entry forcing. Zero disables new wakes; old waves decay naturally.");
        changed |= slider("Wake radius scale",draft.interactionRadius,0.5f,4,"Width of character disturbances. Larger values produce broader wakes.");
        changed |= ui::SliderInt("Maximum actors",&draft.maxActors,1,128,"%d",clampInput);
        help("Maximum nearby loaded actors considered, including the player. Higher counts can cost more CPU time.");
    }
    if (ui::CollapsingHeader("Appearance",ui::ImGuiTreeNodeFlags_DefaultOpen)) {
        changed |= slider("Displacement strength",draft.displacementStrength,0,2,"Scales rendered vertical displacement. Zero leaves the simulated field running for comparison.");
        changed |= slider("Normal strength",draft.normalStrength,0,3,"Strength of simulated surface slopes in shading; does not add geometric height.");
        changed |= slider("Tessellation spacing",draft.tessellationSpacing,8,128,"Target edge length in world units. Lower values add geometry and GPU cost.","%.1f");
        changed |= slider("Tessellation maximum",draft.tessellationMax,1,64,"Maximum subdivision factor per edge. Higher values can increase GPU cost.","%.0f");
        bool debug = draft.debugView != 0;
        if (ui::Checkbox("Diagnostic water colors",&debug)) { draft.debugView = debug ? 1 : 0; changed = true; }
        help("Diagnostic coverage colors in the standalone shader. Leave off for appearance testing.");
        if (!config.tessellation) ui::TextWrapped("Rendering.Tessellation=0 at startup. Density controls require that setting to be enabled and a restart.");
    }
    if (ui::CollapsingHeader("Simulation grid and terrain")) {
        ui::TextWrapped("Grid changes take effect only with Apply grid and reset the local waves. No game restart is needed.");
        ui::SliderInt("Grid resolution",&gridResolution,16,512,"%d",clampInput);
        help("Samples along each axis. Cost scales roughly with resolution squared; higher values cover more water at the same spacing.");
        slider("Grid spacing",gridSpacing,4,128,"Distance between simulation samples. Smaller spacing resolves finer waves but covers less water and can cost more CPU time.","%.1f");
        ui::Checkbox("Terrain mask",&gridTerrain);
        help("Confines simulation to sampled water and shore boundaries.");
        if (ui::Button("Apply grid (resets waves)")) {
            draft.simulation.resolution = gridResolution;
            draft.simulation.spacing = gridSpacing;
            draft.simulation.spongeCells = std::min(16,gridResolution / 4);
            draft.terrainMask = gridTerrain;
            changed = true;
        }
        ui::SameLine();
        if (ui::Button("Discard grid edits")) syncGrid();
        changed |= ui::SliderInt("Terrain queries per update",&draft.terrainQueriesPerUpdate,1,512,"%d",clampInput);
        help("Higher values refresh shoreline masking faster at greater CPU cost. This setting applies live.");
        ui::Text("Selected grid: %d x %d, spacing %.1f",draft.simulation.resolution,draft.simulation.resolution,draft.simulation.spacing);
        ui::Text("Solver limit: %.1f fixed steps/second",1.0 / draft.simulation.timestep());
    }
    if (ui::CollapsingHeader("Floating ice",ui::ImGuiTreeNodeFlags_DefaultOpen)) {
        ui::TextWrapped("Compatibility: Ice is Slick is currently incompatible with ice bobbing.");
        ui::TextWrapped("Controls nearby icefloes01, icefloessolid01 and icefloessolid02 placements within the local simulation. Separate chunks within one mesh move together. Crest following adds lift to reduce waves breaking through the ice.");
        if (!config.floeBobbing) ui::TextWrapped("Enable [Objects] FloeBobbing=1 in the INI and restart to activate floating ice.");
        changed |= slider("Crest following",draft.floeCrestFollow,0,1,"0 follows the average wave height; 1 lifts toward the higher crests beneath the footprint. Does not amplify downward motion.");
        changed |= slider("Extra floe lift",draft.floeExtraLift,0,32,"Additional clearance in world units when crest following is active. Fades away as the waves flatten. Higher values can expose more of the ice's sides.");
        changed |= slider("Floe response (seconds)",draft.floeResponseSeconds,0,2,"Lower values follow incoming crests faster. With crest following active, descent takes three times this response. Motion speed and collision checks still apply.","%.2f");
        if (ui::Button("Original floe motion")) {
            draft.floeCrestFollow=0; draft.floeExtraLift=0; draft.floeResponseSeconds=0.35f; changed=true;
        }
        ui::SameLine();
        if (ui::Button("Crest-following defaults")) {
            const Tuning defaults;
            draft.floeCrestFollow=defaults.floeCrestFollow; draft.floeExtraLift=defaults.floeExtraLift;
            draft.floeResponseSeconds=defaults.floeResponseSeconds; changed=true;
        }
    }
    if (changed) submit("Live tuning updated. Unsaved grid edits are excluded until Apply grid.");

    ui::Separator();
    if (ui::Button("Save tuning to INI")) {
        saveTuning(draft);
        status = "Tuning saved. Preview toggle and unapplied grid edits were not saved; startup settings were preserved.";
    }
    ui::SameLine();
    if (ui::Button("Reload tuning from INI")) {
        Tuning loaded = Config::read(); // read into a temporary; invalid files cannot damage live state
        loaded.previewEnabled = draft.previewEnabled;
        draft = loaded; syncGrid();
        submit("INI tuning reloaded. Startup/compatibility settings still require a game restart.");
        SKSE::log::info("Live tuning reloaded from INI");
    }
    if (ui::Button("Restore session-start tuning")) {
        draft = static_cast<const Tuning&>(config); syncGrid();
        submit("Session-start tuning restored. Save if you want to persist it.");
    }
    ui::SameLine();
    if (ui::Button("Reset local waves")) {
        resetRequested.store(true);
        status = "Wave reset requested. It takes effect when gameplay resumes.";
    }
    ui::TextWrapped("%s",status.c_str());
    const auto requested = tuning.read();
    if (config.enabled && !disabled.load() && appliedTuningRevision.load() < requested.revision)
        ui::TextUnformatted("Simulation update pending; resume gameplay to apply.");
    if (const auto frame = exchange.read(); frame && frame->active)
        ui::Text("Simulation frame: %llu | %d x %d",static_cast<unsigned long long>(frame->sequence),frame->resolution,frame->resolution);

    if (ui::CollapsingHeader("Startup settings (read only; edit INI and restart)")) {
        ui::TextWrapped("These values reflect this session. Save/Reload tuning leaves them unchanged. Keep ENB master water OFF, or keep the supplied CS water override installed with CS water features OFF, for coexistence.");
        ui::Text("[General] Enabled=%d",int(config.enabled));
        ui::Text("[Objects] HideAttachedFoam=%d",int(config.hideAttachedFoam));
        ui::Text("[Objects] HideIceDecals=%d",int(config.hideIceDecals));
        ui::Text("[Objects] FloeBobbing=%d (three reviewed ice models)",int(config.floeBobbing));
        ui::Text("[Rendering] Tessellation=%d",int(config.tessellation));
        ui::Text("[Compatibility] AllowENB=%d AllowCS=%d RestoreWaterConstants=%d",int(config.allowENB),int(config.allowCS),int(config.restoreWaterConstants));
        if (communityShadersActive)
            ui::TextWrapped("CS coexistence: keep Water shader replacement, Unified Water and Water Effects disabled. Restart after CS water configuration changes.");
        ui::Text("[Experimental] ENBWaterIntegration=%d",int(config.enbMeshInput));
        ui::Text("MeshBounds=%d MeshMotionVectors=%d MeshTwoSided=%d MeshTessellationMax=%d",int(config.meshBounds),int(config.meshMotionVectors),int(config.meshTwoSided),config.meshTessellationMax);
        ui::Text("[Diagnostics] LogStats=%d WaterPassTrace=%d RippleTrace=%d",int(config.diagnostics),int(config.waterPassTrace),int(config.rippleTrace));
    }
}
void __stdcall renderMenu() {
    try { renderBody(); }
    catch (const std::exception& e) {
        status = std::string("Settings operation failed: ") + e.what();
        draft = tuning.read().values; syncGrid();
        SKSE::log::error("Menu settings operation failed: {}",e.what());
        ui::TextWrapped("%s",status.c_str());
    }
}
}

void registerMenu() {
    // IsInstalled() only checks for a file. Require a loaded module and every export we call.
    const auto module = GetModuleHandleW(L"SKSEMenuFramework.dll");
    if (!module) { SKSE::log::info("SKSE Menu Framework not loaded; INI-only configuration remains available"); return; }
    for (const auto* symbol : {"AddSectionItem","GetMenuFrameworkVersion","igTextUnformatted","igTextV","igTextWrappedV",
        "igCheckbox","igSliderFloat","igSliderInt","igCollapsingHeader_TreeNodeFlags","igButton","igSameLine",
        "igSeparator","igIsItemHovered","igBeginTooltip","igEndTooltip"}) {
        if (!GetProcAddress(module,symbol)) {
            SKSE::log::warn("SKSE Menu Framework export {} missing; optional menu not registered",symbol); return;
        }
    }
    const auto version = SKSEMenuFramework::GetMenuFrameworkVersion();
    if (version < 3.0f) { SKSE::log::warn("SKSE Menu Framework 3.x required; detected {}",version); return; }
    draft = tuning.read().values; syncGrid();
    SKSEMenuFramework::SetSection("Surface Tides");
    SKSEMenuFramework::AddSectionItem("Settings",renderMenu);
    SKSE::log::info("SKSE Menu Framework {}: registered Surface Tides/Settings; live tuning enabled",version);
}
}
