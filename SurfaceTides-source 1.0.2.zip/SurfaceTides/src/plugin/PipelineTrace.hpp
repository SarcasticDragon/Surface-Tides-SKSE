#pragma once
#include "PCH.hpp"
#include "surfacetides/ForwardedDraw.hpp"

namespace st::plugin {
// Public D3D11 metadata only. No shader bytecode, resource contents or ENB code.
struct ObservedWaterDraw { st::DrawSignature signature; bool canonical{}; };
std::uint64_t startWaterTrace(UINT vs, UINT ps, const st::DrawSignature& expected,
    bool mismatch = false) noexcept;
void traceUnmatchedHistory(std::uint64_t id, const std::array<ObservedWaterDraw,8>& calls, UINT count) noexcept;
void traceWaterPass(ID3D11DeviceContext* context, std::uint64_t id, UINT ordinal,
    const st::DrawSignature& actual, bool canonical, bool matched) noexcept;
void traceWaterResult(std::uint64_t id, UINT ordinal, bool changed) noexcept;
void finishWaterTrace(std::uint64_t id, UINT nativeCalls, bool matched) noexcept;
}
