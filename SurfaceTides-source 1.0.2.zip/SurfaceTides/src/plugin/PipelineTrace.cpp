#include "PipelineTrace.hpp"
#include "Bridge.hpp"
#include <chrono>
#include <sstream>

namespace st::plugin {
namespace {
constexpr UINT maxPasses = 8;
// Sampling uses bounded thread-local storage. It never changes forwarding policy.
struct SampleSlot { std::uint64_t key{}; bool occupied{}; std::chrono::steady_clock::time_point next{}; };
// Independent budgets keep frequent ordinary draws from consuming the samples
// needed to diagnose a rare changed/cancelled draw.
thread_local std::array<std::array<SampleSlot,32>,2> samplePools;
std::atomic<std::uint64_t> nextId{1};

std::string signature(const st::DrawSignature& s) {
    return fmt::format("kind={} args=[{},{},{},{},{}] topology={}",s.kind,
        s.arguments[0],s.arguments[1],s.arguments[2],s.arguments[3],s.arguments[4],s.topology);
}

void resource(std::ostream& out, ID3D11View* view) {
    ComPtr<ID3D11Resource> r;
    view->GetResource(&r);
    out << " resource=" << static_cast<void*>(r.Get());
    if (!r) return;
    D3D11_RESOURCE_DIMENSION type{}; r->GetType(&type);
    out << " type=" << unsigned(type);
    if (type == D3D11_RESOURCE_DIMENSION_TEXTURE2D) {
        ComPtr<ID3D11Texture2D> t;
        if (SUCCEEDED(r.As(&t))) {
            D3D11_TEXTURE2D_DESC d{}; t->GetDesc(&d);
            out << " size=" << d.Width << 'x' << d.Height << " array=" << d.ArraySize
                << " mips=" << d.MipLevels << " samples=" << d.SampleDesc.Count
                << " bind=" << d.BindFlags;
        }
    }
}

std::string outputs(ID3D11DeviceContext* c) {
    std::ostringstream out;
    std::array<ID3D11RenderTargetView*,8> raw{};
    ComPtr<ID3D11DepthStencilView> depth;
    c->OMGetRenderTargets(static_cast<UINT>(raw.size()),raw.data(),&depth);
    // Getters AddRef. Adopt every reference before allocations/formatting can throw.
    std::array<ComPtr<ID3D11RenderTargetView>,8> targets;
    for (UINT i=0;i<raw.size();++i) targets[i].Attach(raw[i]);
    unsigned mask=0;
    for (UINT i=0;i<targets.size();++i) if (targets[i]) {
        mask |= 1u << i;
        D3D11_RENDER_TARGET_VIEW_DESC d{}; targets[i]->GetDesc(&d);
        out << " RT" << i << "{view=" << static_cast<void*>(targets[i].Get())
            << " format=" << unsigned(d.Format) << " dim=" << unsigned(d.ViewDimension);
        resource(out,targets[i].Get()); out << '}';
    }
    out << " RTmask=" << mask;
    if (depth) {
        D3D11_DEPTH_STENCIL_VIEW_DESC d{}; depth->GetDesc(&d);
        out << " DSV{format=" << unsigned(d.Format) << " dim=" << unsigned(d.ViewDimension)
            << " flags=" << d.Flags;
        resource(out,depth.Get()); out << '}';
    } else out << " DSV=null";
    ComPtr<ID3D11BlendState> blend;
    FLOAT factor[4]{}; UINT sampleMask{}; c->OMGetBlendState(&blend,factor,&sampleMask);
    out << " blend=" << static_cast<void*>(blend.Get()) << " sampleMask=" << sampleMask;
    if (blend) {
        D3D11_BLEND_DESC d{}; blend->GetDesc(&d);
        out << " independent=" << d.IndependentBlendEnable << " alphaToCoverage=" << d.AlphaToCoverageEnable;
        for (UINT i=0;i<8;++i) if (mask & (1u<<i)) {
            const auto& b=d.RenderTarget[d.IndependentBlendEnable ? i : 0];
            out << " B" << i << "[" << b.BlendEnable << ',' << unsigned(b.RenderTargetWriteMask)
                << ',' << unsigned(b.SrcBlend) << ',' << unsigned(b.DestBlend) << ',' << unsigned(b.BlendOp)
                << ',' << unsigned(b.SrcBlendAlpha) << ',' << unsigned(b.DestBlendAlpha) << ',' << unsigned(b.BlendOpAlpha) << ']';
        }
    }
    ComPtr<ID3D11DepthStencilState> ds; UINT ref{}; c->OMGetDepthStencilState(&ds,&ref);
    out << " depthState=" << static_cast<void*>(ds.Get()) << " stencilRef=" << ref;
    if (ds) {
        D3D11_DEPTH_STENCIL_DESC d{}; ds->GetDesc(&d);
        out << " depth[" << d.DepthEnable << ',' << unsigned(d.DepthWriteMask) << ',' << unsigned(d.DepthFunc)
            << "] stencil[" << d.StencilEnable << ',' << unsigned(d.StencilReadMask) << ',' << unsigned(d.StencilWriteMask) << ']';
    }
    ComPtr<ID3D11RasterizerState> rs; c->RSGetState(&rs);
    if (rs) {
        D3D11_RASTERIZER_DESC d{}; rs->GetDesc(&d);
        out << " raster[" << unsigned(d.FillMode) << ',' << unsigned(d.CullMode)
            << ',' << d.ScissorEnable << ',' << d.DepthClipEnable << ']';
    }
    std::array<D3D11_VIEWPORT,D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE> views{};
    UINT count=static_cast<UINT>(views.size()); c->RSGetViewports(&count,views.data());
    for (UINT i=0;i<count && i<views.size();++i) {
        const auto& v=views[i]; out << " VP" << i << '[' << v.TopLeftX << ',' << v.TopLeftY
            << ',' << v.Width << ',' << v.Height << ',' << v.MinDepth << ',' << v.MaxDepth << ']';
    }
    return out.str();
}

std::string inputs(ID3D11DeviceContext* c) {
    std::ostringstream out;
    ComPtr<ID3D11VertexShader> vs; ComPtr<ID3D11PixelShader> ps;
    ComPtr<ID3D11HullShader> hs; ComPtr<ID3D11DomainShader> ds; ComPtr<ID3D11GeometryShader> gs;
    UINT vc{},pc{};
    c->VSGetShader(&vs,nullptr,&vc); c->PSGetShader(&ps,nullptr,&pc);
    c->HSGetShader(&hs,nullptr,nullptr); c->DSGetShader(&ds,nullptr,nullptr); c->GSGetShader(&gs,nullptr,nullptr);
    out << "VS=" << static_cast<void*>(vs.Get()) << " PS=" << static_cast<void*>(ps.Get())
        << " HS=" << static_cast<void*>(hs.Get()) << " DS=" << static_cast<void*>(ds.Get())
        << " GS=" << static_cast<void*>(gs.Get()) << " classes=" << vc << ',' << pc;
    for (UINT stage=0;stage<2;++stage) {
        out << (stage==0 ? " VSbytes[" : " PSbytes[");
        for (UINT i=0;i<D3D11_COMMONSHADER_CONSTANT_BUFFER_API_SLOT_COUNT;++i) {
            ComPtr<ID3D11Buffer> cb;
            if (stage==0) c->VSGetConstantBuffers(i,1,&cb); else c->PSGetConstantBuffers(i,1,&cb);
            D3D11_BUFFER_DESC d{}; if (cb) cb->GetDesc(&d);
            if (i) out << ','; out << d.ByteWidth;
        }
        out << ']';
    }
    std::array<ID3D11ShaderResourceView*,16> raw{};
    c->PSGetShaderResources(0,static_cast<UINT>(raw.size()),raw.data());
    std::array<ComPtr<ID3D11ShaderResourceView>,16> textures;
    for (UINT i=0;i<raw.size();++i) textures[i].Attach(raw[i]);
    unsigned mask=0;
    for (UINT i=0;i<textures.size();++i) if (textures[i]) {
        mask |= 1u<<i;
        D3D11_SHADER_RESOURCE_VIEW_DESC d{}; textures[i]->GetDesc(&d);
        out << " t" << i << "{format=" << unsigned(d.Format) << " dim=" << unsigned(d.ViewDimension);
        resource(out,textures[i].Get()); out << '}';
    }
    out << " PSsrvMask0to15=" << mask;
    for (UINT i=0;i<16;++i) {
        ComPtr<ID3D11SamplerState> sampler; c->PSGetSamplers(i,1,&sampler);
        if (sampler) {
            D3D11_SAMPLER_DESC d{}; sampler->GetDesc(&d);
            out << " s" << i << '[' << unsigned(d.Filter) << ',' << unsigned(d.AddressU)
                << ',' << unsigned(d.AddressV) << ',' << unsigned(d.AddressW) << ']';
        }
    }
    // A changed topology can hand geometry to the renderer's domain shader.
    // Capture that stage's metadata too; PS-only resources cannot describe it.
    for (UINT stage=0;stage<2;++stage) {
        if (stage==0 ? !hs : !ds) continue;
        out << (stage==0 ? " HSbytes[" : " DSbytes[");
        for (UINT i=0;i<D3D11_COMMONSHADER_CONSTANT_BUFFER_API_SLOT_COUNT;++i) {
            ComPtr<ID3D11Buffer> cb;
            if (stage==0) c->HSGetConstantBuffers(i,1,&cb); else c->DSGetConstantBuffers(i,1,&cb);
            D3D11_BUFFER_DESC d{}; if (cb) cb->GetDesc(&d);
            if (i) out << ','; out << d.ByteWidth;
        }
        out << ']';
    }
    if (ds) for (UINT i=0;i<16;++i) {
        ComPtr<ID3D11ShaderResourceView> view; c->DSGetShaderResources(i,1,&view);
        if (view) {
            D3D11_SHADER_RESOURCE_VIEW_DESC d{}; view->GetDesc(&d);
            out << " DSt" << i << "{format=" << unsigned(d.Format) << " dim=" << unsigned(d.ViewDimension);
            resource(out,view.Get()); out << '}';
        }
        ComPtr<ID3D11SamplerState> sampler; c->DSGetSamplers(i,1,&sampler);
        if (sampler) {
            D3D11_SAMPLER_DESC d{}; sampler->GetDesc(&d);
            out << " DSs" << i << '[' << unsigned(d.Filter) << ',' << unsigned(d.AddressU)
                << ',' << unsigned(d.AddressV) << ',' << unsigned(d.AddressW) << ']';
        }
    }
    return out.str();
}
}

std::uint64_t startWaterTrace(UINT vs, UINT ps, const st::DrawSignature& expected, bool mismatch) noexcept {
    if (!config.diagnostics || !config.waterPassTrace || !rendererCoexistence()) return 0;
    try {
        const auto key=(std::uint64_t(vs)<<32)|ps;
        auto& samples=samplePools[mismatch ? 1 : 0];
        SampleSlot* slot=nullptr;
        for (auto& s:samples) if (s.occupied && s.key==key) { slot=&s; break; }
        if (!slot) for (auto& s:samples) if (!s.occupied) { s.occupied=true; s.key=key; slot=&s; break; }
        if (!slot) return 0; // hard cap: no unbounded map or log growth per interval
        const auto now=std::chrono::steady_clock::now();
        if (now<slot->next) return 0;
        slot->next=now+std::chrono::seconds(2);
        const auto id=nextId.fetch_add(1,std::memory_order_relaxed);
        SKSE::log::info("Water trace begin id={} gameVS={:X} gamePS={:X} reason={} {}",id,vs,ps,
            mismatch ? "changed-or-unmatched" : "periodic",signature(expected));
        return id;
    } catch (...) { return 0; } // diagnostics must not disable rendering
}
void traceUnmatchedHistory(std::uint64_t id, const std::array<ObservedWaterDraw,8>& calls, UINT count) noexcept {
    if (!id) return;
    try {
        for (UINT i=0;i<count && i<calls.size();++i)
            SKSE::log::info("Water trace unmatched id={} pass={} canonical={} {}",id,i+1,calls[i].canonical,signature(calls[i].signature));
    } catch (...) {}
}
void traceWaterPass(ID3D11DeviceContext* c, std::uint64_t id, UINT ordinal,
    const st::DrawSignature& actual, bool canonical, bool matched) noexcept {
    if (!id || ordinal>maxPasses) return;
    try {
        SKSE::log::info("Water trace native id={} pass={} canonical={} hint={} {}",id,ordinal,canonical,matched,signature(actual));
        SKSE::log::info("Water trace outputs id={} pass={} {}",id,ordinal,outputs(c));
        SKSE::log::info("Water trace inputs id={} pass={} {}",id,ordinal,inputs(c));
    } catch (...) {}
}
void traceWaterResult(std::uint64_t id, UINT ordinal, bool changed) noexcept {
    if (!id || ordinal>maxPasses) return;
    try { SKSE::log::info("Water trace result id={} pass={} replaced={}",id,ordinal,changed); } catch (...) {}
}
void finishWaterTrace(std::uint64_t id, UINT nativeCalls, bool matched) noexcept {
    if (!id) return;
    try { SKSE::log::info("Water trace end id={} nativeCalls={} matched={} truncated={}",id,nativeCalls,matched,nativeCalls>maxPasses); } catch (...) {}
}
}
