# Third-party source and notices

| Component | Revision | License / purpose |
| --- | --- | --- |
| [CommonLibSSE-NG](https://github.com/CharmedBaryon/CommonLibSSE-NG) | `b93280e832f263dbef44e44cbe2936622a02f91a` / 3.6.0 | MIT; engine types, relocations, SKSE interfaces |
| [Community Shaders](https://github.com/community-shaders/skyrim-community-shaders/tree/v0.8.7) | `e53c0a1ffaa01199490c6097a7dabb559932a88e` / v0.8.7 | Package shader MIT license, copyright 2022 Ilya Perapechka |
| [spdlog](https://github.com/gabime/spdlog) | `27cb4c76708608465c413f6d0e6b8d99a4d84302` / 1.14.1 | MIT; logging |
| [fmt](https://github.com/fmtlib/fmt) | 10.2.1 bundled by spdlog | MIT; formatting |
| [rapidcsv](https://github.com/d99kris/rapidcsv) | `a98b85e663114b8fdc9c0dc03abf22c296f38241` / 8.84 | BSD-3-Clause; CommonLib dependency |

Water and frame declarations derive from `package/Shaders/Water.hlsl` and `package/Shaders/Common/FrameBuffer.hlsl`. Their MIT license is retained in `licenses/Upstream-Shaders.txt`. CS runtime LightingData/Permutation dependencies were removed, descriptors became compile-time inputs, and surface sampling, tessellation, constant mapping, and previous-frame displacement were added. The adapted code is distributed under this project's GPL-3.0-or-later terms with upstream notices retained.

Vendored dependency sources omit Git metadata and build output. `cmake/CommonLibFixes.cmake` corrects `Begin/End` versus `begin/end` and `storage` versus `_storage` in two CommonLib headers; no ABI layouts change. Clang builds select fmt's non-consteval/non-constexpr path to avoid a compiler compatibility issue. Windows/MSVC builds use their normal format checking.

The Windows SDK/CRT are system build dependencies. SKSE and Address Library are installed separately. None of these proprietary/system development binaries or game assets is included. NumPy, Pillow, and DXC are optional external tools for the reference preview and secondary shader checks.

MinHook v1.3.4, commit c3fcafdc10146beb5919319d0683e44e3c30d537, https://github.com/TsudaKageyu/minhook. Statically linked; BSD notices in licenses/MinHook-BSD.txt. Added in0.1.4 for direct draw-entry interception.

## SKSE Menu Framework API

Public API header by SkyrimThiago / QTR-Modding and contributors, LGPL-2.1, pinned to `1dcb70179076aae4ab626f43c5baab2735ca5877`. Source: https://github.com/QTR-Modding/SKSE-Menu-Framework-3-API . The unmodified header and license are in `vendor/SKSEMenuFramework`; the license is also shipped with the plugin. Framework binaries/assets are not bundled. Optional runtime dependency for the settings menu only.
