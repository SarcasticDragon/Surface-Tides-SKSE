// SPDX-License-Identifier: GPL-3.0-or-later
// Adapted from Community Shaders v0.8.7. See THIRD_PARTY.md in the source archive.
// No Community Shaders runtime resources are required.

// SurfaceTides 0.1.17 shoreline-r1 (shader-only candidate).
// 0: baseline refraction; 1: displaced-surface depth guard; 2: diagnostic,
// undistorted refraction on the same above-water depth-supported passes.
#ifndef ST_SHORE_REFRACTION
#define ST_SHORE_REFRACTION 1
#endif

// Diagnostic overlays only. Default 0 preserves the existing SSR contribution.
// Set 1 to omit SSR on above-water passes, keeping cubemap/planar reflections.
#ifndef ST_DIAGNOSTIC_NO_SSR
#define ST_DIAGNOSTIC_NO_SSR 0
#endif

// R3 candidate overlay: move the plane used for depth-based material blending
// by the surface's actual vertical displacement. Default 0 retains r1 shading.
#ifndef ST_DISPLACED_DEPTH_BLEND
#define ST_DISPLACED_DEPTH_BLEND 1
#endif

// R4 contact-blend candidate. Default 0 preserves the existing shader.
// The overlay sets 1: fade shading at thin displaced-water/scene contacts,
// without reducing wave height or changing depth, stencil or motion outputs.
#ifndef ST_SHORE_CONTACT_BLEND
#define ST_SHORE_CONTACT_BLEND 1
#endif

#include "FrameBuffer.hlsli"
#include "SurfaceField.hlsli"
#define WATER


struct VS_INPUT
{
#if defined(SPECULAR) || defined(UNDERWATER) || defined(STENCIL) || defined(SIMPLE)
	float4 Position : POSITION0;
#	if defined(NORMAL_TEXCOORD)
	float2 TexCoord0 : TEXCOORD0;
#	endif
#	if defined(VC)
	float4 Color : COLOR0;
#	endif
#endif

#if defined(LOD)
	float4 Position : POSITION0;
#	if defined(VC)
	float4 Color : COLOR0;
#	endif
#endif
};

struct VS_OUTPUT
{
#if defined(SPECULAR) || defined(UNDERWATER)
	float4 HPosition : SV_POSITION0;
	float4 FogParam : COLOR0;
	float4 WPosition : TEXCOORD0;
	float4 TexCoord1 : TEXCOORD1;
	float4 TexCoord2 : TEXCOORD2;
#	if defined(WADING) || (defined(FLOWMAP) && (defined(REFRACTIONS) || defined(BLEND_NORMALS))) || (defined(VERTEX_ALPHA_DEPTH) && defined(VC)) || ((defined(SPECULAR) && NUM_SPECULAR_LIGHTS == 0) && defined(FLOWMAP) /*!defined(NORMAL_TEXCOORD) && !defined(BLEND_NORMALS) && !defined(VC)*/)
	float4 TexCoord3 : TEXCOORD3;
#	endif
#	if defined(FLOWMAP)
	nointerpolation float TexCoord4 : TEXCOORD4;
#	endif
	float4 MPosition : TEXCOORD5;
#endif

#if defined(SIMPLE)
	float4 HPosition : SV_POSITION0;
	float4 FogParam : COLOR0;
	float4 WPosition : TEXCOORD0;
	float4 TexCoord1 : TEXCOORD1;
	float4 TexCoord2 : TEXCOORD2;
	float4 MPosition : TEXCOORD5;
#endif

#if defined(LOD)
	float4 HPosition : SV_POSITION0;
	float4 FogParam : COLOR0;
	float4 WPosition : TEXCOORD0;
	float4 TexCoord1 : TEXCOORD1;
#endif

#if defined(STENCIL)
	float4 HPosition : SV_POSITION0;
	float4 WorldPosition : POSITION1;
	float4 PreviousWorldPosition : POSITION2;
#endif

	float4 NormalsScale : TEXCOORD8;
    float STBaseHeight : TEXCOORD9;
};

#if defined(VSHADER) || defined(DSHADER) || defined(HSHADER) || defined(CONTROL_SHADER)

#include "EngineVS.hlsli"

VS_OUTPUT EvaluateWater(VS_INPUT input)
{
	VS_OUTPUT vsout = (VS_OUTPUT)0;

	vsout.NormalsScale = NormalsScale;

	float4 originalPosition = float4(input.Position.xyz, 1.0);
    float4 unperturbedWorld = mul(World, originalPosition);
    vsout.STBaseHeight = unperturbedWorld.z + CameraPosAdjust[0].z;
    float h = STHeight(unperturbedWorld.xyz + CameraPosAdjust[0].xyz, false);
    float3 localOffset = STWorldToLocalOffset(World, float3(0, 0, h));
    float4 inputPosition = originalPosition + float4(localOffset, 0);
	float4 worldPos = mul(World, inputPosition);
	float4 worldViewPos = mul(WorldViewProj, inputPosition);

	float heightMult = min((1.0 / 10000.0) * max(worldViewPos.z - 70000, 0), 1);

	vsout.HPosition.xy = worldViewPos.xy;
	vsout.HPosition.z = heightMult * 0.5 + worldViewPos.z;
	vsout.HPosition.w = worldViewPos.w;

#	if defined(STENCIL)
	vsout.WorldPosition = worldPos;
	vsout.PreviousWorldPosition = mul(PreviousWorld, originalPosition);
    vsout.PreviousWorldPosition.z += STHeight(vsout.PreviousWorldPosition.xyz + CameraPreviousPosAdjust[0].xyz, true);
#	else
	float fogColorParam = min(VSFogFarColor.w,
		pow(saturate(length(worldViewPos.xyz) * VSFogParam.y - VSFogParam.x), NormalsScale.w));
	vsout.FogParam.xyz = lerp(VSFogNearColor.xyz, VSFogFarColor.xyz, fogColorParam);
	vsout.FogParam.w = fogColorParam;

	vsout.WPosition.xyz = worldPos.xyz;
	vsout.WPosition.w = length(worldPos.xyz);

#		if defined(LOD)
	float4 posAdjust =
		ObjectUV.x ? 0.0 : (QPosAdjust.xyxy + worldPos.xyxy) / NormalsScale.xxyy;

	vsout.TexCoord1.xyzw = NormalsScroll0 + posAdjust;
#		else
	vsout.MPosition.xyzw = inputPosition.xyzw;

	float2 posAdjust = worldPos.xy + QPosAdjust.xy;

	float2 scrollAdjust1 = posAdjust / NormalsScale.xx;
	float2 scrollAdjust2 = posAdjust / NormalsScale.yy;
	float2 scrollAdjust3 = posAdjust / NormalsScale.zz;

#			if !(defined(FLOWMAP) && (defined(REFRACTIONS) || defined(BLEND_NORMALS) || defined(DEPTH) || NUM_SPECULAR_LIGHTS == 0))
#				if defined(NORMAL_TEXCOORD)
	float3 normalsScale = 0.001 * NormalsScale.xyz;
	if (ObjectUV.x) {
		scrollAdjust1 = input.TexCoord0.xy / normalsScale.xx;
		scrollAdjust2 = input.TexCoord0.xy / normalsScale.yy;
		scrollAdjust3 = input.TexCoord0.xy / normalsScale.zz;
	}
#				else
	if (ObjectUV.x) {
		scrollAdjust1 = 0.0;
		scrollAdjust2 = 0.0;
		scrollAdjust3 = 0.0;
	}
#				endif
#			endif

	vsout.TexCoord1 = 0.0;
	vsout.TexCoord2 = 0.0;
#			if defined(FLOWMAP)
#				if !(((defined(SPECULAR) || NUM_SPECULAR_LIGHTS == 0) || (defined(UNDERWATER) && defined(REFRACTIONS))) && !defined(NORMAL_TEXCOORD))
#					if defined(BLEND_NORMALS)
	vsout.TexCoord1.xy = NormalsScroll0.xy + scrollAdjust1;
	vsout.TexCoord1.zw = NormalsScroll0.zw + scrollAdjust2;
	vsout.TexCoord2.xy = NormalsScroll1.xy + scrollAdjust3;
#					else
	vsout.TexCoord1.xy = NormalsScroll0.xy + scrollAdjust1;
	vsout.TexCoord1.zw = 0.0;
	vsout.TexCoord2.xy = 0.0;
#					endif
#				endif
#				if !defined(NORMAL_TEXCOORD)
	vsout.TexCoord3 = 0.0;
#				elif defined(WADING)
	vsout.TexCoord2.zw = ((-0.5 + input.TexCoord0.xy) * 0.1 + CellTexCoordOffset.xy) +
	                     float2(CellTexCoordOffset.z, -CellTexCoordOffset.w + ObjectUV.x) / ObjectUV.xx;
	vsout.TexCoord3.xy = -0.25 + (input.TexCoord0.xy * 0.5 + ObjectUV.yz);
	vsout.TexCoord3.zw = input.TexCoord0.xy;
#				elif (defined(REFRACTIONS) || NUM_SPECULAR_LIGHTS == 0 || defined(BLEND_NORMALS))
	vsout.TexCoord2.zw = (CellTexCoordOffset.xy + input.TexCoord0.xy) / ObjectUV.xx;
	vsout.TexCoord3.xy = (CellTexCoordOffset.zw + input.TexCoord0.xy);
	vsout.TexCoord3.zw = input.TexCoord0.xy;
#				endif
	vsout.TexCoord4 = ObjectUV.x;
#			else
	vsout.TexCoord1.xy = NormalsScroll0.xy + scrollAdjust1;
	vsout.TexCoord1.zw = NormalsScroll0.zw + scrollAdjust2;
	vsout.TexCoord2.xy = NormalsScroll1.xy + scrollAdjust3;
	vsout.TexCoord2.z = worldViewPos.w;
	vsout.TexCoord2.w = 0;
#				if (defined(WADING) || (defined(VERTEX_ALPHA_DEPTH) && defined(VC)))
	vsout.TexCoord3 = 0.0;
#					if (defined(NORMAL_TEXCOORD) && ((!defined(BLEND_NORMALS) && !defined(VERTEX_ALPHA_DEPTH)) || defined(WADING)))
	vsout.TexCoord3.xy = input.TexCoord0;
#					endif
#					if defined(VERTEX_ALPHA_DEPTH) && defined(VC)
	vsout.TexCoord3.z = input.Color.w;
#					endif
#				endif
#			endif
#		endif
#	endif

	return vsout;
}

#include "Tessellation.hlsli"

#endif

typedef VS_OUTPUT PS_INPUT;

struct PS_OUTPUT
{
#if defined(UNDERWATER) || defined(SIMPLE) || defined(LOD) || defined(SPECULAR)
	float4 Lighting : SV_Target0;
#endif

#if defined(STENCIL)
	float4 WaterMask : SV_Target0;
	float2 MotionVector : SV_Target1;
#endif
};

#ifdef PSHADER

SamplerState ReflectionSampler : register(s0);
SamplerState RefractionSampler : register(s1);
SamplerState DisplacementSampler : register(s2);
SamplerState CubeMapSampler : register(s3);
SamplerState Normals01Sampler : register(s4);
SamplerState Normals02Sampler : register(s5);
SamplerState Normals03Sampler : register(s6);
SamplerState DepthSampler : register(s7);
SamplerState FlowMapSampler : register(s8);
SamplerState FlowMapNormalsSampler : register(s9);
SamplerState SSRReflectionSampler : register(s10);
SamplerState RawSSRReflectionSampler : register(s11);

Texture2D<float4> ReflectionTex : register(t0);
Texture2D<float4> RefractionTex : register(t1);
Texture2D<float4> DisplacementTex : register(t2);
TextureCube<float4> CubeMapTex : register(t3);
Texture2D<float4> Normals01Tex : register(t4);
Texture2D<float4> Normals02Tex : register(t5);
Texture2D<float4> Normals03Tex : register(t6);
Texture2D<float4> DepthTex : register(t7);
Texture2D<float4> FlowMapTex : register(t8);
Texture2D<float4> FlowMapNormalsTex : register(t9);
Texture2D<float4> SSRReflectionTex : register(t10);
Texture2D<float4> RawSSRReflectionTex : register(t11);

#include "EnginePS.hlsli"

#	define SampColorSampler Normals01Sampler

#	if defined(LOD)
#		undef WATER_CAUSTICS
#	endif

#	if defined(WATER_CAUSTICS)
#		include "WaterCaustics/WaterCaustics.hlsli"
#	endif

#	if defined(SIMPLE) || defined(UNDERWATER) || defined(LOD) || defined(SPECULAR)
#		if defined(FLOWMAP)
#			if defined(WATER_CAUSTICS)
float3 GetFlowmapNormal(PS_INPUT input, float2 uvShift, float multiplier, float offset, float2 viewOffset, out float3 caustics)
#			else
float3 GetFlowmapNormal(PS_INPUT input, float2 uvShift, float multiplier, float offset)
#			endif
{
	float4 flowmapColor = FlowMapTex.Sample(FlowMapSampler, input.TexCoord2.zw + uvShift);
	float2 flowVector = (64 * input.TexCoord3.xy) * sqrt(1.01 - flowmapColor.z);
	float2 flowSinCos = flowmapColor.xy * 2 - 1;
	float2x2 flowRotationMatrix = float2x2(flowSinCos.x, flowSinCos.y, -flowSinCos.y, flowSinCos.x);
	float2 rotatedFlowVector = mul(transpose(flowRotationMatrix), flowVector);
	float2 uv = offset + (rotatedFlowVector - float2(multiplier * ((0.001 * ReflectionColor.w) * flowmapColor.w), 0));
#			if defined(WATER_CAUSTICS)
	caustics = ComputeWaterCaustics(uv + viewOffset.xy * 0.001);
#			endif
	return float3(FlowMapNormalsTex.Sample(FlowMapNormalsSampler, uv).xy, flowmapColor.z);
}
#		endif

#		if (defined(FLOWMAP) && !defined(BLEND_NORMALS)) || defined(LOD)
#			undef WATER_PARALLAX
#		endif

#		if defined(WATER_PARALLAX)
#			include "WaterParallax/WaterParallax.hlsli"
#		endif

#		if defined(DYNAMIC_CUBEMAPS)
#			include "DynamicCubemaps/DynamicCubemaps.hlsli"
#		endif

#		if defined(WATER_CAUSTICS)
float3 GetWaterNormal(PS_INPUT input, float distanceFactor, float normalsDepthFactor, float3 viewDirection, float depth, inout float3 caustics)
#		else
float3 GetWaterNormal(PS_INPUT input, float distanceFactor, float normalsDepthFactor, float3 viewDirection, float depth)
#		endif
{
	float3 normalScalesRcp = rcp(input.NormalsScale.xyz);

#		if defined(WATER_PARALLAX)
	float2 parallaxOffset = GetParallaxOffset(input, normalScalesRcp);
#		endif

#		if defined(WATER_CAUSTICS)
#			if defined(VERTEX_ALPHA_DEPTH)
	float depthDifference = 128.0;
#			else
	float depthDifference = depth - length(input.WPosition.xyz);
#			endif
	float2 viewOffset = viewDirection.xy * depthDifference;
#		endif

#		if defined(FLOWMAP)
	float2 normalMul =
		0.5 + -(-0.5 + abs(frac(input.TexCoord2.zw * (64 * input.TexCoord4)) * 2 - 1));
	float uvShift = 1 / (128 * input.TexCoord4);

#			if defined(WATER_CAUSTICS)
	float3 flowmapCaustics0;
	float3 flowmapNormal0 = GetFlowmapNormal(input, uvShift.xx, 9.92, 0, viewOffset, flowmapCaustics0);
	float3 flowmapCaustics1;
	float3 flowmapNormal1 = GetFlowmapNormal(input, float2(0, uvShift), 10.64, 0.27, viewOffset, flowmapCaustics1);
	float3 flowmapCaustics2;
	float3 flowmapNormal2 = GetFlowmapNormal(input, 0.0.xx, 8, 0, viewOffset, flowmapCaustics2);
	float3 flowmapCaustics3;
	float3 flowmapNormal3 = GetFlowmapNormal(input, float2(uvShift, 0), 8.48, 0.62, viewOffset, flowmapCaustics3);

	float3 flowmapCausticsWeighted = normalMul.y * (normalMul.x * flowmapCaustics2 + (1.0 - normalMul.x) * flowmapCaustics3) + (1.0 - normalMul.y) * (normalMul.x * flowmapCaustics1 + (1.0 - normalMul.x) * flowmapCaustics0);
	caustics = flowmapCausticsWeighted;
#			else
	float3 flowmapNormal0 = GetFlowmapNormal(input, uvShift.xx, 9.92, 0);
	float3 flowmapNormal1 = GetFlowmapNormal(input, float2(0, uvShift), 10.64, 0.27);
	float3 flowmapNormal2 = GetFlowmapNormal(input, 0.0.xx, 8, 0);
	float3 flowmapNormal3 = GetFlowmapNormal(input, float2(uvShift, 0), 8.48, 0.62);
#			endif

	float2 flowmapNormalWeighted =
		normalMul.y * (normalMul.x * flowmapNormal2.xy + (1 - normalMul.x) * flowmapNormal3.xy) +
		(1 - normalMul.y) *
			(normalMul.x * flowmapNormal1.xy + (1 - normalMul.x) * flowmapNormal0.xy);
	float2 flowmapDenominator = sqrt(normalMul * normalMul + (1 - normalMul) * (1 - normalMul));
	float3 flowmapNormal =
		float3(((-0.5 + flowmapNormalWeighted) / (flowmapDenominator.x * flowmapDenominator.y)) *
				   max(0.4, normalsDepthFactor),
			0);
	flowmapNormal.z =
		sqrt(1 - flowmapNormal.x * flowmapNormal.x - flowmapNormal.y * flowmapNormal.y);
#		endif

#		if defined(WATER_PARALLAX)
	float3 normals1 = Normals01Tex.Sample(Normals01Sampler, input.TexCoord1.xy + parallaxOffset.xy * normalScalesRcp.x).xyz * 2.0 + float3(-1, -1, -2);
#		else
	float3 normals1 = Normals01Tex.Sample(Normals01Sampler, input.TexCoord1.xy).xyz * 2.0 + float3(-1, -1, -2);
#		endif

#		if defined(FLOWMAP) && !defined(BLEND_NORMALS)
	float3 finalNormal =
		normalize(lerp(normals1 + float3(0, 0, 1), flowmapNormal, distanceFactor));
#		elif !defined(LOD)

#			if defined(WATER_PARALLAX)
	float3 normals2 = Normals02Tex.Sample(Normals02Sampler, input.TexCoord1.zw + parallaxOffset.xy * normalScalesRcp.y).xyz * 2.0 - 1.0;
	float3 normals3 = Normals03Tex.Sample(Normals03Sampler, input.TexCoord2.xy + parallaxOffset.xy * normalScalesRcp.z).xyz * 2.0 - 1.0;
#			else
	float3 normals2 = Normals02Tex.Sample(Normals02Sampler, input.TexCoord1.zw).xyz * 2.0 - 1.0;
	float3 normals3 = Normals03Tex.Sample(Normals03Sampler, input.TexCoord2.xy).xyz * 2.0 - 1.0;
#			endif

#			if defined(WATER_CAUSTICS)
	float3 caustics1 = ComputeWaterCaustics(input.TexCoord1.xy + viewOffset.xy * normalScalesRcp.x);
	float3 caustics2 = ComputeWaterCaustics(input.TexCoord1.zw + viewOffset.xy * normalScalesRcp.y);
	float3 caustics3 = ComputeWaterCaustics(input.TexCoord2.xy + viewOffset.xy * normalScalesRcp.z);

	float3 blendedCaustics = NormalsAmplitude.xxx * caustics1 + NormalsAmplitude.yyy * caustics2 + NormalsAmplitude.zzz * caustics3;
	caustics = blendedCaustics;
#			endif

	float3 blendedNormal = normalize(float3(0, 0, 1) + NormalsAmplitude.x * normals1 +
									 NormalsAmplitude.y * normals2 + NormalsAmplitude.z * normals3);
#			if defined(UNDERWATER)
	float3 finalNormal = blendedNormal;
#			else
	float3 finalNormal = normalize(lerp(float3(0, 0, 1), blendedNormal, normalsDepthFactor));
#			endif

#			if defined(FLOWMAP)
	float normalBlendFactor =
		normalMul.y * ((1 - normalMul.x) * flowmapNormal3.z + normalMul.x * flowmapNormal2.z) +
		(1 - normalMul.y) * (normalMul.x * flowmapNormal1.z + (1 - normalMul.x) * flowmapNormal0.z);
	finalNormal = normalize(lerp(normals1 + float3(0, 0, 1), normalize(lerp(finalNormal, flowmapNormal, normalBlendFactor)), distanceFactor));
#				if defined(WATER_CAUSTICS)
	caustics = lerp(blendedCaustics, flowmapCausticsWeighted, normalBlendFactor);
#				endif
#			endif
#		else
	float3 finalNormal =
		normalize(float3(0, 0, 1) + NormalsAmplitude.xxx * normals1);
#		endif

#		if defined(WADING)
#			if defined(FLOWMAP)
	float2 displacementUv = input.TexCoord3.zw;
#			else
	float2 displacementUv = input.TexCoord3.xy;
#			endif
	float3 displacement = normalize(float3(NormalsAmplitude.w * (-0.5 + DisplacementTex.Sample(DisplacementSampler, displacementUv).zw),
		0.04));
	finalNormal = lerp(displacement, finalNormal, displacement.z);
#		endif

    float4 field = STSample(float3(input.WPosition.xy + PosAdjust.xy, input.STBaseHeight), false);
    float3 waveNormal = normalize(float3(-field.yz * STOptions.y, 1));
    finalNormal = normalize(float3(finalNormal.xy / max(0.05, abs(finalNormal.z)) + waveNormal.xy / max(0.05, waveNormal.z), 1));
    return finalNormal;
}

float3 GetWaterSpecularColor(PS_INPUT input, float3 normal, float3 viewDirection,
	float distanceFactor, float refractionsDepthFactor)
{
	float4 dynamicCubemap = 0.0;
	if (ST_PIXEL_DESCRIPTOR & 4) {
		float3 finalSsrReflectionColor = 0.0.xxx;
		float ssrFraction = 0;
		float3 reflectionColor = 0;
		if (ST_PIXEL_DESCRIPTOR & 256) {
			float3 cubemapUV = reflect(viewDirection, WaterParams.y * normal + float3(0, 0, 1 - WaterParams.y));
#		if defined(DYNAMIC_CUBEMAPS)
			dynamicCubemap = specularTexture.SampleLevel(CubeMapSampler, cubemapUV, 0);
			reflectionColor = lerp(dynamicCubemap.xyz, CubeMapTex.SampleLevel(CubeMapSampler, cubemapUV, 0).xyz, saturate(length(input.WPosition.xyz) * 0.0001));
#		else
			reflectionColor = CubeMapTex.SampleLevel(CubeMapSampler, cubemapUV, 0).xyz;
#		endif
		} else {
#		if !defined(LOD) && NUM_SPECULAR_LIGHTS == 0
			float4 reflectionNormalRaw = float4((VarAmounts.w * refractionsDepthFactor) * normal.xy + input.MPosition.xy, input.MPosition.z, 1);
#		else
			float4 reflectionNormalRaw = float4(VarAmounts.w * normal.xy, 0, 1);
#		endif

			float4 reflectionNormal = mul(transpose(TextureProj), reflectionNormalRaw);
			reflectionColor = ReflectionTex.SampleLevel(ReflectionSampler, reflectionNormal.xy / reflectionNormal.ww, 0).xyz;
		}

#		if !defined(LOD) && NUM_SPECULAR_LIGHTS == 0 && (!ST_DIAGNOSTIC_NO_SSR || defined(UNDERWATER))
		if (ST_PIXEL_DESCRIPTOR & 256) {
			float2 ssrReflectionUv = GetDynamicResolutionAdjustedScreenPosition((DynamicResolutionParams2.xy * input.HPosition.xy) * SSRParams.zw + SSRParams2.x * normal.xy);
			float4 ssrReflectionColor1 = SSRReflectionTex.Sample(SSRReflectionSampler, ssrReflectionUv);
			float4 ssrReflectionColor2 = RawSSRReflectionTex.Sample(RawSSRReflectionSampler, ssrReflectionUv);
			float4 ssrReflectionColor = lerp(ssrReflectionColor2, ssrReflectionColor1, SSRParams.y);

			finalSsrReflectionColor = max(0, ssrReflectionColor.xyz);
			ssrFraction = saturate(ssrReflectionColor.w * (SSRParams.x * distanceFactor));
		}
#		endif

		float3 finalReflectionColor = lerp(reflectionColor * WaterParams.w, finalSsrReflectionColor, ssrFraction);
		return lerp(ReflectionColor.xyz, finalReflectionColor, VarAmounts.y);
	}
	return ReflectionColor.xyz * VarAmounts.y;
}

#		if defined(DEPTH)
float GetScreenDepthWater(float2 screenPosition)
{
	float depth = DepthTex.Load(float3(screenPosition, 0)).x;
	return (CameraData.w / (-depth * CameraData.z + CameraData.x));
}
#		endif

#if ST_SHORE_CONTACT_BLEND && defined(DEPTH) && defined(REFRACTIONS) && !defined(VERTEX_ALPHA_DEPTH) && !defined(UNDERWATER) && !defined(LOD) && NUM_SPECULAR_LIGHTS == 0
#define ST_HAS_SHORE_CONTACT_BLEND 1
float STShoreContactWeight(float rasterDepth, float sceneDepth)
{
	// Reuse the opaque depth read by main, and compare with the actual
	// rasterized displaced triangle, not the original flat ReflectPlane.
	float surfaceDepth = CameraData.w / (-rasterDepth * CameraData.z + CameraData.x);
	if (!isfinite(surfaceDepth) || surfaceDepth <= 0 || !isfinite(sceneDepth) || sceneDepth <= 0)
		return 1; // Missing/invalid depth must not erase the water shading.
	// A view-depth contact band, not a vertical bathymetry or collision test.
	// Continuous endpoints avoid a hard cut as a wave meets an opaque rock.
	return smoothstep(0, 12, max(0, sceneDepth - surfaceDepth));
}
#endif

#if defined(DEPTH) && !defined(VERTEX_ALPHA_DEPTH) && !defined(UNDERWATER) && ST_SHORE_REFRACTION == 1
// Invert the existing SV_Position -> raw refraction UV mapping. The offset
// must be removed before converting back to depth-texture pixels. Return an
// invalid clearance for off-screen samples instead of relying on Load's zero.
float STRefractionClearance(float2 rawUV, float surfaceDepth)
{
	if (!all(isfinite(rawUV)) || any(rawUV < 0) || any(rawUV > 1))
		return 0;
	// Validate the same dynamic-resolution-clamped location as the color read.
	float2 adjustedUV = GetDynamicResolutionAdjustedScreenPosition(rawUV);
	float2 pixel = (adjustedUV - DynamicResolutionParams1.xy * VPOSOffset.zw) / VPOSOffset.xy;
	uint width, height;
	DepthTex.GetDimensions(width, height);
	if (!all(isfinite(pixel)) || any(pixel < 0) ||
		any(pixel >= float2(width, height)))
		return 0;
	float sceneDepth = GetScreenDepthWater(pixel);
	return isfinite(sceneDepth) ? max(0, sceneDepth - surfaceDepth) : 0;
}

float2 STShoreRefractionUV(PS_INPUT input, float2 baseUV, float2 distortedUV, float sceneDepth)
{
	// PS SV_Position.z is the rasterized, DISPLACED surface depth. Both sides
	// of the comparison use the game's existing linear-depth conversion.
	float surfaceDepth = CameraData.w / (-input.HPosition.z * CameraData.z + CameraData.x);
	if (!isfinite(surfaceDepth) || surfaceDepth <= 0)
		return baseUV;

	// Fade optical distortion over the first 24 view-depth units of water.
	// This affects refraction only, not the wave geometry, normals or opacity.
	// Reuse the unperturbed depth already read by the main water pixel shader.
	float shoreClearance = isfinite(sceneDepth) ? max(0, sceneDepth - surfaceDepth) : 0;
	float2 candidate = lerp(baseUV, distortedUV, smoothstep(0, 24, shoreClearance));
	float sampleClearance = STRefractionClearance(candidate, surfaceDepth);
	candidate = lerp(baseUV, candidate, smoothstep(0, 24, sampleClearance));

	// The second fade changes the lookup coordinate. Revalidate that final
	// coordinate: an intermediate texel can contain foreground geometry even
	// when the originally proposed sample was behind the water.
	return STRefractionClearance(candidate, surfaceDepth) > 0 ? candidate : baseUV;
}
#endif

float3 GetLdotN(float3 normal)
{
#		if defined(UNDERWATER)
	return 1;
#		else
	if (ST_PIXEL_DESCRIPTOR & 32)
		return 1;
	return saturate(dot(SunDir.xyz, normal));
#		endif
}

float GetFresnelValue(float3 normal, float3 viewDirection)
{
#		if defined(UNDERWATER)
	float3 actualNormal = -normal;
#		else
	float3 actualNormal = normal;
#		endif
	float viewAngle = 1 - saturate(dot(-viewDirection, actualNormal));
	return (1 - FresnelRI.x) * pow(viewAngle, 5) + FresnelRI.x;
}

#		if defined(WATER_CAUSTICS)
float3 GetWaterDiffuseColor(PS_INPUT input, float3 normal, float3 viewDirection,
	float4 distanceMul, float refractionsDepthFactor, float fresnel, float sceneDepth, float3 caustics)
#		else
float3 GetWaterDiffuseColor(PS_INPUT input, float3 normal, float3 viewDirection,
	float4 distanceMul, float refractionsDepthFactor, float fresnel, float sceneDepth)
#		endif
{
#		if defined(REFRACTIONS)
	float4 refractionNormal = mul(transpose(TextureProj),
		float4((VarAmounts.w * refractionsDepthFactor).xx * normal.xy + input.MPosition.xy,
			input.MPosition.z, 1));

	float2 refractionUvRaw =
		float2(refractionNormal.x, refractionNormal.w - refractionNormal.y) / refractionNormal.ww;

#			if defined(DEPTH) && !defined(VERTEX_ALPHA_DEPTH)
#if !defined(UNDERWATER) && (ST_SHORE_REFRACTION == 1 || ST_SHORE_REFRACTION == 2)
	float2 baseRefractionUV =
		DynamicResolutionParams2.xy * input.HPosition.xy * VPOSOffset.xy + VPOSOffset.zw;
#if ST_SHORE_REFRACTION == 1
	refractionUvRaw = STShoreRefractionUV(input, baseRefractionUV, refractionUvRaw, sceneDepth);
#else
	refractionUvRaw = baseRefractionUV;
#endif
#else
	float depth = GetScreenDepthWater(DynamicResolutionParams1.xy * (DynamicResolutionParams2.xy * input.HPosition.xy));
	float refractionDepth =
		GetScreenDepthWater(DynamicResolutionParams1.xy * (refractionUvRaw / VPOSOffset.xy));
	float refractionDepthMul = length(
		float3((refractionDepth * ((VPOSOffset.zw + refractionUvRaw) * 2 - 1)) /
				   ProjData.xy,
			refractionDepth));

	float3 refractionDepthAdjustedViewDirection = -viewDirection * refractionDepthMul;
	float refractionViewSurfaceAngle = dot(refractionDepthAdjustedViewDirection, ReflectPlane.xyz);

	float refractionPlaneMul =
		sign(refractionViewSurfaceAngle) * (1 - ReflectPlane.w / refractionViewSurfaceAngle);

	if (refractionPlaneMul < 0) {
		refractionUvRaw =
			DynamicResolutionParams2.xy * input.HPosition.xy * VPOSOffset.xy + VPOSOffset.zw;
	}
#endif
#			endif

	float2 refractionUV = GetDynamicResolutionAdjustedScreenPosition(refractionUvRaw);
	float3 refractionColor = RefractionTex.Sample(RefractionSampler, refractionUV).xyz;
	float3 refractionDiffuseColor = lerp(ShallowColor.xyz, DeepColor.xyz, distanceMul.y);

#			if defined(UNDERWATER)
	float refractionMul = 0;
#			else
	float refractionMul =
		1 - pow(saturate((-distanceMul.x * FogParam.z + FogParam.z) / FogParam.w), FogNearColor.w);
#			endif

#			if defined(WATER_CAUSTICS)
	refractionColor *= lerp(1.0, caustics, refractionMul);
#			endif

	return lerp(refractionColor * WaterParams.w, refractionDiffuseColor, refractionMul);
#		else
	return lerp(ShallowColor.xyz, DeepColor.xyz, fresnel) * GetLdotN(normal);
#		endif
}

float3 GetSunColor(float3 normal, float3 viewDirection)
{
#		if defined(UNDERWATER)
	return 0.0.xxx;
#		else
	if (ST_PIXEL_DESCRIPTOR & 32)
		return 0.0.xxx;

	float3 reflectionDirection = reflect(viewDirection, normal);

	float reflectionMul = exp2(VarAmounts.x * log2(saturate(dot(reflectionDirection, SunDir.xyz))));

	float3 sunDirection = SunColor.xyz * SunDir.w;
	float sunMul = pow(saturate(dot(normal, float3(-0.099, -0.099, 0.99))), ShallowColor.w);
	return (reflectionMul * sunDirection * 0.3) * DeepColor.w + WaterParams.z * (sunMul * sunDirection * 0.1);
#		endif
}
#	endif

#	if defined(WATER_BLENDING)
#		include "WaterBlending/WaterBlending.hlsli"
#	endif

#	if defined(LIGHT_LIMIT_FIX)
#		include "LightLimitFix/LightLimitFix.hlsli"
#	endif

PS_OUTPUT main(PS_INPUT input)
{
	PS_OUTPUT psout;

#	if defined(SIMPLE) || defined(UNDERWATER) || defined(LOD) || defined(SPECULAR)
	float3 viewDirection = normalize(input.WPosition.xyz);

	float distanceFactor = saturate(lerp(FrameParams.w, 1, (input.WPosition.w - 8192) / (WaterParams.x - 8192)));
	float4 distanceMul = saturate(lerp(VarAmounts.z, 1, -(distanceFactor - 1))).xxxx;

	bool isSpecular = false;

	float depth = 0;

#		if defined(DEPTH)
#			if defined(VERTEX_ALPHA_DEPTH)
#				if defined(VC)
	distanceMul = saturate(input.TexCoord3.z);
#				endif
#			else
	distanceMul = 0;

	depth = GetScreenDepthWater(
		DynamicResolutionParams1.xy * (DynamicResolutionParams2.xy * input.HPosition.xy));
	float2 depthOffset =
		DynamicResolutionParams2.xy * input.HPosition.xy * VPOSOffset.xy + VPOSOffset.zw;
	float depthMul = length(float3((depthOffset * 2 - 1) * depth / ProjData.xy, depth));

	float3 depthAdjustedViewDirection = -viewDirection * depthMul;
	float viewSurfaceAngle = dot(depthAdjustedViewDirection, ReflectPlane.xyz);

	float depthPlaneDistance = ReflectPlane.w;
#if ST_DISPLACED_DEPTH_BLEND && !defined(UNDERWATER) && !defined(LOD)
	// ReflectPlane.w = dot(-restPosition, ReflectPlane.xyz). Raising a point
	// by dz therefore shifts that signed distance by -ReflectPlane.z * dz.
	// Use the interpolated geometry's displacement, not a second field lookup,
	// so the optical depth follows the actual tessellated triangle surface.
	float displacedHeight = (input.WPosition.z + PosAdjust.z) - input.STBaseHeight;
	depthPlaneDistance -= ReflectPlane.z * displacedHeight;
#endif
	float planeMul = (1 - depthPlaneDistance / viewSurfaceAngle);
	distanceMul = saturate(
		planeMul * float4(length(depthAdjustedViewDirection).xx, abs(viewSurfaceAngle).xx) /
		FogParam.z);
#			endif
#		endif

#		if defined(UNDERWATER)
	float4 depthControl = float4(0, 1, 1, 0);
#		elif defined(LOD)
	float4 depthControl = float4(1, 0, 0, 1);
#		elif defined(SPECULAR) && (NUM_SPECULAR_LIGHTS != 0)
	float4 depthControl = float4(0, 0, 1, 0);
#		else
	float4 depthControl = DepthControl * (distanceMul - 1) + 1;
#		endif

#		if defined(WATER_CAUSTICS)
	float3 caustics = 0.0;
	float3 normal = GetWaterNormal(input, distanceFactor, depthControl.z, viewDirection, depth, caustics);
#		else
	float3 normal = GetWaterNormal(input, distanceFactor, depthControl.z, viewDirection, depth);
#		endif

	float fresnel = GetFresnelValue(normal, viewDirection);

#		if defined(SPECULAR) && (NUM_SPECULAR_LIGHTS != 0)
	float3 finalColor = 0.0.xxx;

	for (int lightIndex = 0; lightIndex < NUM_SPECULAR_LIGHTS; ++lightIndex) {
		float3 lightVector = LightPos[lightIndex].xyz - (PosAdjust.xyz + input.WPosition.xyz);
		float3 lightDirection = normalize(normalize(lightVector) - viewDirection);
		float lightFade = saturate(length(lightVector) / LightPos[lightIndex].w);
		float lightColorMul = (1 - lightFade * lightFade);
		float LdotN = saturate(dot(lightDirection, normal));
		float3 lightColor = (LightColor[lightIndex].xyz * pow(LdotN, FresnelRI.z)) * lightColorMul;
		finalColor += lightColor;
	}

	finalColor *= fresnel;

	isSpecular = true;
#		else

	float3 specularColor = GetWaterSpecularColor(input, normal, viewDirection, distanceFactor, depthControl.y);
#			if defined(WATER_CAUSTICS)
	float3 diffuseColor = GetWaterDiffuseColor(input, normal, viewDirection, distanceMul, depthControl.y, fresnel, depth, caustics);

#			else
	float3 diffuseColor = GetWaterDiffuseColor(input, normal, viewDirection, distanceMul, depthControl.y, fresnel, depth);
#			endif

	float3 specularLighting = 0;

#			if defined(LIGHT_LIMIT_FIX)
	uint eyeIndex = 0;
	uint lightCount = 0;

	float3 viewPosition = mul(CameraView[eyeIndex], float4(input.WPosition.xyz, 1)).xyz;
	float2 screenUV = ViewToUV(viewPosition, true, eyeIndex);

	uint clusterIndex = 0;
	if (perPassLLF[0].EnableGlobalLights && GetClusterIndex(screenUV, viewPosition.z, clusterIndex)) {
		lightCount = lightGrid[clusterIndex].lightCount;
		uint lightOffset = lightGrid[clusterIndex].offset;
		[loop] for (uint i = 0; i < lightCount; i++)
		{
			uint light_index = lightList[lightOffset + i];
			StructuredLight light = lights[light_index];

			float3 lightDirection = light.positionWS[eyeIndex].xyz - input.WPosition.xyz;
			float lightDist = length(lightDirection);
			float intensityFactor = saturate(lightDist / light.radius);

			float intensityMultiplier = 1 - intensityFactor * intensityFactor;

			float3 normalizedLightDirection = normalize(lightDirection);

			float3 H = normalize(normalizedLightDirection - viewDirection);
			float HdotN = saturate(dot(H, normal));

			float3 lightColor = light.color.xyz * pow(HdotN, FresnelRI.z);
			specularLighting += lightColor * intensityMultiplier;
		}
	}
	specularColor += specularLighting * 3;
#			endif

#			if defined(UNDERWATER)
	float3 finalSpecularColor = lerp(ShallowColor.xyz, specularColor, 0.5);
	float3 finalColor = saturate(1 - input.WPosition.w * 0.002) *
	                        ((1 - fresnel) * (diffuseColor - finalSpecularColor)) +
	                    finalSpecularColor;
#			else
	float3 sunColor = GetSunColor(normal, viewDirection);
	float specularFraction = lerp(1, fresnel * depthControl.x, distanceFactor);
	float3 finalColorPreFog = lerp(diffuseColor, specularColor, specularFraction) + sunColor * depthControl.w;
	float3 finalColor = lerp(finalColorPreFog, input.FogParam.xyz, input.FogParam.w);
#			endif
#		endif

	psout.Lighting = saturate(float4(finalColor * PosAdjust.w, isSpecular));
#if defined(ST_HAS_SHORE_CONTACT_BLEND)
	float contactWeight = STShoreContactWeight(input.HPosition.z, depth);
	[branch] if (contactWeight < 1) {
		float2 contactUV = DynamicResolutionParams2.xy * input.HPosition.xy * VPOSOffset.xy + VPOSOffset.zw;
		contactUV = GetDynamicResolutionAdjustedScreenPosition(contactUV);
		// Undistorted scene color, using the existing native refraction capture
		// and exposure conversion. Explicit LOD is safe inside this varying branch.
		float3 contactBackground = RefractionTex.SampleLevel(RefractionSampler, contactUV, 0).xyz;
		contactBackground = saturate(contactBackground * WaterParams.w * PosAdjust.w);
		// Blend the complete fogged water color, including reflected highlights;
		// fading only UV distortion still leaves hard reflective contact slivers.
		// Retain the engine's alpha meaning and all geometry/stencil outputs.
		psout.Lighting.xyz = lerp(contactBackground, psout.Lighting.xyz, contactWeight);
	}
#endif
#		if defined(WATER_BLENDING)
#			if defined(DEPTH)
	if (perPassWaterBlending[0].EnableWaterBlending) {
#				if defined(VERTEX_ALPHA_DEPTH) && defined(VC)
		float blendFactor = 1 - smoothstep(0.0, 0.025 * perPassWaterBlending[0].WaterBlendRange, input.TexCoord3.z);
		if (blendFactor > 0.0) {
			float4 background = RefractionTex.Load(float3(DynamicResolutionParams1.xy * (DynamicResolutionParams2.xy * input.HPosition.xy), 0));
			psout.Lighting.xyz = lerp(psout.Lighting.xyz, background.xyz, blendFactor);
			psout.Lighting.w = lerp(psout.Lighting.w, background.w, blendFactor);
		}
#				else
		float blendFactor = 1 - smoothstep(0.0, 0.025 * perPassWaterBlending[0].WaterBlendRange, distanceMul.z);

		if (blendFactor > 0.0) {
			float4 background = RefractionTex.Load(float3(DynamicResolutionParams1.xy * (DynamicResolutionParams2.xy * input.HPosition.xy), 0));
			psout.Lighting.xyz = lerp(psout.Lighting.xyz, background.xyz, blendFactor);
			psout.Lighting.w = lerp(psout.Lighting.w, background.w, blendFactor);
		}
#				endif
	}
#			endif
#		endif

#	endif

#	if defined(STENCIL)
	float3 viewDirection = normalize(input.WorldPosition.xyz);
	float3 normal =
		normalize(cross(ddx_coarse(input.WorldPosition.xyz), ddy_coarse(input.WorldPosition.xyz)));
	float VdotN = dot(viewDirection, normal);
	psout.WaterMask = float4(0, 0, VdotN, 0);

	psout.MotionVector = GetSSMotionVector(input.WorldPosition, input.PreviousWorldPosition);
#	endif

#if !defined(STENCIL)
    if (STDebug.x > 0.5)
        psout.Lighting = float4(STDiagnosticColor(float3(input.WPosition.xy + PosAdjust.xy, input.STBaseHeight)),1);
#endif
    return psout;
}

#endif
