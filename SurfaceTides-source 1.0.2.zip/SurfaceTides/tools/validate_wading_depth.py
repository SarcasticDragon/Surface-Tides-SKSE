#!/usr/bin/env python3
"""Check primary WADING depth-comparison bypass against the recovered pre-test shader.

DXC/SM6 compilation and byte/resource comparisons, not Windows SM5 execution.
"""
import argparse
import hashlib
import pathlib
import re
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--dxc', required=True)
parser.add_argument('--reference', required=True)
parser.add_argument('--baseline-water', required=True, help='Saved source-default Water.hlsl before depth test')
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
source = root / 'Data/Shaders/SurfaceTides'
baseline = pathlib.Path(args.baseline_water).read_bytes()
current = (source / 'Water.hlsl').read_bytes()
dxc = str(pathlib.Path(args.dxc).resolve())
reference = str(pathlib.Path(args.reference).resolve())
descriptors = [0x0002, 0x001e, 0x005e, 0x00df, 0x071e, 0x075e, 0x003e, 0x015e,
               0x081e, 0x101e, 0x381e, 0x401e, 0x471e, 0x5000, 0x5802, 0x5001,
               0x031e, 0x011e, 0x035e, 0x0802, 0x0842, 0x410e, 0x430e, 0x011f,
               0x3002, 0x0106, 0x0116, 0x4802, 0x581e, 0x0042, 0x0742, 0x475e, 0x405e]
flags = ['VC', 'NORMAL_TEXCOORD', 'REFLECTIONS', 'REFRACTIONS', 'DEPTH', 'INTERIOR',
         'WADING', 'VERTEX_ALPHA_DEPTH', 'CUBEMAP', 'FLOWMAP', 'BLEND_NORMALS']
stages = [('VSHADER', 'vs_6_0'), ('CONTROL_SHADER', 'vs_6_0'), ('HSHADER', 'hs_6_0'),
          ('DSHADER', 'ds_6_0'), ('PSHADER', 'ps_6_0')]
def r4(code):
    return code.replace(b'#define ST_DISPLACED_DEPTH_BLEND 0', b'#define ST_DISPLACED_DEPTH_BLEND 1').replace(
        b'#define ST_SHORE_CONTACT_BLEND 0', b'#define ST_SHORE_CONTACT_BLEND 1')

variants = {'baseline': baseline, 'default': current, 'r4': r4(baseline),
            'isolation': (root / 'packaging/wading-depth-diagnostic/Water.hlsl').read_bytes()}
assert b'#define ST_DIAGNOSTIC_WADING_DEPTH 0' in current
assert b'#define ST_DIAGNOSTIC_WADING_DEPTH 1' in variants['isolation']
hashes = {}
resources = {}
listings = {}
total = 0
with tempfile.TemporaryDirectory(prefix='wading-depth-') as directory:
    temp = pathlib.Path(directory)
    shutil.copytree(source, temp, dirs_exist_ok=True)
    subprocess.run([reference, '--headers', str(temp)], check=True)
    for variant, code in variants.items():
        # Exercise the packaged definitions, not compiler overrides.
        (temp / 'Water.hlsl').write_bytes(code)
        for descriptor in descriptors:
            defines = [name + '=1' for bit, name in enumerate(flags) if descriptor & (1 << bit)]
            technique = descriptor >> 11
            defines += (['SPECULAR=1', f'NUM_SPECULAR_LIGHTS={technique}'] if technique < 8 else
                        [{8: 'UNDERWATER', 9: 'LOD', 10: 'STENCIL', 11: 'SIMPLE'}[technique] + '=1'])
            for stage, target in stages:
                command = [dxc, str(temp / 'Water.hlsl'), '-T', target, '-E', 'main', '-HV', '2016',
                           '-Fo', str(temp / 'shader.dxil'), '-Fc', str(temp / 'shader.txt')]
                for define in defines + [stage + '=1', f'ST_PIXEL_DESCRIPTOR={descriptor}']:
                    command += ['-D', define]
                result = subprocess.run(command, capture_output=True, text=True)
                if result.returncode:
                    raise RuntimeError(f'{variant} {descriptor:X} {stage}: {result.stdout}{result.stderr}')
                hashes[variant, descriptor, stage] = hashlib.sha256((temp / 'shader.dxil').read_bytes()).hexdigest()
                if stage == 'PSHADER':
                    listing = (temp / 'shader.txt').read_text()
                    listings[variant, descriptor] = listing
                    resources[variant, descriptor] = listing.split('; Resource Bindings:')[1].split('target datalayout')[0]
                total += 1

changed = []
for descriptor in descriptors:
    for stage, _ in stages:
        assert hashes['default', descriptor, stage] == hashes['baseline', descriptor, stage], (
            f'Default changed {descriptor:X} {stage}')
        target = stage == 'PSHADER' and descriptor == 0x015e
        different = hashes['isolation', descriptor, stage] != hashes['r4', descriptor, stage]
        assert different == target, f'Unexpected isolation scope {descriptor:X} {stage}'
        if stage != 'PSHADER':
            continue
        before = resources['r4', descriptor]
        after = resources['isolation', descriptor]
        assert before == after, f'Pixel shader resources changed {descriptor:X}'
        if target:
            listing = listings['isolation', descriptor]
            assert 'SV_Depth' in listing, 'Missing diagnostic depth output'
            assert '@dx.op.discard' not in listing, 'Unexpected pixel discard'
            # Signature IDs are declaration-order metadata, not target registers.
            # Resolve the depth ID, then verify its emitted constant output.
            depth_id = re.search(r'!\{i32 (\d+), !"SV_Depth"', listing)
            assert depth_id, 'No depth signature metadata'
            assert f'@dx.op.storeOutput.f32(i32 5, i32 {depth_id[1]}, i32 0, i8 0, float 0.000000e+00)' in listing
            assert re.search(r'; SV_Target\s+0\s+xyzw\s+0\s+TARGET', listing), 'Color target0 changed'
            (root / 'docs/wading-depth-target-ps.txt').write_text(listing)
            changed.append(f'{descriptor:04X}')
        else:
            assert 'SV_Depth' not in listings['isolation', descriptor], f'Depth output escaped target: {descriptor:X}'

print(f'{total}/{total} DXC SM6 shader compilations passed across {len(descriptors)} descriptors and four configurations.')
print(f'Default source: {len(descriptors) * len(stages)} byte-identical DXIL comparisons to previous source defaults.')
print('All geometry, stencil/motion, underwater, LOD, additional-light and non-target pixel outputs match r4 byte-for-byte.')
print('Changed pixel shader: ' + ', '.join(changed) + ' only; SV_Depth=0, no discard, unchanged resource bindings.')
print('No C++/DLL/solver changes. Host DXC SM6 validation only; native Windows SM5 and in-game result remain unverified.')
