#!/usr/bin/env python3
"""Package optional foam filtering and the separate reviewed BOS preset."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dll',type=Path,required=True)
parser.add_argument('--output-dir',type=Path,required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = args.output_dir.resolve()
out.mkdir(parents=True,exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
def archive(path,payload):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(payload.items()): z.writestr(name,data)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for name,data in payload.items(): assert z.read(name) == data

dll = args.dll.read_bytes()
assert b'SurfaceTides 0.1.20 development (optional attached foam filter)' in dll
assert b'AttachedFoam: ref=' in dll
assert b'Game topology disagreement' in dll
assert '22/22 passed' in (root/'docs/foam-0.1.20-tests.txt').read_text()
audit = json.loads((root/'docs/foam-0.1.20-profile-validation.json').read_text())
assert audit['passed'] and audit['geometry_cases']==15 and audit['matched_attached_shapes']==3
build = json.loads((root/'docs/foam-0.1.20-build-validation.json').read_text())
assert build['compiled'] and build['dll_sha256'] == sha(dll)
baseline = (root/'recovery/SurfaceTides-0.1.19.2-topology-update.zip').read_bytes()
assert sha(baseline) == '6c7e5a345bc520a77ba857166261e80f2bd87f77aaa2829abc4b824784c9e81d'
with zipfile.ZipFile(root/'recovery/SurfaceTides-0.1.19.2-topology-update.zip') as z:
    assert sha(z.read('SKSE/Plugins/SurfaceTides.dll')) == '3e0c1a49903c6e3f69a0cc56baec370eefc29ce9d7be7dd7ae417a85723da68b'
    runtime = {n:z.read(n) for n in z.namelist() if n.startswith('Shaders/')}
for name,data in runtime.items(): assert data == (root/'Data'/name).read_bytes()
assert sha(runtime['Shaders/SurfaceTides/Water.hlsl']) == '1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e'
runtime['SKSE/Plugins/SurfaceTides.dll'] = dll
runtime['SurfaceTides-foam-README.md'] = (root/'docs/FOAM-0.1.20.md').read_bytes()
runtime['SurfaceTides-LICENSE.txt'] = (root/'LICENSE').read_bytes()
manifest = {'version':'0.1.20','in_game_result':'pending','ini_preserved':True,
            'accepted_shaders_unchanged':True,'attached_filter_default':False,
            'standalone_bos_separate':True,'portable_tests':'22/22 passed',
            'files':{n:{'bytes':len(d),'sha256':sha(d)} for n,d in runtime.items()}}
encoded = (json.dumps(manifest,indent=2)+'\n').encode()
(root/'docs/foam-0.1.20-package.json').write_bytes(encoded)
runtime['SurfaceTides-foam-manifest.json'] = encoded
assert not any(n.endswith('.ini') for n in runtime)
assert not any(n.lower().endswith(('.nif','.dds')) for n in runtime)
mod = out/'SurfaceTides-0.1.20-foam-update.zip'
archive(mod,runtime)
(root/'recovery'/mod.name).write_bytes(mod.read_bytes())

preset = root/'optional/foam-bos'
rules = (preset/'SurfaceTides_Foam_SWAP.ini').read_text()
active = [s.strip() for s in rules.splitlines() if s.strip() and not s.lstrip().startswith((';','['))]
expected = ['0x01B37D~Skyrim.esm','0x106A1D~Skyrim.esm','0x01CCBC~Skyrim.esm']
assert active == [key+'|flags(0x00000800)' for key in expected]
approved = [s.split('\t') for s in (preset/'SurfaceTides_FoamAllowlist-reviewed.tsv').read_text().splitlines() if s and not s.startswith('#')]
assert [r[0] for r in approved] == expected
inputs = json.loads((root/'docs/foam-0.1.20-inputs.json').read_text())
records = {r['FormKey']:r for m in inputs['meshes'] for r in m['base_records']}
for key,path in approved: assert records[key]['ModelPath'] == path and records[key]['Type'] == 'MSTT'
bos = out/'SurfaceTides-standalone-foam-BOS-0.1.zip'
archive(bos,{'SurfaceTides_Foam_SWAP.ini':rules.encode(),
             'SurfaceTides-BOS-README.md':(preset/'README.md').read_bytes(),
             'SurfaceTides-foam-README.md':(root/'docs/FOAM-0.1.20.md').read_bytes(),
             'SurfaceTides-LICENSE.txt':(root/'LICENSE').read_bytes()})

source = out/'SurfaceTides-source-menu.zip'
skip = {'.git','__pycache__','build','out','vcpkg_installed'}
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if not path.is_file() or any(p in skip or p.startswith('build-') for p in rel.parts): continue
        if path.suffix.lower() in {'.pyc','.obj','.pdb','.dll','.lib','.nif','.dds'}: continue
        z.write(path,'SurfaceTides/'+str(rel))
with zipfile.ZipFile(source) as z:
    assert z.testzip() is None
    assert z.read('SurfaceTides/recovery/'+mod.name) == mod.read_bytes()
    assert z.read('SurfaceTides/recovery/SurfaceTides-0.1.19.2-topology-update.zip') == baseline
    assert z.read('SurfaceTides/Data/Shaders/SurfaceTides/Water.hlsl') == runtime['Shaders/SurfaceTides/Water.hlsl']
    assert z.read('SurfaceTides/src/plugin/Foam.cpp') == (root/'src/plugin/Foam.cpp').read_bytes()
for path in [bos,mod,source]: print(path.name,path.stat().st_size,sha(path.read_bytes()))
print('Verified separate packages, exact BOS rules/inventory, preserved INI, unchanged shaders and accepted rollback.')
