// Standalone CPU timing of the selected-floe fit. Not a Skyrim FPS benchmark.
#include "surfacetides/FloeMotion.hpp"
#include <chrono>
#include <cmath>
#include <iostream>

int main() {
    constexpr int n=192, iterations=2000;
    std::vector<st::SurfaceTexel> data(n*n);
    for (int y=0;y<n;++y) for (int x=0;x<n;++x)
        data[std::size_t(y*n+x)]={5*std::sin(x*0.73f)+3*std::cos(y*0.57f),0,0,1};
    st::SurfaceFieldView field{data,{-1920,-1920},20,-14000,2,n,16,60,true};
    const float half=981.32f*0.70710678f;
    const st::FloeFootprint footprint{{0,0},{half,half},0.47f,-14000,60};
    float checksum=0;
    const auto time=[&](float follow) {
        const auto start=std::chrono::steady_clock::now();
        for (int i=0;i<iterations;++i) {
            data[96*n+96].height=static_cast<float>(i%20)*0.1f;
            const auto goal=st::fitFloeCrestTarget(field,footprint,{},follow,4);
            if (!goal.target.valid) return -1.0;
            checksum+=goal.target.pose.heave;
        }
        return std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count()/iterations;
    };
    const double original=time(0), crest=time(1);
    const auto target=st::fitFloeCrestTarget(field,footprint,{},1,4);
    std::cout << "{\"iterations\":" << iterations << ",\"original_us\":" << original
              << ",\"crest_us\":" << crest << ",\"samples\":" << target.samples
              << ",\"mean_heave\":" << target.meanHeave << ",\"crest_target\":" << target.target.pose.heave
              << ",\"checksum\":" << checksum << "}\n";
    return original<0 || crest<0;
}
