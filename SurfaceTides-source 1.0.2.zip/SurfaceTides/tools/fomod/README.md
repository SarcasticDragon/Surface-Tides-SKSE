# FOMOD schema reference

`ModConfig5.0.xsd` is the generic5.0 XML schema retrieved unchanged from https://qconsulting.ca/gemm/ModConfig5.0.xsd on2026-09-15. It is a validation reference, not code compiled into Surface Tides or installed into Skyrim. The XML uses this generic schema, without Fallout-specific extender dependencies. Source and schema hashes are recorded in the release validation report.

The upstream schema has a leading space in one `type=" xs:string"` QName. The validator trims that exact value in memory for libxml2, retaining the reference file unchanged.
