#!/usr/bin/env python3
"""Package the validated 1.0 FOMOD and complete source/recovery checkpoint."""
import argparse, configparser, difflib, hashlib, json, os, zipfile
from pathlib import Path
from validate_fomod import validate

sha=lambda b:hashlib.sha256(b).hexdigest()
def write_zip(path,items):
    temp=path.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in items:z.writestr(name,data)
    with temp.open('rb') as f:os.fsync(f.fileno())
    with zipfile.ZipFile(temp) as z:assert z.testzip() is None
    temp.replace(path)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ['stage','baseline-source','output-dir']:p.add_argument('--'+arg,type=Path,required=True)
    p.add_argument('--installer-name',default='SurfaceTides-1.0-FOMOD.zip')
    a=p.parse_args();root=Path(__file__).resolve().parents[1]
    stage=a.stage.resolve();out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    evidence=root/'docs/release-1.0-evidence';evidence.mkdir(parents=True,exist_ok=True)
    result=validate(stage,root)
    baseline=a.baseline_source.read_bytes()
    assert sha(baseline)=='18e313401e406851d67c2ba70d8b9fd8ebefd2d391c5fc2512db41364b1d8201'
    replacements={
        'CMakeLists.txt':[('VERSION 0.1.25','VERSION 1.0.0')],
        'src/plugin/Main.cpp':[('PluginVersion({0,1,25,0})','PluginVersion({1,0,0,0})'),
            ('SurfaceTides 0.1.25 development (CS coexistence)','SurfaceTides 1.0.0'),
            ('SurfaceTides with CS coexistence (TEST).','SurfaceTides with CS coexistence.')],
        'src/plugin/Menu.cpp':[('Surface Tides 0.1.25 -','Surface Tides 1.0 -'),('CS coexistence test:','CS coexistence:')]}
    patches=[];checked=0
    with zipfile.ZipFile(a.baseline_source) as z:
        for name in z.namelist():
            rel=name.removeprefix('SurfaceTides/')
            if rel.startswith(('src/','include/','Data/Shaders/','recovery/')) or rel=='CMakeLists.txt':
                old=z.read(name);actual=(root/rel).read_bytes();want=old
                for before,after in replacements.get(rel,[]):
                    assert want.count(before.encode())==1
                    want=want.replace(before.encode(),after.encode())
                assert actual==want,'unexpected implementation/recovery change: '+rel
                checked+=1
                if actual!=old:patches.extend(difflib.unified_diff(old.decode().splitlines(True),actual.decode().splitlines(True),fromfile=rel,tofile=rel))
        oldini=configparser.ConfigParser();oldini.read_string(z.read('SurfaceTides/Data/SKSE/Plugins/SurfaceTides.ini').decode())
        newini=configparser.ConfigParser();newini.read(root/'Data/SKSE/Plugins/SurfaceTides.ini')
        assert {s:dict(oldini[s]) for s in oldini}=={s:dict(newini[s]) for s in newini}
        assert {n.removeprefix('SurfaceTides/') for n in z.namelist() if n.startswith(('SurfaceTides/src/','SurfaceTides/include/'))}=={p.relative_to(root).as_posix() for d in ['src','include'] for p in (root/d).rglob('*') if p.is_file()}
    (evidence/'version-only-source.patch').write_text(''.join(patches))
    dll=(stage/'core/SKSE/Plugins/SurfaceTides.dll').read_bytes()
    assert dll[:2]==b'MZ' and b'SurfaceTides 1.0.0' in dll
    binary=(evidence/'binary-inspection.txt').read_text()
    assert 'IMAGE_FILE_MACHINE_AMD64' in binary
    for symbol in ['SKSEPlugin_Load','SKSEPlugin_Version']:assert symbol in binary
    result.update({'baseline_source_sha256':sha(baseline),'baseline_files_compared':checked,
        'runtime_changes':'version and status strings only','simulation_and_shaders_unchanged':True,
        'default_ini_values_unchanged':True,'dll_bytes':len(dll),'dll_sha256':sha(dll),
        'schema_source':'https://qconsulting.ca/gemm/ModConfig5.0.xsd',
        'schema_sha256':sha((root/'tools/fomod/ModConfig5.0.xsd').read_bytes()),
        'schema_qname_whitespace_normalized_in_memory':True,
        'runtime_test':'accepted 0.1.25 baseline; version-labelled 1.0 DLL and FOMOD awaiting user installation'})
    (evidence/'fomod-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    payload=sorted((p.relative_to(stage).as_posix(),p.read_bytes()) for p in stage.rglob('*') if p.is_file())
    assert Path(a.installer_name).name==a.installer_name and a.installer_name.endswith('.zip')
    mod=out/a.installer_name;write_zip(mod,payload)
    (root/'recovery'/mod.name).write_bytes(mod.read_bytes())
    (evidence/'package.json').write_text(json.dumps({'installer_sha256':sha(mod.read_bytes()),'files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in payload}},indent=2)+'\n')
    skip={'.git','__pycache__','build','out','vcpkg_installed'}
    def source_files():
        for path in sorted(root.rglob('*')):
            rel=path.relative_to(root)
            if not path.is_file() or any(s in skip or s.startswith('build-') for s in rel.parts):continue
            if path.suffix.lower() in {'.pyc','.obj','.pdb','.dll','.lib','.nif','.dds'}:continue
            yield 'SurfaceTides/'+rel.as_posix(),path.read_bytes()
    source=out/'SurfaceTides-source-menu.zip';write_zip(source,source_files())
    with zipfile.ZipFile(source) as z:
        for n,b in source_files():assert z.read(n)==b
        assert z.read('SurfaceTides/recovery/'+mod.name)==mod.read_bytes()
    for path in [mod,source]:print(path.name,path.stat().st_size,sha(path.read_bytes()))
    print('PASS: FOMOD paths, version-only implementation scope, unchanged defaults and earlier recoveries, x64 SKSE DLL, archive integrity and full source checkpoint.')

if __name__=='__main__':main()
