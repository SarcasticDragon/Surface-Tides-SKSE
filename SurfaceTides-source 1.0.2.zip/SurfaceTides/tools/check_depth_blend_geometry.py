#!/usr/bin/env python3
"""Analytical water-column examples for the displaced-plane correction.

Intersects a known eye-to-scene ray with two horizontal planes. Compares
independent geometric distances to the shader's material-depth calculation.
This is a mathematical reference, not execution of the GPU shader.
"""
import math


def subtract(a, b):
    return tuple(x - y for x, y in zip(a, b))


def scale(v, s):
    return tuple(x * s for x in v)


def length(v):
    return math.sqrt(sum(x * x for x in v))


cases = [
    # name, eye (world), terrain point (world), rest plane Z, displacement
    ('flat', (0, 0, 100), (120, 30, -20), 0, 0),
    ('crest over rock above rest plane', (0, 0, 100), (120, 30, 20), 0, 48),
    ('trough over submerged bed', (0, 0, 100), (120, 30, -60), 0, -40),
    ('crest at terrain contact', (0, 0, 100), (120, 30, 48), 0, 48),
    ('scene in front of trough', (0, 0, 100), (120, 30, -10), 0, -40),
    ('grazing ray', (0, 0, 20), (10000, 100, -5), 0, 10),
    ('camera-relative world coordinates', (-648, -58340, 750), (-194, -58053, 620), 600, 40),
    ('translated flat plane', (-648, -58340, 750), (-194, -58053, 520), 600, 0),
]
print('Case | actual vertical column | old plane | displaced plane (world units)')
for name, eye, scene, rest_z, displacement in cases:
    surface_z = rest_z + displacement
    ray = subtract(scene, eye)
    ray_fraction = (surface_z - eye[2]) / ray[2]
    surface_relative = scale(ray, ray_fraction)
    scene_to_eye = scale(ray, -1)
    angle = scene_to_eye[2]  # dot with the horizontal rest plane's unit normal
    old_plane_w = eye[2] - rest_z
    # Values entering the shader from displaced WPosition / rest STBaseHeight.
    actual_delta = surface_relative[2] + eye[2] - rest_z
    new_plane_w = old_plane_w - actual_delta
    old_fraction = 1 - old_plane_w / angle
    new_fraction = 1 - new_plane_w / angle
    old_vertical = max(0, old_fraction * abs(angle))
    new_vertical = max(0, new_fraction * abs(angle))
    new_ray_length = max(0, new_fraction * length(scene_to_eye))
    expected_vertical = max(0, surface_z - scene[2])
    expected_ray_length = length(subtract(ray, surface_relative)) if ray_fraction <= 1 else 0
    assert math.isclose(new_vertical, expected_vertical, abs_tol=1e-9), name
    assert math.isclose(new_ray_length, expected_ray_length, abs_tol=1e-9), name
    if displacement == 0:
        assert math.isclose(old_vertical, new_vertical, abs_tol=1e-9), name
    print(f'{name} | {expected_vertical:.3f} | {old_vertical:.3f} | {new_vertical:.3f}')
print(f'{len(cases)}/{len(cases)} analytical ray/vertical-depth cases passed.')
print('No optical rendering, float32 GPU evaluation or live engine constants tested.')
