#!/usr/bin/env python3
"""Validate FOMOD schema, payload and every offered combination without Skyrim."""
import argparse, configparser, hashlib, itertools, json, re
from pathlib import Path, PurePosixPath
from lxml import etree as ET
from build_fomod import VERSION

def validate(stage,root):
    parser=ET.XMLParser(resolve_entities=False,no_network=True)
    config=ET.parse(str(stage/'fomod/ModuleConfig.xml'),parser)
    # Mirror the manager's header rewrite, checking the conflicting declaration
    # is removed before its UTF-16 serialization (libxml2 alone tolerates it).
    for name in ['ModuleConfig.xml','info.xml']:
        raw=(stage/'fomod'/name).read_bytes()
        assert raw.startswith(b'<?xml version="1.0" encoding="utf-8"?>')
        rewritten=re.sub(r'^([^>]*)encoding="[^"]+"',r'\1',raw.decode('utf-8'))
        assert 'encoding=' not in rewritten.split('?>',1)[0]
        ET.fromstring(b'\xfe\xff'+rewritten.encode('utf-16-be'),parser)
    schemaDoc=ET.parse(str(root/'tools/fomod/ModConfig5.0.xsd'),parser)
    # The upstream schema contains type=" xs:string" on versionDependency.
    # Normalize this QName's whitespace for libxml2; retain the downloaded file.
    for node in schemaDoc.iter():
        if node.get('type')==' xs:string':node.set('type','xs:string')
    schema=ET.XMLSchema(schemaDoc);schema.assertValid(config)
    info=ET.parse(str(stage/'fomod/info.xml'),parser)
    assert info.findtext('Version')==VERSION and info.find('Version').get('MachineVersion')==VERSION
    files={p.relative_to(stage).as_posix():p.read_bytes() for p in stage.rglob('*') if p.is_file()}
    for node in config.findall('.//plugin/image'):
        path=node.get('path')
        assert path in files and path.startswith('fomod/images/') and '..' not in PurePosixPath(path).parts
        assert files[path].startswith(b'\x89PNG\r\n\x1a\n')
    def item(node):
        assert node.tag=='file','validator deliberately supports this installer\'s explicit file mappings only'
        source=node.get('source').replace('\\','/');dest=node.get('destination',source).replace('\\','/')
        for path in [source,dest]:
            assert path and not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts and ':' not in path
        assert source in files,source
        return dest,files[source]
    for node in config.findall('.//file'):item(node)
    groups=config.findall('.//installStep/optionalFileGroups/group')
    assert len(groups)==5
    for group in groups:
        assert group.get('type') in ['SelectAll','SelectExactlyOne']
        options=group.findall('plugins/plugin')
        assert sum(p.find('typeDescriptor/type').get('name') in ['Required','Recommended'] for p in options)==1
    required=list(config.find('requiredInstallFiles'))
    patterns=config.findall('conditionalFileInstalls/patterns/pattern')
    assert len(patterns)==26
    cases=[]
    # Expected option meanings are independent of the flags emitted by the builder.
    renderers={'Standalone':(0,0),'ENB - water off':(1,0),'Community Shaders - water off':(0,1)}
    foams={'Keep all foam':(0,0),'Remove attached foam only':(1,0),'Remove standalone foam only (BOS)':(0,1),'Remove both (BOS)':(1,1)}
    for selected in itertools.product(*(g.findall('plugins/plugin') for g in groups)):
        names=[p.get('name') for p in selected]
        flags={f.get('name'):f.text for p in selected for f in p.findall('conditionFlags/flag')}
        installs=list(required)
        for pattern in patterns:
            deps=pattern.find('dependencies');assert deps.get('operator')=='And'
            if all(flags.get(d.get('flag'))==d.get('value') for d in deps):installs.extend(pattern.find('files'))
        resolved={}
        for node in installs:
            dest,data=item(node);key=dest.lower();assert key not in resolved,'duplicate installed destination: '+dest
            resolved[key]=data
        ini=[n for n in resolved if n.endswith('/surfacetides.ini')];assert len(ini)==1
        c=configparser.ConfigParser(strict=True);c.read_string(resolved[ini[0]].decode())
        enb,cs=renderers[names[1]];attached,bos=foams[names[2]]
        ice=int(names[3]=='Remove ice decals');bob=int(names[4]=='Bobbing ice floes')
        for section,key,want in [('Compatibility','AllowENB',enb),('Compatibility','AllowCS',cs),('Objects','HideAttachedFoam',attached),('Objects','HideIceDecals',ice),('Objects','FloeBobbing',bob)]:
            assert c.getint(section,key)==want,(names,key)
        assert c.getint('Experimental','ENBWaterIntegration')==0
        assert c.getint('Diagnostics','RippleTrace')==0 and c.getint('Diagnostics','WaterPassTrace')==0 and c.getint('Diagnostics','LogStats')==1
        assert ('surfacetides_foam_swap.ini' in resolved)==bool(bos)
        csPath='skse/plugins/communityshaders/overrides/surfacetides_global.json'
        assert (csPath in resolved)==bool(cs)
        if cs:
            override=json.loads(resolved[csPath]);override.pop('_metadata')
            assert override=={'Replace Original Shaders':{'Water':False},'Disable at Boot':{'UnifiedWater':True,'WaterEffects':True}}
        assert len([n for n in resolved if n.endswith('.dll')])==1
        assert len([n for n in resolved if n.startswith('shaders/')])==5
        assert not any(n.endswith(('.nif','.dds','.esp','.esm','.esl')) for n in resolved)
        assert 'documentation/surfacetides/licenses/upstream-shaders.txt' in resolved
        assert resolved['documentation/surfacetides/license.txt']==(root/'LICENSE').read_bytes()
        assert 'documentation/surfacetides/licenses/skse-menu-framework-api-lgpl-2.1.txt' in resolved
        cases.append({'choices':names[1:],'installed_files':len(resolved),'ini_sha256':hashlib.sha256(resolved[ini[0]]).hexdigest()})
    assert len(cases)==48 and len({c['ini_sha256'] for c in cases})==24
    return {'version':VERSION,'schema_valid':True,'selection_cases_passed':48,'distinct_ini_variants':24,
        'exactly_one_ini_per_selection':True,'conditional_cs_and_bos_files_correct':True,'dependencies_not_bundled':True,
        'manager_encoding_rewrite_checked':True,
        'preview_images_checked':len(config.findall('.//plugin/image')),
        'manager_ui_tested':False,'cases':cases}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stage',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();report=validate(a.stage.resolve(),Path(__file__).resolve().parents[1]);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n')
    print('PASS: schema, all 48 selection paths, exactly one correct INI, conditional files, core payload and notices.')
