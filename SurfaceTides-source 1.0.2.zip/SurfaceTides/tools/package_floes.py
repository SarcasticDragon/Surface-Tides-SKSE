#!/usr/bin/env python3
"""Package opt-in bobbing for all three reviewed ice models and recovery sources."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dll',type=Path,required=True)
parser.add_argument('--output-dir',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
out=args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
dll=args.dll.read_bytes()
assert b'SurfaceTides 0.1.24.3 development (floe jump release)' in dll
assert b'legacy TES worldSpace scan bypassed' in dll
assert b'HideIceDecals=' in dll and b'L1_IceFloesSolidSlush' in dll
build=json.loads((root/'docs/floe-0.1.24.3-build-validation.json').read_text())
assert build['compiled'] and build['dll_sha256']==sha(dll)
assert build['discovery_regression'] and build['accepted_shaders_unchanged']
assert build['runtime_bobbing_implemented'] and not build['enabled_by_default']
assert build['compiled_floe_dependencies_checked']
assert build['portable_test_groups_passed']==45 and build['floe_collision_crest_solver_renderer_unchanged']
assert build['additive_live_controller_carry'] and build['actor_reposition_call_removed']
assert build['early_takeoff_release'] and build['stable_landing_guard'] and build['jump_handler_forwarded']
assert build['velocity_repair_conditional'] and build['stable_local_rider_delta']
assert build['multi_floe_rider_snapshot_implemented'] and build['active_limit']==64
evidence=root/'docs/floe-0.1.24.3-evidence'
regression=json.loads((evidence/'discovery-regression.json').read_text())
assert regression['passed'] and regression['negative_control_0_1_20_rejected']
floeRegression=json.loads((evidence/'floe-discovery-regression.json').read_text())
assert floeRegression['passed'] and floeRegression['negative_control_0_1_20_rejected']
audit=json.loads((root/'docs/floe-0.1.22-evidence/profile-validation.json').read_text())
assert audit['passed'] and audit['geometry_cases']==21 and audit['matched_attached_shapes']==6
baselines={
    'SurfaceTides-0.1.24.2-rider-drift.zip':'c7ef664d383eabcf42f5adc43d4f6b68a89567e32c66744407c8a2b73025b4e3',
    'SurfaceTides-0.1.24.1-rider-locomotion.zip':'2309b1502ac6118a2f8d0c08f8ea4d8885fe2ae6302944a956e5d228a6c6c2cf',
    'SurfaceTides-0.1.24-three-floe-models.zip':'08f728a06543bebd4f7bff41bdd248e59d83b7f13c05dfb412563fb185587c2f',
    'SurfaceTides-0.1.23-floe-crest-update.zip':'0e5807faa0bff15260532548e4705b0930748a3d4ddbb89a038a4c87e40491be',
    'SurfaceTides-0.1.22.1-floe-water-fix.zip':'5bcc6fd8491c83caedc1d2a6f5d822cd350c9e8bd8502f786d3607c4c27eabc4',
    'SurfaceTides-0.1.22-floe-prototype.zip':'3354f0854001c98acc7f608beaf1fefc2ff2eb4bd1cef9882d980882320aa10b',
    'SurfaceTides-0.1.21-ice-slush-update.zip':'af2db00cc9d868b2bef7a97796fe5b894a16b8d5b37996139640b3d6cce47cd2',
    'SurfaceTides-0.1.19.2-topology-update.zip':'6c7e5a345bc520a77ba857166261e80f2bd87f77aaa2829abc4b824784c9e81d',
    'SurfaceTides-0.1.20.1-foam-hotfix.zip':'7fa11087f5543dbd1c4786362eaedb3606240eda7588ee22cbb3129f6e527a6e'}
for name,digest in baselines.items(): assert sha((root/'recovery'/name).read_bytes())==digest
with zipfile.ZipFile(root/'recovery/SurfaceTides-0.1.19.2-topology-update.zip') as z:
    payload={n:z.read(n) for n in z.namelist() if n.startswith('Shaders/')}
for name,data in payload.items(): assert (root/'Data'/name).read_bytes()==data
assert len(payload)==5
payload['SKSE/Plugins/SurfaceTides.dll']=dll
payload['SurfaceTides-ice-README.md']=(root/'docs/FLOES-0.1.24.3.md').read_bytes()
payload['SurfaceTides-LICENSE.txt']=(root/'LICENSE').read_bytes()
assert not any(n.lower().endswith(('.ini','.nif','.dds','.esp','.esl','.esm')) for n in payload)
manifest={'version':'0.1.24.3','in_game_result':'pending','ini_preserved':True,'accepted_shaders_unchanged':True,
          'enabled_by_default':False,'settings':['[Objects] HideIceDecals=1','[Objects] FloeBobbing=1'],
          'legacy_opt_in':'FloeBobbingTest is used only when FloeBobbing is absent; it now enables all three profiles',
          'reference_scope':'Eligible loaded static placements overlapping the active local water field; maximum 64',
          'model_coverage':['landscape/ice/icefloessolid01.nif','landscape/ice/icefloes01.nif','landscape/ice/icefloessolid02.nif'],
          'runtime_bobbing_implemented':True,'runtime_verified':False,'portable_test_groups_passed':45,'prior_bobbing_user_confirmed':True,
          'spatial_water_query_implemented':True,'floe_collision_crest_solver_renderer_unchanged':True,
          'additive_live_controller_carry':True,'actor_reposition_call_removed':True,
          'native_velocity_preserved':True,'velocity_repair_conditional':True,'stable_local_rider_delta':True,
          'early_takeoff_release':True,'stable_landing_guard':True,'jump_handler_forwarded':True,
          'ice_is_slick':'Incompatible with ice bobbing for now; investigation deferred by user',
          'multi_floe_rider_snapshot_implemented':True,'dense_fit_budget_per_frame':8,
          'known_limitation':'Disconnected chunks in one NIF move as one rigid object; separate references move independently',
          'live_floe_controls':{'FloeCrestFollow':1,'FloeExtraLift':4,'FloeResponseSeconds':0.12},
          'files':{n:{'bytes':len(d),'sha256':sha(d)} for n,d in payload.items()}}
encoded=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'docs/floe-0.1.24.3-package.json').write_bytes(encoded)
payload['SurfaceTides-ice-manifest.json']=encoded
mod=out/'SurfaceTides-0.1.24.3-jump-release.zip'
modTemporary=mod.with_suffix('.zip.tmp')
with zipfile.ZipFile(modTemporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()): z.writestr(name,data)
with modTemporary.open('rb') as f: os.fsync(f.fileno())
modTemporary.replace(mod)
with zipfile.ZipFile(mod) as z:
    assert z.testzip() is None
    for name,data in payload.items(): assert z.read(name)==data
(root/'recovery'/mod.name).write_bytes(mod.read_bytes())
source=out/'SurfaceTides-source-menu.zip'
skip={'.git','__pycache__','build','out','vcpkg_installed'}
sourceTemporary=source.with_suffix('.zip.tmp')
with zipfile.ZipFile(sourceTemporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if not path.is_file() or any(p in skip or p.startswith('build-') for p in rel.parts): continue
        if path.suffix.lower() in {'.pyc','.obj','.pdb','.dll','.lib','.nif','.dds'}: continue
        z.write(path,'SurfaceTides/'+rel.as_posix())
with sourceTemporary.open('rb') as f: os.fsync(f.fileno())
sourceTemporary.replace(source)
with zipfile.ZipFile(source) as z:
    assert z.testzip() is None
    assert z.read('SurfaceTides/recovery/'+mod.name)==mod.read_bytes()
    for name in baselines: assert sha(z.read('SurfaceTides/recovery/'+name))==baselines[name]
    for name in ['src/plugin/Foam.cpp','src/plugin/Floes.cpp','src/core/FloeMotion.cpp','include/surfacetides/FloeMotion.hpp',
                 'include/surfacetides/FloeManagement.hpp','tests/FloeMotionTests.cpp',
                 'include/surfacetides/FloeRider.hpp','src/plugin/Hooks.cpp','src/plugin/Bridge.hpp','docs/FLOES-0.1.24.3.md','docs/RESUME-0.1.24.3.md']:
        assert z.read('SurfaceTides/'+name)==(root/name).read_bytes()
for path in [mod,source]: print(path.name,path.stat().st_size,sha(path.read_bytes()))
print('Verified DLL overlay, INI preservation, unchanged water assets, source checkpoint and accepted rollbacks.')
