#!/usr/bin/env python3
"""Validate contact-fade isolation against the accepted 0.1.19.1 shader.

Host DXC/SM6 comparison only; does not run Skyrim or native FXC/SM5.
"""
import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dxc', required=True, type=Path)
parser.add_argument('--reference', required=True, type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
shader_dir = root / 'Data/Shaders/SurfaceTides'
baseline = (shader_dir / 'Water.hlsl').read_bytes()
candidate = (root / 'packaging/underwater-contact-isolation/Water.hlsl').read_bytes()
assert hashlib.sha256(baseline).hexdigest() == '1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e'
assert candidate == baseline.replace(b'#define ST_SHORE_CONTACT_BLEND 1', b'#define ST_SHORE_CONTACT_BLEND 0')

descriptors = [0x0002, 0x001e, 0x005e, 0x00df, 0x071e, 0x075e, 0x003e, 0x015e,
               0x081e, 0x101e, 0x381e, 0x401e, 0x471e, 0x5000, 0x5802, 0x5001,
               0x031e, 0x011e, 0x035e, 0x0802, 0x0842, 0x410e, 0x430e, 0x011f,
               0x3002, 0x0106, 0x0116, 0x4802, 0x581e, 0x0042, 0x0742, 0x475e, 0x405e]
flags = ['VC', 'NORMAL_TEXCOORD', 'REFLECTIONS', 'REFRACTIONS', 'DEPTH', 'INTERIOR',
         'WADING', 'VERTEX_ALPHA_DEPTH', 'CUBEMAP', 'FLOWMAP', 'BLEND_NORMALS']
stages = [('VSHADER', 'vs_6_0'), ('CONTROL_SHADER', 'vs_6_0'), ('HSHADER', 'hs_6_0'),
          ('DSHADER', 'ds_6_0'), ('PSHADER', 'ps_6_0')]
hashes = {}
listings = {}
total = 0
with tempfile.TemporaryDirectory(prefix='underwater-contact-') as directory:
    temp = Path(directory)
    shutil.copytree(shader_dir, temp, dirs_exist_ok=True)
    subprocess.run([str(args.reference.resolve()), '--headers', str(temp)], check=True)
    for variant, code in [('baseline', baseline), ('candidate', candidate)]:
        (temp / 'Water.hlsl').write_bytes(code)
        for descriptor in descriptors:
            defines = [name + '=1' for bit, name in enumerate(flags) if descriptor & (1 << bit)]
            technique = descriptor >> 11
            defines += (['SPECULAR=1', f'NUM_SPECULAR_LIGHTS={technique}'] if technique < 8 else
                        [{8: 'UNDERWATER', 9: 'LOD', 10: 'STENCIL', 11: 'SIMPLE'}[technique] + '=1'])
            for stage, target in stages:
                command = [str(args.dxc.resolve()), str(temp / 'Water.hlsl'), '-T', target,
                           '-E', 'main', '-HV', '2016', '-Fo', str(temp / 'shader.dxil'),
                           '-Fc', str(temp / 'shader.txt')]
                for define in defines + [stage + '=1', f'ST_PIXEL_DESCRIPTOR={descriptor}']:
                    command += ['-D', define]
                result = subprocess.run(command, capture_output=True, text=True)
                if result.returncode:
                    raise RuntimeError(f'{variant} {descriptor:X} {stage}: {result.stdout}{result.stderr}')
                hashes[variant, descriptor, stage] = hashlib.sha256((temp / 'shader.dxil').read_bytes()).hexdigest()
                if stage == 'PSHADER':
                    listings[variant, descriptor] = (temp / 'shader.txt').read_text()
                total += 1

changed = []
for descriptor in descriptors:
    technique = descriptor >> 11
    has_contact = (bool(descriptor & 0x10) and bool(descriptor & 0x8)
                   and not descriptor & 0x80 and technique in [0, 11])
    for stage, _ in stages:
        differs = hashes['baseline', descriptor, stage] != hashes['candidate', descriptor, stage]
        assert differs == (has_contact and stage == 'PSHADER'), f'Unexpected change: {descriptor:X} {stage}'
    if has_contact:
        changed.append(f'{descriptor:04X}')
    before, after = (listings[variant, descriptor] for variant in ['baseline', 'candidate'])
    assert before.split('; Resource Bindings:')[1].split('target datalayout')[0] == after.split('; Resource Bindings:')[1].split('target datalayout')[0], f'PS resource change: {descriptor:X}'
    assert ('@dx.op.discard' in before) == ('@dx.op.discard' in after)
    assert ('SV_Depth' in before) == ('SV_Depth' in after)

print(f'{total}/{total} DXC SM6 compilations passed across {len(descriptors)} descriptors and five stages.')
print('All geometry, underwater, stencil/motion, LOD, additional-light and non-contact PS outputs match the accepted baseline byte-for-byte.')
print('Contact-fade pixel permutations changed: ' + ', '.join(changed))
print('All resource tables, discard presence and depth-output presence unchanged; PS015E depth correction retained.')
print('Only ST_SHORE_CONTACT_BLEND changes from 1 to 0. No DLL, INI, menu, solver, geometry or normal-math changes.')
print('Host compilation only. Native Windows SM5 and in-game results remain unverified.')
