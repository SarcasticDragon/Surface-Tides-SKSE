#!/usr/bin/env python3
"""Package the reviewed slush filter, preserving INI and accepted water assets."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dll',type=Path,required=True)
parser.add_argument('--output-dir',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
out=args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
dll=args.dll.read_bytes()
assert b'SurfaceTides 0.1.21 development (reviewed ice slush filter)' in dll
assert b'legacy TES worldSpace scan bypassed' in dll
assert b'HideIceDecals=' in dll and b'L1_IceFloesSolidSlush' in dll
build=json.loads((root/'docs/ice-0.1.21-build-validation.json').read_text())
assert build['compiled'] and build['dll_sha256']==sha(dll)
assert build['discovery_regression'] and build['accepted_shaders_unchanged']
assert not build['runtime_bobbing_enabled']
evidence=root/'docs/ice-0.1.21-evidence'
regression=json.loads((evidence/'discovery-regression.json').read_text())
assert regression['passed'] and regression['negative_control_0_1_20_rejected']
audit=json.loads((evidence/'profile-validation.json').read_text())
assert audit['passed'] and audit['geometry_cases']==17 and audit['matched_attached_shapes']==4
baselines={
    'SurfaceTides-0.1.19.2-topology-update.zip':'6c7e5a345bc520a77ba857166261e80f2bd87f77aaa2829abc4b824784c9e81d',
    'SurfaceTides-0.1.20.1-foam-hotfix.zip':'7fa11087f5543dbd1c4786362eaedb3606240eda7588ee22cbb3129f6e527a6e'}
for name,digest in baselines.items(): assert sha((root/'recovery'/name).read_bytes())==digest
with zipfile.ZipFile(root/'recovery/SurfaceTides-0.1.19.2-topology-update.zip') as z:
    payload={n:z.read(n) for n in z.namelist() if n.startswith('Shaders/')}
for name,data in payload.items(): assert (root/'Data'/name).read_bytes()==data
assert len(payload)==5
payload['SKSE/Plugins/SurfaceTides.dll']=dll
payload['SurfaceTides-ice-README.md']=(root/'docs/ICE-0.1.21.md').read_bytes()
payload['SurfaceTides-LICENSE.txt']=(root/'LICENSE').read_bytes()
assert not any(n.lower().endswith(('.ini','.nif','.dds','.esp','.esl','.esm')) for n in payload)
manifest={'version':'0.1.21','in_game_result':'pending','ini_preserved':True,'accepted_shaders_unchanged':True,
          'enabled_by_default':False,'setting':'[Objects] HideIceDecals=1',
          'model_coverage':['landscape/ice/icefloessolid01.nif'],
          'runtime_bobbing_enabled':False,'portable_test_groups_passed':30,
          'files':{n:{'bytes':len(d),'sha256':sha(d)} for n,d in payload.items()}}
encoded=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'docs/ice-0.1.21-package.json').write_bytes(encoded)
payload['SurfaceTides-ice-manifest.json']=encoded
mod=out/'SurfaceTides-0.1.21-ice-slush-update.zip'
with zipfile.ZipFile(mod,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()): z.writestr(name,data)
with zipfile.ZipFile(mod) as z:
    assert z.testzip() is None
    for name,data in payload.items(): assert z.read(name)==data
(root/'recovery'/mod.name).write_bytes(mod.read_bytes())
source=out/'SurfaceTides-source-menu.zip'
skip={'.git','__pycache__','build','out','vcpkg_installed'}
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if not path.is_file() or any(p in skip or p.startswith('build-') for p in rel.parts): continue
        if path.suffix.lower() in {'.pyc','.obj','.pdb','.dll','.lib','.nif','.dds'}: continue
        z.write(path,'SurfaceTides/'+rel.as_posix())
with zipfile.ZipFile(source) as z:
    assert z.testzip() is None
    assert z.read('SurfaceTides/recovery/'+mod.name)==mod.read_bytes()
    for name in baselines: assert sha(z.read('SurfaceTides/recovery/'+name))==baselines[name]
    for name in ['src/plugin/Foam.cpp','src/core/FloeMotion.cpp','include/surfacetides/FloeMotion.hpp',
                 'tests/FloeMotionTests.cpp','docs/ICE-0.1.21.md']:
        assert z.read('SurfaceTides/'+name)==(root/name).read_bytes()
for path in [mod,source]: print(path.name,path.stat().st_size,sha(path.read_bytes()))
print('Verified DLL overlay, INI preservation, unchanged water assets, source checkpoint and accepted rollbacks.')
