#!/usr/bin/env python3
"""Check diagnostic overlay scope against the delivered shoreline-r1 shader.

DXC/SM6 compilation and byte/resource comparisons, not Windows SM5 execution.
"""
import argparse
import hashlib
import pathlib
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--dxc', required=True)
parser.add_argument('--reference', required=True)
parser.add_argument('--baseline-water', required=True, help='Delivered shoreline-r1 Water.hlsl')
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
source = root / 'Data/Shaders/SurfaceTides'
baseline = pathlib.Path(args.baseline_water).read_bytes()
current = (source / 'Water.hlsl').read_bytes()
dxc = str(pathlib.Path(args.dxc).resolve())
reference = str(pathlib.Path(args.reference).resolve())
descriptors = [0x0002, 0x001e, 0x005e, 0x00df, 0x071e, 0x075e, 0x003e, 0x015e,
               0x081e, 0x101e, 0x381e, 0x401e, 0x471e, 0x5000, 0x5802, 0x5001,
               0x031e, 0x011e, 0x035e, 0x0802, 0x0842, 0x410e, 0x430e, 0x011f,
               0x3002, 0x0106]
flags = ['VC', 'NORMAL_TEXCOORD', 'REFLECTIONS', 'REFRACTIONS', 'DEPTH', 'INTERIOR',
         'WADING', 'VERTEX_ALPHA_DEPTH', 'CUBEMAP', 'FLOWMAP', 'BLEND_NORMALS']
stages = [('VSHADER', 'vs_6_0'), ('CONTROL_SHADER', 'vs_6_0'), ('HSHADER', 'hs_6_0'),
          ('DSHADER', 'ds_6_0'), ('PSHADER', 'ps_6_0')]
variants = {'r1': None, 'default': (1, 0), 'A': (2, 0), 'B': (1, 1)}
hashes = {}
resources = {}
total = 0
with tempfile.TemporaryDirectory(prefix='shore-diagnostics-') as directory:
    temp = pathlib.Path(directory)
    shutil.copytree(source, temp, dirs_exist_ok=True)
    subprocess.run([reference, '--headers', str(temp)], check=True)
    for variant, settings in variants.items():
        # Exercise the actual packaged default definitions, not command-line overrides.
        code = baseline if settings is None else current.replace(
            b'#define ST_SHORE_REFRACTION 1',
            f'#define ST_SHORE_REFRACTION {settings[0]}'.encode()).replace(
            b'#define ST_DIAGNOSTIC_NO_SSR 0',
            f'#define ST_DIAGNOSTIC_NO_SSR {settings[1]}'.encode())
        (temp / 'Water.hlsl').write_bytes(code)
        for descriptor in descriptors:
            defines = [name + '=1' for bit, name in enumerate(flags) if descriptor & (1 << bit)]
            technique = descriptor >> 11
            defines += (['SPECULAR=1', f'NUM_SPECULAR_LIGHTS={technique}'] if technique < 8 else
                        [{8: 'UNDERWATER', 9: 'LOD', 10: 'STENCIL', 11: 'SIMPLE'}[technique] + '=1'])
            for stage, target in stages:
                command = [dxc, str(temp / 'Water.hlsl'), '-T', target, '-E', 'main', '-HV', '2016',
                           '-Fo', str(temp / 'shader.dxil'), '-Fc', str(temp / 'shader.txt')]
                for define in defines + [stage + '=1', f'ST_PIXEL_DESCRIPTOR={descriptor}']:
                    command += ['-D', define]
                result = subprocess.run(command, capture_output=True, text=True)
                if result.returncode:
                    raise RuntimeError(f'{variant} {descriptor:X} {stage}: {result.stdout}{result.stderr}')
                hashes[variant, descriptor, stage] = hashlib.sha256((temp / 'shader.dxil').read_bytes()).hexdigest()
                if stage == 'PSHADER':
                    listing = (temp / 'shader.txt').read_text()
                    resources[variant, descriptor] = listing.split('; Resource Bindings:')[1].split('target datalayout')[0]
                total += 1

changed = {'A': [], 'B': []}
for descriptor in descriptors:
    for stage, _ in stages:
        original = hashes['r1', descriptor, stage]
        assert hashes['default', descriptor, stage] == original, f'Default changed {descriptor:X} {stage}'
        target_a = stage == 'PSHADER' and descriptor >> 11 == 0 and descriptor & 0x18 == 0x18 and not descriptor & 0x80
        target_b = stage == 'PSHADER' and descriptor >> 11 == 0 and descriptor & 0x104 == 0x104
        for variant, target in [('A', target_a), ('B', target_b)]:
            different = hashes[variant, descriptor, stage] != original
            assert different == target, f'Unexpected {variant} scope {descriptor:X} {stage}'
            if different:
                changed[variant].append(f'{descriptor:04X}')
        if target_b:
            assert 'SSRReflectionTex' in resources['r1', descriptor]
            assert 'SSRReflectionTex' not in resources['B', descriptor]
            assert 'CubeMapTex' in resources['B', descriptor]
        if target_a:
            assert 'RefractionTex' in resources['A', descriptor]

print(f'{total}/{total} DXC SM6 shader compilations passed across {len(descriptors)} descriptors.')
print(f'Default source: {len(descriptors) * len(stages)} byte-identical DXIL comparisons to delivered r1.')
print('All geometry stages and underwater/stencil/non-target PS outputs remain byte-identical in both overlays.')
for variant, entries in changed.items():
    print(f'{variant} changed PS: ' + ', '.join(entries))
print('B removes SSR texture bindings and retains cubemap bindings; A retains the refraction texture.')
print('Scope/compilation only; Windows SM5, live resource bindings and visual outcome need in-game testing.')
