#!/usr/bin/env python3
"""Package the 1.0.2 water-retention candidate, INI, FOMOD and full source."""
import argparse,configparser,difflib,hashlib,json,zipfile
from pathlib import Path
from package_release import write_zip
from validate_fomod import validate

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ['stage','baseline-source','output-dir']:p.add_argument('--'+arg,type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[1]
    evidence=root/'docs/water-retention-1.0.2-evidence';evidence.mkdir(parents=True,exist_ok=True)
    sha=lambda b:hashlib.sha256(b).hexdigest()
    assert sha(a.baseline_source.read_bytes())=='ce6e511c9bff075964184333a5aa3aaf1a33c78d11a8b3b1f94d5a400d885a12'
    changed=[];patch=[];checked=0
    with zipfile.ZipFile(a.baseline_source) as z:
        oldRuntime=set()
        for name in z.namelist():
            rel=name.removeprefix('SurfaceTides/')
            if name.endswith('/'):continue
            if rel.startswith(('src/','include/')):oldRuntime.add(rel)
            if rel.startswith(('src/','include/','Data/','recovery/')) or rel=='CMakeLists.txt':
                old=z.read(name);new=(root/rel).read_bytes();checked+=1
                if new!=old:
                    changed.append(rel)
                    patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile=rel,tofile=rel))
        assert set(changed)=={'CMakeLists.txt','src/plugin/Main.cpp','src/plugin/Menu.cpp',
            'src/plugin/Game.cpp','Data/SKSE/Plugins/SurfaceTides.ini'},changed
        currentRuntime={f.relative_to(root).as_posix() for d in ['src','include'] for f in (root/d).rglob('*') if f.is_file()}
        assert currentRuntime-oldRuntime=={'include/surfacetides/WaterSelection.hpp'}
        assert not oldRuntime-currentRuntime
        oldini=configparser.ConfigParser();oldini.read_string(z.read('SurfaceTides/Data/SKSE/Plugins/SurfaceTides.ini').decode())
        newini=configparser.ConfigParser();newini.read(root/'Data/SKSE/Plugins/SurfaceTides.ini')
        assert {s:dict(oldini[s]) for s in oldini}=={s:dict(newini[s]) for s in newini}
    rel='include/surfacetides/WaterSelection.hpp'
    patch.extend(difflib.unified_diff([], (root/rel).read_text().splitlines(True),fromfile='/dev/null',tofile=rel))
    (evidence/'source-changes.patch').write_text(''.join(patch))
    tests=(evidence/'portable-tests.txt').read_text()
    for line in ['22/22 passed','24/24 passed','7/7 passed']:assert line in tests,line
    assert 'FAIL ' not in tests
    binary=(evidence/'binary-inspection.txt').read_text()
    for token in ['IMAGE_FILE_MACHINE_AMD64','SKSEPlugin_Load','SKSEPlugin_Version']:assert token in binary,token
    report=validate(a.stage,root)
    payload={f.relative_to(a.stage).as_posix():f.read_bytes() for f in a.stage.rglob('*') if f.is_file()}
    dll=payload['core/SKSE/Plugins/SurfaceTides.dll']
    assert dll[:2]==b'MZ' and b'SurfaceTides 1.0.2 (nearby water retention)' in dll
    report.update({'baseline_source_sha256':sha(a.baseline_source.read_bytes()),'baseline_files_compared':checked,
        'changed_existing_runtime_files':changed,'new_runtime_files':[rel],
        'default_ini_values_unchanged':True,'shaders_solver_removal_bobbing_unchanged':True,
        'portable_test_groups_passed':53,'dll_bytes':len(dll),'dll_sha256':sha(dll),
        'in_game_result':'pending user Ragged Flagon test; prior 1.0.1 accepted'})
    (evidence/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    full=out/'SurfaceTides-1.0.2-FOMOD.zip';write_zip(full,sorted(payload.items()))
    overlay={n.removeprefix('core/'):b for n,b in payload.items() if n.startswith('core/Documentation/')}
    overlay['SKSE/Plugins/SurfaceTides.dll']=dll
    overlay['Documentation/SurfaceTides/WATER-RETENTION-1.0.2.md']=(root/'docs/WATER-RETENTION-1.0.2.md').read_bytes()
    assert not any(n.endswith(('.ini','.json','.nif','.dds','.esp','.esm','.esl','.hlsl')) for n in overlay)
    update=out/'SurfaceTides-1.0.2-water-retention-update.zip';write_zip(update,sorted(overlay.items()))
    ini=out/'SurfaceTides.ini';ini.write_bytes((root/'Data/SKSE/Plugins/SurfaceTides.ini').read_bytes())
    for f in [update,full]:(root/'recovery'/f.name).write_bytes(f.read_bytes())
    (evidence/'packages.json').write_text(json.dumps({f.name:{'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in [ini,update,full]},indent=2)+'\n')
    skip={'.git','__pycache__','build','out','vcpkg_installed'}
    def source_files():
        for f in sorted(root.rglob('*')):
            rel=f.relative_to(root)
            if not f.is_file() or any(s in skip or s.startswith('build-') for s in rel.parts):continue
            if f.suffix.lower() in {'.pyc','.obj','.pdb','.dll','.lib','.nif','.dds'}:continue
            yield 'SurfaceTides/'+rel.as_posix(),f.read_bytes()
    source=out/'SurfaceTides-source-menu.zip';write_zip(source,source_files())
    with zipfile.ZipFile(source) as z:
        for name,data in source_files():assert z.read(name)==data
        for f in [update,full]:assert z.read('SurfaceTides/recovery/'+f.name)==f.read_bytes()
    for f in [ini,update,full,source]:print(f.name,f.stat().st_size,sha(f.read_bytes()))
    print('PASS: scoped source changes, unchanged defaults/recoveries, x64 SKSE DLL, 53 test groups, 48 FOMOD choices, full source and archive integrity.')

if __name__=='__main__':main()
