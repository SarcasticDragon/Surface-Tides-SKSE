#include "surfacetides/Simulation.hpp"
#include <iostream>
#include <cmath>
#include <algorithm>
int main() {
 for(bool river:{false,true}) {
  st::Settings s; s.wind=5; st::Surface surface(s); surface.reset({16020,-44200},-286);
  if(river) { std::vector<std::uint8_t> mask(192*192,0); for(int y=0;y<192;++y) for(int x=0;x<192;++x) if(std::abs(x-96-20*std::sin(y*.04))<22) mask[y*192+x]=1; surface.setWetMask(mask); }
  float peak=0; for(int i=0;i<30*60;++i) { surface.advance(1.0/60); for(auto c:surface.cells()) peak=std::max(peak,std::abs(c.height)); }
  std::cout << (river?"river mask":"open patch") << " 192x192 30s peak=" << peak << " clipped=" << surface.diagnostics().clippedCells << " finite=" << surface.finite() << '\n';
  if(!surface.finite() || surface.diagnostics().clippedCells) return 1;
 }
}
