#!/usr/bin/env python3
"""Package the trace DLL with the exact r4 comparison shader and its sources."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--build-dir', required=True, type=Path)
parser.add_argument('--output-dir', required=True, type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
output = args.output_dir.resolve()
output.mkdir(parents=True, exist_ok=True)
dll = (args.build_dir / 'SurfaceTides.dll').read_bytes()
if dll[:2] != b'MZ':
    raise SystemExit('Expected a newly linked Windows DLL.')
pe = struct.unpack_from('<I', dll, 0x3c)[0]
if (dll[pe:pe+4] != b'PE\0\0' or struct.unpack_from('<H', dll, pe+4)[0] != 0x8664
        or not struct.unpack_from('<H', dll, pe+22)[0] & 0x2000):
    raise SystemExit('Expected x64 PE DLL.')
if (b'SurfaceTides 0.1.18 development (native water metadata trace)' not in dll
        or b'fieldSource={}' not in dll):
    raise SystemExit('Wrong DLL version/build: expected native metadata trace 0.1.18.')
shader = (root / 'packaging/native-water-trace/Water.hlsl').read_bytes()
r4 = '3f4779120b62d21c41f7060ac57c01d4f5d48a046f34393f62fffa0ca85e8a21'
if hashlib.sha256(shader).hexdigest() != r4:
    raise SystemExit('Water.hlsl is not the known r4 comparison payload.')
payload = {
    'SKSE/Plugins/SurfaceTides.dll': dll,
    'Shaders/SurfaceTides/Water.hlsl': shader,
    'SurfaceTides-native-water-trace-README.md': (root / 'docs/NATIVE-WATER-TRACE.md').read_bytes(),
}
for path in sorted((root / 'licenses').rglob('*')):
    if path.is_file():
        payload['SKSE/Plugins/SurfaceTides-licenses/' + str(path.relative_to(root / 'licenses'))] = path.read_bytes()
for name in ['LICENSE', 'THIRD_PARTY.md']:
    payload['SKSE/Plugins/SurfaceTides-licenses/' + name] = (root / name).read_bytes()
manifest = {
    'version': '0.1.18-native-water-trace',
    'purpose': 'Bounded metadata diagnostic, restores full r4 rendering; not a claimed artifact fix',
    'ini_included': False,
    'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
              for name, data in payload.items()},
}
encoded = (json.dumps(manifest, indent=2) + '\n').encode()
(root / 'docs/native-water-trace-package.json').write_bytes(encoded)
payload['SurfaceTides-native-water-trace-manifest.json'] = encoded
mod = output / 'SurfaceTides-0.1.18-native-water-trace.zip'
with zipfile.ZipFile(mod, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(payload.items()):
        archive.writestr(name, data)
source = output / 'SurfaceTides-source-native-water-trace.zip'
skip = {'.git', '__pycache__', 'build', 'out', 'vcpkg_installed'}
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if not path.is_file() or any(p in skip or p.startswith('build-') for p in relative.parts):
            continue
        if path.suffix in {'.pyc', '.obj', '.pdb', '.dll', '.lib'}:
            continue
        archive.write(path, 'SurfaceTides/' + str(relative))
for path in [mod, source]:
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise SystemExit(f'Archive validation failed: {path}')
    print(f'{path.name}: {path.stat().st_size} bytes SHA256 {hashlib.sha256(path.read_bytes()).hexdigest()}')
