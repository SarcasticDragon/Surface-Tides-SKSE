#!/usr/bin/env python3
"""Check the CS opt-in build against the user-tested 0.1.24.3 baseline."""
import argparse, difflib, hashlib, json, re, subprocess, zipfile
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--workspace',type=Path,required=True)
work=p.parse_args().workspace.resolve()
root=Path(__file__).resolve().parents[1]
evidence=root/'docs/cs-0.1.25-evidence'; evidence.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
run=lambda *args:subprocess.check_output([str(x) for x in args],text=True)
llvm=work/'work-tools/topology-fresh/llvm-mingw-20260826-ucrt-ubuntu-22.04-x86_64/bin'
build=work/'build-topology-01192-final'
baseline=work/'deliverables-riders-01243/SurfaceTides-source-menu.zip'
assert sha(baseline.read_bytes())=='790c7186fd105985f0d5e8af1e6da3c131edfa3e23cd4e7f6805a3478a0bba00'
changed=[]; patch=[]
with zipfile.ZipFile(baseline) as z:
    for path in sorted(root.rglob('*')):
        if not path.is_file(): continue
        rel=path.relative_to(root).as_posix()
        if rel.split('/')[0] not in ['src','include','tests','vendor','Data'] and rel!='CMakeLists.txt': continue
        before=z.read('SurfaceTides/'+rel); after=path.read_bytes()
        if before!=after:
            changed.append(rel)
            patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='0.1.24.3/'+rel,tofile='0.1.25/'+rel))
    assert set(changed)=={'CMakeLists.txt','Data/SKSE/Plugins/SurfaceTides.ini','src/plugin/Bridge.hpp',
        'src/plugin/Main.cpp','src/plugin/Game.cpp','src/plugin/Menu.cpp','src/plugin/Hooks.cpp',
        'src/plugin/Renderer.cpp','src/plugin/PipelineTrace.cpp'},changed
    for name in ['Hooks.cpp','Renderer.cpp','PipelineTrace.cpp']:
        current=(root/'src/plugin'/name).read_text().replace('rendererCoexistence()','config.allowENB')
        assert current==z.read('SurfaceTides/src/plugin/'+name).decode(),name
    main=(root/'src/plugin/Main.cpp').read_text()
    old=z.read('SurfaceTides/src/plugin/Main.cpp').decode()
    start=main.index('        if (const auto cs ='); end=main.index('        const auto directory',start)
    oldStart=old.index('        if (GetModuleHandleW(L"CommunityShaders.dll"))'); oldEnd=old.index('        const auto directory',oldStart)
    normalized=main[:start]+old[oldStart:oldEnd]+main[end:]
    normalized=normalized.replace('{0,1,25,0}','{0,1,24,3}').replace('0.1.25 development (CS coexistence)','0.1.24.3 development (floe jump release)')
    assert normalized==old,'unrelated startup or ENB policy changed'
    assert 'if (!config.allowCS)' in main and 'config.allowENB=false;' in main and 'config.enbMeshInput=false;' in main
    assert 'communityShadersActive=true;' in main and 'does not query live feature state' in main
    assert 'bool allowCS = false;' in (root/'src/plugin/Bridge.hpp').read_text()
    assert 'number(L"Compatibility",L"AllowCS",0)' in (root/'src/plugin/Game.cpp').read_text()
    # Preserve every archived rollback, including the just-accepted jump build.
    for name in z.namelist():
        if name.startswith('SurfaceTides/recovery/') and name.endswith('.zip'):
            assert (root/name.removeprefix('SurfaceTides/')).read_bytes()==z.read(name),name
(evidence/'source-changes.patch').write_text(''.join(patch))
config=root/'optional/cs-coexistence/SKSE/Plugins/CommunityShaders/Overrides/SurfaceTides_Global.json'
override=json.loads(config.read_text()); metadata=override.pop('_metadata')
assert metadata['enabled'] is True
assert override=={'Replace Original Shaders':{'Water':False},'Disable at Boot':{'UnifiedWater':True,'WaterEffects':True}}
# These are configuration data, not a CS binary interface or copied CS code.
reference=work/'work/cs-coexistence-0125'
commit=json.loads((reference/'commit.json').read_text())
referenceFiles={p.relative_to(reference/'reference').as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
                for p in sorted((reference/'reference').rglob('*')) if p.is_file()}
(evidence/'cs-source-reference.json').write_text(json.dumps({'repository':'https://github.com/community-shaders/skyrim-community-shaders',
    **commit,'files':referenceFiles,'source_copied_into_plugin':False},indent=2)+'\n')
last=(work/'work/ice-inspection/portable/Testing/Temporary/LastTest.log').read_text()
assert '22/22 passed' in last and '23/23 passed' in last and len(re.findall(r'^PASS ',last,re.M))==45
(evidence/'portable-groups.txt').write_text(last)
for name in ['windows-build.txt','portable-build.txt','portable-tests.txt']:
    (evidence/name).write_bytes((reference/name).read_bytes())
binary=build/'SurfaceTides.dll'; data=binary.read_bytes()
inspection=run(llvm/'llvm-readobj','--file-headers','--coff-exports','--coff-imports',binary)
assert 'IMAGE_FILE_MACHINE_AMD64' in inspection and 'SKSEPlugin_Load' in inspection and 'SKSEPlugin_Version' in inspection
assert b'SurfaceTides 0.1.25 development (CS coexistence)' in data
assert 'Name: CommunityShaders.dll' not in inspection and 'Name: enbseries.dll' not in inspection
(evidence/'binary-inspection.txt').write_text(inspection)
for name in ['Foam','Floes']:
    run('python3',root/'tools/validate_foam_discovery.py','--nm',llvm/'llvm-nm',
        '--old-object',work/'work/foam-crash-01201/Foam-0.1.20.cpp.obj',
        '--new-object',build/f'CMakeFiles/SurfaceTides.dir/src/plugin/{name}.cpp.obj',
        '--output',evidence/f'{name.lower()}-discovery-regression.json')
symbols=run(llvm/'llvm-nm','-u',build/'CMakeFiles/SurfaceTides.dir/src/plugin/Floes.cpp.obj')
assert '?SetPosition@Actor@RE@@' not in symbols and '?SetPosition@TESObjectREFR@RE@@' not in symbols
with zipfile.ZipFile(root/'recovery/SurfaceTides-0.1.19.2-topology-update.zip') as z:
    shaders=[n for n in z.namelist() if n.startswith('Shaders/')]
    assert len(shaders)==5
    for name in shaders: assert (root/'Data'/name).read_bytes()==z.read(name)
report={'version':'0.1.25','compiled':True,'dll_bytes':len(data),'dll_sha256':sha(data),
    'format':'Windows AMD64 MSVC ABI; clang-cl 23.1','exports':['SKSEPlugin_Load','SKSEPlugin_Version'],
    'cs_coexistence_opt_in':True,'cs_enabled_by_default':False,'cs_live_settings_queried':False,
    'cs_override_sha256':sha(config.read_bytes()),'cs_override':override,'cs_reference_commit':commit['sha'],
    'portable_test_groups_passed':45,'discovery_regression':True,'source_changed_files':changed,
    'accepted_floe_foam_solver_code_unchanged':True,'accepted_shaders_unchanged':True,
    'enb_branch_unchanged':True,'draw_algorithms_unchanged':True,'no_cs_or_enb_binary_dependency':True,
    'cs_runtime_result':'pending','user_accepted_baseline':'0.1.24.3; jump release reported effective; occasional prior drift accepted',
    'ice_is_slick':'Incompatible with ice bobbing for now; integration deferred'}
(root/'docs/cs-0.1.25-build-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'dll_bytes':len(data),'dll_sha256':sha(data),'portable_groups':45,'changed_files':changed}))
