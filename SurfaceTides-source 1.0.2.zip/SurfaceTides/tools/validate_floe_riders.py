#!/usr/bin/env python3
"""Validate the compiled rider hotfix and preserve its comparison evidence."""
import argparse, difflib, hashlib, json, re, subprocess, zipfile
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--workspace',type=Path,required=True)
a=p.parse_args(); work=a.workspace.resolve(); root=Path(__file__).resolve().parents[1]
evidence=root/'docs/floe-0.1.24.3-evidence'; evidence.mkdir(exist_ok=True)
llvm=work/'work-tools/topology-fresh/llvm-mingw-20260826-ucrt-ubuntu-22.04-x86_64/bin'
build=work/'build-topology-01192-final'
obj=build/'CMakeFiles/SurfaceTides.dir/src/plugin/Floes.cpp.obj'
sha=lambda b:hashlib.sha256(b).hexdigest()
run=lambda *args:subprocess.check_output([str(x) for x in args],text=True)
symbols=run(llvm/'llvm-nm','-u',obj)
for name in ['?GetCharController@Actor@RE@@','?GetCell@TES@RE@@','?GetWaterHeight@TES@RE@@',
             '?GetSkyCell@TESWorldSpace@RE@@','?GetbhkWorld@TESObjectCELL@RE@@','?SetMotionType@NiAVObject@RE@@']:
    assert name in symbols,name
for name in ['?ForEachReference@TES@RE@@','?ForEachReferenceInRange@TES@RE@@',
             '?SetPosition@Actor@RE@@','?SetPosition@TESObjectREFR@RE@@','?SetMotionType@TESObjectREFR@RE@@','?AddChange@TESForm@RE@@']:
    assert name not in symbols,name
(evidence/'floe-dependencies.txt').write_text(symbols)
asm=run(llvm/'llvm-objdump','-dr',obj)
m=re.search(r'^[^\n]*<\?carry@[^\n>]*>:\n(.*?)(?=\n\n)',asm,re.M|re.S)
assert m,'carry disassembly absent'
carry=m.group(0); (evidence/'rider-disassembly.txt').write_text(carry)
hooksAsm=run(llvm/'llvm-objdump','-dr',build/'CMakeFiles/SurfaceTides.dir/src/plugin/Hooks.cpp.obj')
jump=re.search(r'^[^\n]*<\?jumpButton@[^\n>]*>:\n(.*?)(?=\n\n)',hooksAsm,re.M|re.S)
assert jump,'jump observer disassembly absent'
jump=jump.group(0)
assert '?noteFloeJumpRequest@' in jump and '?originalJumpButton@' in jump
assert 'jmpq' in jump,'original jump handler not forwarded'
(evidence/'jump-observer-disassembly.txt').write_text(jump)
slots=re.findall(r'callq\s+\*0x([0-9a-f]+)\(',carry)
assert slots==['10','30','18','30','38'],slots # controller GetPos/GetVel/SetPos/GetVel/conditional SetVel
assert '*0x548(' not in carry and '*0x558(' not in carry,'actor position virtual call retained'
source=(root/'src/plugin/Floes.cpp').read_text()
assert 'controller.SetPositionImpl(value,false,false);' in source
assert 'controller.GetPositionImpl(value,false);' in source
assert 'actor->SetPosition(' not in source
assert 'offsetFloeRider(adapter,delta,inverseHavokScale,&riderStats)' in source
assert 'const auto delta=floeRiderDelta({feet.x,feet.y,feet.z},from,to);' in source
baseline=work/'deliverables-riders-01242/SurfaceTides-source-menu.zip'
assert sha(baseline.read_bytes())=='d0d03d5cf582021ff4332d9b9badf5704dbbdb5939d5688cb5bcb38d4aef0202'
changed=[]; added=[]; patch=[]
with zipfile.ZipFile(baseline) as z:
    for path in sorted(root.rglob('*')):
        if not path.is_file(): continue
        rel=path.relative_to(root).as_posix()
        if not (rel.split('/')[0] in ['src','include','tests','vendor','Data'] or rel=='CMakeLists.txt'): continue
        name='SurfaceTides/'+rel
        if name not in z.namelist(): added.append(rel); continue
        before=z.read(name); after=path.read_bytes()
        if before!=after:
            changed.append(rel)
            patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='0.1.24.2/'+rel,tofile='0.1.24.3/'+rel))
    before=z.read('SurfaceTides/src/plugin/Floes.cpp').decode()
    # Preserve accepted collision/crest/streaming behavior while auditing the
    # intentional changes to rider eligibility, snapshot support and diagnostics.
    def function(text,signature):
        start=text.index(signature)
        return text[start:text.index('\n}',start)+2]
    for signature in ['PhysicsState physics(', 'RE::BSGeometry* solidGeometry(', 'bool current(',
                      'void updateNode(', 'void release(', 'void acquire(', 'void moveFloe(',
                      'std::size_t loadedCells(', 'void discover(', 'void tick(', 'void updateFloe(']:
        assert function(source,signature)==function(before,signature),signature
    oldHooks=z.read('SurfaceTides/src/plugin/Hooks.cpp').decode()
    hooks=(root/'src/plugin/Hooks.cpp').read_text()
    normalized=hooks
    start=normalized.index('using JumpButtonFn'); end=normalized.index('UpdateFn originalUpdate',start)
    normalized=normalized[:start]+normalized[end:]
    start=normalized.index('        if (config.floeBobbing) {')
    end=normalized.index('        SKSE::log::info("Installed BSWaterShader',start)
    normalized=normalized[:start]+normalized[end:]
    assert normalized==oldHooks,'unrelated renderer hooks changed'
    assert 'if (event && event->IsDown()) noteFloeJumpRequest();' in hooks
    assert 'originalJumpButton(handler,event,data);' in hooks
    assert 'patch(reinterpret_cast<void*>(jump.address()),0x4,&jumpButton)' in hooks
    assert 'cc->wantState==jump' in source and 'cc->context.currentState==jump' in source
    assert 'controller->supportBody.get()!=people.support' in source
    assert 'found->takeoff.allow(now,grounded,leaving,requested)' in source
    assert 'Ice is Slick is currently incompatible with ice bobbing.' in (root/'src/plugin/Menu.cpp').read_text()
assert set(changed)=={'CMakeLists.txt','Data/SKSE/Plugins/SurfaceTides.ini','src/plugin/Floes.cpp',
                     'src/plugin/Main.cpp','src/plugin/Menu.cpp','src/plugin/Hooks.cpp','src/plugin/Bridge.hpp','tests/FloeMotionTests.cpp','include/surfacetides/FloeRider.hpp'},changed
assert added==[],added
(evidence/'source-changes.patch').write_text(''.join(patch))
last=(work/'work/ice-inspection/portable/Testing/Temporary/LastTest.log').read_text()
assert '22/22 passed' in last and '23/23 passed' in last
assert len(re.findall(r'^PASS ',last,re.M))==45
(evidence/'portable-groups.txt').write_text(last)
for name in ['windows-build.txt','portable-build.txt','portable-tests.txt']:
    (evidence/name).write_bytes((work/'work/ice-riders-01243'/name).read_bytes())
binary=build/'SurfaceTides.dll'; data=binary.read_bytes()
inspection=run(llvm/'llvm-readobj','--file-headers','--coff-exports',binary)
assert 'IMAGE_FILE_MACHINE_AMD64' in inspection
assert 'SKSEPlugin_Load' in inspection and 'SKSEPlugin_Version' in inspection
assert b'SurfaceTides 0.1.24.3 development (floe jump release)' in data
(evidence/'binary-inspection.txt').write_text(inspection)
for name in ['discovery-regression.json','floe-discovery-regression.json']:
    newObj=build/('CMakeFiles/SurfaceTides.dir/src/plugin/'+('Foam' if name=='discovery-regression.json' else 'Floes')+'.cpp.obj')
    run('python3',root/'tools/validate_foam_discovery.py','--nm',llvm/'llvm-nm',
        '--old-object',work/'work/foam-crash-01201/Foam-0.1.20.cpp.obj','--new-object',newObj,'--output',evidence/name)
report={'version':'0.1.24.3','compiled':True,'dll_bytes':len(data),'dll_sha256':sha(data),
        'format':'Windows AMD64 MSVC ABI; clang-cl 23.1','exports':['SKSEPlugin_Load','SKSEPlugin_Version'],
        'discovery_regression':True,'compiled_floe_dependencies_checked':True,'accepted_shaders_unchanged':True,
        'runtime_bobbing_implemented':True,'enabled_by_default':False,'portable_test_groups_passed':45,
        'source_changed_files':changed,'source_added_files':added,
        'floe_collision_crest_solver_renderer_unchanged':True,'multi_floe_rider_snapshot_implemented':True,
        'active_limit':64,'dense_fit_budget_per_frame':8,'additive_live_controller_carry':True,
        'compiled_controller_vtable_slots_hex':slots,'actor_reposition_call_removed':True,
        'native_velocity_preserved':True,'velocity_repair_conditional':True,'stable_local_rider_delta':True,'early_takeoff_release':True,'stable_landing_guard':True,'jump_handler_forwarded':True,
        'in_game_jump_result':'pending','ice_is_slick':'Incompatible with ice bobbing for now; investigation deferred by user',
        'prior_user_result':'0.1.24.2 residual drift rare and accepted for now; jumping interrupted. Latest log has zero velocity repairs throughout; root cause inferred, not proven.'}
(root/'docs/floe-0.1.24.3-build-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'dll_bytes':len(data),'dll_sha256':sha(data),'portable_groups':45,'controller_slots':slots}))
