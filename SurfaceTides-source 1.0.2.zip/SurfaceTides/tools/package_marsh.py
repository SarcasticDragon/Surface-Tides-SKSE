#!/usr/bin/env python3
"""Package the Frozen Marsh decal update, full FOMOD and source checkpoint."""
import argparse,difflib,hashlib,json,zipfile
from pathlib import Path
from package_release import write_zip
from validate_fomod import validate

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['stage','baseline-source','output-dir']:p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[1];e=root/'docs/frozen-marsh-1.0.1-evidence'
    sha=lambda b:hashlib.sha256(b).hexdigest()
    assert sha(a.baseline_source.read_bytes())=='c2c4f64b84e3572a7f8cdfb59247aeaa28e7afb0292822c37959e667817193d8'
    changed=[];patch=[]
    with zipfile.ZipFile(a.baseline_source) as z:
        for n in z.namelist():
            rel=n.removeprefix('SurfaceTides/')
            if rel.startswith(('src/','include/','Data/','recovery/')) or rel=='CMakeLists.txt':
                old=z.read(n);new=(root/rel).read_bytes()
                if old!=new:
                    changed.append(rel)
                    patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile=rel,tofile=rel))
    assert set(changed)=={'CMakeLists.txt','src/plugin/Main.cpp','src/plugin/Menu.cpp','src/plugin/Foam.cpp',
        'include/surfacetides/FoamSelection.hpp','include/surfacetides/FloeManagement.hpp'},changed
    (e/'source-changes.patch').write_text(''.join(patch))
    report=validate(a.stage,root)
    for filename in ['profile-validation.json','legacy-profile-validation.json','discovery-regression.json']:
        assert json.loads((e/filename).read_text())['passed']
    tests=(e/'portable-groups.txt').read_text()
    assert '22/22 passed' in tests and '24/24 passed' in tests and 'FAIL ' not in tests
    binary=(e/'binary-inspection.txt').read_text()
    assert 'IMAGE_FILE_MACHINE_AMD64' in binary
    assert 'SKSEPlugin_Load' in binary and 'SKSEPlugin_Version' in binary
    payload={p.relative_to(a.stage).as_posix():p.read_bytes() for p in a.stage.rglob('*') if p.is_file()}
    dll=payload['core/SKSE/Plugins/SurfaceTides.dll'];assert b'SurfaceTides 1.0.1 (Frozen Marsh decals)' in dll
    report.update({'dll_sha256':sha(dll),'dll_bytes':len(dll),'portable_groups_passed':46,
        'simulation_shaders_and_floe_motion_unchanged':True,'runtime_changed_files':changed,
        'new_ice_decal_profiles':9,'new_bobbing_profiles':0,'in_game_result':'pending'})
    (e/'build-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    full=out/'SurfaceTides-1.0.1-FOMOD.zip';write_zip(full,sorted(payload.items()))
    # Small overlay uses existing installation's INI, shader assets and BOS/CS choices.
    overlay={n.removeprefix('core/'):b for n,b in payload.items() if n.startswith('core/Documentation/')}
    overlay['SKSE/Plugins/SurfaceTides.dll']=dll
    overlay['Documentation/SurfaceTides/FROZEN-MARSH-1.0.1.md']=(root/'docs/FROZEN-MARSH-1.0.1.md').read_bytes()
    assert not any(n.endswith(('.ini','.json','.nif','.dds','.esp','.esm','.esl')) for n in overlay)
    update=out/'SurfaceTides-1.0.1-ice-decal-update.zip';write_zip(update,sorted(overlay.items()))
    for path in [update,full]:(root/'recovery'/path.name).write_bytes(path.read_bytes())
    (e/'packages.json').write_text(json.dumps({path.name:{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())} for path in [update,full]},indent=2)+'\n')
    skip={'.git','__pycache__','build','out','vcpkg_installed'}
    def source_files():
        for p in sorted(root.rglob('*')):
            rel=p.relative_to(root)
            if not p.is_file() or any(s in skip or s.startswith('build-') for s in rel.parts):continue
            if p.suffix.lower() in {'.pyc','.obj','.pdb','.dll','.lib','.nif','.dds'}:continue
            yield 'SurfaceTides/'+rel.as_posix(),p.read_bytes()
    source=out/'SurfaceTides-source-menu.zip';write_zip(source,source_files())
    with zipfile.ZipFile(source) as z:
        for n,b in source_files():assert z.read(n)==b
        for path in [update,full]:assert z.read('SurfaceTides/recovery/'+path.name)==path.read_bytes()
    for path in [update,full,source]:print(path.name,path.stat().st_size,sha(path.read_bytes()))
    print('PASS: INI-preserving overlay, full validated FOMOD, source scope, unchanged recoveries and archive integrity.')

if __name__=='__main__':main()
