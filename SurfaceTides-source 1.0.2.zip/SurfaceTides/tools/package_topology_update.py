#!/usr/bin/env python3
"""Package 0.1.19.2 over the accepted menu/save baseline without replacing INI."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dll', required=True, type=Path)
parser.add_argument('--output-dir', required=True, type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = args.output_dir.resolve()
out.mkdir(parents=True, exist_ok=True)
dll = args.dll.read_bytes()
assert b'SurfaceTides 0.1.19.2 development (game topology tracking)' in dll
assert b'Game topology disagreement' in dll
assert '21/21 passed' in (root/'docs/topology-0.1.19.2-tests.txt').read_text()
with zipfile.ZipFile(root/'recovery/SurfaceTides-0.1.19.1-menu-update.zip') as z:
    payload = {n: z.read(n) for n in z.namelist() if n.startswith(('SKSE/', 'Shaders/'))}
    old_dll = z.read('SKSE/Plugins/SurfaceTides.dll')
assert hashlib.sha256(old_dll).hexdigest() == '8928d842d41170d3f9c51696e8cebb8fdfbf5d7357d277f7f41a636ad4c4341f'
for path in (root/'Data/Shaders/SurfaceTides').iterdir():
    if path.is_file():
        assert payload[str(path.relative_to(root/'Data'))] == path.read_bytes()
shader = payload['Shaders/SurfaceTides/Water.hlsl']
assert hashlib.sha256(shader).hexdigest() == '1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e'
payload['SKSE/Plugins/SurfaceTides.dll'] = dll
payload['SurfaceTides-topology-README.md'] = (root/'docs/TOPOLOGY-0.1.19.2.md').read_bytes()
assert 'SKSE/Plugins/SurfaceTides.ini' not in payload
manifest = {
    'version': '0.1.19.2', 'kind': 'compiled game topology tracking candidate',
    'in_game_result': 'pending', 'ini_preserved': True, 'accepted_shaders_unchanged': True,
    'portable_tests': '21/21 passed',
    'files': {n: {'bytes': len(d), 'sha256': hashlib.sha256(d).hexdigest()} for n, d in payload.items()},
}
encoded = (json.dumps(manifest, indent=2)+'\n').encode()
(root/'docs/topology-0.1.19.2-package.json').write_bytes(encoded)
payload['SurfaceTides-topology-manifest.json'] = encoded
mod = out/'SurfaceTides-0.1.19.2-topology-update.zip'
with zipfile.ZipFile(mod, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, d in sorted(payload.items()): z.writestr(n, d)
(root/'recovery'/mod.name).write_bytes(mod.read_bytes())
source = out/'SurfaceTides-source-menu.zip'
skip = {'.git', '__pycache__', 'build', 'out', 'vcpkg_installed'}
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if not path.is_file() or any(p in skip or p.startswith('build-') for p in rel.parts): continue
        if path.suffix in {'.pyc', '.obj', '.pdb', '.dll', '.lib'}: continue
        z.write(path, 'SurfaceTides/'+str(rel))
for path in [mod, source]:
    with zipfile.ZipFile(path) as z: assert z.testzip() is None
    print(path.name, path.stat().st_size, hashlib.sha256(path.read_bytes()).hexdigest())
with zipfile.ZipFile(source) as z:
    assert z.read('SurfaceTides/recovery/'+mod.name) == mod.read_bytes()
    assert z.read('SurfaceTides/Data/Shaders/SurfaceTides/Water.hlsl') == shader
print('Runtime payload, unchanged shaders, INI preservation and source recovery verified.')
