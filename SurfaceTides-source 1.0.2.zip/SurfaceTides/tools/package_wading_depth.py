#!/usr/bin/env python3
"""Package the temporary PS015E depth diagnostic and its source checkpoint."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir', required=True, type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = args.output_dir.resolve()
out.mkdir(parents=True, exist_ok=True)
shader = (root/'packaging/wading-depth-diagnostic/Water.hlsl').read_bytes()
assert b'#define ST_DIAGNOSTIC_WADING_DEPTH 1' in shader
assert b'ST_PIXEL_DESCRIPTOR == 0x015E' in shader
assert b'#define ST_DIAGNOSTIC_SKIP_WADING_SURFACES 0' in shader
assert b'#define ST_DIAGNOSTIC_NO_NATIVE_RIPPLES 0' in shader
assert b'#define ST_DISPLACED_DEPTH_BLEND 1' in shader
assert b'#define ST_SHORE_CONTACT_BLEND 1' in shader
payload = {
    'Shaders/SurfaceTides/Water.hlsl': shader,
    'SurfaceTides-wading-depth-README.md': (root/'docs/WADING-DEPTH-TEST.md').read_bytes(),
}
for path in sorted((root/'licenses').rglob('*')):
    if path.is_file():
        payload['SKSE/Plugins/SurfaceTides-licenses/'+str(path.relative_to(root/'licenses'))] = path.read_bytes()
for name in ['LICENSE', 'THIRD_PARTY.md']:
    payload['SKSE/Plugins/SurfaceTides-licenses/'+name] = (root/name).read_bytes()
manifest = {
    'name': 'SurfaceTides-0.1.18-wading-depth-diagnostic',
    'scope': 'Primary wading PS015E comparison-depth diagnostic only; not a release fix',
    'dll_included': False, 'ini_included': False,
    'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
              for name,data in payload.items()},
}
encoded = (json.dumps(manifest,indent=2)+'\n').encode()
(root/'docs/wading-depth-package.json').write_bytes(encoded)
payload['SurfaceTides-wading-depth-manifest.json'] = encoded
mod = out/'SurfaceTides-0.1.18-wading-depth-diagnostic.zip'
with zipfile.ZipFile(mod,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(payload.items()):
        archive.writestr(name,data)
source = out/'SurfaceTides-source-wading-depth-diagnostic.zip'
skip = {'.git','__pycache__','build','out','vcpkg_installed'}
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if not path.is_file() or any(p in skip or p.startswith('build-') for p in relative.parts):
            continue
        if path.suffix in {'.pyc','.obj','.pdb','.dll','.lib'}:
            continue
        archive.write(path,'SurfaceTides/'+str(relative))
for path in [mod,source]:
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
    print(path.name, path.stat().st_size, hashlib.sha256(path.read_bytes()).hexdigest())
