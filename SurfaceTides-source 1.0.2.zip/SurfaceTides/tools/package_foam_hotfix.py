#!/usr/bin/env python3
"""Package the AE discovery hotfix; preserve INI, shaders, BOS and accepted rollback."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dll',type=Path,required=True)
parser.add_argument('--output-dir',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
out=args.output_dir.resolve()
out.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
dll=args.dll.read_bytes()
assert b'SurfaceTides 0.1.20.1 development (AE foam discovery fix)' in dll
assert b'legacy TES worldSpace scan bypassed' in dll
assert b'Game topology disagreement' in dll
build=json.loads((root/'docs/foam-0.1.20.1-build-validation.json').read_text())
assert build['compiled'] and build['dll_sha256']==sha(dll)
assert build['new_call_chain_inspected'] and build['legacy_global_iterator_removed_from_linked_functions']
regression=json.loads((root/'docs/foam-0.1.20.1-discovery-regression.json').read_text())
assert regression['passed'] and regression['negative_control_0_1_20_rejected']
baseline=root/'recovery/SurfaceTides-0.1.19.2-topology-update.zip'
assert sha(baseline.read_bytes())=='6c7e5a345bc520a77ba857166261e80f2bd87f77aaa2829abc4b824784c9e81d'
with zipfile.ZipFile(baseline) as z:
    payload={n:z.read(n) for n in z.namelist() if n.startswith('Shaders/')}
    assert sha(z.read('SKSE/Plugins/SurfaceTides.dll'))=='3e0c1a49903c6e3f69a0cc56baec370eefc29ce9d7be7dd7ae417a85723da68b'
for name,data in payload.items(): assert (root/'Data'/name).read_bytes()==data
assert sha(payload['Shaders/SurfaceTides/Water.hlsl'])=='1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e'
payload['SKSE/Plugins/SurfaceTides.dll']=dll
payload['SurfaceTides-foam-hotfix-README.md']=(root/'docs/FOAM-0.1.20.1.md').read_bytes()
payload['SurfaceTides-foam-profiles.md']=(root/'docs/FOAM-0.1.20.md').read_bytes()
payload['SurfaceTides-LICENSE.txt']=(root/'LICENSE').read_bytes()
assert not any(n.lower().endswith(('.ini','.nif','.dds','.esp','.esl','.esm')) for n in payload)
manifest={'version':'0.1.20.1','in_game_result':'pending','ini_preserved':True,
          'accepted_shaders_unchanged':True,'bos_preset_changed':False,
          'compiled_discovery_regression':'passed with original 0.1.20 negative control',
          'files':{n:{'bytes':len(d),'sha256':sha(d)} for n,d in payload.items()}}
encoded=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'docs/foam-0.1.20.1-package.json').write_bytes(encoded)
payload['SurfaceTides-foam-hotfix-manifest.json']=encoded
mod=out/'SurfaceTides-0.1.20.1-foam-hotfix.zip'
with zipfile.ZipFile(mod,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()):z.writestr(name,data)
with zipfile.ZipFile(mod) as z:
    assert z.testzip() is None
    for name,data in payload.items(): assert z.read(name)==data
(root/'recovery'/mod.name).write_bytes(mod.read_bytes())
source=out/'SurfaceTides-source-menu.zip'
skip={'.git','__pycache__','build','out','vcpkg_installed'}
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if not path.is_file() or any(p in skip or p.startswith('build-') for p in rel.parts):continue
        if path.suffix.lower() in {'.pyc','.obj','.pdb','.dll','.lib','.nif','.dds'}:continue
        z.write(path,'SurfaceTides/'+str(rel))
with zipfile.ZipFile(source) as z:
    assert z.testzip() is None
    assert z.read('SurfaceTides/recovery/'+mod.name)==mod.read_bytes()
    assert z.read('SurfaceTides/recovery/'+baseline.name)==baseline.read_bytes()
    assert z.read('SurfaceTides/src/plugin/Foam.cpp')==(root/'src/plugin/Foam.cpp').read_bytes()
    assert z.read('SurfaceTides/docs/foam-0.1.20.1-linker.map')==(root/'docs/foam-0.1.20.1-linker.map').read_bytes()
for path in [mod,source]:print(path.name,path.stat().st_size,sha(path.read_bytes()))
print('Verified hotfix payload, unchanged shaders, INI preservation, source and accepted rollback.')
