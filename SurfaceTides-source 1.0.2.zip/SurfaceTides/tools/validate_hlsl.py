#!/usr/bin/env python3
"""DXC syntax/semantic check. This produces temporary SM6 DXIL, NOT Skyrim's SM5 DXBC.
The native Windows ShaderTests target is the required D3DCompiler/SM5 build gate.
"""
import argparse
import pathlib
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--dxc', required=True)
parser.add_argument('--reference', required=True, help='Built SurfaceTidesReference executable')
parser.add_argument("--mesh-only", action="store_true", help="Check new geometry preparation stages only")
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
descriptors = [0x0002, 0x001e, 0x005e, 0x00df, 0x071e, 0x075e, 0x003e, 0x015e,
               0x081e, 0x101e, 0x381e, 0x401e, 0x471e, 0x5000, 0x5802]
flags = ['VC','NORMAL_TEXCOORD','REFLECTIONS','REFRACTIONS','DEPTH','INTERIOR','WADING',
         'VERTEX_ALPHA_DEPTH','CUBEMAP','FLOWMAP','BLEND_NORMALS']
stages = [('VSHADER','vs_6_0'),('CONTROL_SHADER','vs_6_0'),('HSHADER','hs_6_0'),
          ('DSHADER','ds_6_0'),('PSHADER','ps_6_0')]
failures = 0
with tempfile.TemporaryDirectory(prefix='surface-hlsl-') as directory:
    temp = pathlib.Path(directory)
    shutil.copytree(root/'Data/Shaders/SurfaceTides', temp, dirs_exist_ok=True)
    subprocess.run([args.reference,'--headers',str(temp)],check=True)
    for descriptor in ([] if args.mesh_only else descriptors):
        defines = [name+'=1' for bit,name in enumerate(flags) if descriptor & (1 << bit)]
        technique = descriptor >> 11
        if technique < 8:
            defines += ['SPECULAR=1',f'NUM_SPECULAR_LIGHTS={technique}']
        else:
            defines += [{8:'UNDERWATER',9:'LOD',10:'STENCIL',11:'SIMPLE'}[technique]+'=1']
        for stage,target in stages:
            cmd = [args.dxc,str(temp/'Water.hlsl'),'-T',target,'-E','main','-Fo',str(temp/'check.dxil'),'-HV','2016']
            for define in defines+[stage+'=1',f'ST_PIXEL_DESCRIPTOR={descriptor}']:
                cmd += ['-D',define]
            result = subprocess.run(cmd,capture_output=True,text=True)
            if result.returncode:
                failures += 1
                print(f'FAIL {descriptor:04X} {stage}\n{result.stdout}{result.stderr}')
    water_total = 0 if args.mesh_only else len(descriptors)*len(stages)
    mesh_stages = [('MESH_VS','vs_6_0'),('MESH_HS','hs_6_0'),('MESH_DS','ds_6_0'),('MESH_GS','gs_6_0')]
    for cap in (8, 16):
        for attrs in range(8):
            for stage,target in mesh_stages:
                cmd = [args.dxc,str(temp/'MeshInput.hlsl'),'-T',target,'-E','main','-Fo',str(temp/'check.dxil'),'-HV','2016','-D',stage+'=1','-D',f'ST_MESH_MAX_FACTOR={cap}']
                if attrs & 1: cmd += ['-D','ST_MESH_UV=1']
                if attrs & 2: cmd += ['-D','ST_MESH_COLOR=1']
                if attrs & 4: cmd += ['-D','ST_MESH_HISTORY=1']
                result = subprocess.run(cmd,capture_output=True,text=True)
                if result.returncode:
                    failures += 1
                    print(f'FAIL mesh cap={cap} attributes={attrs} {stage}\n{result.stdout}{result.stderr}')
    cmd = [args.dxc,str(temp/'MeshInput.hlsl'),'-T','vs_6_0','-E','main','-Fo',str(temp/'check.dxil'),'-HV','2016','-D','MESH_MOTION_VS=1','-D','ST_MESH_HISTORY=1']
    result = subprocess.run(cmd,capture_output=True,text=True)
    if result.returncode:
        failures += 1
        print('FAIL motion VS\n'+result.stdout+result.stderr)
    total = water_total + 65
    print(f'{total-failures}/{total} DXC SM6 checks passed')
raise SystemExit(bool(failures))
