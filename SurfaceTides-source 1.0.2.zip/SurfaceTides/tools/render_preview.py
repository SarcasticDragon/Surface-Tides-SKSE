#!/usr/bin/env python3
"""Render actual reference-solver output. This is not Skyrim footage or a GPU renderer test."""
import argparse
import pathlib
import struct
import numpy as np
from PIL import Image, ImageDraw, ImageFont

parser=argparse.ArgumentParser()
parser.add_argument('input')
parser.add_argument('output')
args=parser.parse_args()
with open(args.input,'rb') as f:
    magic,n,count,fps=struct.unpack('<4I',f.read(16))
    if magic!=0x53544944: raise ValueError('Not a SurfaceTides reference stream')
    wet=np.frombuffer(f.read(n*n),np.uint8).reshape(n,n).astype(bool)
    heights=np.frombuffer(f.read(),'<f4').reshape(count,n,n)

def font(size):
    for path in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','C:/Windows/Fonts/segoeui.ttf']:
        if pathlib.Path(path).exists(): return ImageFont.truetype(path,size)
    return ImageFont.load_default()

width=900; size=660; left=120; top=112
yy,xx=np.mgrid[:n,:n]
light=np.array([-0.35,-0.45,0.82]); light/=np.linalg.norm(light)
images=[]
for k in range(0,count,2):
    h=heights[k]
    gy,gx=np.gradient(h,8)
    # Slope amplification is for visibility at thumbnail size; the solver data are unchanged.
    normals=np.stack([-gx*5,-gy*5,np.ones_like(h)],axis=-1)
    normals/=np.linalg.norm(normals,axis=-1,keepdims=True)
    diffuse=np.clip(normals@light,0,1)
    half=np.array([-0.12,-0.25,1.0]);half/=np.linalg.norm(half)
    spec=np.maximum(0,normals@half)**85
    variation=np.clip(h*0.06,-0.17,0.17)
    rgb=np.zeros((n,n,3),np.float32)
    rgb[:]=np.array([0.045,0.23,0.30])[None,None,:]*(0.6+diffuse[...,None]*0.8)
    rgb+=spec[...,None]*np.array([0.55,0.77,0.78])
    rgb+=variation[...,None]*np.array([0.1,0.35,0.36])
    rgb[~wet]=[0.20,0.25,0.26]
    rgb=np.uint8(np.clip(rgb*255,0,255))
    water=Image.fromarray(rgb[::-1]).resize((size,size),Image.Resampling.BICUBIC)
    frame=Image.new('RGB',(width,860),'#0B1720');frame.paste(water,(left,top))
    draw=ImageDraw.Draw(frame)
    draw.text((left,27),'SURFACE TIDES',font=font(34),fill='#E1F4F3')
    draw.text((left,72),'Propagating wakes · interference · diffraction',font=font(18),fill='#8EC3CD')
    draw.rounded_rectangle((left+size-115,top+16,left+size-16,top+47),radius=7,fill='#10212C')
    draw.text((left+size-100,top+22),f'{k/fps:04.1f} s',font=font(17),fill='#D2E7EB')
    # Actor path uses the same time and world coordinates as reference.cpp.
    actor_x=-360+(k/fps)*125
    if -512<actor_x<512:
        px=left+(actor_x/8+64)/n*size;py=top+(1-(-110/8+64)/n)*size
        draw.ellipse((px-6,py-6,px+6,py+6),fill='#EBCF95',outline='#FFF1CB',width=2)
    draw.text((left,790),'Actual C++ solver output • schematic boundary mask',font=font(17),fill='#D2E7EB')
    draw.text((left,820),'Reference preview — not in-game footage. Slopes amplified for visibility.',font=font(15),fill='#86A5B6')
    images.append(frame)
output=pathlib.Path(args.output);output.parent.mkdir(parents=True,exist_ok=True)
images[0].save(output,save_all=True,append_images=images[1:],duration=round(2000/fps),loop=0,optimize=False)
images[min(len(images)-1,65)].save(output.with_suffix('.png'))
print(f'Saved {len(images)} preview frames; height range {heights.min():.3f} to {heights.max():.3f} game units')
