#!/usr/bin/env python3
"""Check actual C++ selection and scene rules against the thirteen supplied NIFs."""
import argparse,json,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('inspection',type=Path);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[2]
# Expected selected NIF block IDs are recorded independently of the C++ profiles.
expected={'frozenmarshicefloel01.nif':7,'frozenmarshicefloem01.nif':7,
    'frozenmarshicefloes01.nif':7,'frozenmarshicefloes02.nif':7,
    'frozenmarshicelandbrokenl01.nif':10,'frozenmarshicelandbrokenl01skirt.nif':10,
    'frozenmarshicefloefrosts01.nif':1,'frozenmarshicefloefrosts02.nif':1,'frozenmarshicefloefrosts03.nif':1}
untouched={'frozenmarshice01.nif','frozenmarshicefloechunks01.nif','frozenmarshicefloechunks02.nif','frozenmarshicefloechunks03.nif'}
meshes=json.loads(a.inspection.read_text());assert {m['file'].lower() for m in meshes}==set(expected)|untouched
q=json.dumps;cpp=['#include "surfacetides/FloeManagement.hpp"','#include <iostream>','int main(){'];cases=[]
for mesh in meshes:
    assert mesh['load_code']==0
    name=mesh['file'].lower();blocks={b['id']:b for b in mesh['blocks']}
    model='landscape/ice/'+name
    cpp+=['{',f'int p=st::foam::modelProfile({q(model)}); bool solid=false,unsafe=false; unsigned matched=0,geometries=0;']
    for b in blocks.values():
        if 'vertices' not in b:continue
        shader=blocks[b['shader']];assert shader['type']=='BSLightingShaderProperty'
        collision=b.get('collision',0xffffffff)!=0xffffffff
        controller=b.get('controller',0xffffffff)!=0xffffffff or shader.get('controller',0xffffffff)!=0xffffffff
        cpp+=[f'{{int s=st::foam::shapeSlot(p,{q(b["name"])},false,{q(b["textures"][0])},{q(b["textures"][1])},{q(collision)},{q(controller)});',
            'std::cout << s << "\\n"; ++geometries; if(s>=0)++matched;',
            f'if(p>=0 && st::foam::equal({q(b["name"])},st::foam::profiles[p].rock))solid=true;}}']
        cases.append({'file':name,'block':b['id'],'shape':b['name'],'expected':0 if expected.get(name)==b['id'] else -1})
    unsafe=any(b.get('collision',0xffffffff)!=0xffffffff or b.get('controller',0xffffffff)!=0xffffffff for b in blocks.values())
    cpp += [f'unsafe={q(unsafe)};',
        'std::cout << st::foam::sceneComplete(p,solid,matched,geometries,unsafe) << "\\n";',
        'std::cout << st::isFloeProfile(p) << "\\n";','}']
    cases += [{'file':name,'check':'scene accepted','expected':int(name in expected)},
              {'file':name,'check':'bobbing forbidden','expected':0}]
cpp+=['}']
with tempfile.TemporaryDirectory(prefix='st-marsh-') as d:
    f=Path(d);(f/'check.cpp').write_text('\n'.join(cpp))
    subprocess.run(['g++','-std=c++20','-O2','-I',str(root/'include'),str(f/'check.cpp'),'-o',str(f/'check')],check=True)
    actual=[int(x) for x in subprocess.check_output([str(f/'check')],text=True).splitlines()]
assert len(actual)==len(cases)
for c,v in zip(cases,actual):c['actual']=v;assert c['expected']==v,c
report={'passed':True,'meshes_inspected':13,'geometry_cases':19,'decal_shapes_selected':9,'solid_shapes_retained':10,
    'new_bobbing_models':0,'cases':cases,
    'limits':'Offline metadata test. Loaded paths, runtime visibility and streaming need Skyrim testing.'}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n')
print('PASS: 19 geometries, exactly 9 decals selected and 10 solid shapes retained; all 13 meshes excluded from bobbing.')
