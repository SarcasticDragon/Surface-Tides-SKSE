# Read-only mesh inspection

`inspect_foam.cpp` uses ousnius/nifly to report NIF blocks, shapes, texture references, local height range, parent/child relationships, collision links and controller targets as JSON. It never calls Save or Optimize and does not change the input file. The report does not render textures or establish visible foam by itself; the user visually confirmed the supplied seven models.

The inspection for 0.1.20 used https://github.com/ousnius/nifly commit `cca0a770094bb962fb28ea1fec5ea903e68fda8e`, built locally with CMake in Release mode and BUILD_TESTING=OFF. Link this CLI with its static library, including nifly's `include` and `external` directories, using a C++17 compiler. Example, with paths adjusted to your checkout/build:

```sh
g++ -std=c++17 -O2 -I nifly/include -I nifly/external inspect_foam.cpp nifly-build/src/libnifly.a -o inspect_foam
./inspect_foam /path/to/first.nif /path/to/second.nif > inspection.json
```

The parsed seven-file report is preserved at `docs/foam-0.1.20-nif-inspection.json`, with input SHA-256 hashes in `docs/foam-0.1.20-inputs.json`. The user-supplied NIFs are not redistributed. nifly is GPLv3 and is not a dependency of the SKSE DLL.

`validate_profiles.py` feeds every geometry record in that report to the exact C++ selection header used by the plugin. It checks the three expected attached-foam matches and the twelve geometry records that must not match. It requires Python and g++ with C++20 support:

```sh
python3 tools/nif/validate_profiles.py docs/foam-0.1.20-nif-inspection.json --output docs/foam-0.1.20-profile-validation.json
```

This establishes selector scope on the inspected input metadata. It cannot validate Skyrim's loaded-material paths, scene traversal, visibility changes or cell lifecycle; those require the compiled in-game test.
