#!/usr/bin/env python3
"""Exercise the actual C++ selector on all geometry in an inspect_foam JSON report."""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('inspection', type=Path)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
models = {
    'fxrapids.nif': 'effects/fxrapids.nif',
    'fxrapids02.nif': 'effects/fxrapids02.nif',
    'fxrapidsbig01.nif': 'effects/fxrapidsbig01.nif',
    'fxrapidsringheavy.nif': 'effects/fxrapidsringheavy.nif',
    'fxrapidsringheavy1way.nif': 'effects/fxrapidsringheavy1way.nif',
    'FxRapidsRocks01.nif': 'effects/fxrapidsrocks01.nif',
    'wrrapidrocks01.nif': 'architecture/whiterun/wreffects/wrrapidrocks01.nif',
    'icefloessolid01.nif': 'landscape/ice/icefloessolid01.nif',
    'icefloes01.nif': 'landscape/ice/icefloes01.nif',
    'icefloessolid02.nif': 'landscape/ice/icefloessolid02.nif',
}
expected = {('FxRapidsRocks01.nif',7): 0, ('FxRapidsRocks01.nif',16): 1, ('wrrapidrocks01.nif',5): 0,
            ('icefloessolid01.nif',7): 0, ('icefloes01.nif',7): 0, ('icefloessolid02.nif',7): 0}
meshes = json.loads(args.inspection.read_text())
names={m['file'] for m in meshes}
assert names in (set(models),set(models)-{'icefloes01.nif','icefloessolid02.nif'},
                 set(models)-{'icefloes01.nif','icefloessolid01.nif','icefloessolid02.nif'})
cases = []
cpp = ['#include "surfacetides/FoamSelection.hpp"', '#include <iostream>', 'int main() {']
for mesh in meshes:
    assert mesh['load_code'] == 0
    blocks = {b['id']: b for b in mesh['blocks']}
    for block in blocks.values():
        if 'vertices' not in block:
            continue
        shader = blocks.get(block['shader'], {})
        effect = shader.get('type') == 'BSEffectShaderProperty'
        textures = block['textures']
        source = textures[0] if textures else ''
        grey = textures[2] if effect and len(textures) > 2 else textures[1] if len(textures) > 1 else ''
        values = [models[mesh['file']],block['name'],effect,source,grey,
                  block.get('collision',0xFFFFFFFF) != 0xFFFFFFFF,
                  block.get('controller',0xFFFFFFFF) != 0xFFFFFFFF]
        v = [json.dumps(value) for value in values]
        cpp.append(f'std::cout << st::foam::shapeSlot(st::foam::modelProfile({v[0]}),'+','.join(v[1:])+') << "\\n";')
        cases.append({'file': mesh['file'], 'block': block['id'], 'shape': block['name'],
                      'expected_slot': expected.get((mesh['file'],block['id']),-1)})
cpp.append('}')
with tempfile.TemporaryDirectory(prefix='surfacetides-foam-') as directory:
    path = Path(directory)
    (path/'audit.cpp').write_text('\n'.join(cpp)+'\n')
    subprocess.run(['g++','-std=c++20','-O2','-I',str(root/'include'),str(path/'audit.cpp'),'-o',str(path/'audit')],check=True)
    actual = [int(value) for value in subprocess.check_output([str(path/'audit')],text=True).splitlines()]
assert len(actual) == len(cases)
for case,slot in zip(cases,actual):
    case['actual_slot'] = slot
    assert slot == case['expected_slot'], case
report = {'passed': True, 'geometry_cases': len(cases), 'matched_attached_shapes': sum(s >= 0 for s in actual),
          'note': 'Offline selector validation only; scene traversal and visibility require Skyrim testing.', 'cases': cases}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(f"PASS: {len(cases)} supplied geometry cases; exactly {sum(s >= 0 for s in actual)} reviewed foam/slush shapes selected.")
