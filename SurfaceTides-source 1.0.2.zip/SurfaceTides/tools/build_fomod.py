#!/usr/bin/env python3
"""Generate the Surface Tides 1.0 FOMOD staging tree (standard library only)."""
import argparse, itertools, re
from pathlib import Path
from xml.etree import ElementTree as ET

VERSION='1.0.2'
PREVIEWS={
    'Keep all foam':'foam-kept.png',
    'Remove attached foam only':'foam-attached-removed.png',
    'Remove standalone foam only (BOS)':'foam-standalone-removed.png',
    'Remove both (BOS)':'foam-all-removed.png',
    'Keep ice decals':'ice-decals-kept.png',
    'Remove ice decals':'ice-decals-removed.png',
}
SCHEMA='http://qconsulting.ca/gemm/ModConfig5.0.xsd'
RENDERERS=[
    ('Standalone','standalone','Use Surface Tides without ENB or Community Shaders. No renderer framework is required.'),
    ('ENB - water off','enb','Keep ENB for the rest of the scene. Before launching, save [EFFECT] EnableWater=false in enbseries.ini beside SkyrimSE.exe. Keep ENB water off. This installer does not change your ENB preset.'),
    ('Community Shaders - water off','cs','Keep Community Shaders for the rest of the scene. Installs a small CS override disabling Water shader replacement, Unified Water and Water Effects at boot. Restart after installation. Keep those water features off; other CS features are retained.')]
FOAM=[
    ('Keep all foam',0,0,'Keep authored foam. Flat foam can intersect the simulated waves.'),
    ('Remove attached foam only',1,0,'Hide reviewed foam shapes attached to rapid rocks. Rock geometry and collision are retained. No Base Object Swapper requirement. Waterfall impact effects stay.'),
    ('Remove standalone foam only (BOS)',0,1,'Requires Base Object Swapper 3.0 or newer, installed separately. Removes the three reviewed standalone foam bases through a BOS preset. Attached rock foam and waterfall impact effects stay.'),
    ('Remove both (BOS)',1,1,'Requires Base Object Swapper 3.0 or newer, installed separately. Remove the three standalone foam bases and hide reviewed attached rock foam. Rocks, collision and waterfall impact effects stay.')]
ICE=[('Keep ice decals',0,'Keep the flat slush around ice floes. It may intersect simulated waves.'),
     ('Remove ice decals',1,'Hide reviewed flat slush shapes in the three original ice-floe models and nine Frozen Marsh models, including standalone frost patches. Solid ice and collision stay. No replacement meshes or blank textures are installed.')]
BOBBING=[('Static ice floes',0,'Leave the solid ice at its authored position. Ice is Slick can remain in use without Surface Tides bobbing.'),
         ('Bobbing ice floes',1,'Move nearby supported solid ice floes with the simulation. Incompatible with Ice is Slick for now. Separate chunks inside one mesh move together. Removing the flat ice decals is recommended with this option.')]

def xml_bytes(root):
    ET.indent(root,space='  ')
    # Nexus FomodInstaller strips encoding="..." before rewriting to UTF-16.
    # Its regex misses valid single-quoted declarations emitted by ElementTree.
    return b'<?xml version="1.0" encoding="utf-8"?>\n'+ET.tostring(root,encoding='utf-8',xml_declaration=False)+b'\n'

def make_config():
    ET.register_namespace('xsi','http://www.w3.org/2001/XMLSchema-instance')
    root=ET.Element('config',{'{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation':SCHEMA})
    ET.SubElement(root,'moduleName').text='Surface Tides '+VERSION
    required=ET.SubElement(root,'requiredInstallFiles')
    steps=ET.SubElement(root,'installSteps',order='Explicit')
    def step(name):return ET.SubElement(ET.SubElement(steps,'installStep',name=name),'optionalFileGroups',order='Explicit')
    def group(parent,name,kind='SelectExactlyOne'):
        return ET.SubElement(ET.SubElement(parent,'group',name=name,type=kind),'plugins',order='Explicit')
    def choice(parent,name,description,flags,recommended=False,required=False):
        plugin=ET.SubElement(parent,'plugin',name=name)
        ET.SubElement(plugin,'description').text=description
        c=ET.SubElement(plugin,'conditionFlags')
        for key,value in flags.items():ET.SubElement(c,'flag',name=key).text=str(value)
        t=ET.SubElement(plugin,'typeDescriptor')
        ET.SubElement(t,'type',name='Required' if required else 'Recommended' if recommended else 'Optional')
    intro=group(step('Before installing'),'Requirements and configuration','SelectAll')
    choice(intro,'Surface Tides '+VERSION,
        'Requires Skyrim Steam 1.6.1170 or GOG 1.6.1179, matching SKSE and AE Address Library. Other runtimes, including 1.5.97 and 1.7.x, are not supported. '
        'SKSE Menu Framework 3.x is optional for the in-game settings page. Dependencies are not bundled. '
        'This installer writes SurfaceTides.ini from your choices. BACK UP custom tuning before reinstalling. '
        'When replacing an older Surface Tides mod, use a clean replacement in your mod manager so deselected BOS/CS files do not remain. Restart Skyrim after changing startup options.',
        {'intro':'read'},required=True)
    renderer=group(step('Renderer'),'Choose your renderer')
    for i,(name,value,description) in enumerate(RENDERERS):choice(renderer,name,description,{'renderer':value},recommended=i==0)
    features=step('Surface objects')
    foam=group(features,'Foam')
    for i,(name,attached,standalone,description) in enumerate(FOAM):
        choice(foam,name,description,{'attached':attached,'standalone_foam':standalone},recommended=i==0)
    ice=group(features,'Flat ice decals')
    for i,(name,value,description) in enumerate(ICE):choice(ice,name,description,{'ice':value},recommended=i==0)
    bob=group(features,'Solid ice motion')
    for i,(name,value,description) in enumerate(BOBBING):choice(bob,name,description,{'bobbing':value},recommended=i==0)
    patterns=ET.SubElement(ET.SubElement(root,'conditionalFileInstalls'),'patterns')
    def pattern(flags,source,destination):
        p=ET.SubElement(patterns,'pattern'); deps=ET.SubElement(p,'dependencies',operator='And')
        for key,value in flags.items():ET.SubElement(deps,'flagDependency',flag=key,value=str(value))
        ET.SubElement(ET.SubElement(p,'files'),'file',source=source,destination=destination,priority='10')
    for renderer,attached,ice,bobbing in itertools.product(['standalone','enb','cs'],range(2),range(2),range(2)):
        name=f'{renderer}-foam{attached}-ice{ice}-bob{bobbing}.ini'
        pattern({'renderer':renderer,'attached':attached,'ice':ice,'bobbing':bobbing},'options/config/'+name,'SKSE/Plugins/SurfaceTides.ini')
    pattern({'standalone_foam':1},'options/foam/SurfaceTides_Foam_SWAP.ini','SurfaceTides_Foam_SWAP.ini')
    pattern({'renderer':'cs'},'options/cs/SurfaceTides_Global.json','SKSE/Plugins/CommunityShaders/Overrides/SurfaceTides_Global.json')
    return root,required

def generate(root,stage,dll):
    payload={}
    payload['core/SKSE/Plugins/SurfaceTides.dll']=dll.read_bytes()
    for p in sorted((root/'Data/Shaders').rglob('*')):
        if p.is_file():payload['core/Shaders/'+p.relative_to(root/'Data/Shaders').as_posix()]=p.read_bytes()
    for p in sorted((root/'licenses').glob('*')):
        if p.is_file():payload['core/Documentation/SurfaceTides/licenses/'+p.name]=p.read_bytes()
    payload['core/Documentation/SurfaceTides/THIRD_PARTY.md']=(root/'THIRD_PARTY.md').read_bytes()
    payload['core/Documentation/SurfaceTides/LICENSE.txt']=(root/'LICENSE').read_bytes()
    payload['core/Documentation/SurfaceTides/README.md']=(root/'docs/RELEASE-1.0.md').read_bytes()
    payload['FOMOD-AUTHORING.md']=(root/'docs/FOMOD-1.0.md').read_bytes()
    template=(root/'Data/SKSE/Plugins/SurfaceTides.ini').read_text()
    for renderer,attached,ice,bobbing in itertools.product(['standalone','enb','cs'],range(2),range(2),range(2)):
        text=template
        text=re.sub(r'^; Profile:.*$',f'; Profile: {renderer}; attached foam removal={attached}; ice decal removal={ice}; bobbing={bobbing}.',text,flags=re.M)
        for key,value in {'AllowENB':int(renderer=='enb'),'AllowCS':int(renderer=='cs'),'HideAttachedFoam':attached,'HideIceDecals':ice,'FloeBobbing':bobbing}.items():
            text,count=re.subn(r'^'+key+r'=.*$',f'{key}={value}',text,flags=re.M);assert count==1,key
        payload[f'options/config/{renderer}-foam{attached}-ice{ice}-bob{bobbing}.ini']=text.encode()
    payload['options/foam/SurfaceTides_Foam_SWAP.ini']=(root/'optional/foam-bos/SurfaceTides_Foam_SWAP.ini').read_bytes()
    payload['options/cs/SurfaceTides_Global.json']=(root/'optional/cs-coexistence/SKSE/Plugins/CommunityShaders/Overrides/SurfaceTides_Global.json').read_bytes()
    config,required=make_config()
    for plugin in config.findall('.//plugin'):
        filename=PREVIEWS.get(plugin.get('name'))
        if filename:
            preview=root/'installer/fomod/images'/filename
            if preview.is_file():
                name='fomod/images/'+filename
                payload[name]=preview.read_bytes()
                plugin.insert(1,ET.Element('image',path=name))
    for name in sorted(payload):
        if name.startswith('core/'):
            ET.SubElement(required,'file',source=name,destination=name.removeprefix('core/'),priority='0')
    payload['fomod/ModuleConfig.xml']=xml_bytes(config)
    info=ET.Element('fomod')
    for key,value in [('Name','Surface Tides'),('Author','SurfaceTides contributors'),('Version',VERSION),('Description','Independent surface water simulation with optional foam filtering, ice decal removal and ice-floe bobbing.')]:
        node=ET.SubElement(info,key);node.text=value
        if key=='Version':node.set('MachineVersion',VERSION)
    payload['fomod/info.xml']=xml_bytes(info)
    for name,data in payload.items():
        p=stage/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    actual={p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file()}
    assert actual==set(payload),'staging directory contains unrelated or stale files; use a clean stage'
    for name in ['ModuleConfig.xml','info.xml']:
        p=root/'installer/fomod'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(payload['fomod/'+name])
    return len(payload)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--dll',type=Path,required=True);p.add_argument('--stage',type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[1]
    print(f'Generated {generate(root,a.stage.resolve(),a.dll.resolve())} files: 24 complete INIs, 48 feature combinations, three installer pages.')
