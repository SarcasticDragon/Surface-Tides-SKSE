#!/usr/bin/env python3
"""Package the contact-fade test separately; preserve accepted runtime/source."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir', required=True, type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = args.output_dir.resolve()
out.mkdir(parents=True, exist_ok=True)
baseline = (root / 'Data/Shaders/SurfaceTides/Water.hlsl').read_bytes()
shader = (root / 'packaging/underwater-contact-isolation/Water.hlsl').read_bytes()
assert hashlib.sha256(baseline).hexdigest() == '1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e'
assert shader == baseline.replace(b'#define ST_SHORE_CONTACT_BLEND 1', b'#define ST_SHORE_CONTACT_BLEND 0')
assert '330/330' in (root / 'docs/underwater-contact-validation.txt').read_text()
payload = {
    'Shaders/SurfaceTides/Water.hlsl': shader,
    'SurfaceTides-underwater-contact-README.md': (root / 'docs/UNDERWATER-CONTACT-ISOLATION.md').read_bytes(),
}
for path in sorted((root / 'licenses').rglob('*')):
    if path.is_file():
        payload['SKSE/Plugins/SurfaceTides-licenses/' + str(path.relative_to(root / 'licenses'))] = path.read_bytes()
for name in ['LICENSE', 'THIRD_PARTY.md']:
    payload['SKSE/Plugins/SurfaceTides-licenses/' + name] = (root / name).read_bytes()
manifest = {
    'name': 'SurfaceTides-0.1.19.1-underwater-contact-test',
    'status': 'diagnostic; in-game outcome pending',
    'scope': 'ST_SHORE_CONTACT_BLEND 1 -> 0 only; accepted wading-depth correction retained',
    'dll_included': False, 'ini_included': False,
    'baseline_sha256': hashlib.sha256(baseline).hexdigest(),
    'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
              for name, data in payload.items()},
}
encoded = (json.dumps(manifest, indent=2) + '\n').encode()
(root / 'docs/underwater-contact-package.json').write_bytes(encoded)
payload['SurfaceTides-underwater-contact-manifest.json'] = encoded
mod = out / 'SurfaceTides-0.1.19.1-underwater-contact-test.zip'
with zipfile.ZipFile(mod, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(payload.items()):
        archive.writestr(name, data)
(root / 'recovery' / mod.name).write_bytes(mod.read_bytes())
source = out / 'SurfaceTides-source-menu.zip'
skip = {'.git', '__pycache__', 'build', 'out', 'vcpkg_installed'}
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if not path.is_file() or any(part in skip or part.startswith('build-') for part in relative.parts):
            continue
        if path.suffix in {'.pyc', '.obj', '.pdb', '.dll', '.lib'}:
            continue
        archive.write(path, 'SurfaceTides/' + str(relative))
for path in [mod, source]:
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
    print(path.name, path.stat().st_size, hashlib.sha256(path.read_bytes()).hexdigest())
with zipfile.ZipFile(mod) as archive:
    assert archive.read('Shaders/SurfaceTides/Water.hlsl') == shader
    assert not any(name.endswith(('.dll', '.ini')) for name in archive.namelist())
with zipfile.ZipFile(source) as archive:
    assert archive.read('SurfaceTides/Data/Shaders/SurfaceTides/Water.hlsl') == baseline
    assert archive.read('SurfaceTides/recovery/' + mod.name) == mod.read_bytes()
print('Overlay payload and baseline recovery checks passed.')
