#!/usr/bin/env python3
"""Check the compiled foam scan cannot call the legacy TES worldspace helper."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--nm', type=Path, required=True)
parser.add_argument('--old-object', type=Path, required=True)
parser.add_argument('--new-object', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
def symbols(path):
    return subprocess.check_output([str(args.nm),'-u',str(path)],text=True)
old,new = symbols(args.old_object),symbols(args.new_object)
legacy = '?ForEachReference@TES@RE@@'
required = ['?GetWorldspace@TESObjectREFR@RE@@','?GetSkyCell@TESWorldSpace@RE@@',
            '?ForEachReference@TESObjectCELL@RE@@','?IsInteriorCell@TESObjectCELL@RE@@']
assert legacy in old, 'Negative control does not reproduce the shipped legacy dependency'
assert legacy not in new, 'Foam still calls the crashing global reference scan'
assert '?ForEachReferenceInRange@TES@RE@@' not in new, 'Range helper reintroduces the same global worldspace read'
for symbol in required: assert symbol in new, f'Replacement discovery call missing: {symbol}'
report = {'passed':True, 'negative_control_0_1_20_rejected':True,
          'legacy_global_scan_absent':True, 'replacement_dependencies_verified':required,
          'old_object_sha256':hashlib.sha256(args.old_object.read_bytes()).hexdigest(),
          'new_object_sha256':hashlib.sha256(args.new_object.read_bytes()).hexdigest(),
          'scope':'Compiled object dependency check; does not execute Skyrim or establish crash-free gameplay.'}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print('PASS: shipped 0.1.20 fails the guard; hotfix uses player worldspace and cell-local iteration, with no legacy global scan dependency.')
