#!/usr/bin/env python3
"""Package the optional menu update without overwriting the user's active INI."""
from pathlib import Path
import argparse, hashlib, json, re, zipfile
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dll',type=Path,required=True)
parser.add_argument('--output-dir',type=Path,required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True)
version = re.search(r"project\(SurfaceTides VERSION ([0-9.]+)", (root/"CMakeLists.txt").read_text()).group(1)
def digest(data): return hashlib.sha256(data).hexdigest()
dll = args.dll.read_bytes()
assert ('SurfaceTides '+version+' development').encode() in dll
assert b'registered Surface Tides/Settings' in dll
shader = (root/'Data/Shaders/SurfaceTides/Water.hlsl').read_bytes()
assert digest(shader) == '1c936badb4737418f35567bad0a55611057a58b8acf1e59b1bb7f283cd03386e'
payload = {'SKSE/Plugins/SurfaceTides.dll':dll,
           'SurfaceTides-menu-README.md':(root/('docs/MENU-'+version+'.md')).read_bytes()}
for file in sorted((root/'Data/Shaders').rglob('*')):
    if file.is_file(): payload[str(file.relative_to(root/'Data'))] = file.read_bytes()
for file in sorted((root/'licenses').rglob('*')):
    if file.is_file(): payload['SKSE/Plugins/SurfaceTides-licenses/'+str(file.relative_to(root/'licenses'))] = file.read_bytes()
for name in ['LICENSE','THIRD_PARTY.md']:
    payload['SKSE/Plugins/SurfaceTides-licenses/'+name] = (root/name).read_bytes()
payload['SKSE/Plugins/SurfaceTides-licenses/SurfaceTides-example.ini'] = (root/'Data/SKSE/Plugins/SurfaceTides.ini').read_bytes()
assert 'SKSE/Plugins/SurfaceTides.ini' not in payload
manifest = {'version':version,'kind':'update overlay; existing installation required','ini_preserved':True,
 'accepted_shader_unchanged':True,'framework_bundled':False,'menu_controls_user_verified':True,'save_fix_user_verified':False,
 'portable_tests':'20/20 passed','files':{n:{'bytes':len(d),'sha256':digest(d)} for n,d in payload.items()}}
encoded = (json.dumps(manifest,indent=2)+'\n').encode()
(root/('docs/menu-'+version+'-package.json')).write_bytes(encoded)
payload['SurfaceTides-menu-manifest.json'] = encoded
runtime = out/('SurfaceTides-'+version+'-menu-update.zip')
with zipfile.ZipFile(runtime,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()): z.writestr(name,data)
# Keep all earlier compiled checkpoints and this build recoverable from source.
(root/'recovery'/runtime.name).write_bytes(runtime.read_bytes())
source = out/'SurfaceTides-source-menu.zip'
skip={'.git','__pycache__','build','out','vcpkg_installed'}
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file in sorted(root.rglob('*')):
        rel=file.relative_to(root)
        if not file.is_file() or any(part in skip or part.startswith('build-') for part in rel.parts): continue
        if file.suffix in {'.pyc','.obj','.pdb','.dll','.lib'}: continue
        z.write(file,'SurfaceTides/'+str(rel))
for file in [runtime,source]:
    with zipfile.ZipFile(file) as z: assert z.testzip() is None
    print(file.name,file.stat().st_size,digest(file.read_bytes()))
with zipfile.ZipFile(runtime) as z:
    assert z.read('SKSE/Plugins/SurfaceTides.dll') == dll
    assert z.read('Shaders/SurfaceTides/Water.hlsl') == shader
with zipfile.ZipFile(source) as z:
    assert z.read('SurfaceTides/recovery/'+runtime.name) == runtime.read_bytes()
    assert z.read('SurfaceTides/vendor/SKSEMenuFramework/SKSEMenuFramework.h') == (root/'vendor/SKSEMenuFramework/SKSEMenuFramework.h').read_bytes()
print('Archive payload and recovery checks passed')
