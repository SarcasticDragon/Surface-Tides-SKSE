#!/usr/bin/env python3
"""Check displaced-depth-blend candidate scope against saved r2 defaults.

DXC/SM6 compilation and byte/resource comparisons, not Windows SM5 execution.
"""
import argparse
import hashlib
import pathlib
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--dxc', required=True)
parser.add_argument('--reference', required=True)
parser.add_argument('--baseline-water', required=True, help='Saved r2 default Water.hlsl (same rendering as r1)')
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
source = root / 'Data/Shaders/SurfaceTides'
baseline = pathlib.Path(args.baseline_water).read_bytes()
current = (source / 'Water.hlsl').read_bytes()
dxc = str(pathlib.Path(args.dxc).resolve())
reference = str(pathlib.Path(args.reference).resolve())
descriptors = [0x0002, 0x001e, 0x005e, 0x00df, 0x071e, 0x075e, 0x003e, 0x015e,
               0x081e, 0x101e, 0x381e, 0x401e, 0x471e, 0x5000, 0x5802, 0x5001,
               0x031e, 0x011e, 0x035e, 0x0802, 0x0842, 0x410e, 0x430e, 0x011f,
               0x3002, 0x0106, 0x0116]
flags = ['VC', 'NORMAL_TEXCOORD', 'REFLECTIONS', 'REFRACTIONS', 'DEPTH', 'INTERIOR',
         'WADING', 'VERTEX_ALPHA_DEPTH', 'CUBEMAP', 'FLOWMAP', 'BLEND_NORMALS']
stages = [('VSHADER', 'vs_6_0'), ('CONTROL_SHADER', 'vs_6_0'), ('HSHADER', 'hs_6_0'),
          ('DSHADER', 'ds_6_0'), ('PSHADER', 'ps_6_0')]
variants = {'baseline': None, 'default': 0, 'r3': 1}
hashes = {}
resources = {}
total = 0
with tempfile.TemporaryDirectory(prefix='shore-diagnostics-') as directory:
    temp = pathlib.Path(directory)
    shutil.copytree(source, temp, dirs_exist_ok=True)
    subprocess.run([reference, '--headers', str(temp)], check=True)
    for variant, setting in variants.items():
        # Exercise the actual packaged default definitions, not command-line overrides.
        code = baseline if setting is None else current.replace(
            b'#define ST_DISPLACED_DEPTH_BLEND 0',
            f'#define ST_DISPLACED_DEPTH_BLEND {setting}'.encode())
        (temp / 'Water.hlsl').write_bytes(code)
        for descriptor in descriptors:
            defines = [name + '=1' for bit, name in enumerate(flags) if descriptor & (1 << bit)]
            technique = descriptor >> 11
            defines += (['SPECULAR=1', f'NUM_SPECULAR_LIGHTS={technique}'] if technique < 8 else
                        [{8: 'UNDERWATER', 9: 'LOD', 10: 'STENCIL', 11: 'SIMPLE'}[technique] + '=1'])
            for stage, target in stages:
                command = [dxc, str(temp / 'Water.hlsl'), '-T', target, '-E', 'main', '-HV', '2016',
                           '-Fo', str(temp / 'shader.dxil'), '-Fc', str(temp / 'shader.txt')]
                for define in defines + [stage + '=1', f'ST_PIXEL_DESCRIPTOR={descriptor}']:
                    command += ['-D', define]
                result = subprocess.run(command, capture_output=True, text=True)
                if result.returncode:
                    raise RuntimeError(f'{variant} {descriptor:X} {stage}: {result.stdout}{result.stderr}')
                hashes[variant, descriptor, stage] = hashlib.sha256((temp / 'shader.dxil').read_bytes()).hexdigest()
                if stage == 'PSHADER':
                    listing = (temp / 'shader.txt').read_text()
                    resources[variant, descriptor] = listing.split('; Resource Bindings:')[1].split('target datalayout')[0]
                total += 1

changed = []
for descriptor in descriptors:
    for stage, _ in stages:
        original = hashes['baseline', descriptor, stage]
        assert hashes['default', descriptor, stage] == original, f'Default changed {descriptor:X} {stage}'
        target = stage == 'PSHADER' and descriptor >> 11 == 0 and descriptor & 0x10 and not descriptor & 0x80
        different = hashes['r3', descriptor, stage] != original
        assert different == bool(target), f'Unexpected r3 scope {descriptor:X} {stage}'
        if different:
            changed.append(f'{descriptor:04X}')
        if stage == 'PSHADER':
            assert resources['r3', descriptor] == resources['baseline', descriptor], f'Resource bindings changed {descriptor:X}'

print(f'{total}/{total} DXC SM6 shader compilations passed across {len(descriptors)} descriptors.')
print(f'Default source: {len(descriptors) * len(stages)} byte-identical DXIL comparisons to saved r2 defaults.')
print('All geometry stages and underwater/stencil/non-target PS outputs remain byte-identical in r3.')
print('R3 changed PS: ' + ', '.join(changed))
print('All PS resource binding tables match baseline; SSR/refraction textures retained.')
print('Scope/compilation only; Windows SM5, live bindings and visual outcome need in-game testing.')
