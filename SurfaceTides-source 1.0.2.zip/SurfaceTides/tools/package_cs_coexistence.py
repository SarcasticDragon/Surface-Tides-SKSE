#!/usr/bin/env python3
"""Package the CS coexistence overlay and a complete source/recovery checkpoint."""
import argparse, hashlib, json, os, zipfile
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--dll',type=Path,required=True)
p.add_argument('--output-dir',type=Path,required=True)
a=p.parse_args(); root=Path(__file__).resolve().parents[1]
out=a.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
dll=a.dll.read_bytes()
report=json.loads((root/'docs/cs-0.1.25-build-validation.json').read_text())
assert report['compiled'] and report['dll_sha256']==sha(dll)
assert b'SurfaceTides 0.1.25 development (CS coexistence)' in dll
assert report['portable_test_groups_passed']==45 and report['discovery_regression']
assert report['accepted_floe_foam_solver_code_unchanged'] and report['accepted_shaders_unchanged']
assert report['enb_branch_unchanged'] and report['draw_algorithms_unchanged'] and report['no_cs_or_enb_binary_dependency']
assert report['cs_coexistence_opt_in'] and not report['cs_enabled_by_default'] and not report['cs_live_settings_queried']
accepted=root/'recovery/SurfaceTides-0.1.24.3-jump-release.zip'
assert sha(accepted.read_bytes())=='75f0bbccdf5ce705de14079c99a98fc75c8808592ac1861ea2edd277d3fde66b'
with zipfile.ZipFile(accepted) as z:
    payload={n:z.read(n) for n in z.namelist() if n.startswith('Shaders/')}
assert len(payload)==5
for name,data in payload.items(): assert (root/'Data'/name).read_bytes()==data
payload['SKSE/Plugins/SurfaceTides.dll']=dll
csName='SKSE/Plugins/CommunityShaders/Overrides/SurfaceTides_Global.json'
payload[csName]=(root/'optional/cs-coexistence'/csName).read_bytes()
assert sha(payload[csName])==report['cs_override_sha256']
payload['SurfaceTides-CS-README.md']=(root/'docs/CS-0.1.25.md').read_bytes()
payload['SurfaceTides-LICENSE.txt']=(root/'LICENSE').read_bytes()
assert not any(n.lower().endswith(('.ini','.nif','.dds','.esp','.esl','.esm')) for n in payload)
manifest={'version':'0.1.25','cs_runtime_result':'pending','ini_preserved':True,'portable_test_groups_passed':45,
    'cs_opt_in':'[Compatibility] AllowCS=1','cs_override':report['cs_override'],'cs_live_settings_queried':False,
    'accepted_baseline':'0.1.24.3 jump release; user-confirmed effective',
    'accepted_floe_foam_solver_code_unchanged':True,'accepted_shaders_unchanged':True,
    'enb_branch_unchanged':True,'draw_algorithms_unchanged':True,
    'ice_is_slick':'Incompatible with ice bobbing for now',
    'files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in payload.items()}}
encoded=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'docs/cs-0.1.25-package.json').write_bytes(encoded)
payload['SurfaceTides-CS-manifest.json']=encoded

def write_zip(path,files):
    temporary=path.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in files: z.writestr(name,data)
    with temporary.open('rb') as f: os.fsync(f.fileno())
    with zipfile.ZipFile(temporary) as z: assert z.testzip() is None
    temporary.replace(path)

mod=out/'SurfaceTides-0.1.25-CS-coexistence.zip'
write_zip(mod,sorted(payload.items()))
with zipfile.ZipFile(mod) as z:
    for name,data in payload.items(): assert z.read(name)==data
(root/'recovery'/mod.name).write_bytes(mod.read_bytes())
source=out/'SurfaceTides-source-menu.zip'
skip={'.git','__pycache__','build','out','vcpkg_installed'}
def source_files():
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if not path.is_file() or any(p in skip or p.startswith('build-') for p in rel.parts): continue
        if path.suffix.lower() in {'.pyc','.obj','.pdb','.dll','.lib','.nif','.dds'}: continue
        yield 'SurfaceTides/'+rel.as_posix(),path.read_bytes()
write_zip(source,source_files())
with zipfile.ZipFile(source) as z:
    for name,data in source_files(): assert z.read(name)==data
    assert z.read('SurfaceTides/recovery/'+mod.name)==mod.read_bytes()
    assert z.read('SurfaceTides/recovery/'+accepted.name)==accepted.read_bytes()
for path in [mod,source]: print(path.name,path.stat().st_size,sha(path.read_bytes()))
print('Verified CS overlay, exact three-setting override, INI preservation, accepted shaders and full source/recovery checkpoint.')
