#include "surfacetides/Simulation.hpp"
#include "surfacetides/ShaderLayout.hpp"
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>

int main(int argc,char** argv) {
    if(argc==3 && std::string_view(argv[1])=="--headers") {
        std::filesystem::create_directories(argv[2]);
        std::ofstream(std::filesystem::path(argv[2])/"EngineVS.hlsli")<<st::engineConstantHeader(st::ShaderStage::Vertex,st::referenceConstantTable(st::ShaderStage::Vertex));
        std::ofstream(std::filesystem::path(argv[2])/"EnginePS.hlsli")<<st::engineConstantHeader(st::ShaderStage::Pixel,st::referenceConstantTable(st::ShaderStage::Pixel));
        return 0;
    }
    if(argc!=2) { std::cerr<<"Usage: SurfaceTidesReference output.bin | --headers directory\n"; return 2; }
    st::Settings settings; settings.resolution=128; settings.spacing=8; settings.waveSpeed=115; settings.dispersion=80000;
    settings.wind=0; settings.damping=0.18f; settings.edgeDamping=5; settings.spongeCells=12;
    st::Surface surface(settings);
    std::vector<std::uint8_t> wet(surface.cells().size(),1);
    for(int y=0;y<128;++y) for(int x=0;x<128;++x) {
        const float wx=(x-64)*8.0f, wy=(y-64)*8.0f;
        if((wx+100)*(wx+100)+(wy-85)*(wy-85)<55*55 || (x==85 && (y<47||y>63))) wet[y*128+x]=0;
    }
    surface.setWetMask(wet);
    st::ContactTracker tracker; std::vector<st::Impulse> impulses;
    std::ofstream file(argv[1],std::ios::binary);
    if(!file) return 2;
    const std::uint32_t header[]={0x53544944,128,180,30};
    file.write(reinterpret_cast<const char*>(header),sizeof(header));
    file.write(reinterpret_cast<const char*>(wet.data()),static_cast<std::streamsize>(wet.size()));
    for(int frame=0;frame<180;++frame) {
        for(int sub=0;sub<4;++sub) {
            const double time=(frame*4+sub)/120.0;
            st::Contact contact{1,{static_cast<float>(-360+time*125),-110},-10,0,18,false};
            tracker.update(std::span(&contact,1),1.0/120,impulses);
            for(auto impulse:impulses) { impulse.velocity*=3; surface.addImpulse(impulse); }
            if(frame==3 && sub==0) surface.addImpulse({{-180,65},22,85});
            if(frame==40 && sub==0) surface.addImpulse({{85,40},18,55});
            surface.advance(1.0/120);
        }
        for(const auto& cell:surface.cells()) file.write(reinterpret_cast<const char*>(&cell.height),sizeof(float));
    }
    std::cout<<"180 frames from the production C++ solver; clipped cells="<<surface.diagnostics().clippedCells<<'\n';
    return surface.diagnostics().clippedCells ? 1 : 0;
}
