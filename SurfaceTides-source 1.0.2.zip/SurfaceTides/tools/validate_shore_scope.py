#!/usr/bin/env python3
"""Check shoreline patch scope against an unmodified 0.1.17 Water.hlsl.
DXC/SM6 only: does not execute Windows D3DCompiler or Skyrim.
"""
import argparse, hashlib, pathlib, shutil, subprocess, tempfile
parser = argparse.ArgumentParser()
parser.add_argument('--dxc', required=True)
parser.add_argument('--reference', required=True)
parser.add_argument('--baseline-water', required=True)
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
source = root/'Data/Shaders/SurfaceTides'
dxc = pathlib.Path(args.dxc).resolve()
reference = pathlib.Path(args.reference).resolve()
baseline = pathlib.Path(args.baseline_water).read_bytes()
patch = (source/'Water.hlsl').read_bytes()
descriptors = [0x0002,0x001e,0x005e,0x00df,0x071e,0x075e,0x003e,0x015e,0x081e,0x101e,0x381e,0x401e,0x471e,0x5000,0x5802,0x5001,0x031e,0x011e,0x035e,0x0802,0x0842,0x410e,0x430e]
flags = ['VC','NORMAL_TEXCOORD','REFLECTIONS','REFRACTIONS','DEPTH','INTERIOR','WADING','VERTEX_ALPHA_DEPTH','CUBEMAP','FLOWMAP','BLEND_NORMALS']
stages = [('VSHADER','vs_6_0'),('CONTROL_SHADER','vs_6_0'),('HSHADER','hs_6_0'),('DSHADER','ds_6_0'),('PSHADER','ps_6_0')]
with tempfile.TemporaryDirectory(prefix='shore-scope-') as tmp:
    temp = pathlib.Path(tmp)
    shutil.copytree(source, temp, dirs_exist_ok=True)
    subprocess.run([str(reference),'--headers',str(temp)],check=True)
    hashes = {}
    total = 0
    for mode in [None, 0, 1, 2]:
        (temp/'Water.hlsl').write_bytes(baseline if mode is None else patch)
        for descriptor in descriptors:
            defines=[name+'=1' for bit,name in enumerate(flags) if descriptor&(1<<bit)]
            technique=descriptor>>11
            defines += ['SPECULAR=1',f'NUM_SPECULAR_LIGHTS={technique}'] if technique<8 else [{8:'UNDERWATER',9:'LOD',10:'STENCIL',11:'SIMPLE'}[technique]+'=1']
            for stage,target in stages:
                args=[str(dxc),str(temp/'Water.hlsl'),'-T',target,'-E','main','-HV','2016','-Fo',str(temp/'shader.dxil')]
                for define in defines+[stage+'=1',f'ST_PIXEL_DESCRIPTOR={descriptor}']+([] if mode is None else [f'ST_SHORE_REFRACTION={mode}']):
                    args+=['-D',define]
                result=subprocess.run(args,capture_output=True,text=True)
                if result.returncode: raise RuntimeError(f'{mode} {descriptor:X} {stage}: {result.stdout}{result.stderr}')
                hashes[mode,descriptor,stage]=hashlib.sha256((temp/'shader.dxil').read_bytes()).hexdigest()
                total+=1
    permitted=[]
    for descriptor in descriptors:
        for stage,_ in stages:
            original=hashes[None,descriptor,stage]
            assert hashes[0,descriptor,stage]==original, f'Baseline mode changed {descriptor:X} {stage}'
            may_change=stage=='PSHADER' and descriptor>>11==0 and (descriptor&0x18)==0x18 and not descriptor&0x80
            for mode in [1,2]:
                if not may_change: assert hashes[mode,descriptor,stage]==original, f'Unexpected scope change: {mode} {descriptor:X} {stage}'
            if may_change and hashes[1,descriptor,stage]!=original: permitted.append(f'{descriptor:04X}')
    print(f'{total}/{total} DXC SM6 shader compilations passed; shader modes 0/1/2 covered.')
    print(f'Baseline mode: {len(descriptors)*len(stages)} byte-identical DXIL comparisons passed.')
    print('All vertex/control/hull/domain stages and underwater/stencil/non-target pixel shaders match baseline DXIL.')
    print('Changed above-water refraction PS descriptors: '+', '.join(permitted))
    print('This is Linux SM6 semantic/scope validation, not Windows SM5 or Skyrim execution.')
