unit SurfaceTides_SurfaceObjects;

// Surface Tides: read-only inventory and explicit foam-removal export.
// Does not edit plugins or install output. See README.md beside this script.
// SPDX-License-Identifier: GPL-3.0-or-later

var
  Seen, Inventory, Rules, Problems, AllowKeys, AllowModels, Matched: TStringList;
  OutputDir: string;
  Ready: Boolean;
  Exported: Integer;

function Clean(s: string): string;
begin
  s := StringReplace(s, #9, ' ', [rfReplaceAll]);
  s := StringReplace(s, #13, ' ', [rfReplaceAll]);
  Result := StringReplace(s, #10, ' ', [rfReplaceAll]);
end;

function ModelPath(s: string): string;
begin
  s := LowerCase(Trim(StringReplace(s, '/', '\', [rfReplaceAll])));
  if Copy(s, 1, 7) = 'meshes\' then Delete(s, 1, 7);
  Result := s;
end;

function Winner(e: IInterface): IInterface;
begin
  Result := WinningOverride(MasterOrSelf(e));
  if not Assigned(Result) then Result := e;
end;

function FormKey(e: IInterface): string;
var
  original, owner: IInterface;
  runtimeID, localID, fileID: Cardinal;
begin
  Result := '';
  original := MasterOrSelf(e);
  owner := GetFile(original);
  runtimeID := GetLoadOrderFormID(original);
  if GetIsESL(owner) then localID := runtimeID and $FFF
  else localID := runtimeID and $FFFFFF;
  // Verify ownership rather than guessing a plugin for an injected record.
  fileID := (MasterCount(owner) shl 24) or localID;
  if FileFormIDtoLoadOrderFormID(owner, fileID) <> runtimeID then Exit;
  if localID = 0 then Exit;
  Result := '0x' + IntToHex(localID, 6) + '~' + GetFileName(owner);
end;

function Candidate(s: string): Boolean;
begin
  s := LowerCase(s);
  Result := (Pos('foam', s) > 0) or (Pos('rapid', s) > 0) or
    (Pos('whitewater', s) > 0) or (Pos('waterfall', s) > 0) or
    (Pos('icefloe', s) > 0) or (Pos('ice floe', s) > 0) or
    (Pos('iceberg', s) > 0);
end;

function BaseType(s: string): Boolean;
begin
  Result := (s = 'STAT') or (s = 'MSTT') or (s = 'ACTI');
end;

function Initialize: Integer;
var
  lines: TStringList;
  i, split: Integer;
  line, key, model, allowFile: string;
begin
  Result := 0;
  Ready := False;
  Exported := 0;
  Seen := TStringList.Create;
  Seen.Sorted := True;
  Seen.CaseSensitive := False;
  Inventory := TStringList.Create;
  Rules := TStringList.Create;
  Problems := TStringList.Create;
  AllowKeys := TStringList.Create;
  AllowKeys.CaseSensitive := False;
  AllowModels := TStringList.Create;
  Matched := TStringList.Create;
  Matched.CaseSensitive := False;
  OutputDir := ScriptsPath + 'SurfaceTides-output\' + FormatDateTime('yyyymmdd-hhnnss', Now) + '\';
  if DirectoryExists(OutputDir) then begin
    AddMessage('Surface Tides: output directory already exists; run again in a moment.');
    Result := 1;
    Exit;
  end;
  if not ForceDirectories(OutputDir) then begin
    AddMessage('Surface Tides: cannot create ' + OutputDir);
    Result := 1;
    Exit;
  end;
  Inventory.Add('FormKey' + #9 + 'ModelPath' + #9 + 'Type' + #9 +
    'EditorID' + #9 + 'WinningRecordFile' + #9 + 'BaseFormKey' + #9 +
    'WinningBaseFile' + #9 + 'Status');
  Rules.Add('; Surface Tides: explicitly reviewed standalone foam only. Requires BOS 3.0+.');
  Rules.Add('; Generated from the records processed in this xEdit session.');
  Rules.Add('; A base-form rule disables all its placements. A REFR rule targets one placement.');
  Rules.Add('; This file is independent of the Surface Tides enable/disable setting.');
  Rules.Add('[Transforms]');
  allowFile := ScriptsPath + 'SurfaceTides_FoamAllowlist.tsv';
  lines := TStringList.Create;
  try
    if FileExists(allowFile) then lines.LoadFromFile(allowFile);
    for i := 0 to lines.Count - 1 do begin
      line := Trim(lines[i]);
      if line = '' then Continue;
      if Copy(line, 1, 1) = '#' then Continue;
      if Copy(line, 1, 1) = ';' then Continue;
      split := Pos(#9, line);
      if split = 0 then begin
        Problems.Add('Allowlist line ' + IntToStr(i + 1) + ': expected FormKey TAB ModelPath.');
        Continue;
      end;
      key := Trim(Copy(line, 1, split - 1));
      model := ModelPath(Copy(line, split + 1, Length(line)));
      if (LowerCase(key) = 'formkey') and (model = 'modelpath') then Continue;
      if (Pos('~', key) = 0) or (model = '') or (Pos(#9, model) > 0) or
        (Pos('|', key) > 0) or (Pos(';', key) > 0) then begin
        Problems.Add('Allowlist line ' + IntToStr(i + 1) + ': invalid key/model; copy the first two inventory columns.');
        Continue;
      end;
      if AllowKeys.IndexOf(key) >= 0 then begin
        Problems.Add('Duplicate allowlist key: ' + key);
        Continue;
      end;
      AllowKeys.Add(key);
      AllowModels.Add(model);
    end;
  finally
    lines.Free;
  end;
  Ready := True;
  AddMessage('Surface Tides: read-only scan; name matches are inventory candidates, never automatic removals.');
  AddMessage('Output: ' + OutputDir);
end;

function Process(e: IInterface): Integer;
var
  recordWinner, base: IInterface;
  kind, key, identity, model, status, baseKey, textToCheck: string;
  index: Integer;
begin
  Result := 0;
  if not Ready then Exit;
  kind := Signature(e);
  if not BaseType(kind) and (kind <> 'REFR') then Exit;
  recordWinner := Winner(e);
  identity := IntToHex(GetLoadOrderFormID(recordWinner), 8);
  if Seen.IndexOf(identity) >= 0 then Exit;
  Seen.Add(identity);
  key := FormKey(recordWinner);
  index := AllowKeys.IndexOf(key);
  base := recordWinner;
  if kind = 'REFR' then begin
    base := LinksTo(ElementByPath(recordWinner, 'NAME'));
    if not Assigned(base) then Exit;
    base := Winner(base);
  end;
  if not BaseType(Signature(base)) then Exit;
  baseKey := FormKey(base);
  model := ModelPath(GetElementEditValues(base, 'Model\MODL'));
  if model = '' then model := ModelPath(GetElementEditValues(base, 'MODL'));
  textToCheck := EditorID(recordWinner) + ' ' + EditorID(base) + ' ' + model;
  if not Candidate(textToCheck) and (index < 0) then Exit;
  status := 'review mesh; name match is not proof of standalone foam';
  if GetIsDeleted(recordWinner) or GetIsDeleted(base) then status := 'deleted record; no rule';
  if key = '' then status := 'unsupported/injected identity; no rule';
  if index >= 0 then begin
    Matched.Add(key);
    if GetIsDeleted(recordWinner) or GetIsDeleted(base) then
      Problems.Add(key + ': deleted record cannot be exported.')
    else if model <> AllowModels[index] then
      Problems.Add(key + ': winning model path differs from allowlist (' + model + ').')
    else if ElementExists(recordWinner, 'VMAD') or ElementExists(base, 'VMAD') then
      Problems.Add(key + ': scripted record requires separate review.')
    else if (kind = 'REFR') and ElementExists(recordWinner, 'XESP') then
      Problems.Add(key + ': enable-parent reference requires separate review.')
    else begin
      Rules.Add('; ' + Clean(EditorID(base)) + ' | ' + Clean(model));
      Rules.Add(key + '|flags(0x00000800)');
      Inc(Exported);
      status := 'allowlisted removal; full object, including any embedded rock geometry';
    end;
  end;
  if key = '' then key := 'UNSUPPORTED:' + identity;
  Inventory.Add(Clean(key) + #9 + Clean(model) + #9 + kind + #9 +
    Clean(EditorID(recordWinner)) + #9 + Clean(GetFileName(GetFile(recordWinner))) + #9 +
    Clean(baseKey) + #9 + Clean(GetFileName(GetFile(base))) + #9 + status);
end;

function Finalize: Integer;
var
  i: Integer;
begin
  Result := 0;
  try
    if not Ready then Exit;
    Inventory.SaveToFile(OutputDir + 'SurfaceTides_SurfaceObjects.tsv');
    for i := 0 to AllowKeys.Count - 1 do
      if Matched.IndexOf(AllowKeys[i]) < 0 then
        Problems.Add(AllowKeys[i] + ': not found among processed supported records; check selection and key.');
    if Problems.Count > 0 then begin
      Problems.Insert(0, 'No installable INI generated. Resolve every entry and rerun.');
      Problems.SaveToFile(OutputDir + 'SurfaceTides_Foam_BLOCKED.txt');
      AddMessage('Surface Tides: inventory written, export BLOCKED. See SurfaceTides_Foam_BLOCKED.txt.');
      Result := 1;
    end else begin
      Rules.SaveToFile(OutputDir + 'SurfaceTides_Foam_SWAP.ini');
      AddMessage('Surface Tides: inventory written; exported ' + IntToStr(Exported) + ' explicit foam rules.');
      AddMessage('Install the generated INI at Data root only after reviewing the listed whole objects.');
    end;
    AddMessage('Output: ' + OutputDir);
  finally
    Seen.Free;
    Inventory.Free;
    Rules.Free;
    Problems.Free;
    AllowKeys.Free;
    AllowModels.Free;
    Matched.Free;
  end;
end;

end.
