# Surface Tides — foam inventory and BOS export

Optional preparation tool, version 0.1. No Surface Tides DLL update is needed. The accepted 0.1.19.2 build remains the stress-test baseline.

The script reads winning STAT, MSTT, ACTI and REFR records from the selection processed by xEdit. It inventories names/model paths containing foam, rapid, whitewater, waterfall, icefloe, ice floe or iceberg. These are discovery hints: a match does **not** cause removal. Unusually named assets may be missed. Explicit allowlist entries are also examined even without a name match.

## First pass: inventory only

1. Put `SurfaceTides_SurfaceObjects.pas` and `SurfaceTides_FoamAllowlist.tsv` in SSEEdit's `Edit Scripts` directory.
2. Launch SSEEdit through the mod manager with the relevant full load order. Select the loaded plugins and apply `SurfaceTides_SurfaceObjects`. A smaller selection works but inventories only that selection; referenced base records are resolved to their winning overrides.
3. Find the timestamped output directory printed in Messages, underneath `Edit Scripts/SurfaceTides-output`. The script creates a new directory per run and does not edit any plugin or install files into Data.

With the supplied empty allowlist, it produces an inventory and a **zero-rule** BOS INI. Installing that empty INI does nothing. The useful first result is `SurfaceTides_SurfaceObjects.tsv`.

`WinningRecordFile` and `WinningBaseFile` identify plugin-record winners, **not the mod supplying the NIF bytes**. The winning model path can still be overridden by a loose file or BSA. Inspect the effective model through the mod manager/NifSkope before approving removal. This script neither reads nor edits NIF geometry, extracts archives, nor resolves BOS swaps performed later at runtime.

## Generate removal rules

After verifying that an entire object is unwanted flat foam, copy its **first two inventory columns** (FormKey, ModelPath), separated by a tab, into `SurfaceTides_FoamAllowlist.tsv`. Leave the comment lines in place. Rerun the script over the full selection.

- A STAT/MSTT/ACTI key targets **all placements** of that base object. A REFR key targets only that placement; use this for the first local comparison.
- Never approve a rapid-rock object if any of its rock geometry should remain. The generated rule disables the whole object.
- No supplied vanilla or modded IDs are assumed. Keys include the originating plugin and local ID, independent of ordinary load-order index changes. FormID compaction/renumbering still requires regeneration. Injected/ambiguous ownership is rejected by an ID round-trip check.
- Model-path changes, scripted selected records, enable-parent selected REFRs, missing entries and malformed/duplicate allowlist lines block the entire export. The inventory is still written, alongside a `SurfaceTides_Foam_BLOCKED.txt` report. No installable INI is written on a blocked run.
- An unchanged path does not mean unchanged NIF contents. Recheck affected entries after mesh-replacer changes. A base-form rule cannot guarantee that every placement is free of scripts, enable parents or later BOS changes; reference-specific rules are the narrower option.

Successful output is `SurfaceTides_Foam_SWAP.ini`. Install just that generated file at a mod's **Data root**, with Base Object Swapper 3.0 or later available. It uses documented `[Transforms]` rules and `flags(0x00000800)` to mark targeted references initially disabled. No dummy mesh or ESP is generated.

Removal is independent of the Surface Tides menu toggle: turning simulation off does not restore foam. Disable the generated INI mod and restart/reload for the comparison. This tool does not clear enable/disable state already stored by other mods in a save; use the preserved test save when checking reversibility. Other BOS rules or scripted enable-state changes can affect the result. Do not install multiple stale generated INIs together.

## Useful files to return

The inventory identifies candidates for both foam and ice work. For embedded-foam implementation, supply one representative **winning rapid-rock NIF**, plus its relative mesh path and base/reference identity from the inventory. If comparing vanilla/ERM/Gol Mora variants, keep each variant identified separately. No texture archive or full mod collection is needed initially.

## Validation and sources

This is a development helper: its xEdit calls and BOS syntax were checked against official source/docs, but it has **not been executed in SSEEdit or Skyrim here**. There is no Windows/xEdit test environment available. The script performs no record mutation calls; only its output text files are written. No claim is made that all foam in a given load order can be discovered from record names.

- [BOS configuration and reference flags](https://www.nexusmods.com/skyrimspecialedition/mods/60805)
- [BOS source: property parsing](https://github.com/powerof3/BaseObjectSwapper/blob/c0b9c093aa6260fd9b68beddea411db97f585ea2/src/SwapData.cpp)
- [BOS source: flag application](https://github.com/powerof3/BaseObjectSwapper/blob/c0b9c093aa6260fd9b68beddea411db97f585ea2/src/ObjectProperties.cpp)
- [xEdit scripting functions](https://tes5edit.github.io/docs/13-Scripting-Functions.html)
- [xEdit file API](https://github.com/TES5Edit/TES5Edit/blob/9fb016884bec138ea6c7b872cec831537d464c3e/xEdit/JvI/xejviScriptAdapterFile.pas)
- [xEdit record API](https://github.com/TES5Edit/TES5Edit/blob/9fb016884bec138ea6c7b872cec831537d464c3e/xEdit/JvI/xejviScriptAdapterRecord.pas)

The helper is original Surface Tides code under GPL-3.0-or-later. See the included project LICENSE. No third-party mod code or game meshes are included.
