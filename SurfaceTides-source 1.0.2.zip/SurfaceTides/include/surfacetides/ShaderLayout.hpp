#pragma once
#include <cstdint>
#include <span>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace st {
enum class ShaderStage { Vertex, Pixel };
// Offsets are FLOAT offsets, not byte or float4 offsets. A negative entry is absent.
std::string engineConstantHeader(ShaderStage stage, std::span<const std::int8_t> table,
    std::optional<std::span<const std::string>> activeNames = std::nullopt);
std::vector<std::pair<std::string,std::string>> shaderDefines(std::uint32_t descriptor, const char* stage,
                                                            std::uint32_t pixelDescriptor);
std::vector<std::int8_t> referenceConstantTable(ShaderStage stage);
}
