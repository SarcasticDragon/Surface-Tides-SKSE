#pragma once
#include "Simulation.hpp"
#include <array>

namespace st {
// Shared with the renderer's immutable Frame; preserves the float4 upload ABI.
struct SurfaceTexel { float height{}, slopeX{}, slopeY{}, wet{}; };
static_assert(sizeof(SurfaceTexel) == 16);

// Non-owning view. The caller must retain its Frame while sampling and supply
// the matching applied displacement setting and worldspace/interior identity.
// This module does not read engine objects or move collision/render nodes.
struct SurfaceFieldView {
    std::span<const SurfaceTexel> texels;
    Vec2 origin;
    float spacing{}, restLevel{}, displacementStrength{};
    int resolution{}, edgeFadeCells{};
    std::uint64_t area{};
    bool active{};
};
struct SurfaceHeight {
    float displacement{}, coverage{};
    bool valid{};
};
// level is the water's authored rest level, NOT the object's pivot height.
// Matches SurfaceField.hlsli: bilinear texels, then wet multiplier, edge fade,
// strict 2-unit water-level band and displacement strength. No shading normals.
[[nodiscard]] SurfaceHeight sampleSurfaceHeight(const SurfaceFieldView& field,
    Vec2 world, float level, std::uint64_t area) noexcept;

struct FloeFootprint {
    Vec2 center, halfExtent;
    float yawRadians{}, waterLevel{};
    std::uint64_t area{};
};
struct FloeLimits { float maxHeave = 48.0f, maxTiltRadians = 0.13962634f; }; // 8 degrees
struct FloePose {
    // Relative to the authored rest pose at the footprint center.
    // Plane normal = normalize(-slope.x, -slope.y, 1).
    float heave{};
    Vec2 slope;
};
struct FloeTarget {
    FloePose pose;
    float coverage{};
    bool valid{};
};
// Least-squares plane over a symmetric 3x3 footprint. Includes zero displacement
// outside the field to follow the renderer's local patch falloff. A rigid body
// approximates this plane; it cannot conform to every short ripple underneath.
[[nodiscard]] FloeTarget fitFloeTarget(const SurfaceFieldView& field,
    const FloeFootprint& footprint, FloeLimits limits = {}) noexcept;
struct FloeCrestTarget {
    FloeTarget target;
    float meanHeave{}, addedLift{}, peakDisplacement{};
    unsigned samples{};
    bool limited{};
};
// Visual clearance aid, not physical buoyancy: raise the fitted plane toward
// the highest sampled crest beneath its footprint. Strength=0 retains the
// original fit exactly. Additional freeboard fades away with wave amplitude.
// Sampling is bounded to 65x65, at approximately one field cell per interval.
// A bound-based footprint cannot guarantee clearance for arbitrary mesh tops.
[[nodiscard]] FloeCrestTarget fitFloeCrestTarget(const SurfaceFieldView& field,
    const FloeFootprint& footprint, FloeLimits limits, float strength, float extraLift) noexcept;
// Time-based response, with no separate oscillator. Invalid fields settle to
// rest; paused/nonfinite time retains the prior pose. Epoch changes/restoring
// authored transforms are the future engine adapter's responsibility.
[[nodiscard]] FloePose approachFloeTarget(FloePose prior, const FloeTarget& target,
    float seconds, float responseSeconds) noexcept;
// World-space minimal tilt: row-major rotation taking +Z to the fitted normal.
// Compose on the left of the authored orientation, around the rest water pivot.
[[nodiscard]] std::array<float,9> floeTiltRotation(FloePose pose) noexcept;
// Bound point travel over the floe's radius, including heave and tilt change.
[[nodiscard]] FloePose limitFloeStep(FloePose prior, FloePose next,
    float radius, float maxTravel) noexcept;
} // namespace st
