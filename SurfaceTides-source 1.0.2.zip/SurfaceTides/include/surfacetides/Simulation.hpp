#pragma once

#include <cstdint>
#include <span>
#include <vector>

namespace st {
struct Vec2 { float x{}, y{}; };
struct Cell { float height{}, velocity{}; };
static_assert(sizeof(Cell) == 8);

struct Settings {
    int resolution = 192;
    float spacing = 20.0f;             // Skyrim world units per cell
    float waveSpeed = 210.0f;          // world units / second
    float dispersion = 180000.0f;      // world units^4 / second^2; positive capillary stiffness
    float damping = 0.32f;             // exponential amplitude damping, 1 / second
    float edgeDamping = 4.0f;
    int spongeCells = 16;
    float maxHeight = 24.0f;           // last-resort limiter, counted in diagnostics
    float gustStrength = 1.0f;        // localized idle forcing multiplier, 0 restores continuous wind only
    float wind = 0.25f;               // forcing acceleration amplitude
    void validate() const;
    [[nodiscard]] double timestep() const;
    bool operator==(const Settings&) const = default;
};

struct Impulse { Vec2 position; float radius = 30.0f; float velocity = 40.0f; };
struct Diagnostics {
    std::uint64_t steps{}, clippedCells{}, rejectedImpulses{};
    double droppedSeconds{};
};

// A local, fixed-rest-level free surface. It never changes gameplay water height.
// Units: height in game units; velocity in game units/s. x/y are world axes.
class Surface {
public:
    explicit Surface(Settings settings = {});
    void reset(Vec2 center, float waterLevel);
    void recenter(Vec2 center);        // integer-cell scroll; preserves world-space history
    void setWetMask(std::span<const std::uint8_t> mask);
    void addImpulse(const Impulse& impulse); // zero integrated momentum, including near shores
    void advance(double seconds, int maxSteps = 16);
    void step();
    // Game-thread only. Preserve water/history while changing coefficients on the same grid.
    void retune(const Settings& settings);

    [[nodiscard]] Vec2 origin() const { return origin_; }
    [[nodiscard]] float level() const { return level_; }
    [[nodiscard]] const Settings& settings() const { return settings_; }
    [[nodiscard]] std::span<const Cell> cells() const { return state_; }
    [[nodiscard]] std::span<const std::uint8_t> wetMask() const { return wet_; }
    [[nodiscard]] const Diagnostics& diagnostics() const { return diagnostics_; }
    [[nodiscard]] float sample(Vec2 world) const;
    [[nodiscard]] Vec2 gradient(Vec2 world) const;
    [[nodiscard]] double energy() const;
    [[nodiscard]] double meanHeight() const;
    [[nodiscard]] bool finite() const;
    // For analytic-mode initialization and external terrain adapters, not concurrent access.
    void setState(std::span<const Cell> values);

private:
    void updateAttenuation();
    void laplacian(std::span<const float> in, std::span<float> out) const;
    Settings settings_;
    Vec2 origin_{};
    float level_{};
    double accumulator_{}, time_{};
    std::vector<Cell> state_, scratch_;
    std::vector<std::uint8_t> wet_, wetScratch_;
    std::vector<float> heights_, lap_, bilap_, attenuation_;
    Diagnostics diagnostics_;
};

struct Contact {
    std::uint32_t id{};
    Vec2 position;
    float baseZ{}, waterLevel{}, radius{25.0f};
    bool swimming{};
};

// Produces frame-rate-normalized wakes and entry impacts. No RE pointers are retained.
class ContactTracker {
public:
    void update(std::span<const Contact> contacts, double dt, std::vector<Impulse>& output, float strength = 1, float radiusScale = 1);
    void reset();
private:
    struct Previous { Contact contact; bool touching{}; };
    std::vector<Previous> previous_;
};
} // namespace st
