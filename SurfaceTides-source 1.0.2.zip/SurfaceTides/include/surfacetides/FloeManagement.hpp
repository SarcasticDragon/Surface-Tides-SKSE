#pragma once
#include "FloeMotion.hpp"
#include "FoamSelection.hpp"
#include <algorithm>
#include <cmath>

namespace st {
inline constexpr std::size_t maxManagedFloes=64, maxFloeRefreshes=8;
constexpr bool isFloeProfile(int profile) noexcept {
    // Decal filtering has broader coverage than the three reviewed moving floes.
    return profile>=2 && profile<=4 && foam::profiles[profile].iceDecal;
}
// Conservative XY bound test, including floes whose pivots are outside the
// patch but whose geometry extends into it. Area/water qualification is separate.
inline bool floeOverlapsField(const SurfaceFieldView& field, Vec2 center, float radius) noexcept {
    if (!field.active || field.resolution<2 || field.resolution>512 ||
        !std::isfinite(field.spacing) || field.spacing<=0 ||
        !std::isfinite(field.origin.x) || !std::isfinite(field.origin.y) ||
        !std::isfinite(center.x) || !std::isfinite(center.y) || !std::isfinite(radius) || radius<=0) return false;
    const double span=double(field.resolution-1)*field.spacing;
    const double x=std::clamp(double(center.x),double(field.origin.x),field.origin.x+span)-center.x;
    const double y=std::clamp(double(center.y),double(field.origin.y),field.origin.y+span)-center.y;
    return x*x+y*y<=double(radius)*radius;
}
struct FloeRefreshRequest { float age{}; bool required{}, supported{}; };
// Age-based budget with a small rider preference. The preference is bounded:
// occupied floes cannot permanently starve unoccupied floes. Missing/invalidated
// targets must be recomputed before they can be used for motion.
inline std::size_t selectFloeRefreshes(std::span<const FloeRefreshRequest> requests,
    std::span<std::size_t> output) noexcept {
    const std::size_t budget=std::min(output.size(),maxFloeRefreshes);
    std::array<double,maxFloeRefreshes> scores{};
    std::size_t count=0;
    for (std::size_t i=0;i<std::min(requests.size(),maxManagedFloes);++i) {
        const auto& r=requests[i];
        if (!std::isfinite(r.age) || r.age<0) continue;
        if (!r.required && r.age<(r.supported ? 1.0f/60 : 1.0f/30)) continue;
        const double score=r.age+(r.supported ? 1.0/30 : 0)+(r.required ? 1.0 : 0);
        std::size_t at=0;
        while (at<count && scores[at]>=score) ++at;
        if (at>=budget) continue;
        const auto end=std::min(count,budget-1);
        for (auto j=end;j>at;--j) { scores[j]=scores[j-1]; output[j]=output[j-1]; }
        scores[at]=score; output[at]=i; count=std::min(count+1,budget);
    }
    return count;
}
} // namespace st
