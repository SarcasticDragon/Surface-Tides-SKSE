#pragma once
#include <cmath>
namespace st {
struct MeshBounds { float x{},y{},z{},radius{}; bool valid{}; };
inline bool outsideMeshField(const MeshBounds& b, float x, float y, float extent, float level) {
    if (!b.valid || !std::isfinite(b.x) || !std::isfinite(b.y) || !std::isfinite(b.z) ||
        !std::isfinite(b.radius) || b.radius<=0 || !std::isfinite(x) || !std::isfinite(y) ||
        !std::isfinite(extent) || extent<=0 || !std::isfinite(level)) return false;
    // Extra margin also protects floating-point comparisons at patch borders.
    const float r=b.radius+4;
    return b.x+r<x || b.y+r<y || b.x-r>x+extent || b.y-r>y+extent ||
        b.z+r<level-2 || b.z-r>level+2;
}
}
