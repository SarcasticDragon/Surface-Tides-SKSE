#pragma once

#include "Simulation.hpp"
#include <cmath>
#include <cstdint>
#include <optional>

namespace st {
enum class WaterSource { actor, spatial, retained };
struct SelectedWater {
    float level{};
    WaterSource source{};
};

// Surface lifetime is independent of actor contact lifetime. An interior actor's
// cached water height can disappear on the bank while the pool is still nearby.
// Store coordinates only, and revalidate the anchor through the engine each tick.
class WaterSelection {
public:
    static bool validLevel(float level) {
        return std::isfinite(level) && std::abs(level) <= 1e7f;
    }
    void reset() { anchor_.reset(); }

    // query(xy,z) returns a water height, or an invalid/sentinel height if the
    // location is not in attached water in the caller's current world/interior.
    template<class Query>
    std::optional<SelectedWater> select(std::uint32_t area, Vec2 position,
        float z, float actorLevel, float radius, Query&& query) {
        if (!std::isfinite(position.x) || !std::isfinite(position.y) ||
            !std::isfinite(z) || !std::isfinite(radius) || radius <= 0) {
            reset();
            return std::nullopt;
        }
        if (anchor_ && (anchor_->area != area ||
            std::hypot(position.x-anchor_->position.x,position.y-anchor_->position.y) > radius)) reset();

        const bool actorValid = validLevel(actorLevel);
        const float spatial = query(position,actorValid ? actorLevel : z);
        if (actorValid) {
            // Preserve the actor's original water-body selection. Only a spatially
            // verified position is allowed to outlive that actor's water contact.
            if (validLevel(spatial) && std::abs(spatial-actorLevel) < 2)
                anchor_ = Anchor{area,position,actorLevel};
            else if (anchor_ && std::abs(anchor_->level-actorLevel) >= 2) reset();
            return SelectedWater{actorLevel,WaterSource::actor};
        }
        if (validLevel(spatial)) {
            anchor_ = Anchor{area,position,spatial};
            return SelectedWater{spatial,WaterSource::spatial};
        }
        if (anchor_) {
            const float verified = query(anchor_->position,anchor_->level);
            if (validLevel(verified) && std::abs(verified-anchor_->level) < 2)
                return SelectedWater{anchor_->level,WaterSource::retained};
        }
        reset();
        return std::nullopt;
    }
private:
    struct Anchor { std::uint32_t area; Vec2 position; float level; };
    std::optional<Anchor> anchor_;
};
} // namespace st
