#pragma once
#include <array>
#include <cstdint>
namespace st {
// Game-facing state must not be inferred from temporary downstream bindings.
// The caller serializes access and supplies whether a setter was nested inside
// an intercepted API call. ClearState / ExecuteCommandList(FALSE) reset to the
// D3D default, whereas a newly installed observer has no history yet.
class LogicalTopology {
public:
    bool observe(std::uint32_t value, bool internalCall) {
        if (internalCall) return false;
        value_ = value; known_ = true; return true;
    }
    void clear() { value_ = 0; known_ = true; }
    bool known() const { return known_; }
    std::uint32_t resolve(std::uint32_t initialFallback) const {
        return known_ ? value_ : initialFallback;
    }
private:
    std::uint32_t value_{};
    bool known_{};
};
struct DrawSignature {
    std::uint32_t kind{};
    std::array<std::uint32_t,5> arguments{};
    std::uint32_t topology{};
    bool operator==(const DrawSignature&) const = default;
};
// Separate from replacement-shader forwarding: preserve *every* matching native
// pass, permitting only the observed triangle -> three-control-point conversion.
// The caller must additionally require a known water scope and canonical context.
inline bool meshInputDraw(const DrawSignature& game, const DrawSignature& native) {
    return game.kind < 2 && game.kind == native.kind && game.arguments == native.arguments &&
        game.arguments[0] && game.arguments[0] % 3 == 0 && game.topology == 4 &&
        (native.topology == 4 || native.topology == 35);
}
inline std::uint32_t meshStreamBytes(std::uint32_t vertices, std::uint32_t stride=40, std::uint32_t factor=8) {
    if (factor<8 || factor>16) return 0;
    // Tri domain, deliberately generous storage bound tied to the compiled cap.
    // Four (N+1)^2 triangles/patch, three vertices/triangle, 40-byte vertex.
    const auto bytes=std::uint64_t(vertices / 3) * 12 * (factor+1) * (factor+1) * stride;
    return (stride==40 || stride==56) && vertices && vertices % 3 == 0 && bytes <= 128u*1024u*1024u ?
        static_cast<std::uint32_t>(bytes) : 0;
}
// Only direct calls have a complete argument signature. Match once, within the
// synchronous call scope; indirect/auto or transformed draw calls are not inferred.
class ForwardedDraw {
public:
    explicit ForwardedDraw(DrawSignature expected) : expected_(expected) {}
    bool consume(const DrawSignature& actual) {
        if (used_ || expected_.kind >= 4 || !(expected_ == actual)) return false;
        used_ = true; return true;
    }
    bool used() const { return used_; }
private:
    DrawSignature expected_;
    bool used_{};
};
}
