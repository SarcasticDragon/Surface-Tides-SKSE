#pragma once
#include <cstddef>
#include <cstdint>
#include <limits>

namespace st {
// No native pointer is ever deserialized from a device-child tag.
struct ShaderIdentity {
    std::uint64_t generation{};
    std::uint32_t index{}, stage{};
};
static_assert(sizeof(ShaderIdentity)==16);
inline constexpr auto ambiguousShaderIdentity = std::numeric_limits<std::uint32_t>::max();
inline ShaderIdentity mergeShaderIdentity(ShaderIdentity next, const ShaderIdentity* previous) {
    if (previous && previous->generation == next.generation &&
        (previous->index != next.index || previous->stage != next.stage))
        next.index = ambiguousShaderIdentity;
    return next;
}
inline bool validShaderIdentity(const ShaderIdentity& tag, std::uint64_t generation,
    std::uint32_t stage, std::size_t count) {
    return tag.generation == generation && tag.stage == stage &&
        tag.index != ambiguousShaderIdentity && tag.index < count;
}
}
