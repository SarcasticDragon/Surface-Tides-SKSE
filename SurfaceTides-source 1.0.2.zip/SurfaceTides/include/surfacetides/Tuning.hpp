#pragma once
#include "Simulation.hpp"
#include <cmath>
#include <mutex>
#include <stdexcept>

namespace st {
// Only these values can change after initialization. Startup renderer policy is separate.
struct Tuning {
    Settings simulation = [] { Settings s; s.wind = 5; return s; }();
    bool previewEnabled = true; // session only; never replaces General.Enabled
    bool terrainMask = true;
    int maxActors = 48, terrainQueriesPerUpdate = 96, debugView = 0;
    float interactionStrength = 4, interactionRadius = 1.5f;
    float tessellationSpacing = 20, tessellationMax = 64;
    float normalStrength = 2, displacementStrength = 2;
    float floeCrestFollow = 1, floeExtraLift = 4, floeResponseSeconds = 0.12f;
    void validate() const {
        simulation.validate();
        auto range = [](float v, float lo, float hi) { return std::isfinite(v) && v >= lo && v <= hi; };
        if (maxActors < 1 || maxActors > 128 || terrainQueriesPerUpdate < 1 || terrainQueriesPerUpdate > 512 ||
            debugView < 0 || debugView > 1 || !range(interactionStrength,0,20) || !range(interactionRadius,0.5f,4) ||
            !range(tessellationSpacing,8,128) || !range(tessellationMax,1,64) ||
            !range(normalStrength,0,3) || !range(displacementStrength,0,2) ||
            !range(floeCrestFollow,0,1) || !range(floeExtraLift,0,32) || !range(floeResponseSeconds,0,2))
            throw std::invalid_argument("Invalid SurfaceTides live settings");
    }
};
struct TuningSnapshot { Tuning values; std::uint64_t revision = 0; };
class TuningExchange {
public:
    TuningSnapshot read() const { std::lock_guard lock(mutex_); return current_; }
    std::uint64_t publish(const Tuning& values) {
        values.validate();
        std::lock_guard lock(mutex_);
        current_.values = values;
        return ++current_.revision;
    }
private:
    mutable std::mutex mutex_;
    TuningSnapshot current_;
};
inline bool needsSurfaceReset(const Tuning& before, const Tuning& after) {
    return before.simulation.resolution != after.simulation.resolution ||
        before.simulation.spacing != after.simulation.spacing || before.terrainMask != after.terrainMask;
}
}
