#pragma once
#include <array>
#include <cstdint>
#include <algorithm>

namespace st {
// Recognize the captured one-slot insertion only when all three live engine
// groups match their own buffer descriptors. Sizes validate layout, not contents.
// No renderer-specific buffer size or shader implementation is encoded here.
inline bool shiftedWaterConstants(const std::array<std::uint32_t,3>& engine,
    const std::array<std::uint32_t,3>& required, const std::array<std::uint32_t,4>& bound) {
    for (unsigned i=0;i<3;++i) {
        if (!required[i] || !engine[i] || engine[i]<required[i] || engine[i]%16 ||
            engine[i]>65536 || bound[i+1]!=engine[i]) return false;
    }
    // Distinct groups and an inserted buffer larger than any engine group
    // avoid interpreting an ordinary or ambiguous binding as a shifted layout.
    return engine[0]!=engine[1] && engine[0]!=engine[2] && engine[1]!=engine[2] &&
        bound[0]>*std::max_element(engine.begin(),engine.end()) && bound[0]<=65536 && bound[0]%16==0;
}
}
