#pragma once
#include <array>
#include <string_view>

namespace st::foam {
// Deliberately narrow profiles from the inspected winning NIFs.
// A different shape/material layout stays visible until separately reviewed.
struct Profile {
    std::string_view model, rock;
    std::array<std::string_view,2> shapes;
    std::string_view source, greyscale;
    unsigned count;
    // Lighting profiles use source/greyscale for diffuse/normal respectively.
    bool iceDecal = false;
    // Standalone frost profiles must contain only the reviewed decal geometry,
    // with no collision/controllers anywhere in their scene subtree.
    bool standalone = false;
};
inline constexpr std::array<Profile,14> profiles{{
    {"effects/fxrapidsrocks01.nif", "WetRocksCombined", {"Plane12","BIGwHITEWATER"},
     "effects/fxwhitewater01.dds", "effects/gradients/gradwhitewatersoft.dds", 2},
    {"architecture/whiterun/wreffects/wrrapidrocks01.nif", "RockM06", {"rockRapid04",""},
     "effects/nwf_rapids.dds", "effects/gradients/gradwhitewater02.dds", 1},
    {"landscape/ice/icefloessolid01.nif", "IceFloesSolid01:0", {"L1_IceFloesSolidSlush",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/icefloes01.nif", "IceFloes01:0 - L2_IceFloesChunks:0", {"L1_IceFloes01",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/icefloessolid02.nif", "IceFloesSolid02:0 - L1_IceFloesChunks:0 - L2_IceFloesChunks01:0", {"L1_IceFloesSolid02Slush",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/frozenmarshicefloel01.nif", "FrozenMarshIceFloeL01:0", {"L1_FrozenMarshIceFloeL01",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/frozenmarshicefloem01.nif", "FrozenMarshIceFloeM01:0", {"L1_FrozenMarshIceFloeM01",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/frozenmarshicefloes01.nif", "FrozenMarshIceFloeS01:0", {"L1_FrozenMarshIceFloeS01",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/frozenmarshicefloes02.nif", "FrozenMarshIceFloeS02:0", {"L1_FrozenMarshIceFloeS02",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/frozenmarshicelandbrokenl01.nif", "FrozenMarshIceLandBroken02:0", {"FrozenMarshIceLandBroken02:1",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/frozenmarshicelandbrokenl01skirt.nif", "FrozenMarshIceLandBroken01Skirt:0", {"FrozenMarshIceLandBroken01Skirt:1",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true},
    {"landscape/ice/frozenmarshicefloefrosts01.nif", "", {"FrozenMarshIceFloeFrostS01:1",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true, true},
    {"landscape/ice/frozenmarshicefloefrosts02.nif", "", {"FrozenMarshIceFloeFrostS02:1",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true, true},
    {"landscape/ice/frozenmarshicefloefrosts03.nif", "", {"FrozenMarshIceFloeFrostS03:1",""},
     "landscape/icefloes.dds", "landscape/icefloes_n.dds", 1, true, true}
}};
constexpr bool sceneComplete(int profile, bool solidFound, unsigned matchedShapes,
                             unsigned geometryCount, bool unsafeStandaloneNode) noexcept {
    if (profile < 0 || unsigned(profile) >= profiles.size()) return false;
    const auto& p=profiles[profile];
    if (matchedShapes != p.count) return false;
    return p.standalone ? (!unsafeStandaloneNode && geometryCount == p.count) : solidFound;
}
constexpr char fold(char c) noexcept {
    if (c == '\\') return '/';
    return c >= 'A' && c <= 'Z' ? char(c + ('a'-'A')) : c;
}
constexpr bool equal(std::string_view a, std::string_view b) noexcept {
    if (a.size() != b.size()) return false;
    for (std::size_t i=0;i<a.size();++i) if (fold(a[i]) != fold(b[i])) return false;
    return true;
}
constexpr std::string_view withoutPrefix(std::string_view path, std::string_view prefix) noexcept {
    return path.size() >= prefix.size() && equal(path.substr(0,prefix.size()),prefix) ? path.substr(prefix.size()) : path;
}
constexpr int modelProfile(std::string_view path) noexcept {
    path = withoutPrefix(path,"meshes/");
    for (unsigned i=0;i<profiles.size();++i) if (equal(path,profiles[i].model)) return int(i);
    return -1;
}
constexpr int shapeSlot(int profile, std::string_view name, bool effectShader,
                        std::string_view source, std::string_view greyscale,
                        bool ownsCollision, bool ownsController) noexcept {
    if (profile < 0 || unsigned(profile) >= profiles.size() || ownsCollision || ownsController) return -1;
    const auto& p = profiles[profile];
    if (effectShader == p.iceDecal) return -1;
    if (!equal(withoutPrefix(source,"textures/"),p.source) ||
        !equal(withoutPrefix(greyscale,"textures/"),p.greyscale)) return -1;
    for (unsigned i=0;i<p.count;++i) if (equal(name,p.shapes[i])) return int(i);
    return -1;
}
}
