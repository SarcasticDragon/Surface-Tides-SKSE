#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <limits>

namespace st {
// Jump requests can precede the controller's current airborne state. Release
// carry through that transition and require stable support before reattaching.
struct FloeRiderTakeoff {
    bool suspended{};
    double releaseUntil{}, groundSince=-1, lastGround=-1;
    bool allow(double now, bool grounded, bool leavingGround, bool jumpRequested) noexcept {
        if (!std::isfinite(now)) return false;
        if (leavingGround || jumpRequested) {
            if (!suspended) releaseUntil=now+0.25;
            suspended=true; groundSince=lastGround=-1;
            return false;
        }
        if (!grounded) {
            if (lastGround>=0 && now-lastGround>0.15) groundSince=-1;
            return false;
        }
        if (!suspended) return true;
        // A bobbing support can lose contact for one physics step. Do not
        // carry on that step, but tolerate a short gap in landing history.
        if (groundSince<0 || (lastGround>=0 && now-lastGround>0.15)) groundSince=now;
        lastGround=now;
        if (now<releaseUntil || now-groundSince<0.10) return false;
        *this={};
        return true;
    }
};
struct FloeRiderTransform {
    std::array<float,3> position{};
    std::array<float,9> rotation{1,0,0,0,1,0,0,0,1};
    float scale=1;
};
// Difference of nearby transforms evaluated around the floe, in double
// precision. Avoid after*inverse(before)*worldPoint - worldPoint: forming and
// subtracting those large float world positions injects horizontal jitter.
inline std::array<float,3> floeRiderDelta(const std::array<float,3>& point,
    const FloeRiderTransform& before, const FloeRiderTransform& after) noexcept {
    const auto invalid=[] { const float n=std::numeric_limits<float>::quiet_NaN(); return std::array<float,3>{n,n,n}; };
    if (!std::isfinite(before.scale) || !std::isfinite(after.scale) || before.scale<=0 || after.scale<=0) return invalid();
    for (unsigned axis=0;axis<3;++axis)
        if (!std::isfinite(point[axis]) || !std::isfinite(before.position[axis]) || !std::isfinite(after.position[axis])) return invalid();
    for (unsigned i=0;i<9;++i)
        if (!std::isfinite(before.rotation[i]) || !std::isfinite(after.rotation[i])) return invalid();
    std::array<double,3> local{};
    for (unsigned row=0;row<3;++row) for (unsigned col=0;col<3;++col)
        local[row]+=double(before.rotation[col*3+row])*(double(point[col])-before.position[col])/before.scale;
    std::array<float,3> delta{};
    for (unsigned row=0;row<3;++row) {
        double value=double(after.position[row])-before.position[row];
        for (unsigned col=0;col<3;++col)
            value+=(double(after.scale)*after.rotation[row*3+col]-double(before.scale)*before.rotation[row*3+col])*local[col];
        delta[row]=static_cast<float>(value);
    }
    return delta;
}
struct FloeRiderStats {
    unsigned offsets{}, velocityRepairs{}, invalidPostVelocity{};
    unsigned takeoffReleases{}, landingResumes{}, takeoffSkips{};
    float maxOffset{}, maxVelocityChange{}; // game units and native velocity units
};
// Controller adapter: position()/velocity() return native float4s;
// moveWithoutWarp()/restoreVelocity() use the same native units. The actor's
// cached reference position must never be used as the controller destination.
template<class Controller>
bool offsetFloeRider(Controller& controller, const std::array<float,3>& delta,
    float inverseHavokScale, FloeRiderStats* stats=nullptr) {
    if (!std::isfinite(inverseHavokScale) || inverseHavokScale<1 || inverseHavokScale>1000) return false;
    double travelSquared=0;
    for (const auto value:delta) {
        if (!std::isfinite(value)) return false;
        travelSquared+=double(value)*value;
    }
    if (travelSquared<=1e-12 || travelSquared>128.0*128.0) return false;
    auto position=controller.position();
    const auto velocity=controller.velocity();
    bool changed=false;
    for (unsigned axis=0;axis<3;++axis) {
        if (!std::isfinite(position[axis]) || !std::isfinite(velocity[axis])) return false;
        const float next=position[axis]+delta[axis]/inverseHavokScale;
        if (!std::isfinite(next)) return false;
        changed|=next!=position[axis]; position[axis]=next;
    }
    if (!changed) return false;
    // Preserve W exactly and keep movement already integrated by Havok.
    controller.moveWithoutWarp(position);
    const auto afterVelocity=controller.velocity();
    double velocityChange=0;
    bool invalid=false;
    for (unsigned axis=0;axis<3;++axis) {
        if (!std::isfinite(afterVelocity[axis])) { invalid=true; break; }
        const double difference=double(afterVelocity[axis])-velocity[axis];
        velocityChange+=difference*difference;
    }
    // Most importantly, do not call a velocity setter at all when movement
    // survived the offset. Reissuing an unchanged velocity can still have
    // side effects in the engine or a movement mod's hooks. Ignore metadata W.
    const bool repair=invalid || velocityChange>1e-12;
    if (repair) controller.restoreVelocity(velocity);
    if (stats) {
        ++stats->offsets;
        stats->velocityRepairs+=repair;
        stats->invalidPostVelocity+=invalid;
        stats->maxOffset=std::max(stats->maxOffset,static_cast<float>(std::sqrt(travelSquared)));
        if (!invalid) stats->maxVelocityChange=std::max(stats->maxVelocityChange,static_cast<float>(std::sqrt(velocityChange)));
    }
    return true;
}
}
