#pragma once
// Windows only; include after CommonLib in the plugin.
#include <d3dcompiler.h>
#include <d3d11shader.h>
#include <wrl/client.h>
#include <string>
#include <vector>
#include <stdexcept>
#include <cstring>
#include <span>
#include <cstdint>
#include <array>
namespace st {
inline Microsoft::WRL::ComPtr<ID3D11ShaderReflection> reflectShader(const void* data, std::size_t size) {
    Microsoft::WRL::ComPtr<ID3D11ShaderReflection> result;
    if (FAILED(D3DReflect(data,size,IID_PPV_ARGS(&result)))) throw std::runtime_error("Cannot reflect water shader");
    return result;
}
inline std::vector<std::string> activeEngineConstants(ID3DBlob* blob) {
    const auto reflection = reflectShader(blob->GetBufferPointer(),blob->GetBufferSize());
    std::vector<std::string> names;
    for (int group = 0; group < 3; ++group) {
        auto* buffer = reflection->GetConstantBufferByName(("STEngine" + std::to_string(group)).c_str());
        D3D11_SHADER_BUFFER_DESC desc{};
        if (FAILED(buffer->GetDesc(&desc))) continue;
        for (UINT i = 0; i < desc.Variables; ++i) {
            D3D11_SHADER_VARIABLE_DESC variable{};
            if (FAILED(buffer->GetVariableByIndex(i)->GetDesc(&variable))) throw std::runtime_error("Cannot reflect constant");
            if (variable.uFlags & D3D_SVF_USED) names.emplace_back(variable.Name);
        }
    }
    return names;
}
// Reflect SurfaceTides' own generated shader only, never a renderer replacement.
inline std::array<std::uint32_t,3> engineBufferRequirements(ID3DBlob* blob) {
    const auto reflection = reflectShader(blob->GetBufferPointer(),blob->GetBufferSize());
    std::array<std::uint32_t,3> sizes{};
    for (unsigned i=0;i<3;++i) {
        const auto name="STEngine"+std::to_string(i);
        D3D11_SHADER_INPUT_BIND_DESC binding{};
        if (FAILED(reflection->GetResourceBindingDescByName(name.c_str(),&binding))) continue;
        if (binding.Type!=D3D_SIT_CBUFFER || binding.BindPoint!=i || binding.BindCount!=1)
            throw std::runtime_error("Unexpected SurfaceTides constant binding");
        D3D11_SHADER_BUFFER_DESC desc{};
        if (FAILED(reflection->GetConstantBufferByName(name.c_str())->GetDesc(&desc)))
            throw std::runtime_error("Cannot reflect SurfaceTides constant buffer size");
        sizes[i]=desc.Size;
    }
    return sizes;
}
struct VertexInput { std::string semantic; std::uint32_t index{}, component{}, system{}; std::uint8_t mask{}; std::uint32_t registerIndex{}; };
inline std::vector<VertexInput> originalVertexInputs(const void* data, std::size_t size, bool output=false) {
    // Native shaders may have RDEF stripped. Input signatures remain available
    // because CreateInputLayout requires them; do not require D3DReflect on native code.
    const auto bytes=std::span(static_cast<const std::uint8_t*>(data),size);
    const auto u32=[&](std::size_t offset) {
        if (offset>size || size-offset<4) throw std::runtime_error("Truncated DXBC signature");
        std::uint32_t value{}; std::memcpy(&value,bytes.data()+offset,4); return value;
    };
    if (size<32 || std::memcmp(data,"DXBC",4)!=0 || u32(24)!=size) throw std::runtime_error("Invalid native DXBC");
    const auto chunks=u32(28);
    if (chunks>(size-32)/4) throw std::runtime_error("Invalid DXBC chunk table");
    for (std::uint32_t i=0;i<chunks;++i) {
        const auto offset=std::size_t(u32(32+4*i));
        const auto tag=u32(offset), length=u32(offset+4);
        if (offset+8>size || length>size-offset-8) throw std::runtime_error("Invalid DXBC chunk size");
        const bool extended=tag==(output ? 0x3147534fu : 0x31475349u); // ISG1
        if (tag!=(output ? 0x4e47534fu : 0x4e475349u) && !extended) continue; // ISGN
        if (length<8) throw std::runtime_error("Truncated signature header");
        const auto base=offset+8;
        const auto count=u32(base), start=u32(base+4);
        const std::size_t stride=extended ? 32 : 24;
        if (length<8 || start<8 || start>length || count>(length-start)/stride) throw std::runtime_error("Invalid signature entries");
        std::vector<VertexInput> result;
        for (std::uint32_t j=0;j<count;++j) {
            const auto record=base+start+j*stride+(extended ? 4 : 0);
            const auto nameOffset=u32(record);
            if (nameOffset>=length) throw std::runtime_error("Invalid signature name");
            const auto* name=reinterpret_cast<const char*>(bytes.data()+base+nameOffset);
            const auto* end=static_cast<const char*>(std::memchr(name,0,length-nameOffset));
            if (!end) throw std::runtime_error("Unterminated signature name");
            result.push_back({std::string(name,end),u32(record+4),u32(record+12),u32(record+8),bytes[record+20],u32(record+16)});
        }
        return result;
    }
    throw std::runtime_error("Native shader has no input signature");
}
inline void validateVertexInputs(const void* original, std::size_t originalSize, ID3DBlob* replacement) {
    const auto oldInputs = originalVertexInputs(original,originalSize);
    const auto newShader = reflectShader(replacement->GetBufferPointer(),replacement->GetBufferSize());
    D3D11_SHADER_DESC newDesc{};
    if (FAILED(newShader->GetDesc(&newDesc))) throw std::runtime_error("Cannot inspect vertex input signature");
    for (UINT i = 0; i < newDesc.InputParameters; ++i) {
        D3D11_SIGNATURE_PARAMETER_DESC required{};
        if (FAILED(newShader->GetInputParameterDesc(i,&required))) throw std::runtime_error("Cannot inspect new vertex input");
        if (required.SystemValueType != D3D_NAME_UNDEFINED || !required.ReadWriteMask) continue;
        bool matched = false;
        for (const auto& available : oldInputs) {
            if (_stricmp(required.SemanticName,available.semantic.c_str()) == 0 && required.SemanticIndex == available.index &&
                required.ComponentType == available.component && !(required.ReadWriteMask & ~available.mask)) { matched = true; break; }
        }
        if (!matched) throw std::runtime_error(std::string("Original input layout lacks required input: ") + required.SemanticName);
    }
}
}
