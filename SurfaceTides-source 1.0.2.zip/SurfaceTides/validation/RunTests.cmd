@echo off
setlocal
pushd "%~dp0"
SurfaceTidesTests.exe > validation-results.txt 2>&1
if errorlevel 1 goto failed
SurfaceTidesShaderTests.exe "..\Data\Shaders\SurfaceTides" >> validation-results.txt 2>&1
if errorlevel 1 goto failed
type validation-results.txt
popd
exit /b 0
:failed
type validation-results.txt
popd
exit /b 1
