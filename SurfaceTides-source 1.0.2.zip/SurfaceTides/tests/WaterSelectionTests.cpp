#include "surfacetides/WaterSelection.hpp"
#include <functional>
#include <iostream>
#include <limits>
#include <stdexcept>

namespace {
constexpr float absent = -std::numeric_limits<float>::infinity();
void require(bool condition, const char* message) { if (!condition) throw std::runtime_error(message); }
float pool(st::Vec2 p, float) { return p.x < 0 ? 100.0f : absent; }
void leaveAndReenter() {
    st::WaterSelection select;
    auto enter=select.select(1,{-20,0},90,100,500,pool);
    require(enter && enter->source==st::WaterSource::actor,"actor water rejected");
    for (int i=0;i<300;++i) {
        auto shore=select.select(1,{20,0},120,absent,500,pool);
        require(shore && shore->source==st::WaterSource::retained && shore->level==100,
            "nearby pool expired when the dry actor's water cache was absent");
    }
    auto reenter=select.select(1,{-20,0},90,100,500,pool);
    require(reenter && reenter->level==enter->level,"reentry changed water level");
}
void spatialDiscovery() {
    st::WaterSelection select;
    auto water=select.select(1,{-20,0},120,absent,500,pool);
    require(water && water->source==st::WaterSource::spatial && water->level==100,
        "spatial water needs an actor contact first");
    require(!select.select(1,{600,0},120,absent,500,pool),"distant pool retained outside local field");
    require(!select.select(1,{20,0},120,absent,500,pool),"distant anchor resurrected after returning dry");
}
void areaAndReset() {
    st::WaterSelection select;
    select.select(1,{-20,0},90,100,500,pool);
    require(!select.select(2,{20,0},120,absent,500,pool),"anchor crossed world/interior boundary");
    select.select(1,{-20,0},90,100,500,pool);
    select.reset(); // load, preview off, or explicit grid reset
    require(!select.select(1,{20,0},120,absent,500,pool),"reset retained old water");
}
void revalidate() {
    st::WaterSelection select;
    select.select(1,{-20,0},90,100,500,pool);
    require(!select.select(1,{20,0},120,absent,500,[](st::Vec2,float){return absent;}),
        "detached or unavailable water remained active");
    select.select(1,{-20,0},90,100,500,pool);
    require(!select.select(1,{20,0},120,absent,500,[](st::Vec2 p,float){return p.x<0 ? 150.f : absent;}),
        "remembered surface survived a changed rest level");
}
void unverifiedActor() {
    st::WaterSelection select;
    const auto none=[](st::Vec2,float){return absent;};
    require(bool(select.select(1,{-20,0},90,100,500,none)),"original valid actor selection regressed");
    require(!select.select(1,{20,0},120,absent,500,none),"unverified actor height became persistent anchor");
    select.select(1,{-20,0},90,100,500,pool);
    select.select(1,{20,0},90,100,500,pool); // stale actor cache on dry ground
    require(bool(select.select(1,{20,0},120,absent,500,pool)),"dry cached actor overwrote valid pool anchor");
    select.select(1,{20,0},180,200,500,pool);
    require(!select.select(1,{20,0},220,absent,500,pool),"different actor water inherited old pool anchor");
}
void sentinels() {
    st::WaterSelection select;
    for (float bad : {absent,std::numeric_limits<float>::infinity(),std::numeric_limits<float>::quiet_NaN(),1e20f}) {
        require(!select.select(1,{20,0},120,bad,500,[=](st::Vec2,float){return bad;}),"invalid height accepted");
    }
    select.select(1,{-20,0},90,100,500,pool);
    require(!select.select(1,{20,0},120,absent,0,pool),"invalid range retained anchor");
}
void wavesOutliveContacts() {
    st::Settings settings;
    settings.resolution=64; settings.spacing=10; settings.spongeCells=0;
    settings.wind=0; settings.gustStrength=0; settings.edgeDamping=0; settings.damping=0.5f;
    st::Surface surface(settings);
    st::WaterSelection select;
    st::ContactTracker contacts;
    std::vector<st::Impulse> impulses;
    auto wet=select.select(1,{-20,0},90,100,250,pool);
    surface.reset({0,0},wet->level);
    const st::Contact above{1,{-20,0},120,100,25,false};
    contacts.update(std::span(&above,1),1.0/60,impulses,4,1.5f);
    const st::Contact actor{1,{-20,0},90,100,25,false};
    contacts.update(std::span(&actor,1),1.0/60,impulses,4,1.5f);
    require(!impulses.empty(),"entry did not generate a test wake");
    for (const auto& impulse:impulses) surface.addImpulse(impulse);
    surface.advance(1.0/60);
    const double initialEnergy=surface.energy();
    require(initialEnergy>0,"entry wake has no energy");
    for (int i=0;i<120;++i) {
        auto dry=select.select(1,{20,0},120,absent,250,pool);
        require(dry && dry->level==surface.level(),"dry exit requests inactive/reset field");
        contacts.update({},1.0/60,impulses,4,1.5f);
        require(impulses.empty(),"retention fabricated a dry actor wake");
        surface.advance(1.0/60);
        require(surface.energy()>0 && surface.finite(),"waves erased after water exit");
    }
    require(surface.energy()<initialEnergy,"retained waves do not decay");
}
}
int main() {
    const std::pair<const char*,std::function<void()>> tests[]={
        {"dry exit and reentry",leaveAndReenter},{"spatial discovery and range",spatialDiscovery},
        {"world, interior and reset isolation",areaAndReset},{"anchor revalidation",revalidate},
        {"unverified actor cache",unverifiedActor},{"invalid engine heights",sentinels},
        {"waves outlive actor contacts",wavesOutliveContacts}};
    int failed=0;
    for (const auto& [name,test]:tests) {
        try { test(); std::cout<<"PASS "<<name<<'\n'; }
        catch (const std::exception& e) { ++failed; std::cerr<<"FAIL "<<name<<": "<<e.what()<<'\n'; }
    }
    std::cout<<std::size(tests)-failed<<'/'<<std::size(tests)<<" passed\n";
    return failed ? 1 : 0;
}
