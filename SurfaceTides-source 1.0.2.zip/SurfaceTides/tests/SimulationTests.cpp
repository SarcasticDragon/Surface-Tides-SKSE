#include "surfacetides/Simulation.hpp"
#include "surfacetides/Tuning.hpp"
#include "surfacetides/ShaderLayout.hpp"
#include "surfacetides/ShaderIdentity.hpp"
#include "surfacetides/ForwardedDraw.hpp"
#include "surfacetides/MeshBounds.hpp"
#include "surfacetides/ConstantBinding.hpp"
#include "surfacetides/FoamSelection.hpp"
#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <limits>
#include <numbers>
#include <stdexcept>
#include <thread>

namespace {
void require(bool condition, const char* message) { if (!condition) throw std::runtime_error(message); }
void foamSelection() {
    using namespace st::foam;
    const auto fx=modelProfile("MESHES\\Effects\\FxRapidsRocks01.nif");
    const auto wr=modelProfile("architecture/whiterun/wreffects/WRRapidRocks01.nif");
    require(fx == 0 && wr == 1,"reviewed rock profiles not resolved");
    require(modelProfile("other/fxrapidsrocks01.nif") < 0,"basename-only match hides an unrelated mesh");
    for (const auto* path : {"effects/fxrapids.nif","effects/fxrapids02.nif","effects/fxrapidsbig01.nif",
                            "effects/fxrapidsringheavy.nif","effects/fxrapidsringheavy1way.nif"})
        require(modelProfile(path) < 0,"standalone or waterfall mesh accepted as a rock profile");
    for (int profile=0;profile<2;++profile) {
        const auto& p=profiles[profile];
        for (unsigned i=0;i<p.count;++i) {
            require(shapeSlot(profile,p.shapes[i],true,p.source,p.greyscale,false,false) == int(i),"reviewed foam shape rejected");
            require(shapeSlot(profile,p.shapes[i],false,p.source,p.greyscale,false,false) < 0,"lighting-shader geometry accepted");
            require(shapeSlot(profile,p.shapes[i],true,p.source,p.greyscale,true,false) < 0,"collision-bearing shape accepted");
            require(shapeSlot(profile,p.shapes[i],true,p.source,p.greyscale,false,true) < 0,"shape controller accepted");
            require(shapeSlot(profile,p.shapes[i],true,"other.dds",p.greyscale,false,false) < 0,"unknown source texture accepted");
            require(shapeSlot(profile,p.shapes[i],true,p.source,"other.dds",false,false) < 0,"unknown greyscale accepted");
            require(shapeSlot(1-profile,p.shapes[i],true,p.source,p.greyscale,false,false) < 0,"profile boundaries ignored");
        }
        require(shapeSlot(profile,p.rock,true,p.source,p.greyscale,false,false) < 0,"solid rock accepted as foam");
        require(shapeSlot(profile,"FoamLayer01",true,p.source,p.greyscale,false,false) < 0,"generic foam layer accepted");
    }
    require(shapeSlot(fx,"PLANE12",true,"Textures\\Effects\\FXWhiteWater01.dds",
        "textures/Effects/Gradients/GradWhiteWaterSoft.dds",false,false) == 0,"texture prefix or case normalization failed");
    require(shapeSlot(-1,"Plane12",true,profiles[0].source,profiles[0].greyscale,false,false) < 0,"unrecognized model accepted");
    require(shapeSlot(int(profiles.size()),"Plane12",true,profiles[0].source,profiles[0].greyscale,false,false) < 0,"invalid profile accepted");
}
void liveTuning() {
    st::Tuning initial;
    initial.simulation.resolution = 32;
    initial.simulation.spongeCells = 8;
    st::Surface surface(initial.simulation);
    surface.reset({40,80},600);
    surface.addImpulse({{40,80},40,30});
    surface.advance(0.05);
    const std::vector<st::Cell> original(surface.cells().begin(),surface.cells().end());
    const auto origin = surface.origin();
    auto changed = initial;
    changed.simulation.damping = 2;
    changed.simulation.waveSpeed = 600;
    changed.simulation.dispersion = 1e6f;
    changed.simulation.wind = 0;
    surface.retune(changed.simulation);
    require(surface.origin().x == origin.x && surface.origin().y == origin.y && surface.level() == 600,"retuning moved the water field");
    for (std::size_t i=0; i<original.size(); ++i)
        require(original[i].height == surface.cells()[i].height && original[i].velocity == surface.cells()[i].velocity,"retuning erased live wakes");
    require(!st::needsSurfaceReset(initial,changed),"coefficient adjustment requests grid reset");
    surface.advance(1);
    require(surface.finite(),"retuned solver became nonfinite");
    auto wrongGrid = changed;
    wrongGrid.simulation.resolution = 64;
    bool rejected = false;
    try { surface.retune(wrongGrid.simulation); } catch(const std::invalid_argument&) { rejected = true; }
    require(rejected && surface.settings() == changed.simulation,"grid change was partially committed");
    require(st::needsSurfaceReset(changed,wrongGrid),"grid resize failed to request reset");
    wrongGrid = changed; wrongGrid.terrainMask = !changed.terrainMask;
    require(st::needsSurfaceReset(changed,wrongGrid),"mask change failed to request reset");
    st::TuningExchange channel;
    channel.publish(initial);
    const auto before = channel.read();
    auto invalid = initial; invalid.displacementStrength = std::numeric_limits<float>::quiet_NaN();
    rejected = false;
    try { channel.publish(invalid); } catch(const std::invalid_argument&) { rejected = true; }
    require(rejected && channel.read().revision == before.revision,"invalid UI edit changed settings revision");
    std::thread writer([&] {
        for (int i=0;i<2000;++i) {
            auto value = initial;
            value.maxActors = i%128+1;
            value.terrainQueriesPerUpdate = value.maxActors*2;
            channel.publish(value);
        }
    });
    bool coherent = true;
    for (int i=0;i<2000;++i) {
        const auto value = channel.read().values;
        coherent &= value.terrainQueriesPerUpdate == value.maxActors*2;
    }
    writer.join();
    require(coherent,"UI and simulation observed a torn settings snapshot");
}
st::Settings base() {
    st::Settings s; s.resolution=64; s.spacing=8; s.wind=0; s.damping=0; s.edgeDamping=0; s.spongeCells=0; s.maxHeight=100;
    return s;
}
void calm() {
    st::Surface surface(base()); surface.advance(1);
    require(surface.energy() == 0,"calm water creates energy");
    require(surface.finite(),"nonfinite resting state");
}
void symmetryAndConservation() {
    auto s=base(); s.resolution=65;
    st::Surface surface(s); surface.addImpulse({{0,0},20,60});
    double momentum=0; for (auto c:surface.cells()) momentum+=c.velocity;
    require(std::abs(momentum)<1e-4,"impulse adds net momentum");
    for(int i=0;i<150;++i) surface.step();
    const auto cells=surface.cells(); double symmetry=0;
    for(int y=0;y<s.resolution;++y) for(int x=0;x<s.resolution;++x)
        symmetry=std::max(symmetry,double(std::abs(cells[y*s.resolution+x].height-cells[x*s.resolution+y].height)));
    require(symmetry<2e-5,"radial source loses x/y symmetry");
    require(std::abs(surface.meanHeight())<1e-5,"closed surface changes mean height");
    require(surface.diagnostics().clippedCells==0,"stability depended on clipping");
}
void barrier() {
    auto s=base(); st::Surface surface(s);
    std::vector<std::uint8_t> mask(surface.cells().size(),1);
    for(int y=0;y<s.resolution;++y) mask[y*s.resolution+s.resolution/2]=0;
    surface.setWetMask(mask); surface.addImpulse({{-130,0},16,70});
    for(int i=0;i<400;++i) surface.step();
    for(int y=0;y<s.resolution;++y) for(int x=s.resolution/2;x<s.resolution;++x)
        require(surface.cells()[y*s.resolution+x].height==0,"wave crosses an impermeable disconnected boundary");
    require(surface.energy()>0,"reflective boundary erased all waves");
}
void diffraction() {
    auto s=base(); s.dispersion=0; st::Surface surface(s);
    std::vector<std::uint8_t> mask(surface.cells().size(),1);
    for(int y=0;y<s.resolution;++y) if(std::abs(y-32)>3) mask[y*s.resolution+32]=0;
    surface.setWetMask(mask); surface.addImpulse({{-120,0},18,70});
    float offAxis=0;
    for(int i=0;i<220;++i) { surface.step(); offAxis=std::max(offAxis,std::abs(surface.sample({88,96}))); }
    require(offAxis>0.01f,"waves fail to spread behind a narrow opening");
}
void damping() {
    auto s=base(); s.damping=0.8f; st::Surface surface(s);
    surface.addImpulse({{0,0},24,60}); const auto initial=surface.energy();
    for(int i=0;i<600;++i) surface.step();
    require(surface.energy()<initial*0.002,"damping fails to dissipate energy");
}
void longRun() {
    auto s=base(); s.spacing=4; s.waveSpeed=650; s.dispersion=5e7f;
    st::Surface surface(s); surface.addImpulse({{0,0},14,80}); const auto e=surface.energy();
    for(int i=0;i<2500;++i) surface.step();
    require(surface.finite(),"dispersive solver diverged");
    require(surface.diagnostics().clippedCells==0,"CFL protection failed");
    require(surface.energy()>e*0.6 && surface.energy()<e*1.5,"undamped energy is not bounded");
}
double measuredFrequency(int mode, float dispersion) {
    auto s=base(); s.dispersion=dispersion; s.waveSpeed=80; s.resolution=64; s.spacing=10;
    st::Surface surface(s); std::vector<st::Cell> state(surface.cells().size());
    for(int y=0;y<s.resolution;++y) for(int x=0;x<s.resolution;++x)
        state[y*s.resolution+x].height=static_cast<float>(std::cos(std::numbers::pi*mode*(x+0.5)/s.resolution));
    surface.setState(state);
    std::vector<double> crossings; float last=state[0].height;
    for(int i=1;i<40000 && crossings.size()<4;++i) {
        surface.step(); const auto next=surface.cells()[0].height;
        if(last>0 && next<=0) crossings.push_back((i-1+last/(last-next))*s.timestep());
        last=next;
    }
    require(crossings.size()>=3,"cannot measure mode period");
    const double measured=2*std::numbers::pi/((crossings.back()-crossings.front())/double(crossings.size()-1));
    const double eigenvalue=4*std::pow(std::sin(std::numbers::pi*mode/(2*s.resolution)),2)/(s.spacing*s.spacing);
    const double expected=std::sqrt(s.waveSpeed*s.waveSpeed*eigenvalue+dispersion*eigenvalue*eigenvalue);
    require(std::abs(measured/expected-1)<0.025,"frequency disagrees with gravity/capillary dispersion relation");
    return measured;
}
void dispersion() {
    const auto low0=measuredFrequency(3,0), low1=measuredFrequency(3,2e6f);
    const auto high0=measuredFrequency(15,0), high1=measuredFrequency(15,2e6f);
    require(high1/high0>low1/low0+0.25,"short wavelengths do not disperse faster");
}
void scrolling() {
    st::Surface surface(base()); surface.addImpulse({{32,-24},16,30});
    for(int i=0;i<30;++i) surface.step();
    const auto before=surface.sample({32,-24});
    surface.recenter({-40,24}); require(std::abs(surface.sample({32,-24})-before)<1e-6f,"negative scroll moves world-space wave");
    surface.recenter({40,-24}); require(std::abs(surface.sample({32,-24})-before)<1e-6f,"positive scroll moves world-space wave");
    surface.recenter({100000,100000}); require(surface.energy()==0,"teleport carries waves to another area");
}
void frameRate() {
    auto s=base(); st::Surface a(s),b(s); a.addImpulse({{0,0},20,50}); b.addImpulse({{0,0},20,50});
    for(int i=0;i<120;++i) a.advance(1.0/120);
    for(int i=0;i<30;++i) b.advance(1.0/30);
    require(a.diagnostics().steps==b.diagnostics().steps,"fixed step depends on render rate");
    for(std::size_t i=0;i<a.cells().size();++i) require(a.cells()[i].height==b.cells()[i].height,"fixed-step states differ");
    const auto old=a.energy(); a.advance(0); require(a.energy()==old,"pause advances time");
    a.advance(100); require(a.diagnostics().droppedSeconds>99,"stall is not bounded");
}
void contacts() {
    st::ContactTracker tracker; std::vector<st::Impulse> out;
    st::Contact c{42,{0,0},-10,0,25,false};
    tracker.update(std::span(&c,1),1.0/60,out); require(out.empty(),"loading actor splashes");
    c.position.x=3; tracker.update(std::span(&c,1),1.0/60,out); require(!out.empty(),"moving actor creates no wake");
    tracker.update(std::span(&c,1),1.0/60,out); require(out.empty(),"stationary actor continuously adds energy");
    c.position.x=10000; tracker.update(std::span(&c,1),1.0/60,out); require(out.empty(),"teleport creates wake stripe");
    tracker.reset(); c.position.x=0; c.baseZ=30; tracker.update(std::span(&c,1),1.0/60,out);
    c.baseZ=-1; tracker.update(std::span(&c,1),1.0/60,out); require(!out.empty(),"entry impact missing");
    tracker.reset(); c.baseZ=-400; c.swimming=true; tracker.update(std::span(&c,1),1.0/60,out);
    c.position.x=3; tracker.update(std::span(&c,1),1.0/60,out); require(out.empty(),"deep swimmer disturbs surface directly");
}
void strongerContacts() {
    auto run = [](int fps, float strength, float radius, float wind = 0) {
        st::Settings settings; settings.wind = wind; settings.resolution = 96;
        st::Surface surface(settings); surface.reset({0,0},0);
        st::ContactTracker tracker; std::vector<st::Impulse> out;
        st::Contact c{1,{-180,0},-30,0,25,false};
        tracker.update(std::span(&c,1),1.0/fps,out,strength,radius);
        for (int i=1;i<=fps*2;++i) {
            c.position.x = -180 + 180.0f * float(i)/float(fps);
            tracker.update(std::span(&c,1),1.0/fps,out,strength,radius);
            for (auto impulse:out) surface.addImpulse(impulse);
            surface.advance(1.0/fps,16);
        }
        if(surface.diagnostics().clippedCells) std::cerr << "wake fps=" << fps << " gain=" << strength << " radius=" << radius << " clipped=" << surface.diagnostics().clippedCells << "\n";
        require(surface.finite() && surface.diagnostics().clippedCells==0,"strong wake unstable or clipping");
        require(std::abs(surface.meanHeight()) < 0.05,"strong wake adds bulk water height");
        return surface.energy();
    };
    const auto baseline=run(60,1,1.5f), strong=run(60,4,1.5f);
    require(strong > baseline*14 && strong < baseline*18,"wake gain does not produce expected energy scaling");
    require(run(60,0,1.5f)<1e-6,"zero interaction strength still excites waves");
    run(60,4,1.5f,5); // shipped wind plus stronger contacts must remain bounded
    const auto slow=run(30,4,1.5f), fast=run(120,4,1.5f);
    require(std::abs(slow-fast)/fast < 0.2,"strong wake depends excessively on frame rate");
}
void idleGusts() {
    st::Settings s; s.resolution=96; s.wind=5;
    st::Surface gusts(s);
    auto old=s; old.gustStrength=0; st::Surface continuous(old);
    double curvature=0, previousCurvature=0; float peak=0;
    for(int frame=0;frame<60*20;++frame) {
        gusts.advance(1.0/60); continuous.advance(1.0/60);
        if(frame<60*5) continue;
        const auto a=gusts.cells(), b=continuous.cells();
        for(int y=20;y<76;++y) for(int x=20;x<76;++x) {
            const int i=y*96+x;
            const double ca=a[i-1].height+a[i+1].height+a[i-96].height+a[i+96].height-4*a[i].height;
            const double cb=b[i-1].height+b[i+1].height+b[i-96].height+b[i+96].height-4*b[i].height;
            curvature+=ca*ca; previousCurvature+=cb*cb;
            peak=std::max(peak,std::abs(a[i].height));
        }
    }
    std::cout << "idle gust curvature ratio=" << curvature/previousCurvature << " peak=" << peak
              << " clipped=" << gusts.diagnostics().clippedCells << '\n';
    require(gusts.finite() && gusts.diagnostics().clippedCells==0,"idle gusts diverged or clipped");
    require(curvature>previousCurvature*2,"gusts failed to increase interior surface shape");
    st::Surface slow(s), fast(s);
    for(int i=0;i<30*3;++i) slow.advance(1.0/30);
    for(int i=0;i<120*3;++i) fast.advance(1.0/120);
    for(std::size_t i=0;i<slow.cells().size();++i)
        require(std::abs(slow.cells()[i].height-fast.cells()[i].height)<1e-5,"gust scheduling depends on FPS");
    // No sponge/drag: masked pressure and local impulses must not add net water.
    s.edgeDamping=0; s.damping=0; s.maxHeight=100;
    st::Surface closed(s); std::vector<std::uint8_t> mask(closed.cells().size(),1);
    for(int y=0;y<96;++y) for(int x=0;x<96;++x) if(x<18 || (x>70 && y<35)) mask[y*96+x]=0;
    closed.setWetMask(mask);
    for(int i=0;i<120*3;++i) closed.step();
    require(std::abs(closed.meanHeight())<1e-4,"masked gusts add net water height");
    closed.reset({},0); closed.setWetMask(mask);
    st::Surface repeat(s); repeat.setWetMask(mask);
    for(int i=0;i<120;++i) { closed.step(); repeat.step(); }
    for(std::size_t i=0;i<closed.cells().size();++i)
        require(closed.cells()[i].height==repeat.cells()[i].height,"reset gust sequence is not deterministic");
}
void inputs() {
    auto s=base(); st::Surface surface(s); surface.addImpulse({{0,0},-1,50});
    surface.addImpulse({{0,0},20,std::numeric_limits<float>::quiet_NaN()});
    require(surface.diagnostics().rejectedImpulses==2 && surface.energy()==0,"invalid impulses were applied");
    s.spacing=0; bool rejected=false; try { st::Surface invalid(s); } catch(const std::invalid_argument&) { rejected=true; }
    require(rejected,"invalid configuration accepted");
    bool badMask=false; try { surface.setWetMask({}); } catch(const std::invalid_argument&) { badMask=true; }
    require(badMask,"short terrain mask accepted");
}
void forwardedDraw() {
    const st::DrawSignature expected{0,{600,20,0xfffffffcu,0,0},4};
    st::ForwardedDraw gate(expected);
    auto wrong=expected; wrong.arguments[1]++;
    require(!gate.consume(wrong),"different index offset consumed water identity");
    wrong=expected; wrong.topology=33;
    require(!gate.consume(wrong),"different topology consumed water identity");
    wrong=expected; wrong.kind=2;
    require(!gate.consume(wrong),"different draw method consumed water identity");
    require(gate.consume(expected),"matching forwarded draw was rejected");
    require(!gate.consume(expected),"second downstream pass reused water identity");
    for(unsigned kind=4;kind<7;++kind) {
        auto indirect=expected; indirect.kind=kind;
        st::ForwardedDraw unsupported(indirect);
        require(!unsupported.consume(indirect),"opaque indirect or auto draw accepted");
    }
    st::ForwardedDraw separate(expected);
    require(separate.consume(expected),"draw consumption leaked into another scope");
}
void logicalTopology() {
    st::LogicalTopology state;
    require(!state.known() && state.resolve(4)==4,"initial topology did not retain getter fallback");
    require(!state.observe(35,true) && !state.known(),"nested setter created false game history");

    // Replay the returned UNDERWATER410E trace: identical direct draw arguments,
    // wrapper getter=35, actual native draw=4. The original gate rejected it.
    const st::DrawSignature native{0,{216,0,0,0,0},4};
    auto expected=native; expected.topology=35;
    st::ForwardedDraw oldGate(expected);
    require(!oldGate.consume(native),"trace no longer reproduces the original mismatch");
    require(state.observe(4,false),"outer game setter was not recorded");
    require(!state.observe(35,true),"temporary patch topology replaced game request");
    expected.topology=state.resolve(35);
    st::ForwardedDraw fixedGate(expected);
    auto wrong=native; wrong.arguments[1]=3;
    require(!fixedGate.consume(wrong),"topology correction weakened argument matching");
    require(fixedGate.consume(native),"observed game topology did not repair trace mismatch");
    require(!fixedGate.consume(native),"corrected signature allowed a second native pass");

    // A genuine game patch request must remain a patch request, not an implicit
    // blanket allowance for the reverse conversion observed in the faulty getter.
    state.observe(35,false); expected.topology=state.resolve(4);
    st::ForwardedDraw realPatch(expected);
    require(!realPatch.consume(native),"genuine patch request accepted a triangle conversion");
    require(realPatch.consume(expected),"genuine matching patch draw was rejected");
    auto restored=state;
    restored.observe(4,true);
    require(restored.resolve(4)==35,"preserved command-list state changed on nested setter");
    state.clear();
    require(state.known() && state.resolve(35)==0,"clear/default reset retained stale topology");
    state.observe(4,false);
    require(state.resolve(35)==4,"new game request after clear was not recorded");
}
void constantBindings() {
    // Replay the measured 31E OFF/ON/OFF layout; required sizes may be smaller
    // than the engine's allocations, but must fit the complete mapped groups.
    const std::array<std::uint32_t,3> engine{80,224,1296}, live{80,224,160};
    const std::array<std::uint32_t,4> off{80,224,1296,0}, on{4976,80,224,1296};
    require(!st::shiftedWaterConstants(engine,live,off),"normal bindings remapped");
    require(st::shiftedWaterConstants(engine,live,on),"captured shifted water layout missed");
    require(!st::shiftedWaterConstants(engine,live,off),"repair persisted after water switched off");
    auto wrong=on; wrong[2]=96;
    require(!st::shiftedWaterConstants(engine,live,wrong),"wrong material buffer accepted");
    wrong=on; wrong[3]=0;
    require(!st::shiftedWaterConstants(engine,live,wrong),"missing geometry buffer accepted");
    require(!st::shiftedWaterConstants({0,0,0},live,on),"missing engine descriptors accepted");
    require(!st::shiftedWaterConstants(engine,{80,224,1312},on),"undersized geometry data accepted");
    require(!st::shiftedWaterConstants({80,224,0},{80,224,0},{4992,80,224,720}),"two-group LOD layout remapped");
    require(!st::shiftedWaterConstants({80,80,1296},{80,80,160},{4976,80,80,1296}),"ambiguous duplicate sizes accepted");
    wrong=on; wrong[0]=80;
    require(!st::shiftedWaterConstants(engine,live,wrong),"ordinary leading buffer treated as inserted");
    wrong=on; wrong[0]=4977;
    require(!st::shiftedWaterConstants(engine,live,wrong),"misaligned prefix accepted");
    wrong=on; wrong[0]=65552;
    require(!st::shiftedWaterConstants(engine,live,wrong),"unrecognized large buffer range accepted");
}
void meshFieldBounds() {
    st::MeshBounds b{50,50,0,10,true};
    require(!st::outsideMeshField(b,0,0,100,0),"intersecting geometry excluded");
    b.x=114; require(!st::outsideMeshField(b,0,0,100,0),"border margin excluded");
    b.x=115; require(st::outsideMeshField(b,0,0,100,0),"outside geometry not excluded");
    b.x=50; b.z=16; require(!st::outsideMeshField(b,0,0,100,0),"height margin excluded");
    b.z=17; require(st::outsideMeshField(b,0,0,100,0),"different height band not excluded");
    b.valid=false; require(!st::outsideMeshField(b,0,0,100,0),"unknown bounds used for exclusion");
    b.valid=true; b.radius=-1; require(!st::outsideMeshField(b,0,0,100,0),"negative radius used");
    b.radius=std::numeric_limits<float>::quiet_NaN(); require(!st::outsideMeshField(b,0,0,100,0),"nonfinite bound used");
    b={115,50,0,10,true};
    require(st::outsideMeshField(b,0,0,100,0) && !st::outsideMeshField(b,20,0,100,0),"previous patch union not retained");
    require(st::meshStreamBytes(1536,56)>st::meshStreamBytes(1536),"history stride not budgeted");
    require(!st::meshStreamBytes(1536,0),"unsupported stride accepted");
}
void meshInputSelection() {
    const st::DrawSignature game{0,{1536,0,0,0,0},4};
    auto native=game; native.topology=35;
    require(st::meshInputDraw(game,native),"native ENB tri patch rejected");
    require(st::meshInputDraw(game,native),"second native pass rejected");
    require(st::meshInputDraw(game,game),"triangle follow-up rejected");
    native.topology=33; require(!st::meshInputDraw(game,native),"one-point patch accepted");
    native=game; native.arguments[1]=1; require(!st::meshInputDraw(game,native),"different index range accepted");
    native=game; native.arguments[2]=1; require(!st::meshInputDraw(game,native),"different base vertex accepted");
    native=game; native.kind=2; require(!st::meshInputDraw(game,native),"instancing inferred");
    for (unsigned kind=2;kind<7;++kind) {
        native=game; native.kind=kind;
        require(!st::meshInputDraw(native,native),"unsupported draw kind accepted");
    }
    native=game; native.arguments[0]=0; require(!st::meshInputDraw(native,native),"empty draw accepted");
    native.arguments[0]=5; require(!st::meshInputDraw(native,native),"partial triangle accepted");
    native=game; native.topology=5; require(!st::meshInputDraw(native,native),"strip game draw accepted");
    require(st::meshStreamBytes(1536)>1536*40,"missing amplification storage");
    require(!st::meshStreamBytes(0) && !st::meshStreamBytes(5),"invalid stream capacity accepted");
    require(!st::meshStreamBytes(0xffffffffu),"stream capacity arithmetic overflow");
    require(!st::meshStreamBytes(300000),"oversized draw exceeds memory budget");
    require(st::meshStreamBytes(1536,40,16)==71024640u,"factor16 capacity does not cover conservative amplification");
    require(st::meshStreamBytes(1536,56,16)==99434496u,"factor16 history capacity incorrect");
    require(st::meshStreamBytes(216,40,16)>st::meshStreamBytes(216,40,8),"higher cap did not increase storage");
    require(!st::meshStreamBytes(1536,40,0) && !st::meshStreamBytes(1536,40,17),"unsupported factor accepted");
    require(!st::meshStreamBytes(6000,40,16),"factor16 exceeds memory budget without rejection");
}
void shaderIdentity() {
    const st::ShaderIdentity known{7,2,0};
    require(st::validShaderIdentity(known,7,0,3),"valid shader identity rejected");
    require(!st::validShaderIdentity(known,8,0,3),"stale shader tag accepted after reindex");
    require(!st::validShaderIdentity(known,7,1,3),"vertex tag accepted for pixel shader");
    require(!st::validShaderIdentity(known,7,0,2),"out-of-range shader record accepted");
    const auto duplicate=st::mergeShaderIdentity(known,&known);
    require(st::validShaderIdentity(duplicate,7,0,3),"same identity spuriously ambiguous");
    const auto conflict=st::mergeShaderIdentity({7,1,0},&known);
    require(!st::validShaderIdentity(conflict,7,0,3),"aliased distinct permutations accepted");
    const auto repeated=st::mergeShaderIdentity(known,&conflict);
    require(!st::validShaderIdentity(repeated,7,0,3),"later alias clears ambiguity");
    const auto refreshed=st::mergeShaderIdentity({8,1,0},&conflict);
    require(st::validShaderIdentity(refreshed,8,0,3),"new generation cannot replace stale ambiguity");
    require(!st::validShaderIdentity(st::mergeShaderIdentity({7,2,1},&known),7,1,3),"stage alias accepted");
}
void shaderLayout() {
    auto table=st::referenceConstantTable(st::ShaderStage::Vertex);
    const auto text=st::engineConstantHeader(st::ShaderStage::Vertex,table);
    require(text.find("WorldViewProj : packoffset(c8)")!=std::string::npos,"float offsets interpreted as vector offsets");
    table[11]=48; bool rejected=false; try { st::engineConstantHeader(st::ShaderStage::Vertex,table); } catch(const std::invalid_argument&) { rejected=true; }
    require(rejected,"overlapping shader constants accepted");
    table.assign(table.size(),0); table[0]=16;
    const std::vector<std::string> live{"World","WorldViewProj"};
    const auto sparse=st::engineConstantHeader(st::ShaderStage::Vertex,table,std::span<const std::string>(live));
    require(sparse.find("WorldViewProj : packoffset(c4)")!=std::string::npos,"live constant mapping failed");
    require(sparse.find("static const float4 CellTexCoordOffset")!=std::string::npos,"inactive alias bound to cbuffer");
    const std::vector<std::string> inactive;
    const auto pixelDefaults=st::engineConstantHeader(st::ShaderStage::Pixel,
        st::referenceConstantTable(st::ShaderStage::Pixel),std::span<const std::string>(inactive));
    for (const auto* name : {"LightPos", "LightColor"}) {
        const auto begin=pixelDefaults.find(std::string(name)+"[8] = {");
        require(begin!=std::string::npos,"missing inactive light array");
        const auto end=pixelDefaults.find(';',begin);
        const auto initializer=pixelDefaults.substr(begin,end-begin);
        std::size_t count=0, at=0;
        while ((at=initializer.find("float4(0,0,0,0)",at))!=std::string::npos) { ++count; ++at; }
        require(count==8,"SM5 light array lacks eight explicit vector initializers");
    }
    bool badTechnique=false; try { st::shaderDefines(15u<<11,"VSHADER",0); } catch(const std::invalid_argument&) { badTechnique=true; }
    require(badTechnique,"unknown shader permutation accepted");
}
}
int main() {
    const std::pair<const char*,std::function<void()>> tests[]={{"reviewed attached foam selection",foamSelection},{"live tuning and thread handoff",liveTuning},{"calm",calm},{"symmetry and conservation",symmetryAndConservation},
        {"impermeable barrier",barrier},{"diffraction through opening",diffraction},{"energy damping",damping},
        {"CFL and long-run stability",longRun},{"measured dispersion",dispersion},{"world-space scrolling",scrolling},
        {"fixed timestep and stalls",frameRate},{"character contacts",contacts},{"stronger wake stability",strongerContacts},{"localized idle gusts",idleGusts},{"invalid inputs",inputs},{"forwarded draw isolation",forwardedDraw},{"logical topology forwarding",logicalTopology},{"mesh bounds and history capacity",meshFieldBounds},{"mesh input selection and capacity",meshInputSelection},{"water constant binding repair",constantBindings},{"shader identity validation",shaderIdentity},{"shader ABI layout",shaderLayout}};
    int failures=0;
    for(const auto& [name,test]:tests) {
        try { test(); std::cout<<"PASS "<<name<<'\n'; }
        catch(const std::exception& e) { ++failures; std::cerr<<"FAIL "<<name<<": "<<e.what()<<'\n'; }
    }
    std::cout<<std::size(tests)-failures<<'/'<<std::size(tests)<<" passed\n";
    return failures ? 1 : 0;
}
