#include "surfacetides/FloeMotion.hpp"
#include "surfacetides/FoamSelection.hpp"
#include "surfacetides/Tuning.hpp"
#include "surfacetides/FloeManagement.hpp"
#include "surfacetides/FloeRider.hpp"
#include <cmath>
#include <functional>
#include <iostream>
#include <limits>
#include <numbers>
#include <stdexcept>

namespace {
void require(bool condition, const char* why) { if (!condition) throw std::runtime_error(why); }
void near(float a, float b, const char* why, float tolerance=1e-5f) { require(std::isfinite(a) && std::abs(a-b) < tolerance,why); }
struct Fixture {
    std::vector<st::SurfaceTexel> data=std::vector<st::SurfaceTexel>(33*33);
    st::SurfaceFieldView field{data,{-160,-160},10,600,1,33,2,7,true};
    Fixture() { for (auto& t : data) t.wet=1; }
    void plane(float base,float x,float y) {
        for (int j=0;j<33;++j) for (int i=0;i<33;++i)
            data[std::size_t(j*33+i)].height=base+x*(-160+i*10)+y*(-160+j*10);
    }
    st::SurfaceHeight at(float x,float y) { return st::sampleSurfaceHeight(field,{x,y},600,7); }
    st::FloeFootprint footprint() { return {{0,0},{40,30},0,600,7}; }
};
void iceSelection() {
    using namespace st::foam;
    const int p=modelProfile("MESHES\\LANDSCAPE\\ICE\\ICEFLOESSOLID01.NIF");
    require(p == 2 && profiles[p].iceDecal,"ice model/category not matched");
    const auto slot=[&](const char* shape,bool effect=false,bool collision=false,bool controller=false) {
        return shapeSlot(p,shape,effect,"Textures\\landscape\\IceFloes.dds","textures/landscape/icefloes_n.dds",collision,controller);
    };
    require(slot("L1_IceFloesSolidSlush") == 0,"inspected slush rejected");
    require(slot("IceFloesSolid01:0") < 0,"solid ice would be hidden");
    require(slot("L1_IceFloesSolidSlush",true) < 0,"wrong shader accepted");
    require(slot("L1_IceFloesSolidSlush",false,true) < 0,"collision owner accepted");
    require(slot("L1_IceFloesSolidSlush",false,false,true) < 0,"controlled geometry accepted");
    require(shapeSlot(p,"L1_IceFloesSolidSlush",false,"landscape/glacierslab.dds",profiles[p].greyscale,false,false) < 0,"solid material accepted");
    require(shapeSlot(p,"L1_IceFloesSolidSlush",false,profiles[p].source,"landscape/glacierslab_n.dds",false,false) < 0,"wrong normal accepted");
    for (int profile=3;profile<5;++profile) {
        const auto& item=profiles[profile];
        require(modelProfile(item.model)==profile && item.iceDecal,"new floe profile not resolved");
        require(shapeSlot(profile,item.shapes[0],false,item.source,item.greyscale,false,false)==0,"new slush shape rejected");
        require(shapeSlot(profile,item.rock,false,item.source,item.greyscale,false,false)<0,"new solid ice selected");
        require(shapeSlot(profile,item.shapes[0],true,item.source,item.greyscale,false,false)<0,"new wrong shader selected");
        require(shapeSlot(profile,item.shapes[0],false,item.source,item.greyscale,true,false)<0,"new collision owner selected");
    }
    for (const char* model : {"landscape/ice/iceberg01.nif","landscape/ice/frozenmarsh01.nif","other/icefloessolid01.nif"})
        require(modelProfile(model) < 0,"unreviewed mesh selected");
}
void sampling() {
    Fixture f; f.plane(3,0.02f,-0.04f); f.field.displacementStrength=2;
    near(f.at(0,0).displacement,6,"texel-center origin shifted");
    near(f.at(3,7).displacement,2*(3+0.02f*3-0.04f*7),"fractional bilinear sample shifted");
    near(f.at(0,0).coverage,1,"interior not fully covered");
    for (auto& texel : f.data) { texel.slopeX=9000; texel.slopeY=-9000; }
    near(f.at(0,0).displacement,6,"shading normals affected displacement");
    f.field.displacementStrength=0;
    near(f.at(0,0).displacement,0,"zero displacement retained motion");
}
void wetAndEdge() {
    Fixture f; f.plane(10,0,0);
    near(f.at(-160,0).displacement,0,"outermost texel not faded to rest");
    near(f.at(-150,0).displacement,5,"smoothstep edge fade wrong");
    near(f.at(-155,0).displacement,1.5625f,"fractional edge fade wrong");
    near(f.at(-140,0).displacement,10,"full edge width did not recover height");
    require(f.at(-161,0).valid && f.at(-161,0).coverage == 0,"outside field did not return rest");
    // Height and wetness must be interpolated separately, then multiplied.
    // Premultiplying each texel would produce 2 here, not the GPU's 3.
    for (int y=16;y<=17;++y) { f.data[std::size_t(y*33+16)]={4,0,0,1}; f.data[std::size_t(y*33+17)]={8,0,0,0}; }
    near(f.at(5,5).displacement,3,"wet multiplication differs from shader");
    near(f.at(5,5).coverage,0.5f,"bilinear wetness wrong");
}
void rejectedFields() {
    Fixture f; f.plane(4,0,0);
    require(!st::sampleSurfaceHeight(f.field,{0,0},600,8).valid,"different worldspace accepted");
    require(!st::sampleSurfaceHeight(f.field,{0,0},602,7).valid,"strict 2-unit band accepted boundary");
    require(st::sampleSurfaceHeight(f.field,{0,0},601.99f,7).valid,"matching water band rejected");
    f.field.active=false; require(!f.at(0,0).valid,"inactive patch accepted"); f.field.active=true;
    f.field.area=0; require(!st::sampleSurfaceHeight(f.field,{0,0},600,0).valid,"unknown area accepted"); f.field.area=7;
    f.field.texels=f.field.texels.first(100); require(!f.at(0,0).valid,"truncated field accepted"); f.field.texels=f.data;
    f.field.spacing=0; require(!f.at(0,0).valid,"zero spacing accepted"); f.field.spacing=10;
    f.data[16*33+16].height=std::numeric_limits<float>::quiet_NaN(); require(!f.at(0,0).valid,"NaN reached pose");
    f.data[16*33+16].height=4; f.data[16*33+16].wet=2; require(!f.at(0,0).valid,"invalid wet mask accepted");
}
void planeFit() {
    Fixture f; f.plane(8,0.03f,-0.04f);
    auto footprint=f.footprint(); footprint.center={10,20}; footprint.yawRadians=0.73f;
    auto t=st::fitFloeTarget(f.field,footprint);
    require(t.valid,"tilted plane rejected");
    near(t.pose.heave,7.5f,"mean displacement wrong");
    near(t.pose.slope.x,0.03f,"yaw corrupted world x slope");
    near(t.pose.slope.y,-0.04f,"yaw corrupted world y slope");
    near(t.coverage,1,"fully wet footprint lost coverage");
    f.field.displacementStrength=2;
    t=st::fitFloeTarget(f.field,footprint);
    near(t.pose.heave,15,"floe ignored displacement strength");
    near(t.pose.slope.x,0.06f,"tilt ignored displacement strength");
    footprint.waterLevel=640;
    require(!st::fitFloeTarget(f.field,footprint).valid,"pivot height used as the water level");
}
void averagingAndLimits() {
    Fixture f; f.data[16*33+16].height=18;
    auto t=st::fitFloeTarget(f.field,f.footprint());
    near(t.pose.heave,2,"localized ripple drove entire floe by its peak");
    near(t.pose.slope.x,0,"centered ripple added tilt");
    near(t.pose.slope.y,0,"centered ripple added tilt");
    f.plane(100,2,-2);
    t=st::fitFloeTarget(f.field,f.footprint(),{12,0.1f});
    near(t.pose.heave,12,"heave cap not applied");
    near(std::hypot(t.pose.slope.x,t.pose.slope.y),std::tan(0.1f),"combined tilt cap not applied");
    near(t.pose.slope.x,-t.pose.slope.y,"tilt clamp changed heading");
    auto p=f.footprint(); p.halfExtent.x=0;
    require(!st::fitFloeTarget(f.field,p).valid,"degenerate footprint accepted");
    p=f.footprint(); p.center={5000,5000};
    t=st::fitFloeTarget(f.field,p);
    require(t.valid && t.coverage == 0 && t.pose.heave == 0,"outside floe did not settle to rest");
}
void response() {
    const st::FloeTarget target{{12,{0.03f,-0.04f}},1,true};
    st::FloePose a{}, b{};
    for (int i=0;i<30;++i) a=st::approachFloeTarget(a,target,1.0f/30,0.6f);
    for (int i=0;i<144;++i) b=st::approachFloeTarget(b,target,1.0f/144,0.6f);
    near(a.heave,b.heave,"response depends on frame rate",3e-5f);
    near(a.heave,12*(1-std::exp(-1.0f/0.6f)),"response does not match elapsed time");
    near(st::approachFloeTarget(a,target,0,0.6f).heave,a.heave,"paused pose moved");
    near(st::approachFloeTarget(a,target,1,0).heave,12,"zero response did not snap");
    const auto settling=st::approachFloeTarget(a,{},1,0.6f);
    require(settling.heave >= 0 && settling.heave < a.heave,"invalid frame retained stale lift");
    near(st::approachFloeTarget(a,target,std::numeric_limits<float>::quiet_NaN(),0.6f).heave,a.heave,"invalid dt damaged pose");
}
void actualSimulation() {
    st::Settings settings; settings.resolution=32; settings.spongeCells=8; settings.wind=0; settings.gustStrength=0;
    st::Surface surface(settings); surface.reset({0,0},600);
    surface.addImpulse({{0,0},80,60}); surface.advance(0.04);
    std::vector<st::SurfaceTexel> texels(surface.cells().size());
    for (std::size_t i=0;i<texels.size();++i) texels[i]={surface.cells()[i].height,0,0,float(surface.wetMask()[i] != 0)};
    st::SurfaceFieldView view{texels,surface.origin(),settings.spacing,surface.level(),2,settings.resolution,settings.spongeCells,7,true};
    const st::Vec2 point{surface.origin().x+15*settings.spacing,surface.origin().y+15*settings.spacing};
    near(st::sampleSurfaceHeight(view,point,600,7).displacement,2*surface.cells()[15*32+15].height,"actual solver field does not match center sample");
    auto t=st::fitFloeTarget(view,{{0,0},{20,20},0,600,7});
    require(t.valid && std::abs(t.pose.heave) > 0.001f,"real impulse failed to drive a target");
}
void rigidTilt() {
    const st::FloePose pose{17,{0.04f,-0.03f}};
    const auto r=st::floeTiltRotation(pose);
    const float norm=std::sqrt(1+pose.slope.x*pose.slope.x+pose.slope.y*pose.slope.y);
    near(r[2],-pose.slope.x/norm,"tilt x points away from fitted normal");
    near(r[5],-pose.slope.y/norm,"tilt y points away from fitted normal");
    near(r[8],1/norm,"tilt z points away from fitted normal");
    for (unsigned i=0;i<3;++i) for (unsigned j=0;j<3;++j) {
        float dot=0; for (unsigned k=0;k<3;++k) dot+=r[k*3+i]*r[k*3+j];
        near(dot,i==j?1.0f:0.0f,"tilt matrix deforms rigid ice");
    }
    const auto identity=st::floeTiltRotation({});
    for (unsigned i=0;i<9;++i) near(identity[i],i%4==0?1.0f:0.0f,"rest rotation changed authored pose");
}
void boundedTravel() {
    const st::FloePose before{-20,{-0.05f,0.04f}}, goal{40,{0.05f,-0.04f}};
    constexpr float radius=1200, budget=3;
    const auto next=st::limitFloeStep(before,goal,radius,budget);
    const auto a=st::floeTiltRotation(before), b=st::floeTiltRotation(next);
    // Check actual point travel at axes and diagonals, including off-center
    // points and vertical freeboard, instead of repeating the limiter's norm.
    for (float x : {-0.577350269f,0.0f,0.577350269f})
        for (float y : {-0.577350269f,0.0f,0.577350269f})
            for (float z : {-0.577350269f,0.0f,0.577350269f}) {
                const float p[]{x*radius,y*radius,z*radius};
                float delta[3]{0,0,next.heave-before.heave};
                for (unsigned i=0;i<3;++i) for (unsigned j=0;j<3;++j) delta[i]+=(b[i*3+j]-a[i*3+j])*p[j];
                require(std::sqrt(delta[0]*delta[0]+delta[1]*delta[1]+delta[2]*delta[2])<=budget+1e-4f,"floe point exceeded motion budget");
            }
    require(next.heave>before.heave && next.heave<goal.heave,"bounded step stalled or overshot");
    near(st::limitFloeStep(before,goal,radius,0).heave,before.heave,"zero budget moved floe");
    auto pose=before;
    for (int i=0;i<1000;++i) pose=st::limitFloeStep(pose,goal,radius,budget);
    near(pose.heave,goal.heave,"bounded steps failed to converge");
    near(pose.slope.x,goal.slope.x,"bounded tilt failed to converge");
}
void crestClearance() {
    Fixture f; f.plane(2,0.02f,-0.01f);
    // An interior crest missed by all nine original fit points.
    f.data[17*33+18].height+=18;
    const auto p=f.footprint();
    const auto original=st::fitFloeTarget(f.field,p);
    near(original.pose.heave,2,"test crest reached an original fit point");
    const auto crest=st::fitFloeCrestTarget(f.field,p,{},1,4);
    require(crest.target.valid && crest.addedLift>20,"interior crest did not drive clearance");
    require(crest.samples>9 && crest.samples<=65*65,"dense scan count outside its budget");
    near(crest.target.pose.slope.x,original.pose.slope.x,"clearance altered fitted tilt");
    // Check actual clearance over an independently chosen, finer world grid.
    for (float y=-30;y<=30;y+=2.5f) for (float x=-40;x<=40;x+=2.5f) {
        const auto wave=f.at(x,y);
        const float plane=crest.target.pose.heave+crest.target.pose.slope.x*x+crest.target.pose.slope.y*y;
        require(plane>=wave.displacement+4-1e-4f,"sampled crest still pierces target plane");
    }
    const auto off=st::fitFloeCrestTarget(f.field,p,{},0,32);
    near(off.target.pose.heave,original.pose.heave,"disabled clearance changed original heave");
    near(off.target.coverage,original.coverage,"disabled clearance changed original coverage");
    require(off.samples==0,"disabled feature retained dense sampling cost");
    const auto half=st::fitFloeCrestTarget(f.field,p,{},0.5f,4);
    require(half.target.pose.heave>original.pose.heave && half.target.pose.heave<crest.target.pose.heave,"partial clearance is not between old/new targets");
}
void cancellingCrests() {
    Fixture f;
    for (int y=0;y<33;++y) for (int x=0;x<33;++x)
        f.data[std::size_t(y*33+x)].height=8*std::cos(2*std::numbers::pi_v<float>*(-160+x*10)/60);
    f.field.displacementStrength=2;
    const auto original=st::fitFloeTarget(f.field,f.footprint());
    near(original.pose.heave,0,"mean cancellation fixture invalid",1e-4f);
    const auto crest=st::fitFloeCrestTarget(f.field,f.footprint(),{},1,4);
    require(crest.target.pose.heave>=19.99f,"large cancelling crests still average to flat motion");
    require(crest.addedLift>=19.99f,"visual clearance failed to account for rendered displacement strength");
}
void crestRestAndBounds() {
    Fixture f; f.plane(0,0,0);
    auto sample=[&] { return st::fitFloeCrestTarget(f.field,f.footprint(),{},1,32); };
    near(sample().target.pose.heave,0,"clearance levitates a calm floe");
    f.plane(0.001f,0,0);
    require(sample().target.pose.heave<0.01f,"extra lift does not fade with tiny waves");
    f.plane(12,0,0); f.field.displacementStrength=0;
    near(sample().target.pose.heave,0,"zero displacement retains extra lift");
    f.field.displacementStrength=1;
    for (auto& t:f.data) t.wet=0;
    auto result=sample();
    require(result.target.valid && result.target.coverage==0 && result.target.pose.heave==0,"dry footprint retains lift");
    for (auto& t:f.data) t.wet=1;
    auto far=f.footprint(); far.center={10000,10000};
    result=st::fitFloeCrestTarget(f.field,far,{},1,32);
    require(result.target.valid && result.target.coverage==0 && result.target.pose.heave==0,"outside field retains clearance");
    result=st::fitFloeCrestTarget(f.field,f.footprint(),{15,0.1f},1,32);
    require(result.limited && result.target.pose.heave==15,"crest lift bypasses hard heave limit");
    auto large=f.footprint(); large.halfExtent={100000,100000};
    result=st::fitFloeCrestTarget(f.field,large,{},1,32);
    require(result.target.valid && result.samples==65*65,"large footprint causes unbounded sampling");
    f.plane(-4,0,0);
    result=st::fitFloeCrestTarget(f.field,f.footprint(),{},1,0);
    near(result.target.pose.heave,-4,"uniform trough was pushed farther down or spuriously raised");
}
void crestRejectionsAndTuning() {
    Fixture f; const auto p=f.footprint();
    require(!st::fitFloeCrestTarget(f.field,p,{},-1,4).target.valid,"negative crest follow accepted");
    require(!st::fitFloeCrestTarget(f.field,p,{},1,33).target.valid,"excess extra lift accepted");
    require(!st::fitFloeCrestTarget(f.field,p,{},std::numeric_limits<float>::quiet_NaN(),4).target.valid,"NaN blend accepted");
    f.data[17*33+18].height=std::numeric_limits<float>::quiet_NaN();
    require(!st::fitFloeCrestTarget(f.field,p,{},1,4).target.valid,"dense-sample NaN entered motion");
    st::Tuning original, changed=original;
    changed.floeCrestFollow=0.7f; changed.floeExtraLift=8; changed.floeResponseSeconds=0.2f;
    st::TuningExchange exchange; exchange.publish(changed);
    near(exchange.read().values.floeExtraLift,8,"floe live setting lost in thread handoff");
    require(!st::needsSurfaceReset(original,changed),"floe tuning resets existing waves");
    for (const auto member:{&st::Tuning::floeCrestFollow,&st::Tuning::floeExtraLift,&st::Tuning::floeResponseSeconds}) {
        changed=original; changed.*member=std::numeric_limits<float>::infinity();
        bool rejected=false; try { exchange.publish(changed); } catch (const std::invalid_argument&) { rejected=true; }
        require(rejected,"nonfinite live floe control accepted");
        near(exchange.read().values.floeExtraLift,8,"rejected tuning damaged published state");
    }
}
void fleetProfilesAndBounds() {
    // Adding decal profiles must never widen the keyframed-collision/bobbing set.
    for (unsigned i=0;i<st::foam::profiles.size();++i)
        require(st::isFloeProfile(int(i))==(i>=2 && i<=4),"decal expansion changed bobbing eligibility");
    for (const char* model:{"landscape/ice/icefloes01.nif","landscape/ice/icefloessolid01.nif","meshes\\LANDSCAPE\\ICE\\ICEFLOESSOLID02.NIF"})
        require(st::isFloeProfile(st::foam::modelProfile(model)),"reviewed ice model excluded from bobbing");
    for (const char* model:{"effects/fxrapidsrocks01.nif","landscape/ice/iceberg01.nif","other/icefloes01.nif"})
        require(!st::isFloeProfile(st::foam::modelProfile(model)),"unreviewed rock/ice model animated");
    require(!st::isFloeProfile(-1) && !st::isFloeProfile(9000),"invalid model index accepted");
    Fixture f;
    require(st::floeOverlapsField(f.field,{0,0},10),"interior floe excluded");
    require(st::floeOverlapsField(f.field,{180,0},25),"floe overlapping patch with outside pivot excluded");
    require(!st::floeOverlapsField(f.field,{190,190},40),"diagonally separated floe acquired");
    require(!st::floeOverlapsField(f.field,{900,0},25),"remote floe acquired");
    require(!st::floeOverlapsField(f.field,{0,0},std::numeric_limits<float>::infinity()),"invalid geometry bound accepted");
    f.field.active=false; require(!st::floeOverlapsField(f.field,{0,0},10),"inactive field acquires floes");
}
void fleetRefreshFairness() {
    for (const float fps:{20.0f,60.0f,144.0f}) {
        std::array<st::FloeRefreshRequest,st::maxManagedFloes> requests{};
        std::array<unsigned,st::maxManagedFloes> visits{};
        for (std::size_t i=0;i<requests.size();++i) requests[i]={0,true,i<32};
        float worstAge=0;
        for (unsigned frame=0;frame<300;++frame) {
            for (auto& r:requests) r.age+=1/fps;
            if (frame==150) for (auto& r:requests) r.required=true; // a live/epoch invalidation burst
            std::array<std::size_t,32> chosen{};
            const auto count=st::selectFloeRefreshes(requests,chosen);
            require(count<=st::maxFloeRefreshes,"refresh budget exceeded");
            for (std::size_t i=0;i<count;++i) {
                const auto index=chosen[i]; require(index<requests.size(),"invalid selected index");
                for (std::size_t j=0;j<i;++j) require(chosen[j]!=index,"same floe refreshed twice");
                requests[index].age=0; requests[index].required=false; ++visits[index];
            }
            for (const auto& r:requests) worstAge=std::max(worstAge,r.age);
        }
        for (auto count:visits) require(count>=12,"an unoccupied or late-index floe was starved");
        require(worstAge<=0.55f,"refresh age grew beyond a bounded scheduling cycle");
    }
    std::array<st::FloeRefreshRequest,4> requests{{{0.02f,false,false},{0.02f,false,true},{0,true,false},{0,false,false}}};
    std::array<std::size_t,8> chosen{};
    require(st::selectFloeRefreshes(requests,chosen)==2 && chosen[0]==2 && chosen[1]==1,"fresh/required/rider priorities are wrong");
    require(st::selectFloeRefreshes(requests,{})==0,"zero output budget wrote a selection");
    requests[2].age=std::numeric_limits<float>::quiet_NaN();
    require(st::selectFloeRefreshes(requests,chosen)==1 && chosen[0]==1,"nonfinite scheduler input propagated");
}
struct MovingRider {
    std::array<float,4> live{100,200,30,17}, speed{2,-1,0,23};
    unsigned moves{}, restores{};
    bool clearsVelocity=true, changesMetadata=false;
    auto position() const { return live; }
    auto velocity() const { return speed; }
    void moveWithoutWarp(const std::array<float,4>& p) {
        live=p; if (clearsVelocity) speed={}; if (changesMetadata) speed[3]+=1; ++moves;
    }
    void restoreVelocity(const std::array<float,4>& v) { speed=v; ++restores; }
};
void riderLocomotion() {
    // The controller advances from input before each carry, while the actor
    // reference can still hold yesterday's location. Carry must preserve all
    // of that travel, even if the low-level position setter clears velocity.
    MovingRider c;
    const auto initial=c.live, velocity=c.speed;
    float previousLift=0;
    for (unsigned frame=1;frame<=120;++frame) {
        c.live[0]+=velocity[0]/60; c.live[1]+=velocity[1]/60;
        const float lift=10*std::sin(static_cast<float>(frame)*0.1f);
        require(st::offsetFloeRider(c,{0,0,lift-previousLift},70),"valid additive carry rejected");
        require(c.speed==velocity,"carrying a rider erased native walking velocity");
        previousLift=lift;
    }
    near(c.live[0],initial[0]+4,"walking X was cancelled by platform carry",0.002f);
    near(c.live[1],initial[1]-2,"walking Y was cancelled by platform carry",0.002f);
    near(c.live[2],initial[2]+previousLift/70,"bobbing lost its vertical carry",0.0001f);
    require(c.live[3]==initial[3] && c.moves==120 && c.restores==120,"native W or carry sequencing changed");
    const auto before=c.live;
    require(st::offsetFloeRider(c,{7,-14,21},70),"tilt/translation carry rejected");
    for (unsigned i=0;i<3;++i) near(c.live[i],before[i]+std::array<float,3>{0.1f,-0.2f,0.3f}[i],"wrong native scale or overwritten live position");
    require(st::offsetFloeRider(c,{-7,14,-21},70),"restore carry rejected");
    for (unsigned i=0;i<3;++i) near(c.live[i],before[i],"restore did not undo only platform motion");
}
void riderCarryGuards() {
    MovingRider c;
    const auto initial=c.live, velocity=c.speed;
    for (const auto delta:std::array<std::array<float,3>,4>{{{0,0,0},{129,0,0},{100,100,0},{0,std::numeric_limits<float>::quiet_NaN(),0}}})
        require(!st::offsetFloeRider(c,delta,70),"invalid or zero carry accepted");
    for (const auto scale:{0.0f,-70.0f,1001.0f,std::numeric_limits<float>::infinity()})
        require(!st::offsetFloeRider(c,{0,0,1},scale),"invalid unit conversion accepted");
    require(c.moves==0 && c.restores==0 && c.live==initial && c.speed==velocity,"rejected carry mutated controller");
    c.speed[1]=std::numeric_limits<float>::quiet_NaN();
    require(!st::offsetFloeRider(c,{0,0,1},70) && c.moves==0,"invalid native velocity was overwritten");
    c.speed=velocity; c.live[2]=std::numeric_limits<float>::infinity();
    require(!st::offsetFloeRider(c,{0,0,1},70) && c.moves==0,"invalid native position was overwritten");
}
void riderNaturalBraking() {
    MovingRider c; c.clearsVelocity=false; c.changesMetadata=true;
    st::FloeRiderStats stats;
    const float startX=c.live[0];
    float expectedX=startX;
    for (unsigned frame=0;frame<120;++frame) {
        // Native movement owns acceleration/braking, including a complete stop.
        // A position-only carry should issue NO velocity command of its own.
        const float speed=frame<30?2.0f:frame<60?2.0f*(60-frame)/30.0f:0.0f;
        c.speed[0]=speed; c.speed[1]=0;
        c.live[0]+=speed/60; expectedX+=speed/60;
        require(st::offsetFloeRider(c,{0,0,frame%2?0.25f:-0.25f},70,&stats),"normal carry rejected");
        near(c.speed[0],speed,"native braking replaced with old walking speed");
        near(c.live[0],expectedX,"vertical bobbing introduced horizontal movement");
    }
    require(c.restores==0 && stats.velocityRepairs==0 && stats.offsets==120,"unchanged velocity was redundantly reissued");
    near(c.speed[3],143,"metadata-only velocity change was overwritten");
    c.clearsVelocity=true; c.speed={3,0,0,23};
    require(st::offsetFloeRider(c,{0,0,0.25f},70,&stats),"repair case rejected");
    require(stats.velocityRepairs==1 && c.restores==1,"actual velocity loss not repaired exactly once");
    near(stats.maxVelocityChange,3,"velocity diagnostic did not capture observed change");
    near(c.speed[0],3,"velocity lost during position change");
}
void riderLocalPrecision() {
    st::FloeRiderTransform from,to;
    from.position={114688,139264,-14000}; from.rotation=st::floeTiltRotation({0,{0.04f,0.015f}});
    from.scale=1.5f; to=from;
    const std::array<float,3> feet{115200,139392,-13952};
    require(st::floeRiderDelta(feet,from,to)==std::array<float,3>{},"stationary tilted floe caused phantom carry");
    to.position[2]+=0.125f;
    require(st::floeRiderDelta(feet,from,to)==std::array<float,3>{0,0,0.125f},"pure heave caused lateral drift at world coordinates");
    to.rotation=st::floeTiltRotation({0,{0.0400001f,0.0150002f}});
    const auto worldDelta=st::floeRiderDelta(feet,from,to);
    from.position={0,0,0}; to.position={0,0,0.125f};
    const auto localDelta=st::floeRiderDelta({512,128,48},from,to);
    for (unsigned i=0;i<3;++i) near(worldDelta[i],localDelta[i],"carry depends on distance from world origin",1e-7f);
    require(std::abs(localDelta[0])+std::abs(localDelta[1])>0,"tiny real tilt incorrectly removed");
    from={}; to={}; to.scale=2;
    require(st::floeRiderDelta({1,2,3},from,to)==std::array<float,3>{1,2,3},"local scale conversion wrong");
    from.scale=0;
    require(!std::isfinite(st::floeRiderDelta(feet,from,to)[0]),"invalid transform entered carry");
}
void riderTakeoffTransitions() {
    st::FloeRiderTakeoff player,npc;
    require(player.allow(0,true,false,false),"ordinary standing unexpectedly detached");
    require(!player.allow(0.01,true,false,true),"jump request waited for current airborne state");
    require(npc.allow(0.01,true,false,false),"another rider's jump stopped this rider");
    require(!player.allow(0.1,true,false,false),"stale ground state immediately reattached takeoff");
    require(!player.allow(0.2,false,true,false),"pending controller jump was carried");
    require(!player.allow(0.3,false,false,false),"airborne rider was carried");
    require(!player.allow(0.5,true,false,false),"first landing contact immediately reattached");
    require(!player.allow(0.53,false,false,false),"unsupported landing gap was carried");
    require(!player.allow(0.57,true,false,false),"landing guard ended too early");
    require(player.allow(0.61,true,false,false),"brief contact gap prevented landing recovery");
    require(!player.suspended,"landing did not clear release state");
    require(!npc.allow(1,true,true,false),"NPC pending jump ignored without player input");
    require(!npc.allow(1.3,true,false,false),"landing grace missing");
    require(!npc.allow(1.5,false,false,false),"long unsupported interval accepted");
    require(!npc.allow(1.6,true,false,false),"long gap reused old landing history");
    require(!npc.allow(1.65,true,false,false),"landing history counted an airborne interval");
    require(npc.allow(1.72,true,false,false),"valid landing did not recover");
    st::FloeRiderTakeoff cancelled;
    require(!cancelled.allow(2,true,false,true),"request did not release");
    require(!cancelled.allow(2.26,true,false,false),"cancelled jump bypassed landing confirmation");
    require(cancelled.allow(2.37,true,false,false),"rejected jump permanently disabled carry");
    require(!cancelled.allow(std::numeric_limits<double>::quiet_NaN(),true,false,false),"invalid time accepted");
}
void riderJumpImpulseSurvives() {
    MovingRider c; st::FloeRiderTakeoff gate;
    c.speed={0,0,5,23}; const auto velocity=c.speed; const float start=c.live[2];
    // The engine has accepted input, but support/current-state reporting can
    // lag. A carry setter deliberately clearing velocity must never run here.
    for (unsigned frame=0;frame<30;++frame) {
        const double time=frame/60.0;
        c.live[2]+=c.speed[2]/60;
        const bool allowed=gate.allow(time,frame<3,frame>=2 && frame<8,frame==0);
        if (allowed) st::offsetFloeRider(c,{0,0,-0.5f},70);
    }
    require(c.moves==0 && c.restores==0,"rider carry touched controller during jump");
    require(c.speed==velocity,"takeoff impulse changed");
    near(c.live[2],start+2.5f,"jump ascent was cancelled",0.0001f);
    require(!gate.allow(0.6,true,false,false),"first landing sample carried rider");
    require(gate.allow(0.82,true,false,false)==false,"overlong contact gap counted as stable landing");
    require(gate.allow(0.88,true,false,false)==false,"landing confirmation too short");
    require(gate.allow(0.94,true,false,false),"carry did not resume after landing");
    c.speed={0,0,0,23};
    require(st::offsetFloeRider(c,{0,0,0.5f},70),"standing carry not restored after jump");
}
void independentFloeTargets() {
    Fixture f; f.plane(10,0.025f,0);
    std::array<st::FloeCrestTarget,3> targets{};
    for (unsigned i=0;i<3;++i) {
        auto p=f.footprint(); p.center.x=-60+60*static_cast<float>(i); p.halfExtent={20,20}; p.yawRadians=0.2f*static_cast<float>(i);
        targets[i]=st::fitFloeCrestTarget(f.field,p,{},1,4);
        require(targets[i].target.valid,"independent floe footprint rejected");
    }
    require(targets[0].target.pose.heave<targets[1].target.pose.heave && targets[1].target.pose.heave<targets[2].target.pose.heave,"nearby placements share one pose instead of their local water");
    near(targets[0].target.pose.slope.x,0.025f,"first floe tilt altered by another placement");
    near(targets[2].target.pose.slope.x,0.025f,"rotated floe tilt is not in world coordinates");
}
void marshSceneGuards() {
    using namespace st::foam;
    const int attached=modelProfile("landscape/ice/frozenmarshicefloel01.nif");
    const int frost=modelProfile("landscape/ice/frozenmarshicefloefrosts02.nif");
    require(attached>=5 && frost>=5,"marsh profiles missing");
    require(sceneComplete(attached,true,1,2,false),"complete attached scene rejected");
    require(!sceneComplete(attached,false,1,1,false),"missing solid anchor accepted");
    require(!sceneComplete(attached,true,0,2,false),"missing decal accepted");
    require(sceneComplete(frost,false,1,1,false),"reviewed standalone frost rejected");
    require(!sceneComplete(frost,true,1,2,false),"extra geometry in standalone frost accepted");
    require(!sceneComplete(frost,false,1,1,true),"collision/controller on standalone root accepted");
    require(!sceneComplete(frost,false,0,1,false),"unmatched standalone shape accepted");
    require(!sceneComplete(-1,true,1,1,false),"unknown profile accepted");
    for (int i=5;i<int(profiles.size());++i) {
        const auto& p=profiles[i];
        require(p.iceDecal,"marsh filter tied to wrong toggle");
        require(shapeSlot(i,p.shapes[0],false,p.source,p.greyscale,false,false)==0,"reviewed marsh decal missed");
        require(shapeSlot(i,p.shapes[0],false,"landscape/frozenmarshice01.dds",p.greyscale,false,false)<0,"solid material matched");
        require(shapeSlot(i,p.shapes[0],true,p.source,p.greyscale,false,false)<0,"wrong shader family matched");
        require(shapeSlot(i,p.shapes[0],false,p.source,p.greyscale,true,false)<0,"collision shape matched");
        require(shapeSlot(i,p.shapes[0],false,p.source,p.greyscale,false,true)<0,"controlled shape matched");
    }
}
}
int main() {
    const std::pair<const char*,std::function<void()>> tests[]{
        {"reviewed ice profile",iceSelection},{"Frozen Marsh scene and material guards",marshSceneGuards},{"shader-equivalent height sampling",sampling},
        {"wet interpolation and patch edge",wetAndEdge},{"invalid/different water fields",rejectedFields},
        {"yaw-aware rigid plane fit",planeFit},{"footprint averaging and motion limits",averagingAndLimits},
        {"time-based response and pause",response},{"real solver field to floe target",actualSimulation},
        {"rigid tilt matches surface normal",rigidTilt},{"bounded floe point travel",boundedTravel},
        {"dense interior crest clearance",crestClearance},{"cancelling waves retain crest lift",cancellingCrests},
        {"clearance rest and hard limits",crestRestAndBounds},{"crest rejection and live tuning",crestRejectionsAndTuning},
        {"fleet model coverage and spatial bounds",fleetProfilesAndBounds},{"bounded fair fleet refreshes",fleetRefreshFairness},
        {"independent placement targets",independentFloeTargets},
        {"walking survives additive floe carry",riderLocomotion},{"rider carry mutation guards",riderCarryGuards},
        {"native rider braking avoids velocity writes",riderNaturalBraking},{"rider carry precision far from origin",riderLocalPrecision},
        {"early takeoff and stable landing transitions",riderTakeoffTransitions},{"jump impulse survives stale support",riderJumpImpulseSurvives}};
    int failed=0;
    for (const auto& [name,test] : tests) {
        try { test(); std::cout << "PASS " << name << '\n'; }
        catch (const std::exception& e) { ++failed; std::cerr << "FAIL " << name << ": " << e.what() << '\n'; }
    }
    std::cout << std::size(tests)-failed << '/' << std::size(tests) << " passed\n";
    return failed ? 1 : 0;
}
