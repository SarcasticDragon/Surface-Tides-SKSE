// SPDX-License-Identifier: GPL-3.0-or-later
// SurfaceTides-authored geometry preparation. No renderer implementation code.
// Output remains LOCAL position/UV/color, for the original downstream VS/HS/DS/PS.
#include "FrameBuffer.hlsli"
#include "SurfaceField.hlsli"
#include "EngineVS.hlsli"
#ifndef ST_MESH_MAX_FACTOR
#define ST_MESH_MAX_FACTOR 8
#endif
struct SourceVertex {
    float3 position : POSITION0;
#ifdef ST_MESH_UV
    float2 uv : TEXCOORD0;
#endif
#ifdef ST_MESH_COLOR
    float4 color : COLOR0;
#endif
};
struct MeshVertex {
    float4 position : POSITION0;
    float2 uv : TEXCOORD0;
    float4 color : COLOR0;
#ifdef ST_MESH_HISTORY
    float4 previousWorld : POSITION1;
#endif
};
struct Factors { float edge[3] : SV_TessFactor; float inside : SV_InsideTessFactor; };
#ifdef MESH_VS
MeshVertex main(SourceVertex v) {
    MeshVertex o;
    o.position=float4(v.position,1);
    o.uv=0;
    o.color=1;
#ifdef ST_MESH_HISTORY
    o.previousWorld=0;
#endif
#ifdef ST_MESH_UV
    o.uv=v.uv;
#endif
#ifdef ST_MESH_COLOR
    o.color=v.color;
#endif
    return o;
}
#endif
#ifdef MESH_HS
float EdgeFactor(float3 a, float3 b) {
    // Edge-only decisions give both neighbours the same subdivision points.
    float2 lo=min(a.xy,b.xy), hi=max(a.xy,b.xy);
    float2 fieldEnd=STPatch.xy+(STOptions.x-1)*STPatch.z;
    if (any(hi<STPatch.xy) || any(lo>fieldEnd)) return 1;
    if (min(a.z,b.z)>STPatch.w+STStatus.w || max(a.z,b.z)<STPatch.w-STStatus.w) return 1;
    return clamp(ceil(length(a-b)/max(4,STDebug.y)),1,ST_MESH_MAX_FACTOR);
}
Factors PatchFactors(InputPatch<MeshVertex,3> p) {
    float3 a=mul(World,p[0].position).xyz+CameraPosAdjust[0].xyz;
    float3 b=mul(World,p[1].position).xyz+CameraPosAdjust[0].xyz;
    float3 c=mul(World,p[2].position).xyz+CameraPosAdjust[0].xyz;
    Factors f;
    f.edge[0]=EdgeFactor(b,c); f.edge[1]=EdgeFactor(c,a); f.edge[2]=EdgeFactor(a,b);
    // Interior can intersect the field even when all edges miss it.
    float2 lo=min(a.xy,min(b.xy,c.xy)), hi=max(a.xy,max(b.xy,c.xy));
    bool overlaps=all(hi>=STPatch.xy)&&all(lo<=STPatch.xy+(STOptions.x-1)*STPatch.z);
    overlaps=overlaps && min(a.z,min(b.z,c.z))<=STPatch.w+STStatus.w &&
        max(a.z,max(b.z,c.z))>=STPatch.w-STStatus.w;
    float longest=max(length(a-b),max(length(b-c),length(c-a)));
    // Do not force the maximum for small/already detailed triangles. Large triangles
    // enclosing the field still receive interior detail even when their edges miss.
    float interior=clamp(ceil(longest/max(4,STDebug.y)),1,ST_MESH_MAX_FACTOR);
    f.inside=max(max(f.edge[0],max(f.edge[1],f.edge[2])),overlaps ? interior : 1);
    return f;
}
[domain("tri")][partitioning("integer")][outputtopology("triangle_cw")]
[outputcontrolpoints(3)][patchconstantfunc("PatchFactors")][maxtessfactor(ST_MESH_MAX_FACTOR)]
MeshVertex main(InputPatch<MeshVertex,3> p,uint i:SV_OutputControlPointID) { return p[i]; }
#endif
#ifdef MESH_DS
[domain("tri")]
MeshVertex main(Factors f,float3 b:SV_DomainLocation,const OutputPatch<MeshVertex,3> p) {
    MeshVertex o;
    o.position=p[0].position*b.x+p[1].position*b.y+p[2].position*b.z;
    o.uv=p[0].uv*b.x+p[1].uv*b.y+p[2].uv*b.z;
    o.color=p[0].color*b.x+p[1].color*b.y+p[2].color*b.z;
#ifdef ST_MESH_HISTORY
    o.previousWorld=mul(PreviousWorld,float4(o.position.xyz,1));
    float3 previousAbsolute=o.previousWorld.xyz+CameraPreviousPosAdjust[0].xyz;
    o.previousWorld.z+=STHeight(previousAbsolute,true);
#endif
    float3 world=mul(World,float4(o.position.xyz,1)).xyz+CameraPosAdjust[0].xyz;
    o.position.xyz+=STWorldToLocalOffset(World,float3(0,0,STHeight(world,false)));
    return o;
}
#endif
#ifdef MESH_GS
[maxvertexcount(3)]
void main(triangle MeshVertex p[3],inout TriangleStream<MeshVertex> output) {
    output.Append(p[0]); output.Append(p[1]); output.Append(p[2]); output.RestartStrip();
}
#endif

#ifdef MESH_MOTION_VS
// Original-game stencil output contract, validated against game signature metadata.
// Only the stencil VS is changed; ENB color/tessellation shaders remain intact.
struct MotionOutput {
    float4 position : SV_POSITION0;
    float4 world : POSITION1;
    float4 previousWorld : POSITION2;
};
struct MotionInput { float4 position : POSITION0; float4 previousWorld : POSITION1; };
MotionOutput main(MotionInput v) {
    MotionOutput o;
    o.position=mul(WorldViewProj,float4(v.position.xyz,1));
    o.position.z+=0.5*min(max(o.position.z-70000,0)/10000,1);
    o.world=mul(World,float4(v.position.xyz,1));
    o.previousWorld=v.previousWorld;
    return o;
}
#endif
