// SPDX-License-Identifier: GPL-3.0-or-later
#ifdef VSHADER
VS_OUTPUT main(VS_INPUT input) { return EvaluateWater(input); }
#endif

#ifdef CONTROL_SHADER
VS_INPUT main(VS_INPUT input) { input.Position.w = 1; return input; }
#endif

#ifdef HSHADER
struct STFactors { float edges[3] : SV_TessFactor; float inside : SV_InsideTessFactor; };
float STEdge(VS_INPUT a, VS_INPUT b)
{
    float3 wa = mul(World, float4(a.Position.xyz, 1)).xyz + CameraPosAdjust[0].xyz;
    float3 wb = mul(World, float4(b.Position.xyz, 1)).xyz + CameraPosAdjust[0].xyz;
    float2 center = STPatch.xy + 0.5 * (STOptions.x - 1) * STPatch.z;
    float2 ab = wb.xy - wa.xy;
    float t = saturate(dot(center - wa.xy, ab) / max(1, dot(ab,ab)));
    float distanceToPatch = length(wa.xy + t * ab - center);
    float influence = 1 - smoothstep(0.72, 0.95, distanceToPatch / (STOptions.x * STPatch.z));
    float detail = clamp(ceil(length(wb - wa) / max(8, STDebug.y)), 1, STOptions.w);
    return max(1, ceil(lerp(1, detail, influence * STStatus.x)));
}
STFactors STPatchConstants(InputPatch<VS_INPUT,3> p)
{
    STFactors f;
    // Each shared edge depends only on its endpoints. Reversing edge order is symmetric.
    f.edges[0] = STEdge(p[1],p[2]);
    f.edges[1] = STEdge(p[2],p[0]);
    f.edges[2] = STEdge(p[0],p[1]);
    f.inside = max(f.edges[0],max(f.edges[1],f.edges[2]));
    // Large native triangles may surround the local patch with all edges distant.
    // Edge-only factors cannot detect that case. Subdivide their interior too.
    float2 a = (mul(World,float4(p[0].Position.xyz,1)).xyz + CameraPosAdjust[0].xyz).xy;
    float2 b = (mul(World,float4(p[1].Position.xyz,1)).xyz + CameraPosAdjust[0].xyz).xy;
    float2 c = (mul(World,float4(p[2].Position.xyz,1)).xyz + CameraPosAdjust[0].xyz).xy;
    float2 center = STPatch.xy + 0.5 * (STOptions.x - 1) * STPatch.z;
    float2 ab = b-a, bc = c-b, ca = a-c;
    float2 acenter = center-a, bcenter = center-b, ccenter = center-c;
    float sa = ab.x * acenter.y - ab.y * acenter.x;
    float sb = bc.x * bcenter.y - bc.y * bcenter.x;
    float sc = ca.x * ccenter.y - ca.y * ccenter.x;
    float area = ab.x * (c.y-a.y) - ab.y * (c.x-a.x);
    bool contains = abs(area) > 1e-5 && ((sa >= 0 && sb >= 0 && sc >= 0) || (sa <= 0 && sb <= 0 && sc <= 0));
    if (contains && STStatus.x > 0) {
        float longest = max(length(ab),max(length(bc),length(ca)));
        f.inside = max(f.inside,clamp(ceil(longest / max(8,STDebug.y)),1,STOptions.w));
    }
    return f;
}
[domain("tri")]
[partitioning("integer")]
[outputtopology("triangle_cw")]
[outputcontrolpoints(3)]
[patchconstantfunc("STPatchConstants")]
[maxtessfactor(64)]
VS_INPUT main(InputPatch<VS_INPUT,3> p, uint i : SV_OutputControlPointID) { return p[i]; }
#endif

#ifdef DSHADER
struct STFactors { float edges[3] : SV_TessFactor; float inside : SV_InsideTessFactor; };
[domain("tri")]
VS_OUTPUT main(STFactors factors, float3 bary : SV_DomainLocation, const OutputPatch<VS_INPUT,3> p)
{
    VS_INPUT input = (VS_INPUT)0;
    input.Position = p[0].Position * bary.x + p[1].Position * bary.y + p[2].Position * bary.z;
#if defined(NORMAL_TEXCOORD) && !defined(LOD)
    input.TexCoord0 = p[0].TexCoord0 * bary.x + p[1].TexCoord0 * bary.y + p[2].TexCoord0 * bary.z;
#endif
#ifdef VC
    input.Color = p[0].Color * bary.x + p[1].Color * bary.y + p[2].Color * bary.z;
#endif
    return EvaluateWater(input);
}
#endif
