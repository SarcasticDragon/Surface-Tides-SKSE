// SPDX-License-Identifier: GPL-3.0-or-later
Texture2D<float4> STCurrent : register(t96);
Texture2D<float4> STPrevious : register(t97);
SamplerState STLinearClamp : register(s15);
cbuffer STSurface : register(b11)
{
    float4 STPatch;       // origin xy, spacing, rest height
    float4 STPreviousPatch;
    float4 STOptions;     // resolution, normal strength, displacement strength, maximum tessellation
    float4 STStatus;      // enabled, history valid, edge fade cells, water-height tolerance
    float4 STDebug;       // x: diagnostic color overlay, y: target tessellation edge length
};

float4 STSample(float3 world, bool previous)
{
    float4 patch = previous ? STPreviousPatch : STPatch;
    float2 grid = (world.xy - patch.xy) / patch.z;
    float inside = all(grid >= 0) && all(grid <= STOptions.x - 1);
    // A single rest-height band prevents transfer to bridges, waterfalls, or another lake level.
    float sameLevel = abs(world.z - patch.w) < STStatus.w;
    float edge = min(min(grid.x, grid.y), min(STOptions.x - 1 - grid.x, STOptions.x - 1 - grid.y));
    float fade = smoothstep(0, max(1, STStatus.z), edge) * inside * sameLevel * STStatus.x;
    if (previous) fade *= STStatus.y;
    float2 uv = (grid + 0.5) / STOptions.x; // field samples are cell centers, not texture edges
    float4 v = previous ? STPrevious.SampleLevel(STLinearClamp, uv, 0) : STCurrent.SampleLevel(STLinearClamp, uv, 0);
    v.xyz *= fade * v.w;
    return v;
}
float STHeight(float3 world, bool previous) { return STSample(world, previous).x * STOptions.z; }

float3 STWorldToLocalOffset(row_major float4x4 m, float3 v)
{
    float3 a = float3(m[0][0], m[1][0], m[2][0]);
    float3 b = float3(m[0][1], m[1][1], m[2][1]);
    float3 c = float3(m[0][2], m[1][2], m[2][2]);
    float determinant = dot(a, cross(b,c));
    if (abs(determinant) < 1e-8) return 0;
    return float3(dot(v,cross(b,c)), dot(v,cross(c,a)), dot(v,cross(a,b))) / determinant;
}

float3 STDiagnosticColor(float3 world)
{
    float2 grid = (world.xy - STPatch.xy) / STPatch.z;
    if (!all(grid >= 0) || !all(grid <= STOptions.x - 1)) return float3(1,0,1);
    if (!(abs(world.z - STPatch.w) < STStatus.w)) return float3(1,0.25,0);
    float4 value = STCurrent.SampleLevel(STLinearClamp,(grid + 0.5) / STOptions.x,0);
    if (value.w < 0.5) return float3(0,0.15,1);
    return lerp(float3(0,0.8,0),float3(1,1,1),saturate(abs(value.x) / 2));
}
