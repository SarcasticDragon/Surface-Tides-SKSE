#include "surfacetides/NativeWaterCapture.hpp"
#include <array>
#include <iostream>
#include <thread>
#include <mutex>
#include <vector>

namespace {
int checks{};
void require(bool yes) { ++checks;if (!yes) throw std::runtime_error("capture check "+std::to_string(checks)); }
auto mode(std::initializer_list<std::string_view> names) {
    return st::nativeCaptureMode([&](std::string_view name){
        for (auto value:names) if (value==name) return true;return false;
    });
}
}
int main() {
    const auto vertex=mode({"VSHADER","SPECULAR","NORMAL_TEXCOORD","VC"});
    const auto color=mode({"PSHADER","SPECULAR"});
    const auto stencil=mode({"PSHADER","STENCIL"});
    require(vertex && st::nativeModeBits(*vertex)==13);
    require(color && st::nativeModeBits(*color)==0);
    require(stencil && st::nativeModeBits(*stencil)==2);
    require(bool(mode({"VSHADER","SIMPLE"})));
    require(bool(mode({"PSHADER","UNDERWATER"})));
    require(!mode({"VSHADER","SPECULAR","LOD"}));
    require(!mode({"PSHADER","STENCIL","VR"}));
    require(!mode({"VSHADER","SPECULAR","UNDERWATERMASK"}));
    require(!mode({"CSHADER","SPECULAR"}));
    require(!mode({"SPECULAR"}));
    require(!mode({"PSHADER","VSHADER","SPECULAR"}));
    require(!mode({"VSHADER"}));
    require(st::nativeCaptureText(std::string_view("abc\0\0",5))=="abc");
    require(st::nativeCaptureText(std::string_view("a\0b\0",4))==std::string_view("a\0b",3));
    require(st::nativeCaptureText({}).empty());
    st::NativeWaterSnapshots registry(2);
    require(registry.observe("vertex-source",*vertex));
    require(registry.observe("color-source",*color));
    // Callbacks may interleave and compilation may occur on another worker.
    require(bool(registry.find("color-source",false)));
    require(bool(registry.find("vertex-source",true)));
    require(!registry.find("color-source",true));
    require(!registry.find("unknown-source",false));
    require(registry.observe("vertex-source",*vertex));
    require(!registry.observe("over-budget",*stencil));
    require(bool(registry.find("vertex-source",true)));
    require(!registry.observe("color-source",*stencil));
    require(!registry.find("color-source",false));
    require(!registry.observe("color-source",*color));
    require(!registry.find("color-source",false));
    // Match NativeOS's locking discipline with distinct worker lifetimes.
    st::NativeWaterSnapshots workers;std::mutex lock;
    std::thread preprocess([&]{std::lock_guard guard(lock);workers.observe("same-bytes",*vertex);});
    preprocess.join();bool recovered=false;
    std::thread compile([&]{std::lock_guard guard(lock);recovered=bool(workers.find("same-bytes",true));});
    compile.join();require(recovered);
    std::cout<<checks<<" native OS capture checks passed\n";
}
