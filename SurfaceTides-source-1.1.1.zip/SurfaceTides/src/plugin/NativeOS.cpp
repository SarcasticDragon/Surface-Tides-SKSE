#include "NativeOS.hpp"
#include "Bridge.hpp"
#include "surfacetides/NativeWaterSource.hpp"
#include "surfacetides/NativeWaterCapture.hpp"
#include "surfacetides/NativeWaterReadiness.hpp"
#include "surfacetides/ShaderCacheData.hpp"
#include <MinHook.h>
#include <map>
#include <set>

namespace st::plugin::nativeOS {
namespace {
constexpr GUID tagGUID{0xd8d860af,0xabcb,0x4e30,{0x92,0x66,0x10,0x38,0x28,0xea,0x78,0xd1}};
constexpr UINT flags=D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3;
struct Recipe { st::NativeWaterMode mode; std::string source; UINT flags1=flags, flags2{}; };
std::mutex mutex,ioMutex;
std::map<std::string,std::shared_ptr<Recipe>> recipes;
std::map<std::string,std::shared_ptr<Stage>> stages;
std::set<std::string> missing;
st::NativeWaterSnapshots snapshots;
std::filesystem::path cacheRoot;
std::string field;
std::string compilerStamp;
ComPtr<ID3D11Device> hookedDevice;
std::atomic<bool> observerReady{};
thread_local bool creating{};
thread_local unsigned fileCompileDepth{};
std::atomic<std::uint64_t> captured{},recipeHits{},bytecodeHits{},compiled{},tagged{},failures{},misses{};
std::atomic<std::uint64_t> fileCaptures{},memoryCaptures{},stripAliases{},snapshotCount{},snapshotRejected{},memoryUnmatched{};
st::NativeWaterReadiness readiness;
using CompileFn=decltype(&D3DCompileFromFile);
CompileFn originalCompile{};
using PreprocessFn=decltype(&D3DPreprocess);
using MemoryCompileFn=decltype(&D3DCompile);
using StripFn=decltype(&D3DStripShader);
PreprocessFn originalPreprocess{};MemoryCompileFn originalMemoryCompile{};StripFn originalStrip{};
using CreateDeviceFn=decltype(&D3D11CreateDeviceAndSwapChain);
CreateDeviceFn originalDevice{};
using VSFn=HRESULT (STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11VertexShader**);
using PSFn=HRESULT (STDMETHODCALLTYPE*)(ID3D11Device*,const void*,SIZE_T,ID3D11ClassLinkage*,ID3D11PixelShader**);
VSFn originalVS{};PSFn originalPS{};
std::span<const std::uint8_t> bytes(const void* p,std::size_t n) { return {static_cast<const std::uint8_t*>(p),n}; }
std::vector<std::uint8_t> read(const std::filesystem::path& p,std::size_t limit=st::maxShaderBytes+st::cacheHeaderBytes) {
    std::ifstream f(p,std::ios::binary|std::ios::ate);
    if (!f) return {};
    const auto size=f.tellg();
    if (size<=0 || static_cast<std::uint64_t>(size)>limit) return {};
    std::vector<std::uint8_t> b(static_cast<std::size_t>(size));f.seekg(0);
    if (!f.read(reinterpret_cast<char*>(b.data()),static_cast<std::streamsize>(b.size()))) return {};
    return b;
}
void save(const std::filesystem::path& p,const st::Digest& key,std::span<const std::uint8_t> b) {
    if (!config.shaderCache || cacheRoot.empty()) return;
    // Only this ST-owned directory is written. Never touch Data/ShaderCache.
    std::lock_guard lock(ioMutex);
    const auto data=st::encodeShaderCache(key,b);
    if (data.empty()) return;
    std::error_code error;
    if (!std::filesystem::exists(p,error)) {
        std::uintmax_t total=0;std::size_t count=0;
        for (const auto& entry:std::filesystem::directory_iterator(cacheRoot,error)) if (entry.is_regular_file(error)) {
            total+=entry.file_size(error);++count;
        }
        if (count>=1024 || total+data.size()>256ull*1024*1024) return;
    }
    auto tmp=p;tmp+=L".tmp";
    { std::ofstream f(tmp,std::ios::binary|std::ios::trunc);
      f.write(reinterpret_cast<const char*>(data.data()),static_cast<std::streamsize>(data.size()));
      if (!f) return; }
    if (!MoveFileExW(tmp.c_str(),p.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))
        std::filesystem::remove(tmp,error);
}
ComPtr<ID3D11ShaderReflection> reflection(const void* data,std::size_t size) {
    ComPtr<ID3D11ShaderReflection> r;check(D3DReflect(data,size,IID_PPV_ARGS(&r)),"Native OS shader reflection");return r;
}
void validateOriginal(const void* data,std::size_t size,bool vertex) {
    const auto r=reflection(data,size);D3D11_SHADER_DESC d{};check(r->GetDesc(&d),"Native OS shader description");
    for (UINT i=0;i<d.BoundResources;++i) {
        D3D11_SHADER_INPUT_BIND_DESC b{};check(r->GetResourceBindingDesc(i,&b),"Native OS binding");
        const bool cb=b.Type==D3D_SIT_CBUFFER;
        const bool sampler=b.Type==D3D_SIT_SAMPLER;
        const bool collision=cb ? b.BindPoint<=11 && b.BindPoint+b.BindCount>11 :
            sampler ? b.BindPoint<=15 && b.BindPoint+b.BindCount>15 :
            b.BindPoint<=97 && b.BindPoint+b.BindCount>96;
        if (collision || (vertex && !cb)) throw std::runtime_error("OS shader resource contract unsupported");
    }
}
void validateInputs(const void* original,std::size_t size,ID3DBlob* augmented) {
    const auto a=reflection(original,size),b=reflection(augmented->GetBufferPointer(),augmented->GetBufferSize());
    D3D11_SHADER_DESC ad{},bd{};a->GetDesc(&ad);b->GetDesc(&bd);
    for (UINT i=0;i<bd.InputParameters;++i) {
        D3D11_SIGNATURE_PARAMETER_DESC need{};b->GetInputParameterDesc(i,&need);bool found=false;
        for (UINT j=0;j<ad.InputParameters;++j) {
            D3D11_SIGNATURE_PARAMETER_DESC have{};a->GetInputParameterDesc(j,&have);
            if (!_stricmp(have.SemanticName,need.SemanticName) && have.SemanticIndex==need.SemanticIndex &&
                have.Register==need.Register && have.ComponentType==need.ComponentType &&
                have.SystemValueType==need.SystemValueType && !(need.Mask&~have.Mask)) found=true;
        }
        if (!found) throw std::runtime_error("OS augmented vertex input differs from native input layout");
    }
}
ComPtr<ID3DBlob> buildBlob(const std::string& source,const char* entry,const char* target,UINT flags1,UINT flags2) {
    // Preserve OS compiler policy, adding validation for our modified program.
    flags1 &= ~D3DCOMPILE_SKIP_VALIDATION;
    const auto key=st::shaderCacheKey("NativeOS-2/"+compilerStamp+"/"+std::to_string(flags2),target,entry,source,flags1);
    const auto path=cacheRoot/(st::hexDigest(key)+".stnb");
    ComPtr<ID3DBlob> code,error;
    if (config.shaderCache && !cacheRoot.empty()) {
        const auto stored=read(path);const auto decoded=st::decodeShaderCache(stored,key);
        if (!decoded.empty()) {
            check(D3DCreateBlob(decoded.size(),&code),"Native OS cache blob");
            std::memcpy(code->GetBufferPointer(),decoded.data(),decoded.size());++bytecodeHits;return code;
        }
    }
    const auto hr=D3DCompile(source.data(),source.size(),"SurfaceTides/NativeOS",nullptr,nullptr,entry,target,flags1,flags2,&code,&error);
    if (FAILED(hr)) throw std::runtime_error(std::string(entry)+": "+(error ?
        std::string(static_cast<const char*>(error->GetBufferPointer()),error->GetBufferSize()):"compile failed"));
    ++compiled;save(path,key,bytes(code->GetBufferPointer(),code->GetBufferSize()));return code;
}
std::shared_ptr<Recipe> getRecipe(const st::Digest& key) {
    const auto name=st::hexDigest(key);
    if (auto it=recipes.find(name);it!=recipes.end()) return it->second;
    if (missing.contains(name)) return {};
    if (config.shaderCache && !cacheRoot.empty()) {
        const auto stored=read(cacheRoot/(name+".stnr"));const auto data=st::decodeShaderCache(stored,key);
        if (data.size()>14 && std::memcmp(data.data(),"STNR",4)==0 && data[4]==2 && !(data[5]&~15u)) {
            auto r=std::make_shared<Recipe>();
            r->mode={bool(data[5]&1),bool(data[5]&2),bool(data[5]&4),bool(data[5]&8)};
            r->flags1=r->flags2=0;
            for (unsigned i=0;i<4;++i) { r->flags1|=UINT(data[6+i])<<(8*i);r->flags2|=UINT(data[10+i])<<(8*i); }
            r->source.assign(reinterpret_cast<const char*>(data.data()+14),data.size()-14);
            recipes[name]=r;++recipeHits;return r;
        }
    }
    // Bound negative cache; a subsequent successful compilation removes its key.
    if (missing.size()<16384) missing.insert(name);
    ++misses;return {};
}
std::shared_ptr<Stage> stage(ID3D11Device* device,const void* data,SIZE_T size,bool vertex) {
    if (!observerReady || device!=hookedDevice.Get() || !size || size>st::maxShaderBytes) return {};
    const auto key=st::sha256(bytes(data,size));const auto name=st::hexDigest(key);
    std::lock_guard lock(mutex);
    if (auto it=stages.find(name);it!=stages.end()) return it->second;
    if (stages.size()>=512) return {};
    const auto recipe=getRecipe(key);
    if (!recipe || recipe->mode.vertex!=vertex) return {};
    auto result=std::make_shared<Stage>();result->vertex=vertex;result->stencil=recipe->mode.stencil;
    try {
        validateOriginal(data,size,vertex);
        const auto source=st::augmentNativeWater(recipe->source,field,recipe->mode);
        // Recursive creates are our own parallel objects and must never be tagged.
        struct Scope { Scope(){creating=true;} ~Scope(){creating=false;} } scope;
        if (vertex) {
            auto vs=buildBlob(source,"main","vs_5_0",recipe->flags1,recipe->flags2);validateInputs(data,size,vs.Get());
            auto control=buildBlob(source,"STOSControl","vs_5_0",recipe->flags1,recipe->flags2);validateInputs(data,size,control.Get());
            auto hs=buildBlob(source,"STOSHull","hs_5_0",recipe->flags1,recipe->flags2);auto ds=buildBlob(source,"STOSDomain","ds_5_0",recipe->flags1,recipe->flags2);
            check(device->CreateVertexShader(vs->GetBufferPointer(),vs->GetBufferSize(),nullptr,&result->vs),"Native OS VS");
            check(device->CreateVertexShader(control->GetBufferPointer(),control->GetBufferSize(),nullptr,&result->control),"Native OS control");
            check(device->CreateHullShader(hs->GetBufferPointer(),hs->GetBufferSize(),nullptr,&result->hs),"Native OS HS");
            check(device->CreateDomainShader(ds->GetBufferPointer(),ds->GetBufferSize(),nullptr,&result->ds),"Native OS DS");
        } else {
            auto ps=buildBlob(source,"main","ps_5_0",recipe->flags1,recipe->flags2);
            check(device->CreatePixelShader(ps->GetBufferPointer(),ps->GetBufferSize(),nullptr,&result->ps),"Native OS PS");
        }
        result->valid=true;
        readiness.succeeded(vertex,result->stencil);
        SKSE::log::info("OS native augmented shader ready: stage={} stencil={} sourceKey={}",vertex?"VS":"PS",result->stencil,name.substr(0,12));
    } catch (const std::exception& e) {
        ++failures;readiness.failed();
        SKSE::log::warn("OS native augmentation unavailable: stage={} stencil={} sourceKey={} reason={}; all native ST augmentation disabled for this session, original OS shaders retained",
            vertex?"VS":"PS",result->stencil,name.substr(0,12),e.what());
        if (!vertex && !result->stencil) {
            // Bounded source context distinguishes formatting from an unknown
            // installed shader revision without dumping whole shader recipes.
            const auto pos=recipe->source.find("waterData");
            auto context=pos==std::string::npos ? std::string("waterData token absent") : recipe->source.substr(pos,240);
            for (auto& c:context) if (c=='\r' || c=='\n' || c=='\t') c=' ';
            SKSE::log::warn("OS native rejected normal context: {}",context);
        }
    }
    stages[name]=result;return result;
}
class Tag final:public IUnknown {
public:
    explicit Tag(std::shared_ptr<Stage> s):value(std::move(s)){}
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id,void** p) override {
        if (!p) return E_POINTER;*p=nullptr;
        if (id==IID_IUnknown) { *p=static_cast<IUnknown*>(this);AddRef();return S_OK; }return E_NOINTERFACE;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return ++refs; }
    ULONG STDMETHODCALLTYPE Release() override { const auto n=--refs;if (!n) delete this;return n; }
    std::shared_ptr<Stage> value;
private: std::atomic<ULONG> refs{1};
};
void tag(ID3D11DeviceChild* object,std::shared_ptr<Stage> value) {
    if (!object || !value || !value->valid) return;
    auto* t=new Tag(std::move(value));const auto hr=object->SetPrivateDataInterface(tagGUID,t);t->Release();
    if (SUCCEEDED(hr)) ++tagged;
    else { ++failures;readiness.failed();SKSE::log::warn("OS native shader tagging failed; all native ST augmentation disabled for this session"); }
}
HRESULT STDMETHODCALLTYPE createVS(ID3D11Device* d,const void* b,SIZE_T n,ID3D11ClassLinkage* l,ID3D11VertexShader** out) {
    const auto hr=originalVS(d,b,n,l,out);
    if (SUCCEEDED(hr) && out && *out && !l && !creating) {
        try { tag(*out,stage(d,b,n,true)); } catch (const std::exception& e) { ++failures;readiness.failed();SKSE::log::warn("OS native VS tagging: {}",e.what()); }
    }return hr;
}
HRESULT STDMETHODCALLTYPE createPS(ID3D11Device* d,const void* b,SIZE_T n,ID3D11ClassLinkage* l,ID3D11PixelShader** out) {
    const auto hr=originalPS(d,b,n,l,out);
    if (SUCCEEDED(hr) && out && *out && !l && !creating) {
        try { tag(*out,stage(d,b,n,false)); } catch (const std::exception& e) { ++failures;readiness.failed();SKSE::log::warn("OS native PS tagging: {}",e.what()); }
    }return hr;
}
bool has(const D3D_SHADER_MACRO* defines,const char* name) {
    if (defines) for (unsigned i=0;i<128 && defines[i].Name;++i) if (std::strcmp(defines[i].Name,name)==0) return true;
    return false;
}
bool waterPath(const std::filesystem::path& file) {
    const auto path=std::filesystem::absolute(file).lexically_normal();
    const auto expected=std::filesystem::absolute("Data/Shaders/Water.hlsl").lexically_normal();
    return !_wcsicmp(path.c_str(),expected.c_str());
}
std::optional<st::NativeWaterMode> captureMode(const D3D_SHADER_MACRO* defines) {
    return st::nativeCaptureMode([&](const char* name){return has(defines,name);});
}
bool captureTarget(const char* entry,const char* target) {
    return entry && !std::strcmp(entry,"main") && target &&
        (!std::strcmp(target,"vs_5_0") || !std::strcmp(target,"ps_5_0"));
}
std::string sourceDigest(std::string_view source) {
    return st::hexDigest(st::sha256(bytes(source.data(),source.size())));
}
void captureFailure(const std::exception& error) {
    ++failures;readiness.failed();
    SKSE::log::warn("OS native recipe capture skipped: {}; all native ST augmentation disabled for this session",error.what());
}
bool storeRecipe(ID3DBlob* blob,const std::shared_ptr<Recipe>& recipe) {
    if (!blob || !blob->GetBufferSize() || blob->GetBufferSize()>st::maxShaderBytes) return false;
    const auto key=st::sha256(bytes(blob->GetBufferPointer(),blob->GetBufferSize()));
    const auto name=st::hexDigest(key);
    { std::lock_guard lock(mutex);
      if (recipes.size()>=1024 && !recipes.contains(name)) return false;
      recipes[name]=recipe;missing.erase(name); }
    std::vector<std::uint8_t> payload{'S','T','N','R',2,static_cast<std::uint8_t>(st::nativeModeBits(recipe->mode))};
    for (const UINT f:{recipe->flags1,recipe->flags2}) for (unsigned i=0;i<4;++i) payload.push_back(static_cast<std::uint8_t>(f>>(8*i)));
    payload.insert(payload.end(),recipe->source.begin(),recipe->source.end());
    save(cacheRoot/(name+".stnr"),key,payload);
    return true;
}
HRESULT WINAPI preprocess(LPCVOID source,SIZE_T size,LPCSTR name,const D3D_SHADER_MACRO* defines,
    ID3DInclude* include,ID3DBlob** out,ID3DBlob** errors) {
    const auto hr=originalPreprocess(source,size,name,defines,include,out,errors);
    try {
        if (!observerReady || creating || fileCompileDepth || FAILED(hr) || !out || !*out || !name || !waterPath(name)) return hr;
        const auto mode=captureMode(defines);if (!mode) return hr;
        if ((*out)->GetBufferSize()>st::maxShaderBytes) return hr;
        const auto text=st::nativeCaptureText({static_cast<const char*>((*out)->GetBufferPointer()),(*out)->GetBufferSize()});
        if (text.empty() || text.find("csUtilitySettings")==std::string_view::npos) return hr;
        std::lock_guard lock(mutex);
        if (snapshots.observe(sourceDigest(text),*mode)) ++snapshotCount;
        else ++snapshotRejected;
    } catch (const std::exception& e) { captureFailure(e); }
    return hr;
}
HRESULT WINAPI compileMemory(LPCVOID source,SIZE_T size,LPCSTR name,const D3D_SHADER_MACRO* defines,
    ID3DInclude* include,LPCSTR entry,LPCSTR target,UINT a,UINT b,ID3DBlob** out,ID3DBlob** errors) {
    const auto hr=originalMemoryCompile(source,size,name,defines,include,entry,target,a,b,out,errors);
    try {
        if (!observerReady || creating || fileCompileDepth || FAILED(hr) || !out || !*out ||
            !source || !size || size>st::maxShaderBytes || !name || !waterPath(name) || !captureTarget(entry,target)) return hr;
        // OS 2.18 hands us the exact preprocessed bytes with no macro/include
        // inputs. Anything else needs its own proven provenance, never guessing.
        if ((defines && defines[0].Name) || include) return hr;
        const auto text=st::nativeCaptureText({static_cast<const char*>(source),size});
        std::optional<st::NativeWaterMode> mode;
        { std::lock_guard lock(mutex);mode=snapshots.find(sourceDigest(text),!std::strcmp(target,"vs_5_0")); }
        if (!mode) { ++memoryUnmatched;return hr; }
        auto recipe=std::make_shared<Recipe>();recipe->mode=*mode;recipe->source.assign(text);recipe->flags1=a;recipe->flags2=b;
        if (storeRecipe(*out,recipe)) { ++captured;++memoryCaptures; }
    } catch (const std::exception& e) { captureFailure(e); }
    return hr;
}
HRESULT WINAPI stripShader(LPCVOID source,SIZE_T size,UINT stripFlags,ID3DBlob** out) {
    const auto hr=originalStrip(source,size,stripFlags,out);
    try {
        if (!observerReady || creating || FAILED(hr) || !source || !size || size>st::maxShaderBytes || !out || !*out) return hr;
        const auto key=st::hexDigest(st::sha256(bytes(source,size)));
        std::shared_ptr<Recipe> recipe;
        // Only propagate a recipe already captured in this process. Avoid disk
        // I/O and negative-cache pollution for every unrelated shader strip.
        { std::lock_guard lock(mutex);auto it=recipes.find(key);if (it!=recipes.end()) recipe=it->second; }
        if (recipe && key!=st::hexDigest(st::sha256(bytes((*out)->GetBufferPointer(),(*out)->GetBufferSize()))) && storeRecipe(*out,recipe)) ++stripAliases;
    } catch (const std::exception& e) { captureFailure(e); }
    return hr;
}
HRESULT WINAPI compileFile(LPCWSTR file,const D3D_SHADER_MACRO* defines,ID3DInclude* include,LPCSTR entry,LPCSTR target,
    UINT a,UINT b,ID3DBlob** out,ID3DBlob** errors) {
    struct Scope { Scope(){++fileCompileDepth;} ~Scope(){--fileCompileDepth;} } scope;
    const auto hr=originalCompile(file,defines,include,entry,target,a,b,out,errors);
    // Always return the original blob/HRESULT untouched. Retain the legacy
    // path for OS 2.17 and for OS 2.18's file-compilation fallback.
    try {
        if (!observerReady || creating || FAILED(hr) || !out || !*out || !file || !captureTarget(entry,target) || !waterPath(file)) return hr;
        const auto mode=captureMode(defines);if (!mode || mode->vertex!=(!std::strcmp(target,"vs_5_0"))) return hr;
        const auto path=std::filesystem::absolute(file).lexically_normal();
        auto raw=read(path);if (raw.empty()) return hr;
        ComPtr<ID3DBlob> text,error;
        const auto name=path.string();
        const auto pre=originalPreprocess(raw.data(),raw.size(),name.c_str(),defines,include,&text,&error);
        if (FAILED(pre)) throw std::runtime_error("OS water preprocessing failed; native compilation still returned unchanged");
        const auto processed=st::nativeCaptureText({static_cast<const char*>(text->GetBufferPointer()),text->GetBufferSize()});
        if (processed.find("csUtilitySettings")==std::string_view::npos) return hr;
        auto recipe=std::make_shared<Recipe>();recipe->mode=*mode;recipe->flags1=a;recipe->flags2=b;recipe->source.assign(processed);
        if (storeRecipe(*out,recipe)) { ++captured;++fileCaptures; }
    } catch (const std::exception& e) { captureFailure(e); }
    return hr;
}
template<class T> void hook(void* target,void* replacement,T& original) {
    const auto result=MH_CreateHook(target,replacement,reinterpret_cast<void**>(&original));
    if (result!=MH_OK) throw std::runtime_error(std::string("Native OS hook: ")+MH_StatusToString(result));
    const auto enabled=MH_EnableHook(target);
    if (enabled!=MH_OK) { MH_RemoveHook(target);throw std::runtime_error("Native OS hook enable failed"); }
}
HRESULT WINAPI createDevice(IDXGIAdapter* adapter,D3D_DRIVER_TYPE type,HMODULE software,UINT f,const D3D_FEATURE_LEVEL* levels,UINT count,
    UINT sdk,const DXGI_SWAP_CHAIN_DESC* desc,IDXGISwapChain** chain,ID3D11Device** device,D3D_FEATURE_LEVEL* level,ID3D11DeviceContext** context) {
    const auto hr=originalDevice(adapter,type,software,f,levels,count,sdk,desc,chain,device,level,context);
    if (SUCCEEDED(hr) && device && *device) attachDevice(*device);
    return hr;
}
}
void attachDevice(ID3D11Device* device) {
    if (!observerReady || !device || hookedDevice) return;
    try {
        auto** table=*reinterpret_cast<void***>(device);
        hook(table[12],reinterpret_cast<void*>(&createVS),originalVS);
        try { hook(table[15],reinterpret_cast<void*>(&createPS),originalPS); }
        catch (...) { MH_DisableHook(table[12]);MH_RemoveHook(table[12]);throw; }
        hookedDevice=device;
        SKSE::log::info("OS native shader creation observers installed; original OS objects/cache remain unchanged");
    } catch (const std::exception& e) { ++failures;SKSE::log::warn("OS native device observer unavailable: {}",e.what()); }
}
void installCompilerObserver() {
    if (observerReady || !config.enabled || !config.openShaders || !config.osNativeWater || !GetModuleHandleW(L"CommunityShaders.dll")) return;
    std::vector<void*> installed;
    try {
        const auto source=read("Data/Shaders/SurfaceTides/SurfaceField.hlsli");
        if (source.empty()) throw std::runtime_error("SurfaceField.hlsli missing");
        field.assign(source.begin(),source.end());
        std::array<wchar_t,32768> compilerPath{};
        const auto compilerLength=GetModuleFileNameW(GetModuleHandleW(L"d3dcompiler_47.dll"),compilerPath.data(),static_cast<DWORD>(compilerPath.size()));
        if (compilerLength && compilerLength<compilerPath.size()) {
            const auto compilerBytes=read(std::filesystem::path(std::wstring(compilerPath.data(),compilerLength)),64*1024*1024);
            if (!compilerBytes.empty()) compilerStamp=st::hexDigest(st::sha256(compilerBytes));
        }
        std::array<wchar_t,32768> local{};
        const auto n=GetEnvironmentVariableW(L"LOCALAPPDATA",local.data(),static_cast<DWORD>(local.size()));
        if (n && n<local.size() && config.shaderCache && !compilerStamp.empty()) {
            cacheRoot=std::filesystem::path(std::wstring(local.data(),n))/"SurfaceTides"/"ShaderCache"/"NativeOS-v2";
            std::error_code error;std::filesystem::create_directories(cacheRoot,error);
            if (error) cacheRoot.clear();
        }
        const auto init=MH_Initialize();if (init!=MH_OK && init!=MH_ERROR_ALREADY_INITIALIZED) throw std::runtime_error("MinHook init failed");
        const auto compiler=GetModuleHandleW(L"d3dcompiler_47.dll");
        auto install=[&](const char* name,void* replacement,auto& original) {
            auto* target=GetProcAddress(compiler,name);
            if (!target) throw std::runtime_error(std::string("Microsoft compiler entry unavailable: ")+name);
            hook(reinterpret_cast<void*>(target),replacement,original);installed.push_back(reinterpret_cast<void*>(target));
        };
        installed.reserve(5);
        install("D3DPreprocess",reinterpret_cast<void*>(&preprocess),originalPreprocess);
        install("D3DCompile",reinterpret_cast<void*>(&compileMemory),originalMemoryCompile);
        install("D3DStripShader",reinterpret_cast<void*>(&stripShader),originalStrip);
        install("D3DCompileFromFile",reinterpret_cast<void*>(&compileFile),originalCompile);
        auto* create=GetProcAddress(GetModuleHandleW(L"d3d11.dll"),"D3D11CreateDeviceAndSwapChain");
        if (create) { hook(reinterpret_cast<void*>(create),reinterpret_cast<void*>(&createDevice),originalDevice);installed.push_back(reinterpret_cast<void*>(create)); }
        observerReady=true;
        SKSE::log::info("OS native private cache: enabled={} compilerFingerprint={} path={}",!cacheRoot.empty(),!compilerStamp.empty(),cacheRoot.string());
        SKSE::log::info("OS native Water enabled: passive file+preprocess/memory+strip observers. OS source/settings/cache NEVER written. This build uses NativeOS-v2; request a full OS rebuild with ST loaded, bypassing any OS persistent store for that rebuild.");
    } catch (const std::exception& e) {
        observerReady=false;
        for (auto it=installed.rbegin();it!=installed.rend();++it) { MH_DisableHook(*it);MH_RemoveHook(*it); }
        ++failures;readiness.failed();SKSE::log::warn("OS native observer initialization: {}",e.what());
    }
}
std::shared_ptr<Stage> lookup(ID3D11DeviceChild* object) {
    if (!object) return {};
    // Two retained entries cover repeated VS/PS pairs and repeated non-water VS.
    // Keeping COM references prevents address reuse while an identity is cached.
    struct Identity { ComPtr<ID3D11DeviceChild> object;std::shared_ptr<Stage> stage; };
    thread_local std::array<Identity,2> recent;
    thread_local unsigned next{};
    for (const auto& entry:recent) if (entry.object.Get()==object) return entry.stage;
    IUnknown* unknown{};UINT size=sizeof(unknown);
    std::shared_ptr<Stage> result;
    if (SUCCEEDED(object->GetPrivateData(tagGUID,&size,&unknown)) && unknown) {
        auto* t=static_cast<Tag*>(unknown);result=t->value;t->Release();
    }
    recent[next]={object,result};next=(next+1)%2;return result;
}
void nextFrame() { readiness.nextFrame(); }
bool canRender() { return readiness.canRender(); }
void report() {
    SKSE::log::info("OS native shader totals: captured={} recipeHits={} bytecodeHits={} compiled={} tagged={} misses={} failures={} [misses include non-water; first install needs OS shader rebuild]",
        captured.load(),recipeHits.load(),bytecodeHits.load(),compiled.load(),tagged.load(),misses.load(),failures.load());
    SKSE::log::info("OS native capture paths: file={} memory={} preprocessed={} snapshotRejected={} memoryUnmatched={} stripAliases={} [session totals; memoryUnmatched includes excluded water passes; private NativeOS-v2 cache]",
        fileCaptures.load(),memoryCaptures.load(),snapshotCount.load(),snapshotRejected.load(),memoryUnmatched.load(),stripAliases.load());
    SKSE::log::info("OS native readiness: stages={:X}/F enabled={} failureLatched={} [requires color and stencil VS/PS; activation at frame boundary]",
        readiness.readyStages(),readiness.canRender(),readiness.hasFailure());
}
}
