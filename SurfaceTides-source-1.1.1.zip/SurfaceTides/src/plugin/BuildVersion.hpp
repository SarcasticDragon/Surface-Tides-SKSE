#pragma once

namespace st::plugin {
inline constexpr auto previewName = "1.1.1";
inline constexpr unsigned previewPatch = 1, previewRevision = 0;
}
