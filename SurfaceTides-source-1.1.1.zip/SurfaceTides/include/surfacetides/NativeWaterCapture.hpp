#pragma once
// SPDX-License-Identifier: GPL-3.0-or-later
#include "NativeWaterSource.hpp"
#include <map>
#include <optional>

namespace st {
// Called only after verifying the exact installed Water.hlsl path. Retain the
// preprocessor's mode instead of guessing it from macro-free compiled source.
template<class Has> std::optional<NativeWaterMode> nativeCaptureMode(Has has) {
    if (has("VR") || has("LOD") || has("UNDERWATERMASK")) return {};
    if (!has("SPECULAR") && !has("UNDERWATER") && !has("STENCIL") && !has("SIMPLE")) return {};
    if (has("VSHADER") == has("PSHADER")) return {};
    return NativeWaterMode{has("VSHADER"),has("STENCIL"),has("NORMAL_TEXCOORD"),has("VC")};
}
inline unsigned nativeModeBits(NativeWaterMode mode) {
    return unsigned(mode.vertex)|(unsigned(mode.stencil)<<1)|(unsigned(mode.uv)<<2)|(unsigned(mode.color)<<3);
}
inline std::string_view nativeCaptureText(std::string_view text) {
    while (!text.empty() && text.back()=='\0') text.remove_suffix(1);
    return text;
}
// Source digests can outlive their preprocessing worker. Never pair callbacks by
// thread, pointer identity, or arrival order. Conflicting provenance fails closed.
// NativeOS.cpp supplies synchronization; entries retain no shader source bytes.
class NativeWaterSnapshots {
public:
    explicit NativeWaterSnapshots(std::size_t limit=1024):limit_(limit){}
    bool observe(const std::string& digest,NativeWaterMode mode) {
        auto found=modes_.find(digest);
        if (found!=modes_.end()) {
            if (!found->second || nativeModeBits(*found->second)!=nativeModeBits(mode)) {
                found->second.reset();return false;
            }
            return true;
        }
        if (modes_.size()>=limit_) return false;
        modes_.emplace(digest,mode);return true;
    }
    std::optional<NativeWaterMode> find(const std::string& digest,bool vertex) const {
        auto found=modes_.find(digest);
        if (found==modes_.end() || !found->second || found->second->vertex!=vertex) return {};
        return found->second;
    }
private:
    std::size_t limit_;
    std::map<std::string,std::optional<NativeWaterMode>> modes_;
};
}
