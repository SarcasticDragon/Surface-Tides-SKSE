# Surface Tides 1.1.0 — GOG compatibility test 1

This optional DLL targets **Skyrim Special Edition GOG 1.6.1179**. It contains
the finalized 1.1.0 water implementation with a corrected GOG startup check.
In-game confirmation from a GOG tester is still required.

## Requirements and installation

1. Keep Surface Tides 1.1.0 installed, including its INI and shader files.
2. Use the **GOG build of SKSE 2.2.6** and Address Library data for GOG 1.6.1179
   (`Data/SKSE/Plugins/versionlib-1-6-1179-0.bin`). SKSE downloads:
   https://skse.silverlock.org/
3. Install this optional archive after Surface Tides 1.1.0 and let its
   `SKSE/Plugins/SurfaceTides.dll` overwrite the existing DLL. For manual
   installation, that path is relative to the game's `Data` directory.
4. Launch through GOG SKSE. Keep the existing renderer selection and INI tuning.

This package contains one replacement DLL and documentation/licenses. It does
not replace the INI, shaders, meshes, or FOMOD. Lava prototypes are excluded.
Older GOG runtimes and Steam runtimes are intentionally rejected by this DLL.

## Testing and identification

Check that the save loads without the DLL error, water has its idle motion,
and entering/exiting the water produces wakes. If something fails, provide
`SurfaceTides.log`, `skse64.log`, the game version, and the exact error message.
The expected Surface Tides startup line contains:

```text
SurfaceTides 1.1.0-gog.1, target=GOG 1.6.1179, runtime=1-6-1179-1
```

Logs are normally under `Documents/My Games/Skyrim Special Edition GOG/SKSE`.
The DLL's numeric plugin version is 1.1.0.1, identifying this optional test.

## Cause and validation

SKSE encodes the GOG distribution as the final component of its runtime value:
`0x010649B1` (1.6.1179.1). The released DLL expected `0x010649B0`, so its own
startup guard rejected GOG before initialization. The SKSE metadata and startup
guard now use the GOG value. CommonLib still uses the executable's file version
for Address Library lookup; that filename correctly ends in `-0.bin`.

Reference: https://github.com/ianpatt/skse64/blob/master/skse64_common/skse_version.h

The Windows x64 Release build and PE metadata checks passed. Isolated instruction
emulation of the actual old/new DLLs reproduced the old rejection and verified
the replacement's Query and pre-initialization Load guards (19 cases). The Load
test stops before SKSE::Init; it does not launch the game or test rendering.
Imported DLL dependencies match the released AE16 DLL. Build/test evidence and
the exact code diff are included in the matching source archive.

## Building this target

Use the normal Windows x64 build environment with `ST_RUNTIME=GOG`, for example:

```text
cmake -S . -B build/gog -A x64 -DST_RUNTIME=GOG -DST_BUILD_TESTS=OFF -DST_BUILD_SHADER_TESTS=OFF
cmake --build build/gog --config Release --target SurfaceTides
```

The dedicated profile uses the same pinned pre-1.7 CommonLib and AE structure
layout as the 1.1.0 AE16 build. Rendering, simulation, INIs, shaders, and vendored
dependencies are byte-identical to the finalized 1.1.0 source. The shared AE16
source whitelist is also corrected for future builds; no replacement Steam DLL
or revised FOMOD is distributed with this test.
