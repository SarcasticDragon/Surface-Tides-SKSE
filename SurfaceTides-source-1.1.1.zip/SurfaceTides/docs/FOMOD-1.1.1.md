# Surface Tides 1.1.1 FOMOD authoring

Display version `1.1.1`, machine version `1.1.1.0`. The build combines the
confirmed GOG runtime correction and tested OS 2.18.0 capture implementation.
The lava prototype is excluded; the existing lava/puddle exclusions remain.

## Structure

- Four runtime DLLs: AE16 (Steam 1.6.1170), GOG (1.6.1179), SE (1.5.97),
  and AE17 (1.7.104). GOG uses SKSE's distribution marker 1 in 1.6.1179.1.
  The AE16 binary retains its existing compatible-version list, but the
  installer always supplies the dedicated GOG build for the GOG choice.
- Open Shaders, ENB and Vanilla choices; ENB offers native integration or
  water-off coexistence on its conditional page.
- Four renderer configurations, four foam choices, two ice-decal choices and
  two bobbing choices: 256 selections, 32 complete INIs.
- Five pages, seven groups, 37 conditional file patterns. Each selection
  installs one correct runtime DLL and one complete INI.
- Defaults: Steam AE16, Vanilla, authored foam/ice and static floes. All accepted
  fixes, optimizations and caching/prewarming remain enabled. Timing, detailed
  tracing and debug colors remain off. No INI setting values changed from 1.1.0.

The payload contains seven ST shader/include files, licensing notices and the
optional BOS foam preset. It includes no renderer override, cache, lava addon,
replacement meshes/textures or game plugin.

## Reproduce

Build with `ST_RUNTIME=AE16`, `GOG`, `SE` and `AE17`, using a Windows MSVC
ABI toolchain and the bundled dependencies. The recorded clang-cl toolchain and
four-profile build driver are in `release-1.1.1-evidence`. Portable tests use
`ST_BUILD_PLUGIN=OFF`, `ST_BUILD_TESTS=ON`, `ST_BUILD_SHADER_TESTS=OFF` and CTest.

Run `tools/package_release_111.py` with `--baseline-source` pointing to
`SurfaceTides-source-1.1.0-OS218-FOMOD.zip`, `--dll-dir` containing AE16/GOG/SE/AE17
build directories, and `--output-dir` outside the source tree. Evidence must be
present in `docs/release-1.1.1-evidence`. This verifies successful builds and
runtime declarations, audits the accepted source and unchanged INI values,
generates the installer, validates every selection and writes both archives.
The source ZIP is checked against the user's 25,000,000-byte upload limit.

Read `release-1.1.1-validation.json` for the exact audit, runtime binary hashes,
installer results and limitations. Older packaging scripts describe historical
checkpoints; they are not this release's reproduction entry point.
