# Surface Tides 1.1.1

Maintenance release adding the confirmed GOG loader correction and Open Shaders
2.18.0 support to every runtime build. All 1.1.0 water fixes and performance
improvements are retained. The separate lava
simulation prototype is not included. Reviewed lava and decorative puddles
continue to use their native rendering.

## Install or upgrade

1. Back up custom `SKSE/Plugins/SurfaceTides.ini` tuning and disable older ST test
   overlays, including DLL-only, shader-only and lava-preview installations.
2. Install the FOMOD using MO2 or Vortex and **replace** the old installation.
   Do not merge: deselected optional files must not remain. Remove any obsolete
   ST-owned `SurfaceTides_Global.json` override left by an earlier test.
3. Select the exact Skyrim executable, renderer and optional surface features.
   Each choice installs one matching DLL and a fresh, complete INI. Reapply
   custom tuning selectively; do not overwrite it with an old test INI.
4. Restart Skyrim. Allow compilation to finish on the first uncached water load.

| Skyrim executable | Build | Required separately |
| --- | --- | --- |
| Steam 1.6.1170 | AE16 | Steam SKSE 2.2.6 and AE Address Library |
| GOG 1.6.1179 | GOG | GOG SKSE 2.2.6 and matching GOG AE Address Library |
| 1.5.97 | SE | SKSE 2.0.20 and SE Address Library |
| 1.7.104 | AE17 | SKSE 2.3.1 and matching Address Library v13 |

Other runtimes and VR are unsupported. SKSE Menu Framework 3.x is optional;
the INI works without it. The menu applies live tuning and can save it back to
the INI; settings marked startup-only require a restart.

## Renderer choices

**Open Shaders:** The OS profile sets `OpenShaders=1` and `OSNativeWater=1`.
Keep **Replace Original Shaders → Water ON** in OS. Configure WaterEffects and
Unified Water in OS; the legacy ST feature-matching flags are ignored in native
mode. The updated integration supports OS 2.18.0. On first use or when upgrading
from the original 1.1.0, load ST and use **Advanced Settings → Cache & File
Watcher → Clear Shader Cache** in OS, then allow compilation to finish. Confirm
the full **Clear Shader Cache?** action, not **Clear Active Shaders?**; the latter
does not rebuild the persistent cache. Shift-click switches the clear mode.
If the tested OS 2.18.0 fix is already working, no additional clear is required
solely for updating to 1.1.1.
ST uses private augmented shader copies and caches; it does not write OS source
files, settings or cache. Turning the menu preview off restores native OS water.
To uninstall, remove ST and restart with OS Water replacement still enabled.
The accepted scene-motion workaround remains enabled for frame-generation jitter.

Regular **Community Shaders is incompatible** and blocked by default. Choose
OS only for an actual Open Shaders installation. `BlockCS=0` remains an
unsupported manual bypass for testing.

**ENB:** Recommended within this profile, **ENB water integration** keeps native/ENB water shaders and allows ENB water to remain
enabled. The accepted camera-artifact, ripple-clipping and mid-distance water
fixes are included. No separate ENB patch is needed. The alternative **ENB water
off (coexistence)** uses ST water shading: save `[EFFECT] EnableWater=false` in
`enbseries.ini` beside SkyrimSE.exe, restart, and keep ENB water off in that mode.
ENB presence never disables ST. The installer does not edit ENB settings.
Mixed OS/ENB installations are not established as supported.

**Vanilla:** ST water rendering without a renderer framework. If ENB is present,
this profile selects water-off coexistence; disable ENB water as described above.

## Changes in 1.1.1

- Dedicated GOG 1.6.1179 installer choice with the confirmed SKSE runtime
  identification correction. The GOG DLL also includes the OS 2.18.0 fix.
- Recognizes OS 2.18.0 preprocessed, in-memory water shader compilation while
  preserving the earlier file-based path. Original OS rendering is retained
  until all required ST shader stages are ready.
- Retains the tested private shader-cache version and all 1.1.0 configuration
  values. No lava simulation features are included.

## Retained changes since public Beta 1

- Corrected ENB ripple clipping while preserving mid-distance water tiles and
  the accepted camera-artifact correction. Previously reported underwater
  defects remained absent in the accepted tests.
- Preserved verified nearby water and lingering wakes when actors leave ponds,
  including the Deep Folk Crossing case. Invalid actor water-height reports no
  longer force an inappropriate switch away from verified water.
- Added bounded nearby-water discovery and verified shore-anchor handoff.
  Newly loaded nearby water activates without waiting for a player or NPC to
  enter it; the latest author test confirms this behavior.
- Integrated native Open Shaders Water with corrected refraction, guarded
  activation, working menu on/off behavior and normal OS water after uninstall.
  WaterEffects and Unified Water follow OS's own configuration.
- Retained the accepted OS scene-motion workaround for frame-generation jitter.
- Included renderer CPU work reductions, cached continuous-wind calculations,
  sliced foam/ice-decal discovery, shader caching/prewarming and cache fixes.
  Simulation field size, resolution and visual defaults are unchanged.
- Excluded reviewed Forge lava and decorative WaterPuddle surfaces from ST
  augmentation while leaving ordinary water that shares meshes eligible.
- Retained independent attached/standalone foam options, flat ice-decal removal
  and optional ice-floe bobbing, with fresh full INIs for every installer profile.

## Final INI defaults and limits

All accepted rendering fixes, `OptimizeRenderer`, `OptimizeSimulation`,
`OptimizeDiscovery`, `ShaderCache` and `PrewarmShaders` stay enabled.
`PerformanceTimings=0` removes the beta timing measurements by default; set it
to 1 and restart for performance reports. `LogStats=1` remains enabled. Debug
colors, detailed water-pass tracing and ripple tracing default to 0. The INI,
missing-key fallback and in-memory default agree on the timing setting.

Standalone foam removal requires Base Object Swapper 3.0 or newer. Ice bobbing
remains incompatible with Ice is Slick. Newly loaded foam/ice decals may take
several updates to be discovered. Unknown shader variants may compile on demand;
keep ST's private cache under `%LOCALAPPDATA%\SurfaceTides\ShaderCache` between
normal launches. Native ENB mesh-input shaders retain their existing compilation
path. The deferred water-color investigation is not claimed as fixed. Unreviewed
custom lava or puddle types may require additional identification.

No lava simulation addon, replacement game meshes/textures, ESP, Papyrus script,
renderer preset or cache files are installed. ST does not write save records.

For reports, include `SurfaceTides.log` from the affected launch, the winning
INI, exact runtime/renderer versions, location and a clip for visual problems.
For OS issues include its log. Preserve logs before starting another run.

## Validation

All four Windows DLLs are built from the same combined GOG/OS source with
release metadata `1.1.1.0`. Runtime PE declarations, the FOMOD schema, all
**256 installer selections** and all **32 complete INIs** are checked. Each
selection installs exactly one matching DLL and INI, all seven ST shader/include
files, required notices and the BOS file when selected. Fifteen portable suites
are checked; the tested OS capture, GOG identification, renderer and solver
implementations are preserved unchanged from the accepted source checkpoint.

The GOG correction and OS 2.18.0 fix were confirmed separately in user testing.
Automated checks do not constitute an in-game test of every new DLL/renderer
combination or a mod-manager UI test. The newly combined GOG plus OS build still
benefits from normal post-release runtime testing.
