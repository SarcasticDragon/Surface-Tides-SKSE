# CommonLib 8.1 uses DirectXTK's SimpleMath. Compile that complete upstream
# component; the unused toolkit renderers would require Windows-only FXC.
add_library(SurfaceTidesSimpleMath STATIC vendor/DirectXTK/Src/SimpleMath.cpp)
target_compile_features(SurfaceTidesSimpleMath PUBLIC cxx_std_17)
target_compile_definitions(SurfaceTidesSimpleMath PRIVATE WIN32_LEAN_AND_MEAN NOMINMAX)
target_include_directories(SurfaceTidesSimpleMath PUBLIC
    "$<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/vendor/DirectXTK/Inc>")
add_library(Microsoft::DirectXTK ALIAS SurfaceTidesSimpleMath)
install(TARGETS SurfaceTidesSimpleMath EXPORT CommonLibSSE-targets)
file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/dependency-config/directxtkConfig.cmake"
    "if(NOT TARGET Microsoft::DirectXTK)\n  message(FATAL_ERROR \"Missing SimpleMath target\")\nendif()\n")
set(directxtk_DIR "${CMAKE_CURRENT_BINARY_DIR}/dependency-config" CACHE PATH "Local SimpleMath" FORCE)
set(FETCHCONTENT_SOURCE_DIR_HDE64 "${CMAKE_CURRENT_SOURCE_DIR}/vendor/minhook")
set(COMMONLIB_PREBUILT OFF CACHE BOOL "Build the pinned source" FORCE)
set(COMMONLIB_ENABLE_IPO OFF CACHE BOOL "Match the cross-build toolchain" FORCE)
