#!/usr/bin/env python3
"""Build the complete release FOMOD with exact-runtime DLLs and fresh full INIs."""
import argparse, itertools, re
from pathlib import Path
from xml.etree import ElementTree as ET

VERSION='1.1.0'
MACHINE_VERSION='1.1.0.0'
BINARY_PATCH=0
BINARY_REVISION=0
SCHEMA='http://qconsulting.ca/gemm/ModConfig5.0.xsd'
RUNTIMES=[
    ('Skyrim 1.6.1170 / GOG 1.6.1179','AE16','Requires matching SKSE 2.2.6 and AE Address Library.'),
    ('Skyrim 1.5.97','SE','Requires SKSE 2.0.20 and SE Address Library.'),
    ('Skyrim 1.7.104','AE17','Requires SKSE 2.3.1 and matching Address Library v13.')]
RENDERERS=[
    ('Open Shaders (OS)','os','For an actual Open Shaders installation. Community Shaders is incompatible. Keep Replace Original Shaders > Water ON in OS. Choose WaterEffects and Unified Water normally in OS; ST uses the native OS water shader. First use requires one OS shader-cache rebuild with ST loaded; let compilation finish. This installer does not change OS settings or install renderer overrides.'),
    ('ENB','enb','Select native ENB water integration or the established ENB-water-off coexistence path on the next page. ENB presence never disables Surface Tides. This installer does not change your ENB preset.'),
    ('Vanilla','vanilla','Surface Tides without a renderer framework. No ENB or Open Shaders dependency. If ENB is detected, the water-off coexistence path is used automatically.')]
ENB_MODES=[
    ('ENB water integration','native',1,'Includes the accepted camera-artifact and ripple-clipping corrections. ENB water may remain ON. Also includes the accepted pond water-retention fix. Includes verified nearby-water discovery without actor contact.'),
    ('ENB water off (coexistence)','off',0,'Use ST water while ENB handles the rest of the scene. Save [EFFECT] EnableWater=false in enbseries.ini beside SkyrimSE.exe and restart. Keep ENB water OFF. The installer does not edit this file.')]
FOAM=[
    ('Keep all foam',0,0,'Keep authored foam. Flat foam can intersect the simulated waves.'),
    ('Remove attached foam only',1,0,'Hide reviewed foam shapes attached to rapid rocks. Rock geometry and collision are retained. No Base Object Swapper requirement. Waterfall impact effects stay.'),
    ('Remove standalone foam only (BOS)',0,1,'Requires Base Object Swapper 3.0 or newer, installed separately. Removes the three reviewed standalone foam bases through a BOS preset. Attached rock foam and waterfall impact effects stay.'),
    ('Remove both (BOS)',1,1,'Requires Base Object Swapper 3.0 or newer, installed separately. Remove the three standalone foam bases and hide reviewed attached rock foam. Rocks, collision and waterfall impact effects stay.')]
ICE=[('Keep ice decals',0,'Keep the flat slush around ice floes. It may intersect simulated waves.'),
     ('Remove ice decals',1,'Hide reviewed flat slush shapes in the three original ice-floe models and nine Frozen Marsh models, including standalone frost patches. Solid ice and collision stay. No replacement meshes or blank textures are installed.')]
BOBBING=[('Static ice floes',0,'Leave the solid ice at its authored position. Ice is Slick can remain in use without Surface Tides bobbing.'),
         ('Bobbing ice floes',1,'Move nearby supported solid ice floes with the simulation. Incompatible with Ice is Slick for now. Separate chunks inside one mesh move together. Removing the flat ice decals is recommended with this option.')]

def profiles():
    yield 'vanilla',{'renderer':'vanilla'},0,0,0
    for _,mode,native,_ in ENB_MODES:
        yield 'enb-'+mode,{'renderer':'enb','enb_mode':mode},0,0,native
    yield 'os-native',{'renderer':'os'},0,0,0

def xml_bytes(root):
    ET.indent(root,space='  ')
    # FomodInstaller's encoding rewrite expects double-quoted declarations.
    return b'<?xml version="1.0" encoding="utf-8"?>\n'+ET.tostring(root,encoding='utf-8',xml_declaration=False)+b'\n'

def make_config():
    ET.register_namespace('xsi','http://www.w3.org/2001/XMLSchema-instance')
    root=ET.Element('config',{'{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation':SCHEMA})
    ET.SubElement(root,'moduleName').text='Surface Tides '+VERSION
    required=ET.SubElement(root,'requiredInstallFiles')
    steps=ET.SubElement(root,'installSteps',order='Explicit')
    def dependencies(parent,name,flags):
        deps=ET.SubElement(parent,name,operator='And')
        for key,value in flags.items():ET.SubElement(deps,'flagDependency',flag=key,value=str(value))
    def step(name,visible=None):
        node=ET.SubElement(steps,'installStep',name=name)
        if visible:dependencies(node,'visible',visible)
        return ET.SubElement(node,'optionalFileGroups',order='Explicit')
    def group(parent,name,kind='SelectExactlyOne'):
        return ET.SubElement(ET.SubElement(parent,'group',name=name,type=kind),'plugins',order='Explicit')
    def choice(parent,name,description,flags,recommended=False,required=False):
        node=ET.SubElement(parent,'plugin',name=name)
        ET.SubElement(node,'description').text=description
        c=ET.SubElement(node,'conditionFlags')
        for key,value in flags.items():ET.SubElement(c,'flag',name=key).text=str(value)
        ET.SubElement(ET.SubElement(node,'typeDescriptor'),'type',name='Required' if required else 'Recommended' if recommended else 'Optional')
    intro=group(step('Before installing'),'Requirements and configuration','SelectAll')
    choice(intro,'Surface Tides '+VERSION,
        'Release 1.1.0: ENB camera/ripple fixes, pond retention and automatic nearby-water discovery, native OS water, performance improvements, caching/prewarming and lava/puddle exclusions. '
        'Choose your exact Skyrim executable version on the next page; other runtimes and VR are unsupported. '
        'Install matching SKSE and Address Library separately. SKSE Menu Framework 3.x is optional. '
        'This installer writes a COMPLETE NEW SurfaceTides.ini. BACK UP custom tuning. '
        'Cleanly replace the old mod so deselected files and old SurfaceTides_Global.json overrides do not remain. '
        'Restart Skyrim after changing startup settings. The first uncached water load can pause for shader compilation.',
        {'intro':'read'},required=True)
    runtime=group(step('Game runtime'),'Choose the exact executable version')
    for i,(name,value,desc) in enumerate(RUNTIMES):choice(runtime,name,desc,{'runtime':value},recommended=i==0)
    renderer=group(step('Renderer'),'Choose your renderer')
    for name,value,desc in RENDERERS:choice(renderer,name,desc,{'renderer':value},recommended=value=='vanilla')
    enb=group(step('ENB water mode',{'renderer':'enb'}),'Choose the ENB water path')
    for i,(name,value,_,desc) in enumerate(ENB_MODES):choice(enb,name,desc,{'enb_mode':value},recommended=i==0)
    features=step('Surface objects')
    foam=group(features,'Foam')
    for i,(name,attached,bos,desc) in enumerate(FOAM):choice(foam,name,desc,{'attached':attached,'standalone_foam':bos},recommended=i==0)
    ice=group(features,'Flat ice decals')
    for i,(name,value,desc) in enumerate(ICE):choice(ice,name,desc,{'ice':value},recommended=i==0)
    bob=group(features,'Solid ice motion')
    for i,(name,value,desc) in enumerate(BOBBING):choice(bob,name,desc,{'bobbing':value},recommended=i==0)
    patterns=ET.SubElement(ET.SubElement(root,'conditionalFileInstalls'),'patterns')
    def pattern(flags,source,destination):
        p=ET.SubElement(patterns,'pattern');dependencies(p,'dependencies',flags)
        ET.SubElement(ET.SubElement(p,'files'),'file',source=source,destination=destination,priority='10')
    for _,runtime,_ in RUNTIMES:
        pattern({'runtime':runtime},f'options/runtime/{runtime}/SurfaceTides.dll','SKSE/Plugins/SurfaceTides.dll')
    for (profile,flags,_,_,_),attached,ice,bob in itertools.product(profiles(),range(2),range(2),range(2)):
        filename=f'{profile}-foam{attached}-ice{ice}-bob{bob}.ini'
        pattern(dict(flags,attached=attached,ice=ice,bobbing=bob),'options/config/'+filename,'SKSE/Plugins/SurfaceTides.ini')
    pattern({'standalone_foam':1},'options/foam/SurfaceTides_Foam_SWAP.ini','SurfaceTides_Foam_SWAP.ini')
    return root,required

def generate(root,stage,dlls):
    assert set(dlls)=={'AE16','SE','AE17'}
    payload={f'options/runtime/{runtime}/SurfaceTides.dll':dll.read_bytes() for runtime,dll in dlls.items()}
    for p in sorted((root/'Data/Shaders').rglob('*')):
        if p.is_file():payload['core/Shaders/'+p.relative_to(root/'Data/Shaders').as_posix()]=p.read_bytes()
    for p in sorted((root/'licenses').glob('*')):
        if p.is_file():payload['core/Documentation/SurfaceTides/licenses/'+p.name]=p.read_bytes()
    for name in ['THIRD_PARTY.md','LICENSE']:
        payload['core/Documentation/SurfaceTides/'+('LICENSE.txt' if name=='LICENSE' else name)]=(root/name).read_bytes()
    payload['core/Documentation/SurfaceTides/README.md']=(root/'docs/RELEASE-1.1.0.md').read_bytes()
    payload['FOMOD-AUTHORING.md']=(root/'docs/FOMOD-1.1.0.md').read_bytes()
    template=(root/'Data/SKSE/Plugins/SurfaceTides.ini').read_text()
    for (profile,flags,effects,unified,native),attached,ice,bob in itertools.product(profiles(),range(2),range(2),range(2)):
        text=re.sub(r'^; Profile:.*$',f'; Profile: {profile}; attached foam removal={attached}; ice decal removal={ice}; bobbing={bob}.',template,flags=re.M)
        values={'BlockCS':1,'OpenShaders':int(flags['renderer']=='os'),'OSNativeWater':int(flags['renderer']=='os'),'OSWaterEffects':effects,'OSUnifiedWater':unified,'ENBWaterIntegration':native,'HideAttachedFoam':attached,'HideIceDecals':ice,'FloeBobbing':bob}
        for key,value in values.items():
            text,count=re.subn(r'^'+key+r'=.*$',f'{key}={value}',text,flags=re.M);assert count==1,key
        payload[f'options/config/{profile}-foam{attached}-ice{ice}-bob{bob}.ini']=text.encode()
    payload['options/foam/SurfaceTides_Foam_SWAP.ini']=(root/'optional/foam-bos/SurfaceTides_Foam_SWAP.ini').read_bytes()
    config,required=make_config()
    for name in sorted(payload):
        if name.startswith('core/'):ET.SubElement(required,'file',source=name,destination=name.removeprefix('core/'),priority='0')
    payload['fomod/ModuleConfig.xml']=xml_bytes(config)
    info=ET.Element('fomod')
    for key,value in [('Name','Surface Tides'),('Author','SurfaceTides contributors'),('Version',VERSION),('Description','Release 1.1.0: automatic nearby-water discovery; ENB camera/ripple and pond fixes; native Open Shaders water; performance improvements; caching/prewarming; lava/puddle exclusions. OS, ENB and Vanilla; optional foam, ice decals and bobbing.')]:
        node=ET.SubElement(info,key);node.text=value
        if key=='Version':node.set('MachineVersion',MACHINE_VERSION)
    payload['fomod/info.xml']=xml_bytes(info)
    for name,data in payload.items():
        p=stage/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    actual={p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file()}
    assert actual==set(payload),'Use a clean stage: unrelated/stale files found'
    for name in ['ModuleConfig.xml','info.xml']:(root/'installer/fomod'/name).write_bytes(payload['fomod/'+name])
    return len(payload)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for runtime in ['ae16','se','ae17']:p.add_argument('--dll-'+runtime,type=Path,required=True)
    p.add_argument('--stage',type=Path,required=True);a=p.parse_args()
    count=generate(Path(__file__).resolve().parents[1],a.stage.resolve(),{runtime:getattr(a,'dll_'+runtime.lower()).resolve() for runtime in ['AE16','SE','AE17']})
    print(f'Generated {count} files: 3 runtime DLLs, 32 full INIs, 192 supported selection paths.')
