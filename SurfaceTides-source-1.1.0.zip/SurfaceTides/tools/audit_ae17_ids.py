#!/usr/bin/env python3
"""Check the linked AE17 DLL's direct Address Library lookups against an offsets CSV.

This checks ID presence, not engine signatures, structures, virtual calls or runtime
behavior. It requires the matching lld-link /MAP output. Unknown lookup forms fail
the audit so that compiler changes cannot silently weaken the check.
"""
import argparse
import bisect
import csv
import hashlib
import json
import re
import subprocess
from pathlib import Path


def audit(dll, map_file, csv_file, objdump):
    symbols = {}
    for line in map_file.read_text().splitlines():
        match = re.match(r'\s+0001:[0-9a-fA-F]+\s+(\S+)\s+([0-9a-fA-F]{16})\s', line)
        if match:
            symbols.setdefault(int(match[2], 16), []).append(match[1])
    addresses = sorted(symbols)
    lookup = {address for address, names in symbols.items()
              if any(name.startswith('?id2offset@IDDB@REL@@') for name in names)}
    assert len(lookup) == 1, 'Expected one IDDB::id2offset implementation'
    wrappers = {address for address, names in symbols.items()
                if any(name.startswith('??0?$Relocation@') and
                       re.search(r'V(?:RelocationID|VariantID)@', name) for name in names)}
    assert wrappers, 'No recognized relocation constructors'
    disassembly = subprocess.check_output(
        [str(objdump), '-d', '--no-show-raw-insn', '--x86-asm-syntax=intel', str(dll)], text=True)
    instructions = []
    for line in disassembly.splitlines():
        match = re.match(r'([0-9a-f]+):\s+(\S+)\s*(.*)', line)
        if match:
            instructions.append((int(match[1], 16), match[2], match[3]))

    with csv_file.open(newline='') as file:
        offsets = {int(row['aeid']): int(row['ae_addr'], 16) for row in csv.DictReader(file)}
    sites, unresolved, forwarding = [], [], []
    for i, (address, opcode, operands) in enumerate(instructions):
        target = re.match(r'0x([0-9a-f]+)\b', operands)
        if opcode not in ('call', 'jmp') or not target:
            continue
        target = int(target[1], 16)
        if target not in lookup | wrappers:
            continue
        entry = addresses[bisect.bisect_right(addresses, address) - 1]
        if target in lookup and entry in wrappers:
            forwarding.append(hex(address))
            continue
        ident = None
        # The current compiler emits an immediate EDX load just before each call.
        # Stop at control flow or any other write/use of RDX rather than guessing.
        for _, previous_op, previous_args in reversed(instructions[max(0, i - 5):i]):
            if previous_op == 'mov':
                constant = re.fullmatch(r'edx, 0x([0-9a-f]+)', previous_args)
                if constant:
                    ident = int(constant[1], 16)
                    break
            if previous_op in ('call', 'ret') or previous_op.startswith('j') or re.search(r'\b[re]dx\b', previous_args):
                break
        if ident is None:
            unresolved.append(hex(address))
            continue
        sites.append({'site': hex(address), 'id': ident,
                      'mapped_offset': hex(offsets[ident]) if offsets.get(ident) else None,
                      'function': symbols[entry][0]})
    assert sites and forwarding, 'Incomplete lookup scan'
    return {'dll_sha256': hashlib.sha256(dll.read_bytes()).hexdigest(),
            'map_sha256': hashlib.sha256(map_file.read_bytes()).hexdigest(),
            'offsets_csv_sha256': hashlib.sha256(csv_file.read_bytes()).hexdigest(),
            'scope': 'Direct linked IDDB calls and recognized RelocationID/VariantID constructors; ID presence only',
            'call_sites': len(sites), 'unique_ids': len({site['id'] for site in sites}),
            'missing_ids': sorted({site['id'] for site in sites if site['mapped_offset'] is None}),
            'unresolved_sites': unresolved, 'constructor_forwarding_sites': forwarding,
            'sites': sites}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dll', type=Path, required=True)
    parser.add_argument('--map', type=Path, required=True)
    parser.add_argument('--csv', type=Path, required=True)
    parser.add_argument('--objdump', type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.dll, args.map, args.csv, args.objdump)
    print(json.dumps(report, indent=2))
    raise SystemExit(1 if report['missing_ids'] or report['unresolved_sites'] else 0)
