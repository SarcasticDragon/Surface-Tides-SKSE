#include "surfacetides/Simulation.hpp"
#include <algorithm>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <string>

using Clock=std::chrono::steady_clock;
void run(const std::string& scene,bool optimized,int repeat) {
    st::Settings settings;settings.wind=scene=="wind_off" ? 0.f : 5.f;
    settings.gustStrength=scene=="continuous_only" ? 0.f : 1.f;
    st::Surface surface(settings,optimized);st::Vec2 center{-169000,103400};
    surface.reset(center,-14000);
    std::vector<std::uint8_t> wet(surface.cells().size(),1);
    if(scene=="pond")for(std::size_t i=0;i<wet.size();++i)wet[i]=i%13<2;
    if(scene=="dry")std::fill(wet.begin(),wet.end(),0);
    surface.setWetMask(wet);
    surface.addImpulse({center,50,60});
    for(int i=0;i<120;++i)surface.step();
    std::vector<double> elapsed;elapsed.reserve(600);
    for(int i=0;i<600;++i) {
        const auto start=Clock::now();
        if(scene=="scrolling" && i%8==0) {
            center.x+=80;center.y-=80;surface.recenter(center);surface.setWetMask(wet);
        }
        surface.step();
        elapsed.push_back(std::chrono::duration<double,std::milli>(Clock::now()-start).count());
    }
    const double mean=std::accumulate(elapsed.begin(),elapsed.end(),0.)/double(elapsed.size());
    std::sort(elapsed.begin(),elapsed.end());
    std::cout<<std::setprecision(10)<<"{\"scene\":\""<<scene<<"\",\"optimized\":"<<(optimized?"true":"false")
        <<",\"repeat\":"<<repeat<<",\"steps\":600,\"meanMs\":"<<mean
        <<",\"p95Ms\":"<<elapsed[569]<<",\"maxMs\":"<<elapsed.back()
        <<",\"energy\":"<<surface.energy()<<",\"clipped\":"<<surface.diagnostics().clippedCells<<"}\n";
}
int main() {
    for(const auto* scene:{"continuous_only","open_water","pond","scrolling","dry","wind_off"})
        for(int repeat=0;repeat<5;++repeat) {
            // Alternate order to reduce systematic warm-up/clock bias.
            run(scene,repeat%2!=0,repeat);run(scene,repeat%2==0,repeat);
        }
}
