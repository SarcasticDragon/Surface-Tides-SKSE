#!/usr/bin/env python3
"""Package public Beta 11 through accepted surface exclusions, without the lava prototype."""
import argparse
import configparser
import difflib
import json
import zipfile
from pathlib import Path
from build_fomod import VERSION, MACHINE_VERSION, BINARY_PATCH, BINARY_REVISION, generate
from package_os_preview4 import digest, source_items, write_zip
from validate_fomod import validate

BASELINE_SHA256 = '1e1648055d9916e6d5af6c42da1025952beb13c45c2b62726970e4698a692967'
PREVIOUS_SHA256 = '515b555dbf5137a4dfc869708c9ba06d368eb9f34573b2652f5220ade1e48d58'
REMOVED = {
    'include/surfacetides/LavaGeometry.hpp', 'src/plugin/Lava.hpp', 'src/plugin/Lava.cpp',
    'tests/LavaTests.cpp', 'Data/Shaders/SurfaceTides/LavaDeform.hlsl',
    'optional/lava/SurfaceTidesLava.ini', 'tools/package_lava_prototype1.py',
    'docs/LAVA-PROTOTYPE-1.md',
}
ALLOWED = {
    'CMakeLists.txt', 'README.md', 'Data/SKSE/Plugins/SurfaceTides.ini',
    'src/plugin/BuildVersion.hpp', 'src/plugin/Main.cpp', 'src/plugin/Hooks.cpp',
    'src/plugin/Bridge.hpp', 'src/plugin/Game.cpp', 'src/plugin/Menu.cpp',
    'tools/build_fomod.py', 'tools/validate_fomod.py',
    'installer/fomod/ModuleConfig.xml', 'installer/fomod/info.xml',
    'docs/BETA-1.1.0-beta.11.md', 'docs/FOMOD-beta.11.md', 'docs/LAVA-ASSETS-2026-10-03.md',
}
# Reviewed prototype-removal diff: no other water-hook/runtime changes accepted.
REVIEWED_HOOKS_SHA256 = '38bd272ce9735601a9bdfe2c1dcb9ddc4f02a6117e4ab81baf89924d08143d4e'
REVIEWED_CMAKE_SHA256 = '7d9b62fed0bbba2a614305b3de6e3f49359441b5f89e19539aa99f070b608359'

def read_zip(path):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        items = [i for i in z.infolist() if not i.is_dir()]
        assert len({i.filename for i in items}) == len(items)
        return {i.filename: z.read(i) for i in items}

def ini_values(data):
    c = configparser.ConfigParser(strict=True)
    c.read_string(data.decode())
    return {(s,k): v for s in c.sections() for k,v in c.items(s)}

def audit_source(root, old):
    current = dict(source_items(root)); prefix = 'SurfaceTides/'
    removed = sorted(old.keys() - current.keys())
    expected_removed = {prefix+n for n in REMOVED}
    expected_removed.update(n for n in old if n.startswith(prefix+'docs/lava-prototype.1-evidence/'))
    assert set(removed) == expected_removed, removed
    changed = sorted(n for n in old.keys() & current.keys() if old[n] != current[n])
    assert set(changed) <= {prefix+n for n in ALLOWED}, changed
    new = sorted(current.keys() - old.keys())
    assert all(n.startswith(prefix+'docs/beta.11-public-evidence/') or n in {
        prefix+'docs/beta.11-public-validation.json', prefix+'tools/package_beta11_public.py'} for n in new), new
    assert digest(current[prefix+'src/plugin/Hooks.cpp']) == REVIEWED_HOOKS_SHA256
    assert digest(current[prefix+'CMakeLists.txt']) == REVIEWED_CMAKE_SHA256
    name = prefix+'src/plugin/Main.cpp'
    assert old[name].replace(b'#include "Lava.hpp"\n',b'').replace(b'    st::plugin::lava::reset();\n',b'') == current[name]
    name = prefix+'src/plugin/Game.cpp'
    assert old[name].replace(b'number(L"Performance",L"OptimizeDiscovery",0)',b'number(L"Performance",L"OptimizeDiscovery",1)') == current[name]
    name = prefix+'src/plugin/Bridge.hpp'
    assert old[name].replace(b'bool optimizeDiscovery = false; // untested target four is opt-in during OS correctness work',
        b'bool optimizeDiscovery = true; // spread foam/ice discovery across updates for the public beta') == current[name]
    before = ini_values(old[prefix+'Data/SKSE/Plugins/SurfaceTides.ini'])
    after = ini_values(current[prefix+'Data/SKSE/Plugins/SurfaceTides.ini'])
    before[('Performance','optimizediscovery')] = '1'
    assert before == after, 'Unexpected source-template setting change'
    assert not any(n in current for n in expected_removed)
    for name,data in current.items():
        if name.startswith((prefix+'src/',prefix+'include/',prefix+'Data/')):
            assert b'lava::' not in data and b'SurfaceTidesLava.ini' not in data, name
    shaders = {n:digest(data) for n,data in current.items() if n.startswith(prefix+'Data/Shaders/')}
    assert len(shaders) == 7
    assert all(current[n] == old[n] for n in shaders)
    diffs=[]
    for name in changed:
        if name.startswith(prefix+'src/') or name==prefix+'CMakeLists.txt':
            diffs.extend(difflib.unified_diff(old[name].decode().splitlines(True),current[name].decode().splitlines(True),
                fromfile='prototype-v33/'+name.removeprefix(prefix),tofile='public-beta11/'+name.removeprefix(prefix)))
    (root/'docs/beta.11-public-evidence/release-code.diff').write_text(''.join(diffs))
    return {'changed_baseline_files': changed, 'removed_prototype_files': removed,
            'new_public_release_files': new, 'preserved_baseline_files': len(old)-len(removed),
            'accepted_water_shader_sha256': shaders,
            'only_changed_template_value': 'Performance.OptimizeDiscovery=1',
            'prototype_checkpoint_modified': False, 'lava_prototype_included': False}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['baseline-source','previous-fomod','dll-dir','output-dir']:
        p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[1];out=a.output_dir.resolve()
    assert not out.is_relative_to(root);out.mkdir(parents=True,exist_ok=True)
    assert digest(a.baseline_source.read_bytes()) == BASELINE_SHA256
    assert digest(a.previous_fomod.read_bytes()) == PREVIOUS_SHA256
    old=read_zip(a.baseline_source);previous=read_zip(a.previous_fomod)
    assert VERSION=='1.1.0-beta.11' and (BINARY_PATCH,BINARY_REVISION)==(1,1)
    ev=root/'docs/beta.11-public-evidence'
    ctest=(ev/'portable-ctest.txt').read_text()
    assert '100% tests passed out of 14' in ctest
    for test in ['water_selection','ripple_coverage_policy','discovery_schedule','wind_forcing_equivalence','native_os_source','surface_eligibility']:
        assert test in ctest
    dlls={r:a.dll_dir/r/'SurfaceTides.dll' for r in ['AE16','SE','AE17']}
    for r,dll in dlls.items():
        result=json.loads((ev/(r.lower()+'-build-result.json')).read_text())
        assert result['exit_code']==0 and result['last_phase']=='build'
        log=(ev/(r.lower()+'-build.txt')).read_text()
        assert 'Linking CXX shared library SurfaceTides.dll' in log and 'FAILED:' not in log
        binary=dll.read_bytes()
        for marker in [b'1.1.0-beta.11', b'OSNativeWater', b'MeshRippleCoverage', b'MeshWadingDepth',
                       b'OptimizeDiscovery', b'OptimizeSimulation', b'Surface exclusions:', b'NativeOS-v1']:
            assert marker in binary, (r,marker)
        for marker in [b'SurfaceTidesLava.ini', b'LavaDeform.hlsl', b'Lava effect setup/restore hooks', b'lava-prototype']:
            assert marker not in binary, (r,marker)
    stage=out/'fomod-stage'
    generate(root,stage,dlls)
    checked=validate(stage,root)
    (ev/'fomod-validation.json').write_text(json.dumps(checked,indent=2)+'\n')
    audit=audit_source(root,old)
    payload={p.relative_to(stage).as_posix():p.read_bytes() for p in stage.rglob('*') if p.is_file()}
    for n in payload:
        assert 'lava' not in n.lower(), n
    for n in payload.keys() & previous.keys():
        if n.startswith('core/') and n!='core/Documentation/SurfaceTides/README.md':
            # MeshInput changed earlier for ripple coverage; the current prior Beta11 already has it.
            # Other water shader updates since that checkpoint are recorded, not reverted.
            if '/licenses/' in n or n.endswith(('THIRD_PARTY.md','LICENSE.txt')):
                assert payload[n] == previous[n], n
    installer=out/f'SurfaceTides-{VERSION}-FOMOD.zip'
    write_zip(installer,sorted(payload.items()))
    assert read_zip(installer)==payload
    report={'version':VERSION,'machine_version':MACHINE_VERSION,
        'baseline_source_version':33,'baseline_sha256':BASELINE_SHA256,
        'previous_fomod_sha256':PREVIOUS_SHA256,'previous_fomod_retained_in_version_history':True,
        **audit,'portable_suites_passed':14,'selection_cases_passed':checked['selection_cases_passed'],
        'complete_ini_variants':checked['distinct_ini_variants'],'runtime_binaries':checked['runtime_binaries'],
        'all_accepted_water_hlsl_unchanged':True,'native_os_source_patcher_unchanged':True,
        'source_include_and_vendor_changes_restricted':True,
        'installer_files_added':sorted(payload.keys()-previous.keys()),
        'installer_files_removed':sorted(previous.keys()-payload.keys()),
        'installer_files_changed':sorted(n for n in payload.keys()&previous.keys() if payload[n]!=previous[n]),
        'installer':installer.name,'installer_bytes':installer.stat().st_size,'installer_sha256':digest(installer.read_bytes()),
        'native_runtime_execution_and_manager_ui_tested':False,
        'enb_implementation_source_shaders_bytecode_or_sdk_accessed':False}
    (root/'docs/beta.11-public-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    source=out/f'SurfaceTides-source-{VERSION}.zip'
    final=dict(source_items(root));write_zip(source,sorted(final.items()))
    assert read_zip(source)==final
    for f in [installer,source]:
        print(json.dumps({'path':str(f),'bytes':f.stat().st_size,'sha256':digest(f.read_bytes())}),flush=True)
    print('PASS: 3 runtime DLLs, 14 portable suites, 192 selections, 32 full INIs; lava prototype excluded.')

if __name__=='__main__':main()
