"""Secondary DXC checks only: preserve FXC namespace-scoped cbuffer semantics.

DXC exports cbuffer members globally; OS uses FXC's enclosing namespace.
Rename those global exports and add aliases in the original namespace. Buffer
declarations, member order, types and registers remain unchanged. Production
uses the installed headers verbatim with D3DCompiler, never this transformation.
"""
import re
import shutil
from pathlib import Path


def stage_headers(source: Path, target: Path):
    shutil.copytree(source / 'Common', target / 'Common')
    count = 0
    for relative, namespace in [('Common/FrameBuffer.hlsli', 'FrameBuffer'),
                                ('Common/SharedData.hlsli', 'SharedData'),
                                ('Common/Permutation.hlsli', 'Permutation')]:
        path = target / relative
        text = path.read_text()

        def adapt(match):
            nonlocal count
            aliases, declarations = [], []
            for line in match['body'].splitlines():
                if line.lstrip().startswith('#'):
                    aliases.append(line)
                    declarations.append(line)
                    continue
                member = re.match(r'^(\s*)((?:row_major\s+)?[\w:]+)\s+(\w+)(\[[^\]]+\])?(\s*(?::\s*packoffset\([^)]*\))?\s*;.*)$', line)
                if not member:
                    assert not line.strip() or line.lstrip().startswith('//'), line
                    declarations.append(line)
                    continue
                indent, kind, name, array, tail = member.groups()
                renamed = 'ST_DXC_' + namespace + '_' + name
                declarations.append(f'{indent}{kind} {renamed}{array or ""}{tail}')
                aliases.append(f'{indent}static const {kind} {name}{array or ""} = ::{renamed};')
                count += 1
            return match['head'] + '\n'.join(declarations) + '\n\t};\n' + '\n'.join(aliases)

        pattern = r'(?P<head>\bcbuffer\s+\w+\s*:\s*register\([^)]*\)\s*\{)(?P<body>.*?)\};?'
        text, buffers = re.subn(pattern, adapt, text, flags=re.S)
        assert buffers, f'No buffers found in {relative}'
        path.write_text(text)
    return count
