// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only lava asset inspection. Link with ousnius/nifly; never calls Save/Optimize.
#include <NifFile.hpp>
#include <Shaders.hpp>
#include <Animation.hpp>
#include <bhk.hpp>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <limits>
#include <string_view>

static void string(std::string_view s) {
    std::cout << '"';
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') std::cout << '\\' << char(c);
        else if (c < 32) std::cout << "\\u" << std::hex << std::setw(4) << std::setfill('0') << unsigned(c) << std::dec;
        else std::cout << char(c);
    }
    std::cout << '"';
}

int main(int argc, char** argv) {
    using namespace nifly;
    if (argc < 2) return 2;
    std::cout << '[';
    for (int a = 1; a < argc; ++a) {
        if (a != 1) std::cout << ',';
        NifFile file;
        const int code = file.Load(std::filesystem::path(argv[a]));
        std::cout << "{\"file\":"; string(std::filesystem::path(argv[a]).filename().string());
        std::cout << ",\"load_code\":" << code << ",\"blocks\":[";
        if (code != 0 || !file.IsValid()) return 1;
        auto& h = file.GetHeader();
        for (std::uint32_t i = 0; i < h.GetNumBlocks(); ++i) {
            if (i) std::cout << ',';
            auto* block = h.GetBlock<NiObject>(i);
            std::cout << "{\"id\":" << i << ",\"type\":"; string(h.GetBlockTypeStringById(i));
            if (auto* net = dynamic_cast<NiObjectNET*>(block)) {
                std::cout << ",\"name\":"; string(net->name.get());
                std::cout << ",\"controller\":" << net->controllerRef.index;
            }
            if (auto* av = dynamic_cast<NiAVObject*>(block)) {
                std::cout << ",\"flags\":" << av->flags << ",\"collision\":" << av->collisionRef.index;
                auto* parent = file.GetParentNode(av);
                std::cout << ",\"parent\":" << (parent ? file.GetBlockID(parent) : 0xFFFFFFFFu);
                std::cout << ",\"translation\":[" << av->transform.translation.x << ',' << av->transform.translation.y << ',' << av->transform.translation.z << ']'
                          << ",\"scale\":" << av->transform.scale;
            }
            if (auto* node = dynamic_cast<NiNode*>(block)) {
                std::cout << ",\"children\":[";
                bool first = true;
                for (auto& child : node->childRefs) {
                    if (!first) std::cout << ',';
                    first = false; std::cout << child.index;
                }
                std::cout << ']';
            }
            if (auto* shape = dynamic_cast<NiShape*>(block)) {
                std::cout << ",\"vertices\":" << shape->GetNumVertices() << ",\"triangles\":" << shape->GetNumTriangles();
                auto* shader = file.GetShader(shape);
                std::cout << ",\"shader\":" << (shader ? file.GetBlockID(shader) : 0xFFFFFFFFu);
                if (shader) { std::cout << ",\"shader_block_type\":"; string(h.GetBlockTypeStringById(file.GetBlockID(shader))); }
                if (shader) std::cout << ",\"shader_type\":" << shader->GetShaderType();
                const auto* alpha=shape->AlphaPropertyRef();
                std::cout << ",\"alpha_property\":" << (alpha ? alpha->index : 0xFFFFFFFFu);
                std::cout << ",\"textures\":[";
                bool first = true;
                for (auto& texture : file.GetTexturePathRefs(shape)) {
                    if (!first) std::cout << ',';
                    first = false; string(texture.get());
                }
                std::cout << ']';
                if (const auto* vertices = file.GetVertsForShape(shape); vertices && !vertices->empty()) {
                    float lo = std::numeric_limits<float>::max(), hi = -lo;
                    for (const auto& v : *vertices) { lo = std::min(lo,v.z); hi = std::max(hi,v.z); }
                    std::cout << ",\"local_z_min\":" << lo << ",\"local_z_max\":" << hi;
                    float xlo=lo, xhi=-lo, ylo=lo, yhi=-lo;
                    xlo=ylo=std::numeric_limits<float>::max(); xhi=yhi=-xlo;
                    for (const auto& v : *vertices) {
                        xlo=std::min(xlo,v.x); xhi=std::max(xhi,v.x);
                        ylo=std::min(ylo,v.y); yhi=std::max(yhi,v.y);
                    }
                    std::cout << ",\"local_xy_min\":[" << xlo << ',' << ylo << ']'
                              << ",\"local_xy_max\":[" << xhi << ',' << yhi << ']';
                    float xmin=std::numeric_limits<float>::max(),ymin=xmin,zmin=xmin;
                    float xmax=-xmin,ymax=-xmin,zmax=-xmin;
                    for (auto v : *vertices) {
                        NiAVObject* node=shape;
                        unsigned depth=0;
                        while (node && depth++<64) {
                            v=node->transform.ApplyTransform(v);
                            node=file.GetParentNode(node);
                        }
                        if (node) return 3;
                        xmin=std::min(xmin,v.x);xmax=std::max(xmax,v.x);
                        ymin=std::min(ymin,v.y);ymax=std::max(ymax,v.y);
                        zmin=std::min(zmin,v.z);zmax=std::max(zmax,v.z);
                    }
                    std::cout << ",\"nif_bounds_min\":[" << xmin << ',' << ymin << ',' << zmin << ']'
                              << ",\"nif_bounds_max\":[" << xmax << ',' << ymax << ',' << zmax << ']';
                }
            }
            if (auto* shader=dynamic_cast<BSShaderProperty*>(block)) {
                std::cout << ",\"shader_flags1\":" << shader->shaderFlags1 << ",\"shader_flags2\":" << shader->shaderFlags2
                          << ",\"uv_offset\":[" << shader->uvOffset.u << ',' << shader->uvOffset.v << ']'
                          << ",\"uv_scale\":[" << shader->uvScale.u << ',' << shader->uvScale.v << ']';
            }
            if (auto* shader=dynamic_cast<BSEffectShaderProperty*>(block)) {
                std::cout << ",\"source_texture\":"; string(shader->sourceTexture.get());
                std::cout << ",\"greyscale_texture\":"; string(shader->greyscaleTexture.get());
                std::cout << ",\"base_color\":[" << shader->baseColor.r << ',' << shader->baseColor.g << ',' << shader->baseColor.b << ',' << shader->baseColor.a << ']'
                          << ",\"base_color_scale\":" << shader->baseColorScale
                          << ",\"falloff\":[" << shader->falloffStartAngle << ',' << shader->falloffStopAngle << ',' << shader->falloffStartOpacity << ',' << shader->falloffStopOpacity << ']';
            }
            if (auto* shader=dynamic_cast<BSWaterShaderProperty*>(block)) std::cout << ",\"water_flags\":" << shader->waterFlags;
            if (auto* alpha=dynamic_cast<NiAlphaProperty*>(block)) std::cout << ",\"alpha_flags\":" << alpha->flags << ",\"alpha_threshold\":" << unsigned(alpha->threshold);
            if (auto* body = dynamic_cast<bhkRigidBody*>(block)) {
                std::cout << ",\"shape\":" << body->shapeRef.index
                          << ",\"motion_system\":" << unsigned(body->motionSystem)
                          << ",\"quality_type\":" << unsigned(body->qualityType)
                          << ",\"collision_response\":" << unsigned(body->collisionResponse)
                          << ",\"mass\":" << body->mass
                          << ",\"body_translation\":[" << body->translation.x << ',' << body->translation.y << ',' << body->translation.z << ']';
            }
            if (auto* controller = dynamic_cast<NiTimeController*>(block)) {
                std::cout << ",\"target\":" << controller->targetRef.index << ",\"next\":" << controller->nextControllerRef.index;
                std::cout << ",\"frequency\":" << controller->frequency << ",\"phase\":" << controller->phase
                          << ",\"start_time\":" << controller->startTime << ",\"stop_time\":" << controller->stopTime;
            }
            if (auto* controller=dynamic_cast<BSEffectShaderPropertyFloatController*>(block)) std::cout << ",\"controlled_variable\":" << controller->typeOfControlledVariable;
            if (auto* controller=dynamic_cast<BSEffectShaderPropertyColorController*>(block)) std::cout << ",\"controlled_color\":" << controller->typeOfControlledColor;
            std::cout << '}';
        }
        std::cout << "]}";
    }
    std::cout << "]\n";
}
