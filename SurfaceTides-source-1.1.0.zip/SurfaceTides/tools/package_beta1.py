#!/usr/bin/env python3
"""Package the complete beta and preserve the authoritative preview.10 source."""
import argparse, json, zipfile
from pathlib import Path
from build_fomod import generate, VERSION
from validate_fomod import validate
from package_os_preview4 import source_items, write_zip, digest

BASELINE_SHA256='3da42606c1a78bff1626fc66f0acb2b885add4b479797879364b46f38133d69d'
ALLOWED_CHANGES={
    'README.md','docs/OS-ROADMAP-2026-09-24.md','src/plugin/BuildVersion.hpp',
    'src/plugin/Main.cpp','src/plugin/Bridge.hpp','src/plugin/Game.cpp','src/plugin/Menu.cpp',
    'src/plugin/Renderer.cpp','src/plugin/Hooks.cpp','include/surfacetides/ShaderCompatibility.hpp',
    'tests/ShaderCompatibilityTests.cpp','Data/SKSE/Plugins/SurfaceTides.ini',
    'tools/build_fomod.py','tools/validate_fomod.py','installer/fomod/ModuleConfig.xml','installer/fomod/info.xml'}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build-root',type=Path,required=True);p.add_argument('--baseline-source',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[1];output=a.output_dir.resolve()
    assert not output.is_relative_to(root),'Keep packages outside source'
    output.mkdir(parents=True,exist_ok=True);e=root/'docs/beta.1-evidence'
    assert '100% tests passed out of 8' in (e/'portable-ctest.txt').read_text()
    assert digest(a.baseline_source.read_bytes())==BASELINE_SHA256,'Wrong source checkpoint'
    with zipfile.ZipFile(a.baseline_source) as z:
        baseline={x.filename:z.read(x) for x in z.infolist() if not x.is_dir()}
    dlls={runtime:(a.build_root/runtime.lower()/'SurfaceTides.dll').resolve() for runtime in ['AE16','SE','AE17']}
    for runtime,dll in dlls.items():
        build=(e/(runtime.lower()+'-final-build.txt')).read_text()
        assert 'Linking CXX shared library SurfaceTides.dll' in build and 'FAILED:' not in build and 'error:' not in build
        binary=dll.read_bytes()
        for marker in [VERSION.encode(),b'legacy AllowENB ignored; no ENB presence guard',b'EXPERIMENTAL ENB mesh-input integration',b'via=resolved-import',b'Shader prewarm complete:',b'Shader cache ready:',b'OSPreserveSceneMotion',b'OSWaterEffects',b'OSUnifiedWater']:
            assert marker in binary,(runtime,marker)
        assert b'Set [Compatibility] AllowENB=1 for an ENB compatibility test.' not in binary
        assert b'this combination is unsupported. SurfaceTides disabled.' not in binary
    stage=output/'fomod-stage'
    generate(root,stage,dlls)
    fomod=validate(stage,root)
    (e/'fomod-validation.json').write_text(json.dumps(fomod,indent=2)+'\n')
    entries=dict(source_items(root))
    assert set(baseline)<=set(entries),'Baseline files lost'
    changed=sorted(name for name in baseline if baseline[name]!=entries[name])
    assert set(changed)<={'SurfaceTides/'+name for name in ALLOWED_CHANGES},changed
    # Guard against accidental rendering/solver changes while reenabling ENB.
    for name in ['src/plugin/Renderer.cpp','src/plugin/Hooks.cpp']:
        key='SurfaceTides/'+name
        assert baseline[key].replace(b'config.allowENB',b'config.enbActive')==entries[key],name
    game='SurfaceTides/src/plugin/Game.cpp'
    assert baseline[game].split(b'    c.blockCS',1)[1]==entries[game].split(b'    c.blockCS',1)[1]
    protected=['src/core/','Data/Shaders/','vendor/','src/plugin/ShaderCache','include/surfacetides/ShaderCache',
               'src/plugin/Floes.cpp','src/plugin/Foam.cpp','src/plugin/WaterQuery.hpp']
    assert all(not any(name.startswith('SurfaceTides/'+prefix) for prefix in protected) for name in changed)
    shader_hashes={p.name:digest(p.read_bytes()) for p in (root/'Data/Shaders/SurfaceTides').iterdir() if p.is_file()}
    assert len(shader_hashes)==7
    installer=output/f'SurfaceTides-{VERSION}-FOMOD.zip'
    write_zip(installer,[(p.relative_to(stage).as_posix(),p.read_bytes()) for p in sorted(stage.rglob('*')) if p.is_file()])
    report={'version':VERSION,'machine_version':'1.1.0.11','baseline_source_version':15,'baseline_source_sha256':BASELINE_SHA256,
        'baseline_source_files_preserved':len(baseline),'changed_baseline_files':changed,
        'new_files':sorted((set(entries)|{'SurfaceTides/docs/beta.1-validation.json'})-set(baseline)),
        'runtime_binaries':fomod['runtime_binaries'],'portable_ctest_suites_passed':8,
        'installer_selection_paths_passed':336,'full_ini_variants':56,'installer':installer.name,
        'installer_sha256':digest(installer.read_bytes()),'shader_sha256':shader_hashes,
        'cache_compiler_identity_and_cache_behavior_unchanged':True,
        'simulation_water_selection_objects_vendors_and_all_hlsl_unchanged':True,
        'renderer_and_hooks_only_change':'Rename ENB permission flag to effective detected renderer state; selection is handled in Main',
        'enb_presence_guards_removed':True,'legacy_allow_enb_ignored_including_zero':True,
        'cs_guard_and_os_selection_preserved':True,'native_enb_integration':'Existing experimental path, separately selected in FOMOD; prior visual limitations not resolved',
        'cache_prewarm_scope':'ST-owned water stages; excludes experimental native ENB mesh-input stage compilation',
        'returned_cache_evidence':'77 cache hits; zero cold/invalid/IO failures; 11 pairs prewarmed in 58.687 ms',
        'native_windows_shader_game_and_mod_manager_execution':'Not available; automated checks are not in-game or installer UI confirmation',
        'no_enb_source_obtained_or_used':True}
    (root/'docs/beta.1-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    source=output/f'SurfaceTides-source-{VERSION}.zip'
    write_zip(source,source_items(root))
    with zipfile.ZipFile(source) as z:assert set(baseline)<=set(z.namelist())
    for file in [installer,source]:print(json.dumps({'path':str(file),'bytes':file.stat().st_size,'sha256':digest(file.read_bytes())}),flush=True)
    print('PASS: three runtime builds, eight portable suites, 336 installer paths; baseline files and protected behavior preserved.')

if __name__=='__main__':main()
