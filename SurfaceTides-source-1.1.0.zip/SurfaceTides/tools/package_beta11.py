#!/usr/bin/env python3
"""Package the accepted coverage.2 implementation as the full Beta 11 checkpoint."""
import argparse
import configparser
import json
import zipfile
from pathlib import Path
from build_fomod import VERSION, MACHINE_VERSION, BINARY_REVISION, generate
from package_os_preview4 import digest, source_items, write_zip
from validate_fomod import validate

BASELINE_SHA256 = 'ace6459c0d52650aff820a1961d5fd1d4934b9cf1648be42259a1f7c62e6d42d'
PREVIOUS_SHA256 = '3a7b5a2095230f5b303b443108e84d3dc2cbd8c55aadc737b9dd6cb88c1c1c95'
ALLOWED = {
    'README.md', 'Data/SKSE/Plugins/SurfaceTides.ini', 'cmake/windows-clang.cmake',
    'src/plugin/BuildVersion.hpp', 'src/plugin/Main.cpp',
    'tools/build_fomod.py', 'tools/validate_fomod.py',
    'installer/fomod/ModuleConfig.xml', 'installer/fomod/info.xml',
    'docs/OS-ROADMAP-2026-09-24.md',
}

def read_zip(path):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        items=[i for i in z.infolist() if not i.is_dir()]
        assert len({i.filename for i in items})==len(items)
        return {i.filename:z.read(i) for i in items}

def ini_values(data):
    c=configparser.ConfigParser(strict=True);c.read_string(data.decode())
    return {(s,k):v for s in c.sections() for k,v in c.items(s)}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['baseline-source','previous-fomod','dll-dir','output-dir']:
        p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[1];out=a.output_dir.resolve()
    assert not out.is_relative_to(root);out.mkdir(parents=True,exist_ok=True)
    assert digest(a.baseline_source.read_bytes())==BASELINE_SHA256
    assert digest(a.previous_fomod.read_bytes())==PREVIOUS_SHA256
    old=read_zip(a.baseline_source);previous=read_zip(a.previous_fomod)
    assert VERSION=='1.1.0-beta.11' and BINARY_REVISION==15
    ev=root/'docs/beta.11-evidence'
    ctest=(ev/'portable-ctest.txt').read_text()
    assert '100% tests passed' in ctest and 'out of 10' in ctest
    dlls={r:a.dll_dir/r/'SurfaceTides.dll' for r in ['AE16','SE','AE17']}
    for r,dll in dlls.items():
        result=json.loads((ev/(r.lower()+'-build-result.json')).read_text())
        assert result['exit_code']==0
        log=(ev/(r.lower()+'-build.txt')).read_text()
        assert 'Linking CXX shared library SurfaceTides.dll' in log and 'FAILED:' not in log
        binary=dll.read_bytes()
        for marker in [b'1.1.0-beta.11',b'MeshRippleCoverage',b'MeshWadingDepth',b'Beta 11 accepted ripple coverage']:
            assert marker in binary,(r,marker)
        assert b'beta.11-pond-test.1' not in binary and b'dry-bank retention' not in binary
    stage=out/'fomod-stage';generate(root,stage,dlls);checked=validate(stage,root)
    (ev/'fomod-validation.json').write_text(json.dumps(checked,indent=2)+'\n')
    payload={p.relative_to(stage).as_posix():p.read_bytes() for p in stage.rglob('*') if p.is_file()}
    assert previous.keys()==payload.keys(),'Unexpected installer files'
    changed_payload=sorted(n for n in payload if payload[n]!=previous[n])
    permitted={'fomod/ModuleConfig.xml','fomod/info.xml','FOMOD-AUTHORING.md',
        'core/Documentation/SurfaceTides/README.md','core/Shaders/SurfaceTides/MeshInput.hlsl'}
    permitted.update(n for n in payload if n.startswith('options/config/'))
    permitted.update(f'options/runtime/{r}/SurfaceTides.dll' for r in dlls)
    assert set(changed_payload)<=permitted,changed_payload
    for n in payload:
        if n.startswith('options/config/'):
            before,after=ini_values(previous[n]),ini_values(payload[n])
            assert after.pop(('Experimental','meshripplecoverage'))=='1'
            assert before==after,n
    current=dict(source_items(root));assert old.keys()<=current.keys(),'Lost baseline source files'
    changed=sorted(n for n in old if old[n]!=current[n])
    assert set(changed)<={'SurfaceTides/'+n for n in ALLOWED},changed
    main='SurfaceTides/src/plugin/Main.cpp'
    assert old[main].replace(b'Beta 2 ripple coverage candidate',b'Beta 11 accepted ripple coverage')==current[main], 'Unexpected startup code change'
    assert ini_values(old['SurfaceTides/Data/SKSE/Plugins/SurfaceTides.ini'])==ini_values(current['SurfaceTides/Data/SKSE/Plugins/SurfaceTides.ini'])
    new=set(current)-set(old)
    assert all(n.startswith('SurfaceTides/docs/') or n=='SurfaceTides/tools/package_beta11.py' for n in new),new
    installer=out/f'SurfaceTides-{VERSION}-FOMOD.zip';write_zip(installer,sorted(payload.items()))
    assert read_zip(installer)==payload
    report={'version':VERSION,'machine_version':MACHINE_VERSION,'binary_revision':15,
        'baseline_source_version':22,'baseline_sha256':BASELINE_SHA256,
        'previous_fomod_sha256':PREVIOUS_SHA256,'previous_fomod_preserved':True,
        'baseline_files_preserved':len(old),'changed_baseline_files':changed,
        'changed_installer_files':changed_payload,'portable_suites_passed':10,
        'selection_cases_passed':checked['selection_cases_passed'],'complete_ini_variants':checked['distinct_ini_variants'],
        'runtime_binaries':checked['runtime_binaries'],
        'accepted_implementation_and_hlsl_unchanged':True,'pond_candidate_included':False,
        'only_added_installer_ini_value':'Experimental.MeshRippleCoverage=1',
        'installer':installer.name,'installer_bytes':installer.stat().st_size,'installer_sha256':digest(installer.read_bytes()),
        'native_runtime_execution_and_manager_ui_tested':False,
        'enb_implementation_source_shaders_bytecode_or_sdk_accessed':False}
    (root/'docs/beta.11-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    source=out/f'SurfaceTides-source-{VERSION}.zip';final=dict(source_items(root));write_zip(source,sorted(final.items()))
    assert read_zip(source)==final
    for f in [installer,source]:print(json.dumps({'path':str(f),'bytes':f.stat().st_size,'sha256':digest(f.read_bytes())}),flush=True)
    print('PASS: three runtime DLLs, ten portable suites, 336 paths, 56 full INIs; accepted implementation preserved.')

if __name__=='__main__':main()
