# Third-party source and notices

| Component | Revision | License / purpose |
| --- | --- | --- |
| [CommonLibSSE-NG](https://github.com/CharmedBaryon/CommonLibSSE-NG) | `b93280e832f263dbef44e44cbe2936622a02f91a` / 3.6.0 | MIT; engine types, relocations, SKSE interfaces |
| [Community Shaders](https://github.com/community-shaders/skyrim-community-shaders/tree/v0.8.7) | `e53c0a1ffaa01199490c6097a7dabb559932a88e` / v0.8.7 | Package shader MIT license, copyright 2022 Ilya Perapechka |
| [spdlog](https://github.com/gabime/spdlog) | `27cb4c76708608465c413f6d0e6b8d99a4d84302` / 1.14.1 | MIT; logging |
| [fmt](https://github.com/fmtlib/fmt) | 10.2.1 bundled by spdlog | MIT; formatting |
| [rapidcsv](https://github.com/d99kris/rapidcsv) | `a98b85e663114b8fdc9c0dc03abf22c296f38241` / 8.84 | BSD-3-Clause; CommonLib dependency |

Water and frame declarations derive from `package/Shaders/Water.hlsl` and `package/Shaders/Common/FrameBuffer.hlsl`. Their MIT license is retained in `licenses/Upstream-Shaders.txt`. CS runtime LightingData/Permutation dependencies were removed, descriptors became compile-time inputs, and surface sampling, tessellation, constant mapping, and previous-frame displacement were added. The adapted code is distributed under this project's GPL-3.0-or-later terms with upstream notices retained.

Vendored dependency sources omit Git metadata and build output. `cmake/CommonLibFixes.cmake` corrects `Begin/End` versus `begin/end` and `storage` versus `_storage` in two CommonLib headers; no ABI layouts change. Clang builds select fmt's non-consteval/non-constexpr path to avoid a compiler compatibility issue. Windows/MSVC builds use their normal format checking.

The Windows SDK/CRT are system build dependencies. SKSE and Address Library are installed separately. None of these proprietary/system development binaries or game assets is included. NumPy, Pillow, and DXC are optional external tools for the reference preview and secondary shader checks.

MinHook v1.3.4, commit c3fcafdc10146beb5919319d0683e44e3c30d537, https://github.com/TsudaKageyu/minhook. Statically linked; BSD notices in licenses/MinHook-BSD.txt. Added in0.1.4 for direct draw-entry interception.

## SKSE Menu Framework API

Public API header by SkyrimThiago / QTR-Modding and contributors, LGPL-2.1, pinned to `1dcb70179076aae4ab626f43c5baab2735ca5877`. Source: https://github.com/QTR-Modding/SKSE-Menu-Framework-3-API . The unmodified header and license are in `vendor/SKSEMenuFramework`; the license is also shipped with the plugin. Framework binaries/assets are not bundled. Optional runtime dependency for the settings menu only.

## Runtime compatibility preview 1

The SE 1.5.97 and AE16 builds retain the original CommonLibSSE-NG revision above. The AE17 build uses [alandtse/CommonLibSSE-NG v8.1.0](https://github.com/alandtse/CommonLibSSE-NG/tree/v8.1.0), commit `3c0f5a87c3b166c9a6712d5c3bd180e9ac5ad0fd`. Its GPL-3.0-or-later text, Modding and Linking Exceptions, retained MIT notice, and hde64 notice are included in licenses/. Its source is vendored separately in vendor/CommonLibSSE-AE17; its RE headers are unmodified.

AE17 also compiles the unmodified SimpleMath.cpp component of [Microsoft DirectXTK may2026](https://github.com/microsoft/DirectXTK/tree/may2026), commit `5a8f5d01cc1328e6451b588617c9985fa5a2a8ab`, under MIT. CommonLib uses its math types; unused toolkit renderers and audio components are not built. Full component source and headers are provided in vendor/DirectXTK and its license in licenses/DirectXTK-MIT.txt. The Windows SDK supplies DirectXMath.

## Open Shaders preview.3

The adapter calls shader helpers from the user’s separately installed [Open Shaders 2.14.0](https://github.com/alandtse/open-shaders/tree/164d06bd657c07970e3633a8659bae061f6273b1), a GPL-3.0 fork of Community Shaders. Water color-space, directional-light and output composition follow its public water shader. No OS shader files or binaries are redistributed in the install overlay; its existing notices remain with its installation. New adapter code is GPL-3.0-or-later. See docs/OPEN-SHADERS-preview.3.md for exact references and validation boundaries. No ENB-origin code was added.

Preview.6 adds `OpenShadersWaterEffects.hlsli`, a GPL-3.0-or-later adapter calling
the installed `WaterEffects/WaterParallax.hlsli`. Flow-coordinate callbacks and
normal sampling follow the public OS `package/Shaders/Water.hlsl` at commit
`a996a271790ffa9f944d2d7e8a05e6fbd73a85d3`; the parallax helper is byte-identical
to the 2.14.0 release reference above. OS retains ownership of caustics lighting
and settings. OS headers, feature textures and binaries are not bundled.

Preview.7 adapts Unified Water's flow dimensions, scaled tile UVs, wading UVs,
per-pixel fog/distance and distant surface blend from the same public OS water
shader, also checked byte-for-byte against v2.13.0. Its geometry-constant
interface is documented in OS src/Features/UnifiedWater.cpp. Adaptations retain
this project's GPL-3.0-or-later terms and upstream notices. No OS engine source,
cache, mesh, texture, header or binary is redistributed in the install overlay.
