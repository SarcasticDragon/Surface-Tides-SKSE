#pragma once
#include <cstdint>

namespace st {
// Restrict the native integration candidate to the same primary wading pair
// as the accepted ST-owned PS depth correction. Never include additive lights,
// stencil/motion, underwater, interiors or a mixed shader pair.
constexpr bool primaryWadingPair(std::uint32_t vertex, std::uint32_t pixel) {
    return vertex == 0x015e && pixel == 0x015e;
}

// D3D11 public enum values: ZERO=0, KEEP=1, EQUAL=3, LESS_EQUAL=4,
// ALWAYS=8. Templates keep the policy testable without Windows headers.
template<class Description>
bool canRelaxWadingDepth(const Description& d, std::uint32_t reference, bool hasStencilView) {
    const auto read = static_cast<std::uint32_t>(d.StencilReadMask);
    const auto readOnlyEqual = [](const auto& face) {
        return face.StencilFunc == 3 && face.StencilFailOp == 1 &&
            face.StencilDepthFailOp == 1 && face.StencilPassOp == 1;
    };
    return hasStencilView && d.DepthEnable && d.DepthWriteMask == 0 &&
        d.DepthFunc == 4 && d.StencilEnable && (read == 2 || read == 4 || read == 8) &&
        (reference & read) == read && readOnlyEqual(d.FrontFace) && readOnlyEqual(d.BackFace);
}

template<class Description>
Description relaxWadingDepth(Description d) {
    // Stencil still selects pixels. Depth and stencil writes remain unchanged;
    // only the comparison is relaxed for this read-only color pass.
    d.DepthFunc = static_cast<decltype(d.DepthFunc)>(8);
    return d;
}

// Beta 2 coverage candidate, deliberately narrower than the accepted depth
// correction. The captured base pass excludes bit 0; wading tests bit 1.
// Never generalize this to the other selected-water masks without a trace.
constexpr bool opaqueRippleColorWrites(std::uint32_t writeMask, bool blendEnable,
    bool alphaToCoverage, std::uint32_t sampleMask) {
    // The returned native base/wading passes write RGB (7), preserving alpha.
    // Alpha writes are not needed to establish visible color coverage. Keep
    // rejecting partial RGB, blending, alpha-to-coverage and partial samples.
    return (writeMask == 7 || writeMask == 15) && !blendEnable &&
        !alphaToCoverage && sampleMask == UINT32_MAX;
}

template<class Description>
bool canMarkRippleCoverage(const Description& d, std::uint32_t reference, bool writableStencil) {
    return writableStencil && reference == 3 && d.StencilReadMask == 2 &&
        d.StencilWriteMask == 255 && canRelaxWadingDepth(d,reference,true);
}

template<class Description>
bool recognizesRippleBase(const Description& d, std::uint32_t reference) {
    const auto excludesCoverage = [](const auto& face) {
        return face.StencilFunc == 6 && face.StencilFailOp == 1 &&
            face.StencilDepthFailOp == 1 && face.StencilPassOp == 1;
    };
    return reference == 1 && d.DepthEnable && d.DepthWriteMask == 0 &&
        d.DepthFunc == 4 && d.StencilEnable && d.StencilReadMask == 1 &&
        d.StencilWriteMask == 255 && excludesCoverage(d.FrontFace) && excludesCoverage(d.BackFace);
}

template<class Description>
Description markRippleCoverage(Description d) {
    d = relaxWadingDepth(d); // retain the accepted camera-artifact correction
    d.StencilWriteMask = 1; // never overwrite the water-selection or other bits
    d.FrontFace.StencilPassOp = static_cast<decltype(d.FrontFace.StencilPassOp)>(3);
    d.BackFace.StencilPassOp = static_cast<decltype(d.BackFace.StencilPassOp)>(3);
    return d;
}

constexpr bool recentRippleBase(std::uint64_t observed, std::uint64_t current) {
    // A previous-frame observation is needed when wading precedes base color.
    return observed != 0 && current >= observed && current - observed <= 1;
}
}
