#pragma once
#include <array>

namespace st {
enum class WaterRenderMode { native, simulation, osCompatibility };
constexpr WaterRenderMode waterRenderMode(bool os, bool preview, bool frameActive) {
    if (preview && frameActive) return WaterRenderMode::simulation;
    return os ? WaterRenderMode::osCompatibility : WaterRenderMode::native;
}
// SurfaceField.hlsli b11: valid denominators with every ST effect disabled.
// Both t96/t97 must also bind an immutable zero texel in compatibility mode.
constexpr std::array<float,20> inactiveSurfaceParameters() {
    return {0,0,1,0, 0,0,1,0, 1,0,0,1, 0,0,1,2, 0,20,0,0};
}
}
