#pragma once

#include "Simulation.hpp"
#include <cmath>
#include <cstdint>
#include <optional>
#include <numbers>

namespace st {
enum class WaterSource { actor, spatial, retained, nearby };
struct SelectedWater {
    float level{};
    WaterSource source{};
    bool rejectedActorSwitch{};
};

// Surface lifetime is independent of actor contact lifetime. On the bank an
// actor's cached water height can disappear or change to an exterior fallback.
// Store coordinates only, and revalidate the anchor through the engine each tick.
class WaterSelection {
public:
    static bool validLevel(float level) {
        return std::isfinite(level) && std::abs(level) <= 1e7f;
    }
    static bool exposedExteriorWater(float water, bool groundKnown, float ground) {
        return validLevel(water) && groundKnown && std::isfinite(ground) && ground < water - 1;
    }
    void reset() {
        anchor_.reset(); searchArea_.reset(); restartSearch(); nearbyQueries_ = 0;
    }
    unsigned nearbyQueries() const { return nearbyQueries_; }
    // A fixed ceiling keeps dry-land discovery from becoming a frame spike.
    static constexpr unsigned maxNearbyQueries = 8;

    // query(xy,z) returns a water height, or an invalid/sentinel height if the
    // location is not in attached water in the caller's current world/interior.
    template<class Query>
    std::optional<SelectedWater> select(std::uint32_t area, Vec2 position,
        float z, float actorLevel, float radius, Query&& query, unsigned nearbyBudget = 0) {
        nearbyQueries_ = 0;
        if (!std::isfinite(position.x) || !std::isfinite(position.y) ||
            !std::isfinite(z) || !std::isfinite(radius) || radius <= 0) {
            reset();
            return std::nullopt;
        }
        if (!searchArea_ || *searchArea_ != area || searchRadius_ != radius ||
            std::hypot(position.x-searchPosition_.x,position.y-searchPosition_.y) > radius) {
            reset(); searchArea_ = area; searchRadius_ = radius;
        }
        searchPosition_ = position;
        if (anchor_ && (anchor_->area != area ||
            std::hypot(position.x-anchor_->position.x,position.y-anchor_->position.y) > radius)) {
            anchor_.reset(); restartSearch();
        }

        const bool actorValid = validLevel(actorLevel);
        const float spatial = query(position,actorValid ? actorLevel : z);
        if (actorValid && z < actorLevel) {
            // The actor cache can report a height just above dry feet. Do not
            // discard nearby verified water for that unverified height alone.
            if (validLevel(spatial) && std::abs(spatial-actorLevel) < 2) {
                anchor_ = Anchor{area,position,actorLevel};
                return SelectedWater{actorLevel,WaterSource::actor};
            }
            // A different, spatially verified immersed body still wins at once.
            if (validLevel(spatial) && z < spatial) {
                anchor_ = Anchor{area,position,spatial};
                return SelectedWater{spatial,WaterSource::spatial};
            }
            if (anchor_ && std::abs(anchor_->level-actorLevel) >= 2) {
                const float verified = query(anchor_->position,anchor_->level);
                if (validLevel(verified) && std::abs(verified-anchor_->level) < 2)
                    return SelectedWater{anchor_->level,WaterSource::retained,true};
                reset();
            }
            // Preserve actor-only support for placed/interior water when no
            // verified alternative exists, without making a persistent anchor.
            return SelectedWater{actorLevel,WaterSource::actor};
        }
        if (validLevel(spatial) && z < spatial) {
            anchor_ = Anchor{area,position,spatial};
            return SelectedWater{spatial,WaterSource::spatial};
        }
        // A dry actor's cell fallback must not replace nearby verified water.
        // Keep the wet anchor fixed; never drag it onto the bank with the actor.
        if (anchor_) {
            const float verified = query(anchor_->position,anchor_->level);
            if (validLevel(verified) && std::abs(verified-anchor_->level) < 2) {
                if (!anchor_->hasDryReference) {
                    anchor_->referencePosition = position;
                    anchor_->hasDryReference = true;
                }
                // Hand off along a bank before the old point leaves the field.
                // Only the same water level may replace a retained dry-bank anchor.
                const float anchorDistance = std::hypot(position.x-anchor_->position.x,position.y-anchor_->position.y);
                if (anchorDistance > radius * 0.5f) {
                    // Try the previous wet offset at the player's new position
                    // first. This handles walking parallel to a river, including
                    // water in the outer half of the field. Never move blindly:
                    // the projected point must pass the same engine validation.
                    const Vec2 projected{anchor_->position.x + position.x - anchor_->referencePosition.x,
                        anchor_->position.y + position.y - anchor_->referencePosition.y};
                    if (nearbyBudget && std::hypot(projected.x-position.x,projected.y-position.y) < anchorDistance * 0.9f) {
                        ++nearbyQueries_;
                        const float projectedLevel = query(projected,anchor_->level);
                        if (validLevel(projectedLevel) && std::abs(projectedLevel-anchor_->level) < 2) {
                            anchor_->position = projected;
                            anchor_->referencePosition = position;
                            restartSearch();
                            return SelectedWater{anchor_->level,WaterSource::nearby};
                        }
                    }
                    if (auto nearby = findNearby(area,position,z,anchorDistance * 0.9f,query,nearbyBudget,anchor_->level)) {
                        anchor_ = nearby;
                        return SelectedWater{anchor_->level,WaterSource::nearby};
                    }
                }
                return SelectedWater{anchor_->level,WaterSource::retained};
            }
        }
        if (validLevel(spatial)) {
            anchor_ = Anchor{area,position,spatial};
            return SelectedWater{spatial,WaterSource::spatial};
        }
        anchor_.reset();
        if (auto nearby = findNearby(area,position,z,radius,query,nearbyBudget)) {
            anchor_ = nearby;
            return SelectedWater{anchor_->level,WaterSource::nearby};
        }
        return std::nullopt;
    }
private:
    struct Anchor {
        std::uint32_t area; Vec2 position; float level;
        Vec2 referencePosition;
        bool hasDryReference = false;
        Anchor(std::uint32_t a, Vec2 p, float h) : area(a), position(p), level(h), referencePosition(p) {}
    };
    void restartSearch() { ring_ = 1; spoke_ = 0; }
    template<class Query>
    std::optional<Anchor> findNearby(std::uint32_t area, Vec2 position, float z,
        float radius, Query& query, unsigned budget, std::optional<float> requiredLevel = {}) {
        // Sixteen concentric rings, nearest first. Continue across inactive
        // updates instead of repeating only the first handful of bank samples.
        // The center follows the player; no engine pointers or unverified levels
        // are cached. At the default field size radial spacing is 108 units.
        while (nearbyQueries_ < budget && nearbyQueries_ < maxNearbyQueries) {
            const float angle = 2 * std::numbers::pi_v<float> * float(spoke_) / float(8 * ring_);
            const float distance = radius * float(ring_) / 16;
            const Vec2 point{position.x + distance * std::cos(angle),position.y + distance * std::sin(angle)};
            if (++spoke_ == 8 * ring_) { spoke_ = 0; if (++ring_ > 16) ring_ = 1; }
            ++nearbyQueries_;
            const float level = query(point,z);
            if (validLevel(level) && (!requiredLevel || std::abs(level-*requiredLevel) < 2)) {
                restartSearch();
                Anchor candidate{area,point,level};
                candidate.referencePosition = position;
                candidate.hasDryReference = true;
                return candidate;
            }
        }
        return std::nullopt;
    }
    std::optional<Anchor> anchor_;
    std::optional<std::uint32_t> searchArea_;
    Vec2 searchPosition_{};
    float searchRadius_{};
    unsigned ring_ = 1, spoke_ = 0, nearbyQueries_ = 0;
};
} // namespace st
