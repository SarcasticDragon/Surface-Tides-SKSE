#pragma once

namespace st {
// OS intentionally retains CS's DLL and SKSE plugin names. The OS selection is
// an explicit user declaration, not identification from that shared filename.
enum class ShaderRenderer { None, BlockedCS, UnsupportedCS, OpenShaders, MissingOpenShaders };
constexpr ShaderRenderer selectShaderRenderer(bool modulePresent, bool openShaders, bool blockCS) {
    if (!modulePresent) return openShaders ? ShaderRenderer::MissingOpenShaders : ShaderRenderer::None;
    if (openShaders) return ShaderRenderer::OpenShaders;
    return blockCS ? ShaderRenderer::BlockedCS : ShaderRenderer::UnsupportedCS;
}
// Used only after the CS/OS route has been handled. ENB detection selects a
// rendering path, never a disabled state. Legacy AllowENB is not a policy input.
enum class NativeRenderer { Vanilla, ENBCoexistence, ENBIntegration };
constexpr NativeRenderer selectNativeRenderer(bool possibleENB, bool integrationRequested) {
    if (!possibleENB) return NativeRenderer::Vanilla;
    return integrationRequested ? NativeRenderer::ENBIntegration : NativeRenderer::ENBCoexistence;
}
}
