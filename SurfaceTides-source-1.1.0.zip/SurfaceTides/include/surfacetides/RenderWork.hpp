#pragma once
#include <array>
#include <cstdint>
#include <cstring>
#include <span>
#include <vector>

namespace st {
struct ShaderObjectRecord {
    const void* metadata{};
    const void* object{};
    bool operator==(const ShaderObjectRecord&) const = default;
};
// Ordered records preserve the engine's first-record-wins alias behavior.
class ShaderIndexSnapshot {
public:
    bool matches(const void* owner, const std::vector<ShaderObjectRecord>& vs,
        const std::vector<ShaderObjectRecord>& ps) const {
        return owner_ == owner && vs_ == vs && ps_ == ps;
    }
    void commit(const void* owner, const std::vector<ShaderObjectRecord>& vs,
        const std::vector<ShaderObjectRecord>& ps) {
        vs_ = vs; ps_ = ps; owner_ = owner;
    }
private:
    const void* owner_{};
    std::vector<ShaderObjectRecord> vs_, ps_;
};

struct WaterShaderKey {
    std::uint32_t vs{}, ps{};
    std::array<std::int8_t,20> vertexOffsets{};
    std::array<std::int8_t,64> pixelOffsets{};
    bool operator==(const WaterShaderKey&) const = default;
};
struct WaterShaderKeyHash {
    std::size_t operator()(const WaterShaderKey& key) const noexcept {
        std::uint64_t result = (std::uint64_t(key.vs) << 32) | key.ps;
        const auto mix = [&](const auto& offsets) {
            for (std::size_t i=0; i<offsets.size(); i+=8) {
                std::uint64_t word{};
                const auto remaining = offsets.size()-i;
                std::memcpy(&word,offsets.data()+i,remaining<8 ? remaining : 8);
                result ^= word + 0x9e3779b97f4a7c15ULL + (result<<6) + (result>>2);
            }
        };
        mix(key.vertexOffsets); mix(key.pixelOffsets);
        return static_cast<std::size_t>(result);
    }
};

// Snapshot and restore exactly b0,b1,b2,b11,b12. Contiguous ranges reduce
// API calls without touching any intervening engine/OS slots (notably b4-b6).
// Accept takes ownership of references returned by a D3D Get call.
template<class Pointer, class Get, class Accept>
void captureWaterConstants(Get get, Accept accept, bool batched) {
    constexpr unsigned slots[]{0,1,2,11,12};
    std::array<Pointer,5> raw{};
    if (batched) { get(0,3,raw.data()); get(11,2,raw.data()+3); }
    else for (unsigned i=0;i<5;++i) get(slots[i],1,raw.data()+i);
    for (unsigned i=0;i<5;++i) accept(i,raw[i]);
}
template<class Pointer, class Read, class Set>
void restoreWaterConstants(Read read, Set set, bool batched) {
    constexpr unsigned slots[]{0,1,2,11,12};
    std::array<Pointer,5> raw{};
    for (unsigned i=0;i<5;++i) raw[i]=read(i);
    if (batched) { set(0,3,raw.data()); set(11,2,raw.data()+3); }
    else for (unsigned i=0;i<5;++i) set(slots[i],1,raw.data()+i);
}
}
