#pragma once
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>

namespace st {
struct TimingStat {
    std::uint64_t count{};
    double totalMS{}, maxMS{};
    void add(double ms) { ++count; totalMS+=ms; maxMS=std::max(maxMS,ms); }
    double meanMS() const { return count ? totalMS/static_cast<double>(count) : 0; }
};
// Stack-only, disabled scopes make no clock calls. Collectors are thread-local.
class CpuTimer {
public:
    using Clock = std::chrono::steady_clock;
    explicit CpuTimer(TimingStat* target):target_(target) {
        if (target_) start_=Clock::now();
    }
    ~CpuTimer() { stop(); }
    CpuTimer(const CpuTimer&)=delete;
    CpuTimer& operator=(const CpuTimer&)=delete;
    void stop() {
        if (target_) {
            target_->add(std::chrono::duration<double,std::milli>(Clock::now()-start_).count());
            target_=nullptr;
        }
    }
private:
    TimingStat* target_{};
    Clock::time_point start_{};
};
// Avoid fixed draw-cadence aliasing: deterministic pseudo-random 1/128 sampling.
class DrawTimingSampler {
public:
    bool sample() {
        state_^=state_<<13; state_^=state_>>17; state_^=state_<<5;
        return (state_&127u)==0;
    }
private:
    std::uint32_t state_=0x61c88647u;
};
template<std::size_t Capacity=4096>
class FrameIntervals {
public:
    TimingStat stats;
    void add(double ms) { stats.add(ms); values_[next_]=ms; next_=(next_+1)%Capacity; }
    // Nearest-rank percentiles over at most the last Capacity observations.
    double percentile(double quantile) const {
        const auto n=std::min<std::uint64_t>(stats.count,Capacity);
        if (!n) return 0;
        auto copy=values_;
        std::sort(copy.begin(),copy.begin()+n);
        const auto rank=static_cast<std::size_t>(std::ceil(std::clamp(quantile,0.0,1.0)*static_cast<double>(n)));
        return copy[rank ? rank-1 : 0];
    }
    std::size_t retained() const { return static_cast<std::size_t>(std::min<std::uint64_t>(stats.count,Capacity)); }
    void reset() { stats={}; next_=0; }
private:
    std::array<double,Capacity> values_{};
    std::size_t next_{};
};
}
