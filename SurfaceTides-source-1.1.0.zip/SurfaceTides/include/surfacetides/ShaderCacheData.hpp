#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <cstring>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace st {
using Digest = std::array<std::uint8_t,32>;
class Sha256 {
public:
    void add(std::span<const std::uint8_t> bytes) {
        size_+=bytes.size();
        for (auto byte:bytes) { block_[used_++]=byte; if (used_==64) { transform(); used_=0; } }
    }
    void add(std::string_view text) { add({reinterpret_cast<const std::uint8_t*>(text.data()),text.size()}); }
    Digest finish() {
        const auto bits=size_*8;
        block_[used_++]=0x80;
        if (used_>56) { std::fill(block_.begin()+used_,block_.end(),0); transform(); used_=0; }
        std::fill(block_.begin()+used_,block_.begin()+56,0);
        for (unsigned i=0;i<8;++i) block_[63-i]=static_cast<std::uint8_t>(bits>>(i*8));
        transform();
        Digest result{};
        for (unsigned i=0;i<8;++i) for (unsigned j=0;j<4;++j)
            result[4*i+j]=static_cast<std::uint8_t>(state_[i]>>(24-8*j));
        return result;
    }
private:
    void transform() {
        constexpr std::uint32_t k[]{
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
            0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
            0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
            0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
        std::uint32_t w[64]{};
        for (unsigned i=0;i<16;++i) for (unsigned j=0;j<4;++j) w[i]=(w[i]<<8)|block_[4*i+j];
        for (unsigned i=16;i<64;++i) {
            const auto a=w[i-15], b=w[i-2];
            w[i]=w[i-16]+(std::rotr(a,7)^std::rotr(a,18)^(a>>3))+w[i-7]+(std::rotr(b,17)^std::rotr(b,19)^(b>>10));
        }
        auto a=state_[0],b=state_[1],c=state_[2],d=state_[3],e=state_[4],f=state_[5],g=state_[6],h=state_[7];
        for (unsigned i=0;i<64;++i) {
            const auto t1=h+(std::rotr(e,6)^std::rotr(e,11)^std::rotr(e,25))+((e&f)^(~e&g))+k[i]+w[i];
            const auto t2=(std::rotr(a,2)^std::rotr(a,13)^std::rotr(a,22))+((a&b)^(a&c)^(b&c));
            h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;
        }
        state_[0]+=a;state_[1]+=b;state_[2]+=c;state_[3]+=d;state_[4]+=e;state_[5]+=f;state_[6]+=g;state_[7]+=h;
    }
    std::array<std::uint32_t,8> state_{0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    std::array<std::uint8_t,64> block_{};
    std::uint64_t size_{};
    unsigned used_{};
};
inline Digest sha256(std::span<const std::uint8_t> data) { Sha256 hash;hash.add(data);return hash.finish(); }
inline std::string hexDigest(const Digest& digest) {
    constexpr char digits[]="0123456789abcdef";
    std::string result;result.reserve(64);
    for (auto byte:digest) { result+=digits[byte>>4];result+=digits[byte&15]; }
    return result;
}
// Length-delimited components prevent ambiguous concatenations in cache keys.
inline void hashPart(Sha256& hash, std::string_view part) {
    std::array<std::uint8_t,8> size{};
    for (unsigned i=0;i<8;++i) size[i]=static_cast<std::uint8_t>(std::uint64_t(part.size())>>(8*i));
    hash.add(size);hash.add(part);
}
inline Digest shaderCacheKey(std::string_view context, std::string_view target,
    std::string_view defines, std::string_view source, std::uint32_t flags,
    std::string_view vertexLayout={},std::string_view pixelLayout={}) {
    Sha256 hash;
    hashPart(hash,"SurfaceTides shader cache format 1/main");hashPart(hash,context);
    hashPart(hash,target);hashPart(hash,defines);hashPart(hash,source);
    hashPart(hash,vertexLayout);hashPart(hash,pixelLayout);
    hashPart(hash,std::to_string(flags));return hash.finish();
}
constexpr std::size_t maxShaderBytes=8*1024*1024, cacheHeaderBytes=80;
inline std::vector<std::uint8_t> encodeShaderCache(const Digest& key, std::span<const std::uint8_t> code) {
    if (code.empty() || code.size()>maxShaderBytes) return {};
    std::vector<std::uint8_t> result(cacheHeaderBytes+code.size());
    std::memcpy(result.data(),"STCSO001",8);
    for (unsigned i=0;i<8;++i) result[8+i]=static_cast<std::uint8_t>(std::uint64_t(code.size())>>(8*i));
    std::copy(key.begin(),key.end(),result.begin()+16);
    const auto checksum=sha256(code);std::copy(checksum.begin(),checksum.end(),result.begin()+48);
    std::copy(code.begin(),code.end(),result.begin()+cacheHeaderBytes);return result;
}
inline std::span<const std::uint8_t> decodeShaderCache(std::span<const std::uint8_t> file,const Digest& key) {
    if (file.size()<=cacheHeaderBytes || file.size()>cacheHeaderBytes+maxShaderBytes ||
        std::memcmp(file.data(),"STCSO001",8) || !std::equal(key.begin(),key.end(),file.begin()+16)) return {};
    std::uint64_t length=0;
    for (unsigned i=0;i<8;++i) length|=std::uint64_t(file[8+i])<<(8*i);
    if (length!=file.size()-cacheHeaderBytes) return {};
    auto code=file.subspan(cacheHeaderBytes);const auto checksum=sha256(code);
    if (!std::equal(checksum.begin(),checksum.end(),file.begin()+48)) return {};
    return code;
}
struct WaterPermutation {
    std::uint32_t vs{},ps{};
    bool operator==(const WaterPermutation&) const=default;
};
constexpr std::size_t maxPrewarmPairs=32;
inline bool rememberPermutation(std::vector<WaterPermutation>& pairs,WaterPermutation pair) {
    if (std::find(pairs.begin(),pairs.end(),pair)!=pairs.end()) return false;
    if (pairs.size()>=maxPrewarmPairs) pairs.erase(pairs.begin());
    pairs.push_back(pair);return true;
}
inline std::vector<WaterPermutation> prewarmPlan(std::span<const WaterPermutation> learned) {
    // Observed in returned logs. No fabricated native metadata or thousands of
    // speculative variants. The renderer must find each pair in current records.
    constexpr std::uint32_t seeds[]{0x5000,0x5001,0x11e,0x31e,0x410e,0x430e,0x434e,0x35e,0x3002,0x15e,0x71e};
    std::vector<WaterPermutation> result;
    for (auto id:seeds) result.push_back({id,id});
    for (auto it=learned.rbegin();it!=learned.rend();++it) {
        const auto pair=*it;
        if (result.size()>=maxPrewarmPairs) break;
        if (std::find(result.begin(),result.end(),pair)==result.end()) result.push_back(pair);
    }
    return result;
}
inline std::vector<std::uint8_t> encodePrewarmHistory(std::span<const WaterPermutation> pairs) {
    if (pairs.size()>maxPrewarmPairs) return {};
    std::vector<std::uint8_t> bytes(8+pairs.size()*8);
    std::memcpy(bytes.data(),"STPAIRS1",8);
    for (std::size_t i=0;i<pairs.size();++i) for (unsigned j=0;j<4;++j) {
        bytes[8+8*i+j]=static_cast<std::uint8_t>(pairs[i].vs>>(8*j));
        bytes[12+8*i+j]=static_cast<std::uint8_t>(pairs[i].ps>>(8*j));
    }
    return bytes;
}
inline std::vector<WaterPermutation> decodePrewarmHistory(std::span<const std::uint8_t> bytes) {
    if (bytes.size()<8 || bytes.size()>8+8*maxPrewarmPairs || (bytes.size()-8)%8 || std::memcmp(bytes.data(),"STPAIRS1",8)) return {};
    std::vector<WaterPermutation> pairs;
    for (std::size_t i=8;i<bytes.size();i+=8) {
        WaterPermutation pair;
        for (unsigned j=0;j<4;++j) { pair.vs|=std::uint32_t(bytes[i+j])<<(8*j);pair.ps|=std::uint32_t(bytes[i+4+j])<<(8*j); }
        rememberPermutation(pairs,pair);
    }
    return pairs;
}
}
