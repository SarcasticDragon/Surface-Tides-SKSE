#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>

namespace st {
// Addresses can change without changing the immediate-context COM object.
// Each accepted address keeps a permanent index for its own native trampoline.
template<std::size_t Kinds = 7, std::size_t Capacity = 8>
class DrawDispatchRegistry {
public:
    using Address = std::uintptr_t;
    using Targets = std::array<Address,Kinds>;
    enum class Error { none, nullTarget, differentKindAlias, capacity };
    struct Plan {
        Targets targets{};
        std::array<std::size_t,Kinds> indices{};
        std::array<bool,Kinds> added{};
        Error error{};
        explicit operator bool() const { return error == Error::none; }
    };
    std::optional<std::size_t> find(std::size_t kind, Address target) const {
        for (std::size_t i=0;i<counts_[kind];++i)
            if (targets_[kind][i]==target) return i;
        return {};
    }
    std::size_t count(std::size_t kind) const { return counts_[kind]; }
    Address target(std::size_t kind, std::size_t index) const { return targets_[kind][index]; }
    Plan plan(const Targets& current) const {
        Plan result; result.targets=current;
        for (std::size_t kind=0;kind<Kinds;++kind) {
            if (!current[kind]) { result.error=Error::nullTarget; return result; }
            for (std::size_t other=0;other<Kinds;++other) if (other!=kind) {
                if (current[other]==current[kind] || find(other,current[kind])) {
                    result.error=Error::differentKindAlias; return result;
                }
            }
            if (auto existing=find(kind,current[kind])) result.indices[kind]=*existing;
            else {
                if (counts_[kind]==Capacity) { result.error=Error::capacity; return result; }
                result.indices[kind]=counts_[kind]; result.added[kind]=true;
            }
        }
        return result;
    }
    // Commit only after all requested native hooks have been installed. A failed
    // installation leaves the registry, existing indices and trampolines intact.
    bool commit(const Plan& p) {
        if (!p) return false;
        const auto expected=plan(p.targets);
        if (!expected || expected.indices!=p.indices || expected.added!=p.added) return false;
        for (std::size_t kind=0;kind<Kinds;++kind) if (p.added[kind])
            targets_[kind][counts_[kind]++]=p.targets[kind];
        return true;
    }
private:
    std::array<std::array<Address,Capacity>,Kinds> targets_{};
    std::array<std::size_t,Kinds> counts_{};
};
}
