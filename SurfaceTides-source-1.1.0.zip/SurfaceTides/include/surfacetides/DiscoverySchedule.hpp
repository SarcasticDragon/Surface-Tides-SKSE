#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <vector>

namespace st {
// Cell identities only: engine pointers/iterators must be rebuilt for each slice.
class DiscoverySchedule {
public:
    bool synchronize(std::uint64_t area, std::span<const std::uint32_t> cells) {
        if (area == area_ && std::equal(cells.begin(),cells.end(),cells_.begin(),cells_.end())) return false;
        cells_.assign(cells.begin(),cells.end()); area_=area; cursor_=0; running_=false; next_=0;
        return true;
    }
    // Call at most once per update, and only after the previous cell's queue drains.
    std::optional<std::size_t> nextCell(double now) {
        if (cells_.empty()) return {};
        if (!running_) {
            if (now < next_) return {};
            cursor_=0; running_=true; next_=now+1.0;
        }
        const auto result=cursor_++;
        if (cursor_==cells_.size()) running_=false;
        return result;
    }
    void reset() { cells_.clear(); area_=0; cursor_=0; running_=false; next_=0; }
private:
    std::vector<std::uint32_t> cells_;
    std::uint64_t area_{};
    std::size_t cursor_{};
    bool running_{};
    double next_{};
};

// The first candidate always makes progress. One engine operation cannot be
// preempted, so this is a soft time budget plus a hard candidate-count limit.
struct DiscoveryInspectionBudget {
    static constexpr std::size_t limit=8;
    static constexpr double seconds=0.0002;
    double start{};
    std::size_t completed{};
    bool available(double now) const { return completed<limit && (!completed || now-start<seconds); }
};
}
