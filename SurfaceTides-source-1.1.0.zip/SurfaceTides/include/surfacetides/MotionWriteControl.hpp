#pragma once
#include <cstdint>
#include <iterator>

namespace st {
// Shader descriptors are independently checked: a mixed color/stencil pair
// must never change the output-merger state.
inline bool isWaterStencilPair(std::uint32_t vertex, std::uint32_t pixel) {
    return ((vertex >> 11) & 15u) == 10u && ((pixel >> 11) & 15u) == 10u;
}

// Works with D3D11_BLEND_DESC. Preserve the *effective* original state of all
// other targets when enabling independent masks; inactive array entries are
// ignored by D3D11 when IndependentBlendEnable is false.
template<class Description>
Description withoutMotionTargetWrites(Description original) {
    if (!original.IndependentBlendEnable)
        for (std::size_t i = 1; i < std::size(original.RenderTarget); ++i)
            original.RenderTarget[i] = original.RenderTarget[0];
    original.IndependentBlendEnable = true;
    original.RenderTarget[1].RenderTargetWriteMask = 0;
    return original;
}
}
