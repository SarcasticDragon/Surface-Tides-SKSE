#pragma once
#include <cstdint>

namespace st {
// Classification is separate from simulation ownership: a future lava addon
// must supply its own physics/material path, while decorative puddles stay native.
enum class SurfaceKind : std::uint8_t { Water, Lava, DecorativePuddle };
struct SurfaceCatalog {
    std::uint32_t puddleBase{}, lavaBase{}, forgeLavaBase{}, lavaWater{};
};
struct SurfaceIdentity {
    std::uint32_t base{}, water{};
    bool lavaMaterial{};
};
constexpr bool knownFormMatch(std::uint32_t known, std::uint32_t actual) {
    return known != 0 && known == actual;
}
constexpr SurfaceKind classifySurface(const SurfaceCatalog& catalog, SurfaceIdentity object) {
    if (knownFormMatch(catalog.puddleBase,object.base)) return SurfaceKind::DecorativePuddle;
    if (knownFormMatch(catalog.lavaBase,object.base) || knownFormMatch(catalog.forgeLavaBase,object.base) ||
        knownFormMatch(catalog.lavaWater,object.water) || object.lavaMaterial) return SurfaceKind::Lava;
    return SurfaceKind::Water;
}
constexpr bool baseSimulationEligible(SurfaceKind kind) { return kind == SurfaceKind::Water; }
// A forwarding scope is authoritative even for ordinary water. Never substitute
// a later geometry hint for its copied identity; no hint remains permissive.
constexpr SurfaceKind drawSurface(SurfaceKind current, bool forwarded, SurfaceKind copied) {
    return forwarded ? copied : current;
}
}
