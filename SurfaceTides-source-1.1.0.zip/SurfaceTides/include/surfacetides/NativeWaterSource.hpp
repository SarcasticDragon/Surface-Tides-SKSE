#pragma once
// SPDX-License-Identifier: GPL-3.0-or-later
// Transforms PREPROCESSED, openly supplied OS source. Unknown contracts fail closed.
#include <regex>
#include <stdexcept>
#include <string>
#include <string_view>
namespace st {
struct NativeWaterMode { bool vertex{}, stencil{}, uv{}, color{}; };
inline void nativeReplace(std::string& source,const std::string& pattern,const std::string& replacement) {
    const std::regex re(pattern);
    const auto count=std::distance(std::sregex_iterator(source.begin(),source.end(),re),std::sregex_iterator());
    if (count!=1) throw std::runtime_error("OS source contract is missing or ambiguous: "+pattern);
    source=std::regex_replace(source,re,replacement);
}
inline std::string augmentNativeWater(std::string source,const std::string& field,NativeWaterMode m) {
    if (source.find("STOSVertexCore")!=std::string::npos || source.find("STOSPixelCore")!=std::string::npos)
        throw std::runtime_error("OS source already augmented");
    if (std::regex_search(source,std::regex(R"(:\s*TEXCOORD14\b)")))
        throw std::runtime_error("OS source uses reserved ST varying");
    nativeReplace(source,R"((struct\s+VS_OUTPUT\s*\{)([^}]*)(\}))","$1$2\n float STOSBaseHeight : TEXCOORD14;\n$3");
    if (m.vertex) {
        nativeReplace(source,R"(VS_OUTPUT\s+main\s*\(\s*VS_INPUT\s+input\s*\))","VS_OUTPUT STOSVertexCore(VS_INPUT input)");
        source+=R"(
VS_OUTPUT main(VS_INPUT input) {
    float4 original=float4(input.Position.xyz,1);
    float3 absolute=mul(World[0],original).xyz+FrameBuffer::CameraPosAdjust[0].xyz;
    input.Position.xyz+=STWorldToLocalOffset(World[0],float3(0,0,STHeight(absolute,false)));
    VS_OUTPUT result=STOSVertexCore(input);
    result.STOSBaseHeight=absolute.z;
)";
        if (m.stencil) source+=R"(
    result.PreviousWorldPosition=mul(PreviousWorld[0],original);
    result.PreviousWorldPosition.z+=STHeight(result.PreviousWorldPosition.xyz+FrameBuffer::CameraPreviousPosAdjust[0].xyz,true);
)";
        source+=R"(
    return result;
}
VS_INPUT STOSControl(VS_INPUT input) { input.Position.w=1; return input; }
struct STOSFactors { float edge[3]:SV_TessFactor; float inside:SV_InsideTessFactor; };
float STOSEdge(float3 a,float3 b) {
    // Preserve the accepted ST detail/fade policy and 1..64 menu range.
    float2 center=STPatch.xy+0.5*(STOptions.x-1)*STPatch.z;
    float2 ab=b.xy-a.xy;
    float t=saturate(dot(center-a.xy,ab)/max(1,dot(ab,ab)));
    float distanceToPatch=length(a.xy+t*ab-center);
    float influence=1-smoothstep(0.72,0.95,distanceToPatch/(STOptions.x*STPatch.z));
    float detail=clamp(ceil(length(b-a)/max(8,STDebug.y)),1,STOptions.w);
    return max(1,ceil(lerp(1,detail,influence*STStatus.x)));
}
STOSFactors STOSPatch(InputPatch<VS_INPUT,3> p) {
    float3 a=mul(World[0],float4(p[0].Position.xyz,1)).xyz+FrameBuffer::CameraPosAdjust[0].xyz;
    float3 b=mul(World[0],float4(p[1].Position.xyz,1)).xyz+FrameBuffer::CameraPosAdjust[0].xyz;
    float3 c=mul(World[0],float4(p[2].Position.xyz,1)).xyz+FrameBuffer::CameraPosAdjust[0].xyz;
    STOSFactors f;
    f.edge[0]=STOSEdge(b,c);f.edge[1]=STOSEdge(c,a);f.edge[2]=STOSEdge(a,b);
    f.inside=max(f.edge[0],max(f.edge[1],f.edge[2]));
    float2 center=STPatch.xy+0.5*(STOptions.x-1)*STPatch.z;
    float2 ab=b.xy-a.xy,bc=c.xy-b.xy,ca=a.xy-c.xy;
    float2 acenter=center-a.xy,bcenter=center-b.xy,ccenter=center-c.xy;
    float sa=ab.x*acenter.y-ab.y*acenter.x;
    float sb=bc.x*bcenter.y-bc.y*bcenter.x;
    float sc=ca.x*ccenter.y-ca.y*ccenter.x;
    float area=ab.x*(c.y-a.y)-ab.y*(c.x-a.x);
    bool contains=abs(area)>1e-5&&((sa>=0&&sb>=0&&sc>=0)||(sa<=0&&sb<=0&&sc<=0));
    if (contains && STStatus.x>0) {
        float longest=max(length(ab),max(length(bc),length(ca)));
        f.inside=max(f.inside,clamp(ceil(longest/max(8,STDebug.y)),1,STOptions.w));
    }
    return f;
}
[domain("tri")][partitioning("integer")][outputtopology("triangle_cw")]
[outputcontrolpoints(3)][patchconstantfunc("STOSPatch")][maxtessfactor(64)]
VS_INPUT STOSHull(InputPatch<VS_INPUT,3> p,uint i:SV_OutputControlPointID) { return p[i]; }
[domain("tri")]
VS_OUTPUT STOSDomain(STOSFactors f,float3 b:SV_DomainLocation,const OutputPatch<VS_INPUT,3> p) {
    VS_INPUT input=(VS_INPUT)0;
    input.Position=p[0].Position*b.x+p[1].Position*b.y+p[2].Position*b.z;
)";
        if (m.uv) source+="input.TexCoord0=p[0].TexCoord0*b.x+p[1].TexCoord0*b.y+p[2].TexCoord0*b.z;\n";
        if (m.color) source+="input.Color=p[0].Color*b.x+p[1].Color*b.y+p[2].Color*b.z;\n";
        source+="return main(input);\n}\n";
    } else {
        nativeReplace(source,R"(PS_OUTPUT\s+main\s*\(\s*PS_INPUT\s+input\s*\))","PS_OUTPUT STOSPixelCore(PS_INPUT input)");
        if (!m.stencil) {
            // Preprocessors may separate punctuation from identifiers. Match
            // HLSL tokens, not one compiler's spelling of member access.
            nativeReplace(source,R"(\bfloat3\s+normal\s*=\s*waterData\s*\.\s*normal\s*;)",R"(
    float3 stosPosition=float3(input.WPosition.xy+FrameBuffer::CameraPosAdjust[0].xy,input.STOSBaseHeight);
    float4 stosField=STSample(stosPosition,false);
    float3 normal=normalize(waterData.normal+float3(-stosField.yz*STOptions.y,0));
)");
        }
        source+="\nPS_OUTPUT main(PS_INPUT input) {\n PS_OUTPUT result=STOSPixelCore(input);\n";
        if (!m.stencil) source+=R"(
    if (STDebug.x>0.5) result.Lighting.rgb=STDiagnosticColor(float3(input.WPosition.xy+FrameBuffer::CameraPosAdjust[0].xy,input.STOSBaseHeight));
)";
        source+="return result;\n}\n";
    }
    return field+"\n"+source;
}
}
