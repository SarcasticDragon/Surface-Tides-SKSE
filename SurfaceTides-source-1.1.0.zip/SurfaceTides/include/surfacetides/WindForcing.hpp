#pragma once

#include <cassert>
#include <cmath>
#include <cstdint>
#include <span>
#include <vector>

namespace st {
// Evaluate the existing two world-space wind waves using angle addition.
// Axis caches are O(n), rather than a second n*n field. They contain no time
// recurrence, so long runs cannot accumulate oscillator drift. No allocations
// occur in fill(), including when the surface scrolls or its wet mask changes.
class WindForcing {
public:
    void resize(std::size_t resolution) {
        x_.resize(resolution); y_.resize(resolution); valid_ = false;
    }

    double fill(float originX, float originY, float spacing, double time,
        std::span<const std::uint8_t> wet, std::span<float> output) {
        const auto n = x_.size();
        assert(n != 0 && wet.size() == n*n && output.size() == n*n);
        if (!valid_ || originX != originX_ || originY != originY_ || spacing != spacing_) {
            for (std::size_t i = 0; i < n; ++i) {
                // Preserve the original float world-coordinate calculation
                // before promoting it for the double-precision phase math.
                const double wx = originX + static_cast<float>(i) * spacing;
                const double wy = originY + static_cast<float>(i) * spacing;
                x_[i] = basis(wx * 0.009, wx * 0.015);
                y_[i] = basis(wy * 0.004, -wy * 0.008);
            }
            originX_ = originX; originY_ = originY; spacing_ = spacing; valid_ = true;
        }
        const auto t = basis(time * 1.4, time * 2.1);
        double sum = 0; std::size_t wetCount = 0;
        for (std::size_t y = 0; y < n; ++y) {
            const auto& row = y_[y];
            const double s1 = row.s1*t.c1 - row.c1*t.s1;
            const double c1 = row.c1*t.c1 + row.s1*t.s1;
            const double s2 = row.s2*t.c2 - row.c2*t.s2;
            const double c2 = row.c2*t.c2 + row.s2*t.s2;
            for (std::size_t x = 0; x < n; ++x) {
                const auto i = y*n + x;
                if (!wet[i]) { output[i] = 0; continue; }
                const auto& column = x_[x];
                output[i] = static_cast<float>((column.s1*c1 + column.c1*s1) +
                    0.45*(column.s2*c2 + column.c2*s2));
                sum += output[i]; ++wetCount;
            }
        }
        return wetCount ? sum / static_cast<double>(wetCount) : 0;
    }

private:
    struct Basis { double s1{}, c1{}, s2{}, c2{}; };
    static Basis basis(double first, double second) {
        return {std::sin(first),std::cos(first),std::sin(second),std::cos(second)};
    }
    std::vector<Basis> x_, y_;
    float originX_{}, originY_{}, spacing_{};
    bool valid_ = false;
};
} // namespace st
