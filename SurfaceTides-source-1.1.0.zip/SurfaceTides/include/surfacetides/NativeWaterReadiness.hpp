#pragma once
// SPDX-License-Identifier: GPL-3.0-or-later
#include <atomic>
namespace st {
// Compiler workers record readiness; Present publishes it to the draw hooks.
// A known augmentation failure disables every native ST pass for this session.
// In particular, a valid stencil program must not run alone after color fails.
class NativeWaterReadiness {
public:
    void succeeded(bool vertex, bool stencil) {
        stages_.fetch_or(1u << ((stencil ? 2u : 0u) + (vertex ? 0u : 1u)));
    }
    void failed() { failed_.store(true); }
    void nextFrame() { enabled_.store(stages_.load() == 15u && !failed_.load()); }
    bool canRender() const { return enabled_.load() && !failed_.load(); }
    bool hasFailure() const { return failed_.load(); }
    unsigned readyStages() const { return stages_.load(); }
private:
    std::atomic<unsigned> stages_{};
    std::atomic<bool> failed_{}, enabled_{};
};
}
