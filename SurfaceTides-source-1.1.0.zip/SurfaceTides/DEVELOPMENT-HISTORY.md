# Historical development checkpoints

These notes preserve prior test states. Follow README.md and docs/RELEASE-1.1.0.md for the final release.

# Surface Tides 1.1.0-beta.12-water-discovery.1 — development test

This test checkpoint adds verified nearby-water acquisition and shore-side
anchor handoff to public Beta 11. See the [test instructions and diagnosis](docs/WATER-DISCOVERY-beta12-test.1.md).
The AE16 DLL is supplied as an overlay; in-game acceptance is pending. This
source copy leaves the published Beta 11 release and the separate lava prototype
unchanged. The baseline description below is retained for reference.

## Public Beta 11 baseline

The baseline is the public Beta 11 source matching the complete OS/ENB/Vanilla FOMOD.
It includes all accepted water fixes and performance work since Beta 1 through
the lava/puddle exclusions. The lava prototype is maintained separately and is
not compiled or shipped in this branch. The earlier ripple-only Beta 11 source
is superseded by this public rollup.

Start with [installation, changes and known limits](docs/BETA-1.1.0-beta.11.md)
and [installer authoring](docs/FOMOD-beta.11.md). The OS profile now uses native
OS Water replacement ON. OptimizeDiscovery is enabled for broader beta testing;
field size and quality defaults are unchanged. Fourteen portable test suites
and all three runtime builds are checked; in-game stress testing remains needed.

## Historical development notes

Everything below records earlier checkpoints, including superseded defaults,
version labels, pending tests and compatibility instructions. Use the current
public release notes above for installation. Prototype implementation and its
private evidence are excluded; preceding asset research is retained as history.

## Previous checkpoint: accepted exclusions and inspected lava assets

The user confirms the exclusions work. The returned AE16/native-OS log confirms
17,707 reported lava draws and 14,462 puddle draws bypassed ST, with native
readiness F/F throughout and zero augmentation failures/rejected draws. Keep the
current surface-exclusions-test.1 DLL; no runtime code changed in this checkpoint.
See [acceptance and asset findings](docs/LAVA-ASSETS-2026-10-03.md).

All seven supplied NIFs were parsed read-only. `Lava1024` is the activator whose
winning model is `Water\Water1024.nif`; a separate Lava1024.nif is not missing
from this setup. The visible pool is the flat `DweSpecialForgeLava01:0` effect-
shader shape, alongside four animated bubble shapes. Lava03 is the vertical
column and remains out of scope. The following sections are historical checkpoints.

## Previous exclusion test candidate

That AE16 candidate was `1.1.0-beta.12-surface-exclusions-test.1`.
It leaves the reviewed Forge lava and WaterPuddle draws with their original
renderer, using object/water identities rather than banning the shared
Water1024 mesh. Native OS test-2 rendering and the accepted performance work
remain the baseline. In-game exclusion acceptance was subsequently received.
See [test instructions and exact scope](docs/SURFACE-EXCLUSIONS-beta12-test.1.md).

Target-four A/B logs show smaller discovery peaks with a small average CPU
increase. Keep `OptimizeDiscovery=1` for broader testing; the packaged default
has not changed. See [the measured return](docs/PERFORMANCE-beta12-discovery-return.md).

## Previous checkpoint: accepted native OS Water; target 4 resumed

The user accepts native test 2 visually and considers this correctness work
complete for now. The matching AE16/OS 2.13 log reports readiness F/F throughout,
zero augmentation failures, zero rejected native draws, and working private-cache
reuse. See [accepted checkpoint and target-4 test](docs/OS-NATIVE-beta12-ACCEPTED.md).

Keep the same `1.1.0-beta.12-os-native-test.2` DLL. Its existing target-four code
is tested by setting `[Performance] OptimizeDiscovery=1` and restarting, with
timing enabled. No DLL rebuild, shader-cache clear, or replacement INI is needed.
Default remains 0 until the performance/visual return. The user is beginning that
test while lava feasibility is investigated; lava implementation follows target 4.
See [lava feasibility and next evidence](docs/LAVA-FEASIBILITY-2026-10-03.md).

## Historical native test 2 candidate

[Native OS test 2](docs/OS-NATIVE-beta12-test.2.md) addresses the test-1 return:
stencil augmentation succeeded but all five color-PS attempts were rejected by
the normal-source matcher. The matcher now tolerates member-access whitespace.
A known augmentation failure disables all native ST augmentation for the session,
and activation waits for color/stencil VS/PS at a frame boundary. This is a new
compiled candidate; visual refraction acceptance is pending. The user confirms
normal OS water after removing ST; that return also rebuilt OS's disk cache.

## Prior native checkpoint — 2026-10-02

The user also accepts the Unified Water enabled on/off return visually; no new log accompanied that acceptance. Both accepted adapter configurations remain the baseline. The next priority is native OS Water replacement ON and simple ST removal, ahead of further performance work.

[Native OS test 1](docs/OS-NATIVE-beta12-test.1.md) adds a separately opted-in `OSNativeWater=1` path. It augments copies of OS's actual compiled water source/feature definitions, leaves OS files/settings/cache intact, and returns directly to native OS rendering when inactive. An initial OS shader rebuild teaches ST the recipes; subsequent use has a private content/compiler-keyed cache. Compiled candidate only; in-game acceptance remains pending. The older accepted adapter stays available with `OSNativeWater=0`.

## Accepted adapter checkpoint

The user confirms correct on/off behavior with beta.12-os-state-test.1,
WaterEffects enabled and Unified Water disabled. The matching JSON/logs confirm
OS Water replacement OFF and ST OSUnifiedWater=0. Successful water bindings and
compatibility-only draws continue through preview-off, with zero failed draws.
See [acceptance and remaining checks](docs/OS-TOGGLE-beta12-ACCEPTED.md).

New concrete uninstall lead: SettingsUser(2).json has CS Utility.water.waveAmplitude=0.
OS v2.13's own shader uses zero to flatten surface normals; its default is1.
Restoring this value is the next no-ST visual check. ST does not write OS settings;
the origin of the zero value is unknown. No uninstall success has been claimed.

The subsequent user report also accepts the toggle with UW enabled on both sides
(OS feature on and ST OSUnifiedWater=1); no new log was supplied for that return.
The accepted DLL remains available as a fallback. The false-height-switch guard was not
triggered in this return; keep observing rare spontaneous stops. Discovery remains
untested and off. Preserve accepted wind, ENB and Beta11 installer checkpoints.

## Earlier checkpoints below

# Active candidate: Beta 12 OS state test 1 — 2026-10-02

Correctness work takes priority over discovery performance testing. The 095353
log records a river-height switch from -250 to an unverified actor height
-107.1443, followed by an inactive frame 50ms later. The new candidate protects
still-attached, revalidated nearby water from that false immersion and retains
OS compatibility rendering when the simulation is off or temporarily absent.
See [candidate, uninstall control and test instructions](docs/OS-STATE-beta12-test.1.md).

Latest uninstall control: re-enabling OS Water replacement changed pale water
into mirror-like water but did not fix it. The uninstall problem is unresolved.
Next requested: ST absent, OS Water ON, UW disabled at boot; return the winning
SettingsUser.json and Data/Shaders/Water.hlsl. See the candidate notes. Do not
repeat the failed Water-on-only control or claim the candidate repairs uninstall.

Target four remains untested and now defaults off (OptimizeDiscovery=0); its
implementation and previous source checkpoint are preserved. Accepted wind,
cache/prewarm, ENB ripple/camera and pond work remain. No field-size reduction.
The DLL is AE16 only, labeled 1.1.0-beta.12-os-state-test.1; do not promote until
in-game results. The full Beta 11 installer is unchanged.

## Historical checkpoints below

# Active source: Beta 12 discovery test 1

The wind performance change is accepted from the returned ENB A/B logs. The current candidate implements only target four: one-cell foam/ice-decal discovery slices, deferred handle-based shape inspection, phase timings, and an independent OptimizeDiscovery switch. See [discovery scope, comparison and limits](docs/PERFORMANCE-beta12-discovery-test.1.md). The DLL label is 1.1.0-beta.12-discovery-test.1. Await in-game results before promoting this discovery candidate.

Preserve simulation size/detail, wind math, pond retention, ENB ripple/camera correction, OS support and caching. Target five is deferred. Record the user's larger-field request for later menu/coverage work; the existing resolution/spacing controls already permit field-size adjustments, but this test changes neither them nor their defaults. Keep the accepted wind-test overlay and Beta 11 installer as rollback checkpoints.

## Historical checkpoints below

# Active source: Beta 12 performance test 1

The Deep Folk Crossing dry-bank fix is now accepted by the user and corroborated by stable pond height/epoch in the returned log. Preserve it. The next priority is the original performance target three: game-thread simulation wind math and recurring work. This candidate caches the continuous wind terms while retaining the original math through OptimizeSimulation=0 for comparison. It is an AE16 DLL-only test over Beta 11, not a new full FOMOD.

See [performance test, benchmark and comparison instructions](docs/PERFORMANCE-beta12-test.1.md) and [accepted pond return](docs/POND-beta11-ACCEPTED.md). All accepted rendering/OS/pond behavior is retained; changes are confined to continuous wind evaluation, its switch and tests. The full log label is 1.1.0-beta.12-performance-test.1. Local solver gains require an in-game timing/visual return before promotion. Preserve the released Beta 11 and accepted pond overlays/source as rollback checkpoints. Subsequent release numbering continues from Beta 11.

## Historical checkpoints below

# Active source: Beta 11 pond test 1

This source snapshot contains the unaccepted AE16 dry-bank retention candidate. The separately packaged complete Beta 11 FOMOD and its source ZIP preserve the accepted coverage.2 implementation. Use the full log label `1.1.0-beta.11-pond-test.1` to identify this test; both builds share packed revision 15. See [pond test instructions and limits](docs/POND-beta11-test.1.md). Return the same bank-crossing clip and fresh log before promoting the candidate. The accepted checkpoint notes below remain applicable to the installer.

# Surface Tides — accepted Beta 11 checkpoint

The user has accepted coverage.2: ENB ripples and mid-distance water both look correct. The planned Beta 2 is now **Beta 11**; subsequent betas count upward. The full FOMOD contains that accepted fix, the camera correction, OS integration and shader caching/prewarming. It rebuilds all three runtime profiles with the Beta 11 label and supplies MeshWadingDepth=1 and MeshRippleCoverage=1 in every full INI. Beta 1 remains a rollback checkpoint.

See [Beta 11 install and known issues](docs/BETA-1.1.0-beta.11.md), [acceptance evidence](docs/ENB-RIPPLE-beta11-ACCEPTED.md), and [packaging recipe](docs/FOMOD-beta.11.md). The returning pond water-exit reset is investigated in a **separate** [AE16 dry-bank test](docs/POND-beta11-test.1.md), not included in the accepted installer. Keep color investigation deferred and preserve the user's absence of previous underwater defects. No ENB implementation inspection is permitted.

## Historical checkpoints below

# Current investigation: Beta 2 ENB ripple coverage test 2

The returned coverage.1 run restores water tiles but applies **zero** ripple protection: an incorrect RGBA-only guard rejects the native RGB-only color passes. The **coverage.2** candidate accepts complete RGB writes with optional alpha, preserving the native blend state and every other coverage/depth guard. The returned run therefore does not establish whether the stencil-marking proposal works when active.

See [coverage.2 installation, evidence and limits](docs/ENB-RIPPLE-beta2-coverage.2.md). This AE16 overlay preserves the current INI and all shaders, and still needs an in-game result. Keep base-test.1 disabled. Beta 1 remains the released checkpoint; OS, caching/prewarming and the accepted ENB camera correction remain intact.

## Earlier candidate checkpoint

# Current investigation: Beta 2 ENB ripple coverage

The user confirms that base-color isolation removes ripple clipping. Its mid-distance missing water is consistent with the diagnostic suppressing the ordinary tiles. The new **ripple-coverage.1** candidate restores base geometry and marks successful primary wading pixels for the observed base-water stencil exclusion. It retains the accepted camera correction and requires a matching recent base pass on the same views. This candidate needs an in-game result; Beta 1 remains the released checkpoint.

See [install, test, rollback and integration limits](docs/ENB-RIPPLE-beta2-coverage.1.md). Disable the old shader-only diagnostic. This focused overlay supplies an AE16 DLL and the default MeshInput shader, preserves the working INI, and defaults MeshRippleCoverage to 1. Source HLSL is unchanged. No ENB implementation inspection is permitted. Previous underwater issues remain absent and color work stays parked.

# Surface Tides 1.1.0-beta.1 — packaged ENB fix

The complete Beta 1 FOMOD now includes the accepted ENB camera-artifact correction for all three runtime profiles, alongside shader caching/prewarming, the accumulated OS support and OS/ENB/Vanilla choices. It installs a fresh full INI with MeshWadingDepth=1. ENB presence blocking stays removed; regular CS remains incompatible with its configurable guard.

The exact enb-depth.1 DLLs are reused without recompilation. The returned Skyrim 1.6.1170 test confirms the camera fix; the user's previous underwater issues are absent in current testing. Minor native ENB ripple clipping is a **Beta 2 target**. Broader stress testing and the parked color investigation remain open. The DLL log retains its enb-depth.1 label for traceability; installer and SKSE machine revision are 1.1.0.12.

Use [Beta 1 installation and known issues](docs/BETA-1.1.0-beta.1.md), [installer authoring](docs/FOMOD-beta.1.md), [promotion validation](docs/beta.1-final-validation.json), and [current priorities](docs/OS-ROADMAP-2026-09-24.md). Back up custom tuning, replace the previous installation and disable older test overlays. All 336 installer paths and 56 full INIs are checked; this does not substitute for a mod-manager UI test. The source retains prior development evidence and the [accepted ENB result](docs/ENB-DEPTH-beta.1-ACCEPTED.md).

## Historical release notes below

These entries record earlier states. The beta instructions above supersede older CS compatibility claims, ENB presence guards, disabled-OS-effects instructions and runtime restrictions.

# Surface Tides runtime previews — AE17 preview 2 / SE preview 1

Compatibility testing branch based on the accepted 1.0.2 release.

- `ST_RUNTIME=SE`: exact Skyrim 1.5.97 target, SKSE 2.0.20, matching SE Address Library.
- `ST_RUNTIME=AE17`: exact Skyrim 1.7.104 target, SKSE 2.3.1, matching Address Library v13.
- `ST_RUNTIME=AE16` (default): retains the existing 1.6.1170 / 1.6.1179 target selection for source maintenance.

AE17 preview 1 aborted on Address Library ID 13358. [Preview 2](docs/RUNTIME-COMPATIBILITY-1.1.0-preview.2.md) replaces that water query with the mapped cell API. The SE preview 1 DLL is carried forward. These are candidate runtime ports, pending in-game testing. See the [original compatibility notes](docs/RUNTIME-COMPATIBILITY-1.1.0-preview.1.md) for build commands. The released 1.0.2 package remains the tested baseline; historical documentation below describes that release.

---

# Surface Tides 1.0.2

Version 1.0.2 keeps spatially verified nearby water active after the player leaves it. This addresses an interior water-height cache loss that previously deactivated the simulation and erased wakes on reentry. No rendering, solver, removal or bobbing algorithm changed. Portable regression tests and the Windows build are checked before packaging; the Ragged Flagon result still needs the user's game test. See [WATER-RETENTION-1.0.2.md](docs/WATER-RETENTION-1.0.2.md) and [resume checkpoint](docs/RESUME-1.0.2.md).

The complete INI keeps the same keys/defaults as 1.0.1. FOMOD choices select exactly one of 24 full INIs; standalone foam adds a separate BOS file, giving 48 total combinations. The DLL uses defaults when the INI is missing and does not generate one at startup. Small DLL update overlays deliberately preserve the existing INI.

The user has confirmed the 1.0.1 Frozen Marsh decal update works. It adds six attached slush profiles and three standalone frost profiles under the existing HideIceDecals option. Four inspected solid-only models remain untouched. Bobbing stays limited to the original three models. See [FROZEN-MARSH-1.0.1.md](docs/FROZEN-MARSH-1.0.1.md) for scope and historical validation.

Independent SKSE/D3D11 water-surface simulation. No Community Shaders or ENB installation is required. Version 1.0 promotes the user-accepted 0.1.25 implementation, with a FOMOD installer. Broader stress testing continues.

**Runtime gate: Steam 1.6.1170 and GOG 1.6.1179 only**, with the matching SKSE 2.2.6 and AE Address Library. **1.7.104 is not supported.** Do not remove the version gate without auditing the changed engine and shader layouts.

Install the FOMOD ZIP through a mod manager; its selected files place `SKSE` and `Shaders` inside Data. There is no ESP or Papyrus script. Configuration is in `SKSE/Plugins/SurfaceTides.ini`; the optional SKSE Menu Framework page updates tuning live. Startup renderer switches still require a restart. Logs go to the normal SKSE log directory as `SurfaceTides.log`. Standalone rendering and ENB water-off coexistence are supported by user testing. The latter is confirmed in one ENB 0.505/Silent Horizons 2 setup with FYX and Water for ENB textures; broader stress testing continues. CS water-off coexistence passed its first user test in 0.1.25; full ENB water integration is experimental with known unresolved visual defects. No save records are written.

## Version 1.0 installation

The wizard offers standalone, ENB water-off or CS water-off operation, plus independent attached/standalone foam removal, flat ice removal and solid ice bobbing. Standalone foam removal requires Base Object Swapper; bobbing remains incompatible with Ice is Slick. The installer writes a complete INI: **back up custom tuning and cleanly replace old installations rather than merging deselected optional files**. Simulation, shaders and object behavior are unchanged from accepted 0.1.25; DLL edits are version/status strings only.

See [release instructions](docs/RELEASE-1.0.md), [FOMOD authoring guide](docs/FOMOD-1.0.md) and [resume checkpoint](docs/RESUME-1.0.md). XML and all 48 selection combinations pass automated validation. Actual MO2/Vortex wizard interaction still needs a user click-through. Earlier sections below record development history; their pending-test instructions are superseded by subsequent accepted results.

## Accepted initial test: Community Shaders coexistence

The old DLL disabled Surface Tides unconditionally when CS was loaded. Version0.1.25 adds `[Compatibility] AllowCS=1` as a startup opt-in. The separate CS test installer includes a partial CS settings override disabling Water shader replacement, UnifiedWater and WaterEffects at boot; other CS settings are retained. The simulation, accepted water shaders and ice/foam/jump behavior remain unchanged. Compilation and all45 portable groups pass. The user now confirms normal simulation and no immediate visual issues with CS; the returned log confirms active water tessellation with no draw failures or warnings. Sustained stress testing remains. See [CS-0.1.25-ACCEPTED.md](docs/CS-0.1.25-ACCEPTED.md) for the recorded result. See [CS-0.1.25.md](docs/CS-0.1.25.md) and [RESUME-0.1.25.md](docs/RESUME-0.1.25.md) for installation, logging and limitations.

## Accepted: jump release

The user confirms0.1.24.3's jump change works well. Preserve that exact installer/source as the accepted pre-CS baseline. The earlier testing status below is historical.

The user reports rare residual drift in 0.1.24.2, acceptable for now, but jumps can animate without gaining height. Version 0.1.24.3 releases rider carry on an early jump request and waits for ground-contact confirmation before resuming. The engine's jump handler is forwarded unchanged. The DLL builds and all45 portable groups pass; in-game takeoff still needs confirmation. **Ice is Slick is incompatible with ice bobbing for now**, with integration deferred by agreement. See [FLOES-0.1.24.3.md](docs/FLOES-0.1.24.3.md) and [RESUME-0.1.24.3.md](docs/RESUME-0.1.24.3.md).

## Previous: rider drift candidate

Version 0.1.24.1 improved walking, but the user reports some sliding after stopping, independently of Ice is Slick. That mod makes movement blocking return. Version 0.1.24.2 computes the carry delta locally in double precision and avoids setting velocity unless the position update actually changed it. Small diagnostic counters distinguish normal carry from velocity repair. The DLL builds and all 43 portable groups pass; runtime drift reduction remains unverified. Ice is Slick is a reported conflict with bobbing pending further investigation. See [FLOES-0.1.24.2.md](docs/FLOES-0.1.24.2.md) and [RESUME-0.1.24.2.md](docs/RESUME-0.1.24.2.md).

## Previous: rider locomotion hotfix

The user confirms the three ice models look good in 0.1.24, but walking is blocked while bobbing. Version 0.1.24.1 replaces per-update actor repositioning with additive live character-controller offsets and preserves linear velocity. All other floe management, water rendering and settings behavior remain unchanged. The DLL builds and all 41 portable test groups pass; in-game walking/riding confirmation is pending. See [FLOES-0.1.24.1.md](docs/FLOES-0.1.24.1.md) and [RESUME-0.1.24.1.md](docs/RESUME-0.1.24.1.md).

## Previous: three-model floe bobbing

Version 0.1.24 extends the accepted crest-following behavior to eligible loaded placements of `icefloessolid01.nif`, `icefloes01.nif` and `icefloessolid02.nif` within the active local water field. Each reference has independent motion, collision tracking and rider handling. Discovery and dense sampling are spread across frames, with at most 64 managed floes. The existing `FloeBobbingTest=1` opt-in carries forward when the new `FloeBobbing` key is absent. Current live controls apply to all managed floes under Floating ice. See [FLOES-0.1.24.md](docs/FLOES-0.1.24.md) and [RESUME-0.1.24.md](docs/RESUME-0.1.24.md).

The user reports the three-model visuals look good. The returned log confirms six active floes across all three models with low collision errors and no blocked references. Rider locomotion is defective in this version and addressed by the current candidate; broader stress and streaming testing continues. Disconnected chunks within one NIF move as one rigid object; splitting those assets is deferred beyond initial release.

## Accepted: adjustable floe crest following

The user confirms 0.1.23 prevents clipping on the selected test floe. The strong discoloration was isolated to their ENB/Silent Horizons 2 preset; behavior in other presets is untested. Version 0.1.23 adds bounded crest-based lift with live SKSE Menu Framework controls and an original-motion comparison button. See [FLOES-0.1.23.md](docs/FLOES-0.1.23.md) for its historical implementation notes. Its exact installer remains the immediate accepted rollback.

## Accepted: selected floe water lookup correction

The next returned log confirms the old reference water value was the finite no-water sentinel (-3.40282e+38), while the spatial query correctly returns -14000. The target now acquires and moves. IcyFixes stayed installed. The neighbouring-floe overlap in the video is an existing placement issue according to the user and is outside this change.

The first 0.1.22 log finds E7B8A and its reviewed model, but every acquisition attempt stops at the combined area/water gate. No motion or collision conversion occurred. Version 0.1.22.1 resolves water through the engine's position/cell query rather than the static reference's cached/owner-cell height. Area, attachment and water-band checks remain enforced. Diagnostics now include the actual values. Keep IcyFixes installed for the next test; the log does not establish an override conflict. See [FLOES-0.1.22.1.md](docs/FLOES-0.1.22.1.md). Compiled and binary/source checks passed; the corrected lookup and motion still need in-game confirmation.

## Selected floe motion and three ice profiles

Version 0.1.22 extends `HideIceDecals` to the three inspected floe models and adds opt-in `[Objects] FloeBobbingTest=1` for `0x0E7B8A~Skyrim.esm` outside Septimus Signus' outpost. It follows the actual surface field with bounded height/tilt, uses engine keyframed collision, checks collision tracking, and handles grounded riders identified by support-body identity. The DLL builds and 32 portable test groups pass. In-game collision/rider testing is pending. See [FLOES-0.1.22.md](docs/FLOES-0.1.22.md) for installation, scope, diagnostics and rollback. No Bobbing Framework, CS or ENB dependency was added.

## Accepted: solid01 slush removal

The user confirms the 0.1.21 `[Objects] HideIceDecals=1` filter appears to work for the supplied `icefloessolid01.nif`: only `L1_IceFloesSolidSlush` is hidden, retaining solid ice and collision. [ICE-0.1.21.md](docs/ICE-0.1.21.md) records that first profile. Preserve its accepted ZIP for rollback.

The 0.1.21 CPU sampling/footprint groundwork is now consumed by the 0.1.22 runtime prototype. Its first game test should verify both the visible ice and collision before widening reference coverage.

## Accepted: reviewed static foam

**0.1.20 is withdrawn for an attached-foam load crash.** The [0.1.20.1 hotfix](docs/FOAM-0.1.20.1.md) avoids the bundled global reference iterator's stale AE worldspace read. It uses the player cell/worldspace and attached grid instead. The user confirms the crash is gone and initial attached-foam behavior is correct; wider location testing continues. This fix is retained in 0.1.21. Preserve 0.1.20.1 and 0.1.19.2 as accepted rollback packages.

Optional `[Objects] HideAttachedFoam=1` hides only the reviewed foam child shapes in the supplied FXrapidsRocks01 and WRRapidRocks01 variants, retaining the winning rocks and existing collision. It defaults off and requires a restart. A separate BOS preset disables the three confirmed standalone foam bases. Waterfall impact rings remain. See [FOAM-0.1.20.md](docs/FOAM-0.1.20.md) for the original findings. No game/mod NIF files are distributed.

## Accepted baseline: underwater draw forwarding correction

The user ruled out Underwater NG and the contact-fade test. The affected region ends at the boundary of cell(0,-15). New trace data shows the game-facing topology getter reporting patches while the underlying underwater draw uses triangles; the exact forwarding gate consequently misses draws. Version0.1.19.2 tracks the game's topology setter, keeping strict native draw matching. It includes the accepted shader, not the unsuccessful contact-fade diagnostic. **The user confirms the underwater gaps are gone (2026-09-15).** See [TOPOLOGY-0.1.19.2.md](docs/TOPOLOGY-0.1.19.2.md) for evidence, testing and rollback. Preserve this exact build for sustained stress testing.

## Later: broader surface-object coverage

Continue stress testing the reviewed foam/slush coverage and three-model floe motion, then evaluate additional affected objects. Dynamic foam and splitting disconnected ice chunks are deferred until after initial release. Bobbing Framework's inspected source has no external surface-height provider; JSON alone cannot synchronize it. See [SURFACE-OBJECTS.md](docs/SURFACE-OBJECTS.md) and the optional load-order helper in tools/xedit. No dependency on that framework was added.

## Previous: INI saving hotfix

The user confirms all menu settings and the0.1.19.1 INI-save correction work. The correction fixes a false failure in the cache-flush step that prevented Save tuning from replacing the INI. See [MENU-0.1.19.1.md](docs/MENU-0.1.19.1.md). It is retained in0.1.19.2.

## Previous: optional menu for stress testing

Install the menu update after the working build. It preserves your INI and includes the exact accepted shoreline shader. Open **Surface Tides / Settings** in SKSE Menu Framework 3.x. Most tuning applies live; grid changes use Apply grid; renderer startup settings remain read-only. Save/Reload tuning and session-start restore are provided. Without the framework the simulation works as before.

See [MENU-0.1.19.md](docs/MENU-0.1.19.md) for controls, build validation, limitations and the next-work checkpoint. The DLL is compiled, portable tests pass, and in-game verification remains with the user. All earlier diagnostic instructions below are historical; do not revert the accepted shader.

## Previous: shoreline fragments fixed in both tested configurations

The user confirms that the primary-wading depth correction removes the fragments in the standard near-vanilla environment and with ENB loaded/master water disabled. Preserve the exact tested0.1.18 DLL and correction shader. **Keep the wading-depth overlay enabled**, restore Interaction.Strength=4, set Diagnostics.RippleTrace=0 and retain LogStats=1, then restart for full-wake testing. Earlier instructions to remove this overlay are superseded. No rendering change accompanies this documentation checkpoint.

The correction is accepted in these setups; its narrow depth override still needs safeguards for a broad release. CS coexistence remains unimplemented/gated. See [WADING-DEPTH-TEST.md](docs/WADING-DEPTH-TEST.md) and wading-depth-confirmed-result.json for the confirmed outcome and the remaining work. The package retains its diagnostic filename to preserve artifact identity/history.

## Historical: test depth rejection in the primary wading color pass

The native trace captured a separate moving Water2048 wading mesh with depth writes off and LESS_EQUAL testing. Original shoreline artifacts persist; the earlier suppression smear is gone. SurfaceTides-0.1.18-wading-depth-diagnostic.zip tests that depth comparison in PS015E only while retaining its full shading and geometry. Install after the0.1.18/r4 baseline, keep the existing Strength0/displacement2/normal2/DebugView0 controls, restart and repeat look–walk–look. Return the result/log and note any new water over solid objects. This is a temporary diagnostic, not a production fix. Deactivate it to restore r4 afterward. See [WADING-DEPTH-TEST.md](docs/WADING-DEPTH-TEST.md) for evidence, limits and validation. All older next-test instructions below are historical.

## Historical: restore r4 rendering; capture native water draw metadata

The WADING suppression test caused severe repeated-image smearing, so it is withdrawn. Version0.1.18 changes diagnostic capture only and restores the complete shoreline-r4 shader in the overlay. Install SurfaceTides-0.1.18-native-water-trace.zip last, set Diagnostics.RippleTrace=1 / LogStats=1, keep Interaction.Strength=0 and the existing comparison settings, restart, and record the same look–walk–look sequence for about45seconds. Return the log. The original minor artifact may remain; this build is not a claimed fix. Disable the overlay and restore Strength4 / RippleTrace0 afterward. See [NATIVE-WATER-TRACE.md](docs/NATIVE-WATER-TRACE.md) for exact controls, limitations, continuity and rollback. **All older next-test instructions below are historical and superseded.**

## Historical: actor wakes excluded; wading surface draw diagnostic

The artifact persists with Interaction.Strength0. Camera movement reproduces it after the character has walked, superseding the earlier camera-only inference. The new SurfaceTides-0.1.17-wading-surface-diagnostic.zip suppresses visible above-water WADING draws, preserving base-water simulation and separate stencil/motion passes. Install last over r4, keep Strength0 / DisplacementStrength2 / NormalStrength2 / DebugView0, restart, and repeat look–walk–look. Report original artifacts and any missing water coverage. Restore r4/Strength4 afterward. This is a diagnostic, not a fix; holes would make disappearance of artifacts inconclusive. See docs/WADING-SURFACE-ISOLATION.md. The earlier native-ripple and actor-force tests below are complete and must not be repeated.

## Earlier: native ripple isolation returned no improvement

Native ripples disappeared but shoreline artifacts remain. Restore0.1.17 shoreline-r4 after each temporary shader test and restart. Next, on r4, change only Interaction.Strength to0; retain full displacement2, normal strength2 and debug0, restart and walk the same route. This removes actor forcing while preserving wind waves and grid movement. Restore Strength4 afterward. Source remains available; no binary/shader/solver change in this follow-up. See docs/NATIVE-RIPPLE-ISOLATION.md and native-ripple-returned-result.json. Persistent saving is still unavailable; this is a local documentation update only.

## Earlier: native ripple normal isolation

The light-pass diagnostic did not fix the artifact. User comparisons found RW2 clean at the tested location, Wavy Waters affected, and no reproduction with detached-camera movement alone. The Water for ENB2.19/Shades/4K environment is restored unchanged. No common defective asset has been established.

SurfaceTides-0.1.17-native-ripple-diagnostic.zip temporarily removes the material-scaled native WADING ripple normal texture from above-water shaders while retaining SurfaceTides height displacement, actor wakes, idle waves and all geometry. Install last over the current r4 comparison, leave DebugView=0 and other settings unchanged, restart, walk through the shoreline and stop briefly. Flat native ripple shading may be absent. Disable the overlay/restart afterward. This is a diagnostic, not a fix. See docs/NATIVE-RIPPLE-ISOLATION.md for full continuity, limitations and next steps; older "next test" instructions below are historical and superseded.

The source was recovered from the user's pre-light-pass archive, not the inaccessible later version38. The new checkpoint has a distinct filename. Durable save was unavailable this session; retain the delivered source ZIP.

## Earlier: native TAA already off; diagnostic color view

The user confirms native TAA is already disabled; AA is normally supplied by ENB in their usual setup. ENB remains absent from the current comparison. Skip the TAA test. R4 did not improve the shoreline artifact. Next set Diagnostics.DebugView=1 in the active SurfaceTides.ini and restart, retaining r4, full displacement and the same Water for ENB2.19/Shades of Skyrim/4K setup. Compare whether the fragments appear in the colored water surface or only in normal shading, then restore DebugView=0. See docs/SHORELINE-COVERAGE-CONTROL.md. No new shader or binary is needed.

## Earlier result: r4 did not improve the artifact

The user reports no new banding but no improvement from r4. Sequence #1(18).mp4 shows the same shoreline/wake area with camera movement; no new log accompanies it. R4 is not an accepted fix. The next control is native TAA disabled, keeping the current r4 shader, full displacement, Water for ENB2.19/Shades of Skyrim/4K and ENB absent. If TAA is already disabled, report that and skip the test. See docs/SHORELINE-R4-RESULT.md. No new shader, binary or installer in this follow-up.

## Earlier: displacement control confirmed; shoreline-r4 candidate

The user reports the artifact disappears with General.Enabled=0 and also with Enabled=1 / Rendering.DisplacementStrength=0 while retaining NormalStrength=2. The reported setup is Water for ENB2.19, Shades of Skyrim,4K, with ENB removed. Displacement is required to expose the artifact in these comparisons; the specific mesh/material mechanism remains unresolved.

The r4 shader overlay softens the full water color at thin contacts with the opaque scene, using the actual displaced surface depth. It preserves r1 refraction and r3 depth blending; it does not reduce wave geometry or change underwater/stencil rendering. This is a contact-shading candidate, not a confirmed fix or collision simulation. See docs/SHORELINE-R4.md. Install SurfaceTides-0.1.17-shoreline-r4.zip after the current SurfaceTides files, restore Enabled=1 / DisplacementStrength=2 / NormalStrength=2, restart and compare the same shoreline with the existing Water for ENB version and ENB absent. No DLL/INI in the overlay; startup version remains0.1.17.

Source ST_SHORE_CONTACT_BLEND defaults0, preserving r1 default rendering. The candidate overlay enables both contact blending and displaced-depth blending. Default shader outputs match source version34; the latest full installer remains r1 until a candidate is confirmed.

## Earlier shoreline result: artifact persists without ENB

The user reports no meaningful fix from r3 after removing ENB and retaining Water for ENB. The new log shows system graphics DLLs, a shared native context, advancing simulation and no failed water draws. Its ENB-water-OFF label is explained by a leftover enbseries.ini, not evidence of an active ENB graphics wrapper. The cause remains unresolved; neither Water for ENB meshes nor textures have been isolated.

Next, hold the current shader files and load order constant. First compare with General.Enabled=0 and restart. Only if that is clean, restore Enabled=1 and compare with Rendering.DisplacementStrength=0, retaining NormalStrength=2; restart again. Restore Enabled=1 and DisplacementStrength=2 afterward. These controls separate whether SurfaceTides is required from whether its geometry displacement is required. Do not also roll the shader back between these comparisons. See docs/SHORELINE-NATIVE-CONTROLS.md. No executable, shader or preset changes accompany this checkpoint; no additional installer is needed.

## Earlier shoreline-r3 candidate

A (refraction distortion off) made no visible change; B (SSR off) appeared to restore shoreline bleed. These user observations do not isolate the cause. Code review found that depth-controlled water color/reflection blending still used the rest plane after geometry displacement. The r3 shader overlay adjusts that plane to the actual displaced surface while preserving r1 refraction and ordinary SSR. The latest user test reports the artifact remains; r3 is not a confirmed fix.

Install SurfaceTides-0.1.17-shoreline-r3.zip after SurfaceTides/r1, disable diagnostic overlays A/B, let r3 Water.hlsl win, and restart with ENB water OFF. No DLL/INI changes. Disabling r3 returns to the underlying r1 shader. See docs/SHORELINE-R3.md. Source ST_DISPLACED_DEPTH_BLEND defaults0, keeping default rendering unchanged; only the test overlay enables it. Latest full installer remains r1 until a fix is confirmed.

## Earlier diagnostic follow-up

User reports shoreline-r1 partly contains the terrain bleed, but fragments remain inside the water. The latest log shows ongoing simulation/rendering and successful shader compilation. The cause is unresolved. Two temporary shader overlays isolate refraction distortion (A) and our screen-space reflections (B). Enable one at a time above r1 and restart between tests; keep ENB water OFF. They contain no DLL or INI. See docs/SHORELINE-DIAGNOSTICS-R2.md.

Source defaults still compile identically to r1. The new ST_DIAGNOSTIC_NO_SSR macro defaults to0 and is for these diagnostic overlays, not an INI control or permanent rendering change. The latest full installer remains r1; neither diagnostic is adopted as a fix.

## Current candidate and confirmed baseline

**0.1.17 standalone and ENB water-OFF coexistence are user-confirmed.** The latest ENB coexistence test works normally until Water for ENB is added; shoreline rocks then show small intermittent refraction artifacts. This does not establish a mesh defect. The source now contains the **shoreline-r1 shader candidate** for that report. Its visual result remains unverified.

The candidate changes only above-water, depth-supported refraction in Water.hlsl. It compares scene depth with the rasterized displaced surface, fades distortion at shallow intersections and rejects foreground/off-screen samples. It leaves simulation, normals, geometry stages, underwater shading, hooks and compatibility settings unchanged. This is a shader-only update: DLL and startup version remain0.1.17. See docs/SHORELINE-R1.md for the evidence, limitations and rollback.

Install SurfaceTides-0.1.17-shoreline-r1.zip as a separate mod after the confirmed0.1.17 coexistence package, let its Water.hlsl win, then restart Skyrim. It contains no DLL or INI. Keep ENB master water OFF and Experimental.ENBWaterIntegration=0. Disable this overlay and restart to restore the confirmed shader. Compare the same shoreline without changing wave settings; a short clip and normal SurfaceTides.log are sufficient. Detailed traces remain off.

The preserved0.1.17 baseline has neither ripple clipping nor underwater gaps in rivers/lakes in the user's tests. Its four standalone shader files match the preserved0.1.9 coexistence package, whose shaders and preset were unchanged from0.1.6. The candidate changes Water.hlsl only; those earlier packages remain the visual rollback.

An optional source preset lives in presets/enb-water-off/SurfaceTides.ini and sets AllowENB=1, experimental integration0. Save ENB [EFFECT] EnableWater=false before launch and keep it off. The standard source preset retains AllowENB=0. CS coexistence is still the next separate compatibility task, after this shoreline investigation; its startup gate remains.

This is a renderer-neutral project. Neither ENB nor Community Shaders is required or affiliated. Existing third-party credits and licenses remain intact. No ENB implementation code, shader contents or SDK is used in this candidate.

## Optional compatibility and experimental path

| Mode | Configuration | Status |
| --- | --- | --- |
| SurfaceTides standalone | Supplied defaults; no external renderer loaded | Baseline user-confirmed in rivers/lakes; shoreline-r1 pending |
| SurfaceTides water with ENB's other effects | Compatibility.AllowENB=1, Experimental.ENBWaterIntegration=0; saved ENB EFFECT.EnableWater=false and keep it off | 0.1.17 coexistence user-confirmed; shoreline refraction issue after adding Water for ENB is under investigation |
| Native/ENB water integration | Compatibility.AllowENB=1 and Experimental.ENBWaterIntegration=1 | Preserved experiment, disabled by default; known ripple/underwater defects and different shading |
| SurfaceTides water with CS's other effects | Separate adapter/testing still required | Not supported yet; existing startup gate remains |

The old [Compatibility] ENBMeshInput setting is ignored and logged if present. Integration now requires the explicit [Experimental] ENBWaterIntegration key. This prevents an old test INI from silently re-enabling it. MeshBounds, MeshMotionVectors, MeshTessellationMax and MeshTwoSided are now read from [Experimental] only. They have no effect on standalone rendering. Experimental mesh cap defaults to 8, custom motion VS to 0 and two-sided override to 0; the 0.1.16 cap 16/two-sided test did not fix the reported defects.

Keep ordinary water textures/materials as inputs to SurfaceTides shading where compatible. The earlier Water for ENB texture result is encouraging, not blanket support for every custom map or ENB-specific effect. No mesh files, gameplay water levels or saved records are altered.

Later shader identity/forwarding, state restoration and constant-binding repair remain in the code. Mesh preparation, native ENB stages, performance optimizations and bounded diagnostics are preserved behind their mode/diagnostic gates. Full native ENB water rendering is not mixed into the default path. See docs/RESUME-0.1.17.md for the accepted direction and exact validation limits.

## Functionality

- Persistent CPU height/vertical-velocity field, with propagation, interference, dispersion, damping, and deterministic wind forcing.
- Actor wakes and surface-entry impacts from loaded actors' position, scale, swimming state, and water height.
- Reflecting wet/dry boundaries and diffraction through openings; coarse exterior land/water mask.
- Player-following patch with world-space scrolling and reset handling for loading, teleports, and changing water levels.
- D3D11 hull/domain tessellation and water-mesh displacement, simulated gradient normals, and previous-frame displacement for the stencil/motion-vector pass.
- Adapted native-style water material, reflection, refraction, flowmap, fog, and depth shading.
- Live shader-constant mapping, input-signature checks that work with stripped native shader bytecode, per-permutation fallback, and restoration of modified D3D bindings.

Defaults: 192² samples at 20 world units, approximately a 3,840-unit-wide local patch, 48 actors, up to 64 subdivisions per edge in the standalone shader path or 8 in the optional mesh-input preset (configurable to 16). One water elevation band is active at a time. In the standalone shader path, `Tessellation=0` disables our hull/domain stages; `DisplacementStrength=0` isolates shading; `TerrainMask=0` isolates mask problems. All other options are in the INI.

## Physical scope

This is a damped linear surface-wave model: `h_t=v`, `v_t=c² L(h)-beta L(L(h))`, using a masked graph Laplacian. The positive biharmonic term gives wavelength-dependent, capillary-style dispersion. It is not exact finite-depth gravity-wave dispersion or full fluid dynamics. The CFL-limited fixed-step solver uses a boundary sponge and bounded catch-up. Impulses subtract their sampled wet-footprint mean to avoid injecting net vertical momentum.

Exterior terrain is sampled in four-cell blocks under a per-update budget. Arbitrary collision meshes and interior walls are not represented. Contacts do not use foot/hand animation bones or Havok impulses. There is no buoyancy, draining, water transfer, breaking-wave spray, persistent foam, or river-current advection. Engine water levels and gameplay swimming rules remain unchanged. Distant LOD is retained.

## Build

Windows: VS 2022 C++ tools, Windows SDK, CMake 3.25+. Dependencies are bundled as source in `vendor`, with pinned FetchContent fallbacks. No vcpkg setup is needed. The CRT is linked statically.

```powershell
cmake --preset windows-release
cmake --build --preset windows-release --parallel 2
ctest --preset windows-release
cmake --install build/windows --config Release --component SurfaceTides --prefix out/SurfaceTides
```

Zip the contents of `out/SurfaceTides` for installation. The source archive is not a mod-manager package. `validation/RunTests.cmd`, when included in the delivered source archive, runs the prebuilt numerical and native shader tests without rebuilding.

Portable numerical tests:

```sh
cmake --preset portable
cmake --build --preset portable --parallel 2
ctest --preset portable
build/portable/SurfaceTidesReference reference.bin
python 3 -m pip install numpy pillow
python 3 tools/render_preview.py reference.bin preview.gif
```

Optional clang-cl cross-build: configure Ninja with `-DCMAKE_TOOLCHAIN_FILE=cmake/windows-clang.cmake`, absolute `-DST_LLVM_BIN=...` and `-DST_WINDOWS_SYSROOT=...`, and `-DCMAKE_BUILD_TYPE=Release`. The sysroot must be an xwin MSVC/Windows SDK layout using `--use-winsysroot-style --preserve-ms-arch-notation`. This is the MSVC ABI, not the MinGW C++ ABI.

## Validation limits

See `docs/VALIDATION.md` for actual build/test results. Native SM5 compilation and game execution are distinct gates. Initial shader compilation is synchronous and can hitch; there is no disk shader cache. GPU/CPU cost, material fidelity, TAA, stencil/color agreement, tessellation winding, and engine-hook behavior require in-game testing. A failed related permutation may cause a depth/color mismatch. Device recreation requires restarting the game.

The preview is actual numerical solver output rendered schematically, with amplified slopes. It is not Skyrim footage or proof of renderer integration.

## License

GPL-3.0-or-later, with additional permission to combine this mod with Skyrim and SKSE for making/running the mod; see `licenses/SurfaceTides-Additional-Permission.txt`. No permission to redistribute proprietary game files is granted. The water shader is adapted from Community Shaders v 0.8.7 with its source credit and MIT notice retained; see `THIRD_PARTY.md`. No Skyrim assets, SKSE binaries, Address Library database, or Microsoft SDK/compiler binaries are bundled.


OS follow-up (2026-09-23): shader hotfix 1 is confirmed compiling in the returned
Skyrim log. The color-test.2 candidate and optional refraction control are
documented in docs/OPEN-SHADERS-preview.3-color-test.2.md; visual results are pending.


Returned OS test.2 result: no improvement in color or jitter with either overlay.
See docs/OPEN-SHADERS-preview.3-reflection-probe.3.md for the next
controlled diagnostic. Canonical runtime shader source is unchanged this turn.
