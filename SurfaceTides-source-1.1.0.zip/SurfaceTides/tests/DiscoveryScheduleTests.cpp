#include "surfacetides/DiscoverySchedule.hpp"
#include <array>
#include <iostream>
#include <numeric>
#include <stdexcept>

void require(bool value, const char* message) { if (!value) throw std::runtime_error(message); }
int main() {
    st::DiscoverySchedule scan;
    const std::array<std::uint32_t,4> cells{11,22,33,44};
    require(scan.synchronize(7,cells),"initial population must trigger scan");
    for (std::size_t i=0;i<cells.size();++i) {
        require(!scan.synchronize(7,cells),"stable list must preserve progress");
        require(scan.nextCell(10.0+0.02*double(i))==i,"each attached cell must be visited once");
    }
    require(!scan.nextCell(10.5),"completed sweep must respect one-second cadence");
    require(scan.nextCell(11.0)==0,"next sweep must restart at first cell");
    // Processing a dense cell's backlog takes many frames. A long pause must
    // resume the remaining cells, not repeatedly start the first cell again.
    require(scan.nextCell(15.0)==1,"slow inspection cannot starve later cells");
    require(scan.nextCell(16.0)==2 && scan.nextCell(17.0)==3,"slow sweep must complete");
    require(scan.nextCell(18.0)==0,"overdue completed sweep can restart");
    const std::array<std::uint32_t,3> changed{55,11,33};
    require(scan.synchronize(7,changed),"attach/detach/reorder must invalidate queued discovery");
    require(scan.nextCell(18.001)==0,"new current cell must be considered promptly");
    require(scan.synchronize(8,changed),"world/interior transition must invalidate same IDs");
    require(scan.nextCell(18.002)==0,"area change must restart immediately");
    require(scan.synchronize(8,{}),"unavailable cell must invalidate");
    require(!scan.nextCell(19.0),"empty cell set must never yield an index");
    scan.reset();
    require(scan.synchronize(8,changed) && scan.nextCell(19.001)==0,"disable/re-enable must start fresh");
    // No 25-cell/49-cell cap: larger attached grids retain their complete search area.
    std::vector<std::uint32_t> large(401); std::iota(large.begin(),large.end(),100u);
    scan.synchronize(99,large);
    for (std::size_t i=0;i<large.size();++i)
        require(scan.nextCell(20.0+double(i)/30.0)==i,"large/slow sweeps must cover every cell");
    // Hard count limit and soft time limit independently constrain inspections.
    st::DiscoveryInspectionBudget count{20.0};
    for (int i=0;i<8;++i) { require(count.available(20.0),"count budget ended early"); ++count.completed; }
    require(!count.available(20.0),"more than eight inspections in one update");
    st::DiscoveryInspectionBudget time{20.0};
    require(time.available(20.1),"expensive enumeration must still allow forward progress");
    ++time.completed;
    require(!time.available(20.1),"over-budget slice must yield after one candidate");
    time={20.0,1};
    require(time.available(20.0001) && !time.available(20.0003),"200us soft time gate");
    std::cout << "PASS discovery: full-area coverage, cadence, slow sweeps, cell/area invalidation, reset and inspection budgets\n";
}
