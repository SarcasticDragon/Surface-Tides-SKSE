#include "surfacetides/WaterSelection.hpp"
#include <algorithm>
#include <functional>
#include <iostream>
#include <limits>
#include <stdexcept>

namespace {
constexpr float absent = -std::numeric_limits<float>::infinity();
void require(bool condition, const char* message) { if (!condition) throw std::runtime_error(message); }
float pool(st::Vec2 p, float) { return p.x < 0 ? 100.0f : absent; }
void leaveAndReenter() {
    st::WaterSelection select;
    auto enter=select.select(1,{-20,0},90,100,500,pool);
    require(enter && enter->source==st::WaterSource::actor,"actor water rejected");
    for (int i=0;i<300;++i) {
        auto shore=select.select(1,{20,0},120,absent,500,pool);
        require(shore && shore->source==st::WaterSource::retained && shore->level==100,
            "nearby pool expired when the dry actor's water cache was absent");
    }
    auto reenter=select.select(1,{-20,0},90,100,500,pool);
    require(reenter && reenter->level==enter->level,"reentry changed water level");
}
void spatialDiscovery() {
    st::WaterSelection select;
    auto water=select.select(1,{-20,0},120,absent,500,pool);
    require(water && water->source==st::WaterSource::spatial && water->level==100,
        "spatial water needs an actor contact first");
    require(!select.select(1,{600,0},120,absent,500,pool),"distant pool retained outside local field");
    require(!select.select(1,{20,0},120,absent,500,pool),"distant anchor resurrected after returning dry");
}
void areaAndReset() {
    st::WaterSelection select;
    select.select(1,{-20,0},90,100,500,pool);
    require(!select.select(2,{20,0},120,absent,500,pool),"anchor crossed world/interior boundary");
    select.select(1,{-20,0},90,100,500,pool);
    select.reset(); // load, preview off, or explicit grid reset
    require(!select.select(1,{20,0},120,absent,500,pool),"reset retained old water");
}
void revalidate() {
    st::WaterSelection select;
    select.select(1,{-20,0},90,100,500,pool);
    require(!select.select(1,{20,0},120,absent,500,[](st::Vec2,float){return absent;}),
        "detached or unavailable water remained active");
    select.select(1,{-20,0},90,100,500,pool);
    require(!select.select(1,{20,0},120,absent,500,[](st::Vec2 p,float){return p.x<0 ? 150.f : absent;}),
        "remembered surface survived a changed rest level");
}
void unverifiedActor() {
    st::WaterSelection select;
    const auto none=[](st::Vec2,float){return absent;};
    require(bool(select.select(1,{-20,0},90,100,500,none)),"original valid actor selection regressed");
    require(!select.select(1,{20,0},120,absent,500,none),"unverified actor height became persistent anchor");
    select.select(1,{-20,0},90,100,500,pool);
    select.select(1,{20,0},90,100,500,pool); // stale actor cache on dry ground
    require(bool(select.select(1,{20,0},120,absent,500,pool)),"dry cached actor overwrote valid pool anchor");
    auto rejected=select.select(1,{20,0},180,200,500,pool);
    require(rejected && rejected->level==100 && rejected->rejectedActorSwitch,
        "unverified actor height replaced a revalidated pool");
    require(bool(select.select(1,{20,0},220,absent,500,pool)),"rejected actor switch erased the pool anchor");
}
void riverBankFalseImmersion() {
    st::WaterSelection select;
    const auto river=[](st::Vec2 p,float){return p.x<0 ? -250.f : absent;};
    select.select(0x3C,{-20,0},-250.3f,-250.f,1728,river);
    // 2026-10-02 log: -250 -> -107.1443, player Z=-107.6678;
    // an inactive frame followed 50ms later when the actor cache disappeared.
    for (int i=0;i<100;++i) {
        auto bank=select.select(0x3C,{20,0},-107.6678f,-107.1443f,1728,river);
        require(bank && bank->level==-250 && bank->rejectedActorSwitch,
            "false immersion reset the river to the bank fallback");
        auto next=select.select(0x3C,{20,0},-107.f,absent,1728,river);
        require(next && next->level==-250,"river stopped after actor fallback disappeared");
    }
    auto detached=select.select(0x3C,{20,0},-107.6678f,-107.1443f,1728,
        [](st::Vec2,float){return absent;});
    require(detached && detached->level==-107.1443f && !detached->rejectedActorSwitch,
        "unavailable old river blocked actor-only water");
    require(!select.select(0x3C,{20,0},-100.f,absent,1728,river),
        "failed revalidation retained an obsolete anchor");
    select.select(1,{-20,0},-251.f,-250.f,100,river);
    auto far=select.select(1,{200,0},-108.f,-107.f,100,river);
    require(far && far->level==-107 && !far->rejectedActorSwitch,"distant anchor blocked new body");
    select.select(1,{-20,0},-251.f,-250.f,100,river);
    auto area=select.select(2,{20,0},-108.f,-107.f,100,river);
    require(area && area->level==-107 && !area->rejectedActorSwitch,"anchor crossed world boundary");
    select.select(1,{-20,0},-251.f,-250.f,100,river);
    auto verified=select.select(1,{20,0},-108.f,-107.f,100,
        [](st::Vec2 p,float){return p.x<0 ? -250.f : -107.f;});
    require(verified && verified->level==-107 && verified->source==st::WaterSource::actor,
        "confirmed new water body was blocked");
    select.reset();select.select(1,{-20,0},-251.f,-250.f,100,river);
    auto mismatched=select.select(1,{20,0},-300.f,-107.f,100,
        [](st::Vec2 p,float){return p.x<0 ? -250.f : -280.f;});
    require(mismatched && mismatched->level==-280 && mismatched->source==st::WaterSource::spatial,
        "spatially confirmed new body lost to unrelated actor cache");
}
void sentinels() {
    st::WaterSelection select;
    for (float bad : {absent,std::numeric_limits<float>::infinity(),std::numeric_limits<float>::quiet_NaN(),1e20f}) {
        require(!select.select(1,{20,0},120,bad,500,[=](st::Vec2,float){return bad;}),"invalid height accepted");
    }
    select.select(1,{-20,0},90,100,500,pool);
    require(!select.select(1,{20,0},120,absent,0,pool),"invalid range retained anchor");
}
void wavesOutliveContacts() {
    st::Settings settings;
    settings.resolution=64; settings.spacing=10; settings.spongeCells=0;
    settings.wind=0; settings.gustStrength=0; settings.edgeDamping=0; settings.damping=0.5f;
    st::Surface surface(settings);
    st::WaterSelection select;
    st::ContactTracker contacts;
    std::vector<st::Impulse> impulses;
    auto wet=select.select(1,{-20,0},90,100,250,pool);
    surface.reset({0,0},wet->level);
    const st::Contact above{1,{-20,0},120,100,25,false};
    contacts.update(std::span(&above,1),1.0/60,impulses,4,1.5f);
    const st::Contact actor{1,{-20,0},90,100,25,false};
    contacts.update(std::span(&actor,1),1.0/60,impulses,4,1.5f);
    require(!impulses.empty(),"entry did not generate a test wake");
    for (const auto& impulse:impulses) surface.addImpulse(impulse);
    surface.advance(1.0/60);
    const double initialEnergy=surface.energy();
    require(initialEnergy>0,"entry wake has no energy");
    for (int i=0;i<120;++i) {
        auto dry=select.select(1,{20,0},120,absent,250,pool);
        require(dry && dry->level==surface.level(),"dry exit requests inactive/reset field");
        contacts.update({},1.0/60,impulses,4,1.5f);
        require(impulses.empty(),"retention fabricated a dry actor wake");
        surface.advance(1.0/60);
        require(surface.energy()>0 && surface.finite(),"waves erased after water exit");
    }
    require(surface.energy()<initialEnergy,"retained waves do not decay");
}
void dryExteriorFallback() {
    constexpr float pond=-5327.14f, fallback=-5616.f;
    auto query=[](st::Vec2 p,float) {
        const float water=p.x<0 ? pond : fallback;
        const float ground=p.x<0 ? pond-80 : pond+40;
        return st::WaterSelection::exposedExteriorWater(water,true,ground) ? water : absent;
    };
    st::WaterSelection selection;
    auto wet=selection.select(1,{-20,0},pond-28,pond,500,query);
    require(wet && wet->level==pond,"pond entry failed");
    for (int i=0;i<300;++i) {
        const float actor=i%2 ? fallback : absent;
        auto dry=selection.select(1,{30,0},pond+36,actor,500,query);
        require(dry && dry->level==pond && dry->source==st::WaterSource::retained,
            "valid below-ground cell fallback replaced the nearby pond");
    }
    require(selection.select(1,{-20,0},pond-30,pond,500,query)->level==pond,
        "reentry into retained pond changed level");
    require(!selection.select(1,{600,0},pond+40,fallback,500,query),
        "buried fallback kept a distant pond alive");
}
void switchBodiesOnlyOnEntry() {
    st::WaterSelection selection;
    auto two=[](st::Vec2 p,float){return p.x<0 ? 100.f : 30.f;};
    selection.select(1,{-20,0},90,100,500,two);
    auto bank=selection.select(1,{20,0},140,30,500,two);
    require(bank && bank->level==100 && bank->source==st::WaterSource::retained,
        "a different nearby water height stole a dry actor's active pond");
    auto entered=selection.select(1,{20,0},20,30,500,two);
    require(entered && entered->level==30 && entered->source==st::WaterSource::actor,
        "retention prevented entry into a lower water body");
    selection.reset(); selection.select(1,{-20,0},90,100,500,two);
    entered=selection.select(1,{20,0},20,absent,500,two);
    require(entered && entered->level==30 && entered->source==st::WaterSource::spatial,
        "spatially verified immersion could not change body without actor cache");
}
void terrainVerification() {
    require(st::WaterSelection::exposedExteriorWater(100,true,90),"exposed water rejected");
    for (float ground : {99.f,100.f,110.f,std::numeric_limits<float>::quiet_NaN()})
        require(!st::WaterSelection::exposedExteriorWater(100,true,ground),"buried/unknown water accepted");
    require(!st::WaterSelection::exposedExteriorWater(100,false,0),"failed terrain lookup accepted");
    require(!st::WaterSelection::exposedExteriorWater(absent,true,0),"invalid water accepted");
    st::WaterSelection select;
    require(!select.select(1,{20,0},140,30,500,[](st::Vec2,float){return absent;}),
        "unverified dry actor fallback created a simulation");
}
void fallbackWavesOutliveContacts() {
    st::Settings settings;settings.resolution=64;settings.spacing=10;
    settings.spongeCells=0;settings.wind=0;settings.gustStrength=0;settings.edgeDamping=0;settings.damping=0.5f;
    st::Surface surface(settings);st::WaterSelection selection;
    auto wet=selection.select(1,{-20,0},90,100,250,pool);
    surface.reset({0,0},wet->level);
    st::ContactTracker contacts;std::vector<st::Impulse> impulses;
    const st::Contact above{1,{-20,0},120,100,25,false},actor{1,{-20,0},90,100,25,false};
    contacts.update(std::span(&above,1),1.0/60,impulses,4,1.5f);
    contacts.update(std::span(&actor,1),1.0/60,impulses,4,1.5f);
    for (const auto& impulse:impulses) surface.addImpulse(impulse);
    surface.advance(1.0/60);const auto initial=surface.energy();require(initial>0,"wake absent");
    const st::Contact dry{1,{20,0},140,-200,25,false};
    for (int i=0;i<120;++i) {
        const auto selected=selection.select(1,{20,0},140,-200,250,pool);
        require(selected && selected->level==surface.level(),"valid dry fallback erased existing wave field");
        contacts.update(std::span(&dry,1),1.0/60,impulses,4,1.5f);
        require(impulses.empty(),"dry fallback generated a fake wake");
        surface.advance(1.0/60);require(surface.energy()>0 && surface.finite(),"wave field disappeared");
    }
    require(surface.energy()<initial,"retained wake did not decay");
}
void coldDryBankDiscovery() {
    st::WaterSelection selection;
    // The player starts 400 units inland and never provides a water cache.
    // A shoreline sample, rather than an actor contact, must create the field.
    std::optional<st::SelectedWater> selected;
    for (int tick=0;tick<150 && !selected;++tick) {
        selected=selection.select(1,{400,0},140,absent,1728,pool,8);
        require(selection.nearbyQueries()<=8,"dry-bank discovery exceeded its update budget");
    }
    require(selected && selected->level==100 && selected->source==st::WaterSource::nearby,
        "a fresh dry-bank arrival still required actor contact");
    for (int tick=0;tick<20;++tick) {
        selected=selection.select(1,{400,0},140,absent,1728,pool,8);
        require(selected && selected->level==100,"cold-discovered water was not retained");
    }
}
void continuousDryBankTraversal() {
    st::WaterSelection selection;
    auto selected=selection.select(1,{-20,0},90,100,1728,pool,8);
    require(selected && selected->level==100,"initial river contact failed");
    unsigned handoffs=0;
    // Walk 12,000 units along the dry bank, well beyond the old 1,728-unit
    // anchor lifetime. A handoff must keep the existing level active throughout.
    for (int tick=0;tick<=1000;++tick) {
        selected=selection.select(1,{40,float(tick)*12},140,absent,1728,pool,8);
        require(selected && selected->level==100,"dry-bank traversal lost its water field");
        handoffs+=selected->source==st::WaterSource::nearby;
        require(selection.nearbyQueries()<=8,"bank handoff exceeded its update budget");
    }
    require(handoffs>1,"long traversal never refreshed its nearby-water anchor");
}
void distantDryBankTraversal() {
    // Water remains inside the field while the player is more than half a
    // radius inland. Handoff must still find it before the old anchor expires.
    for (const float step:{5.f,10.f}) {
        st::WaterSelection selection;
        std::optional<st::SelectedWater> selected;
        for (int tick=0;tick<150 && !selected;++tick)
            selected=selection.select(1,{1000,0},140,absent,1728,pool,8);
        require(selected && selected->level==100,"distant dry bank failed initial acquisition");
        unsigned handoffs=0;
        for (float y=0;y<=12000;y+=step) {
            selected=selection.select(1,{1000,y},140,absent,1728,pool,8);
            if (!selected || selected->level!=100)
                throw std::runtime_error("distant-bank traversal lost its water field at step="+
                    std::to_string(step)+" y="+std::to_string(y));
            handoffs+=selected->source==st::WaterSource::nearby;
            require(selection.nearbyQueries()<=8,"distant-bank handoff exceeded its budget");
        }
        require(handoffs>1,"distant-bank traversal never refreshed its anchor");
    }
}
void boundedIncrementalSearch() {
    st::WaterSelection selection;
    const st::Vec2 position{20,30};
    float farthest=0;
    unsigned calls=0;
    auto empty=[&](st::Vec2 p,float) {
        ++calls;
        const float distance=std::hypot(p.x-position.x,p.y-position.y);
        require(distance<=500.001f,"nearby search left the configured field");
        farthest=std::max(farthest,distance);
        return absent;
    };
    require(!selection.select(1,position,140,absent,500,empty,0),"empty world acquired water");
    require(calls==1 && selection.nearbyQueries()==0,"zero search budget performed nearby queries");
    for (int tick=0;tick<150;++tick) {
        calls=0;
        require(!selection.select(1,position,140,absent,500,empty,100),"empty world acquired water");
        require(selection.nearbyQueries()<=8 && calls<=9,"large requested budget bypassed the fixed ceiling");
    }
    require(farthest>=499,"incremental search repeatedly sampled the center without reaching the field edge");
    selection.reset();calls=0;
    selection.select(1,position,140,absent,500,empty,3);
    require(selection.nearbyQueries()==3 && calls==4,"small explicit query budget was not honored");

    // A water strip at the edge cannot be discovered by repeatedly restarting
    // only the nearest ring on each inactive update.
    selection.reset();
    std::optional<st::SelectedWater> distant;
    auto farPool=[](st::Vec2 p,float) { return p.x<-490 ? 70.f : absent; };
    for (int tick=0;tick<150 && !distant;++tick)
        distant=selection.select(1,{0,0},140,absent,500,farPool,8);
    require(distant && distant->level==70,"inactive updates failed to advance the search to distant water");
}
void discoveryRejectsUnverifiedSamples() {
    struct Candidate { float water; bool groundKnown; float ground; bool attached; };
    const Candidate rejected[]={
        {100,true,120,true}, // buried cell fallback
        {100,false,0,true}, // missing terrain
        {100,true,std::numeric_limits<float>::quiet_NaN(),true},
        {absent,true,0,true},
        {std::numeric_limits<float>::infinity(),true,0,true},
        {std::numeric_limits<float>::quiet_NaN(),true,0,true},
        {1e20f,true,0,true},
        {100,true,0,false} // detached cell with an otherwise valid height
    };
    for (const auto& candidate:rejected) {
        st::WaterSelection selection;
        const auto verified=[&](st::Vec2,float) {
            return candidate.attached && st::WaterSelection::exposedExteriorWater(
                candidate.water,candidate.groundKnown,candidate.ground) ? candidate.water : absent;
        };
        for (int tick=0;tick<150;++tick)
            require(!selection.select(1,{0,0},140,absent,500,verified,8),
                "nearby discovery accepted an unavailable or below-ground sample");
    }
    st::WaterSelection selection;
    auto water=selection.select(1,{20,0},140,absent,500,pool,8);
    require(water && water->source==st::WaterSource::nearby,"test did not acquire nearby water");
    require(!selection.select(1,{20,0},140,absent,500,[](st::Vec2,float){return absent;},8),
        "a cold-discovered anchor survived detachment");
}
void discoveryAreaAndReset() {
    st::WaterSelection selection;
    require(bool(selection.select(1,{20,0},140,absent,500,pool,8)),"nearby anchor setup failed");
    auto none=[](st::Vec2,float){return absent;};
    require(!selection.select(2,{20,0},140,absent,500,none,8),"nearby anchor crossed area boundary");
    require(bool(selection.select(1,{20,0},140,absent,500,pool,8)),"nearby anchor recovery failed");
    selection.reset();
    require(!selection.select(1,{20,0},140,absent,500,none,8),"explicit reset preserved a discovered anchor");

    auto scan=[&](std::uint32_t area,st::Vec2 position,float radius) {
        std::vector<st::Vec2> offsets;
        selection.select(area,position,140,absent,radius,[&](st::Vec2 p,float) {
            if (p.x!=position.x || p.y!=position.y) offsets.push_back({p.x-position.x,p.y-position.y});
            return absent;
        },8);
        return offsets;
    };
    auto same=[](const std::vector<st::Vec2>& a,const std::vector<st::Vec2>& b) {
        if (a.size()!=b.size()) return false;
        for (std::size_t i=0;i<a.size();++i)
            if (std::hypot(a[i].x-b[i].x,a[i].y-b[i].y)>0.001f) return false;
        return true;
    };
    selection.reset();
    const auto first=scan(1,{0,0},500);
    const auto continued=scan(1,{0,0},500);
    require(!same(first,continued),"inactive scan did not advance");
    require(same(first,scan(2,{0,0},500)),"new area retained an old search cursor");
    scan(2,{0,0},500);selection.reset();
    require(same(first,scan(2,{0,0},500)),"explicit reset retained an old search cursor");
    scan(2,{0,0},500);
    require(same(first,scan(2,{1000,0},500)),"teleport retained an old search cursor");
}
void nearbyHandoffRespectsBodyPriority() {
    st::WaterSelection selection;
    auto waters=[](st::Vec2 p,float) {
        if (std::hypot(p.x+20,p.y)<30) return 100.f;
        if (p.x>800) return 30.f;
        return absent;
    };
    selection.select(1,{-20,0},90,100,1728,waters,8);
    for (int tick=0;tick<150;++tick) {
        auto bank=selection.select(1,{1000,0},140,30,1728,waters,8);
        require(bank && bank->level==100,"dry-bank handoff switched to a different water level");
    }
    auto immersed=selection.select(1,{1000,0},20,30,1728,waters,8);
    require(immersed && immersed->level==30 && immersed->source==st::WaterSource::actor,
        "nearby retention overruled verified actor immersion");
    selection.reset();selection.select(1,{-20,0},90,100,1728,waters,8);
    immersed=selection.select(1,{1000,0},20,absent,1728,waters,8);
    require(immersed && immersed->level==30 && immersed->source==st::WaterSource::spatial,
        "nearby retention overruled verified spatial immersion");
}
void projectedHandoffRequiresVerification() {
    for (const float bad:{absent,30.f,std::numeric_limits<float>::quiet_NaN(),1e20f}) {
        st::WaterSelection selection;
        bool projectedSeen=false;
        unsigned calls=0;
        auto query=[&](st::Vec2 p,float) {
            ++calls;
            if (std::hypot(p.x+20,p.y)<30) return 100.f;
            if (std::hypot(p.x+20,p.y-1000)<0.01f) {
                projectedSeen=true;
                return bad;
            }
            return absent;
        };
        selection.select(1,{-20,0},90,100,1728,query,1);
        selection.select(1,{20,0},140,absent,1728,query,1); // dry bank reference
        calls=0;
        auto retained=selection.select(1,{20,1000},140,absent,1728,query,1);
        require(projectedSeen,"test did not exercise the projected wet-offset query");
        require(retained && retained->level==100 && retained->source==st::WaterSource::retained,
            "unverified/different-level projection replaced the original wet anchor");
        require(selection.nearbyQueries()==1 && calls==3,
            "projected probe bypassed the combined nearby-query budget");
        auto originalOnly=[](st::Vec2 p,float) { return std::hypot(p.x+20,p.y)<30 ? 100.f : absent; };
        retained=selection.select(1,{20,1000},140,absent,1728,originalOnly,0);
        require(retained && retained->level==100,"rejected projection moved the remembered anchor");
    }
}
}
int main() {
    const std::pair<const char*,std::function<void()>> tests[]={
        {"dry exit and reentry",leaveAndReenter},{"spatial discovery and range",spatialDiscovery},
        {"world, interior and reset isolation",areaAndReset},{"anchor revalidation",revalidate},
        {"unverified actor cache",unverifiedActor},{"invalid engine heights",sentinels},
        {"river bank false immersion",riverBankFalseImmersion},
        {"waves outlive actor contacts",wavesOutliveContacts},
        {"dry exterior fallback retains pond",dryExteriorFallback},
        {"different water body entry",switchBodiesOnlyOnEntry},
        {"exterior terrain verification",terrainVerification},
        {"waves survive valid dry fallback",fallbackWavesOutliveContacts},
        {"cold dry-bank discovery without actors",coldDryBankDiscovery},
        {"continuous dry-bank traversal",continuousDryBankTraversal},
        {"distant dry-bank traversal at walking and running speeds",distantDryBankTraversal},
        {"bounded incremental nearby search",boundedIncrementalSearch},
        {"nearby samples require verification",discoveryRejectsUnverifiedSamples},
        {"nearby discovery area and reset",discoveryAreaAndReset},
        {"nearby handoff and immersed body priority",nearbyHandoffRespectsBodyPriority},
        {"projected handoff requires verification",projectedHandoffRequiresVerification}};
    int failed=0;
    for (const auto& [name,test]:tests) {
        try { test(); std::cout<<"PASS "<<name<<'\n'; }
        catch (const std::exception& e) { ++failed; std::cerr<<"FAIL "<<name<<": "<<e.what()<<'\n'; }
    }
    std::cout<<std::size(tests)-failed<<'/'<<std::size(tests)<<" passed\n";
    return failed ? 1 : 0;
}
