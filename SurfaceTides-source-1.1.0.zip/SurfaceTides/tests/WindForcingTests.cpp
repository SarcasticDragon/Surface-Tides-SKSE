#include "surfacetides/Simulation.hpp"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>

namespace {
void require(bool test, const char* message) { if (!test) throw std::runtime_error(message); }
float direct(float ox,float oy,float dx,int x,int y,double time) {
    const double wx=ox+x*dx, wy=oy+y*dx;
    return static_cast<float>(std::sin(wx*0.009+wy*0.004-time*1.4)+
        0.45*std::sin(wx*0.015-wy*0.008-time*2.1));
}
void fields() {
    st::WindForcing wind;
    double maxError=0, maxMeanError=0; std::size_t comparisons=0;
    for (int n : {16,31,64,192,512}) {
        wind.resize(static_cast<std::size_t>(n));
        std::vector<std::uint8_t> wet(std::size_t(n)*n,1);
        std::vector<float> values(wet.size());
        for (float dx : {4.f,20.25f,128.f})
        for (st::Vec2 origin : {st::Vec2{},st::Vec2{-169035,103400},st::Vec2{10000000,-8000000}})
        for (double time : {0.,1./120.,23.75,3600.,86400.,604800.}) {
            // Change the mask without changing the cached coordinates.
            for (int mode=0;mode<3;++mode) {
                for (std::size_t i=0;i<wet.size();++i) wet[i]=mode==0 || (mode==1 && i%7<2);
                const double mean=wind.fill(origin.x,origin.y,dx,time,wet,values);
                double expectedMean=0; std::size_t count=0;
                for (int y=0;y<n;++y) for (int x=0;x<n;++x) {
                    const auto i=std::size_t(y)*n+x;
                    if (!wet[i]) { require(values[i]==0,"dry field contains wind forcing"); continue; }
                    const auto expected=direct(origin.x,origin.y,dx,x,y,time);
                    maxError=std::max(maxError,std::abs(double(values[i])-expected));
                    expectedMean+=expected; ++count; ++comparisons;
                }
                if (count) expectedMean/=double(count);
                maxMeanError=std::max(maxMeanError,std::abs(mean-expectedMean));
            }
        }
    }
    std::cout<<"field comparisons="<<comparisons<<" maxForceError="<<maxError
        <<" maxMeanError="<<maxMeanError<<'\n';
    require(maxError<2e-6,"cached forcing differs from the accepted world-space formula");
    require(maxMeanError<2e-7,"cached forcing changes wet-cell mean subtraction");
}
void solver() {
    double maxHeight=0,maxVelocity=0; std::size_t comparisons=0;
    for (int n : {64,192}) for (bool moving : {false,true}) {
        st::Settings settings; settings.resolution=n;settings.wind=5;settings.spacing=20;
        st::Surface reference(settings,false),optimized(settings,true);
        st::Vec2 center{-167280,58680};
        reference.reset(center,-5327.14f); optimized.reset(center,-5327.14f);
        std::vector<std::uint8_t> mask(std::size_t(n)*n,1);
        for (int step=0;step<3600;++step) {
            if (moving && step%37==0) {
                center.x+=step%74 ? -80.f : 160.f;center.y+=40;
                reference.recenter(center);optimized.recenter(center);
            }
            if (step%61==0) {
                for (std::size_t i=0;i<mask.size();++i) mask[i]=(i+std::size_t(step/61))%11<7;
                reference.setWetMask(mask);optimized.setWetMask(mask);
            }
            if (step%113==0) {
                const st::Impulse impulse{center,50,75};
                reference.addImpulse(impulse);optimized.addImpulse(impulse);
            }
            if (step==1000 || step==1100 || step==2000) {
                settings.wind=step==1000 ? 0.f : 5.f;
                settings.gustStrength=step==1100 ? 0.f : 1.f;
                settings.damping=step==2000 ? 0.8f : 0.32f;
                reference.retune(settings);optimized.retune(settings);
            }
            if (step==2400) { // Reset time at an already cached origin.
                reference.reset(center,-5327.14f);optimized.reset(center,-5327.14f);
            }
            if (step==3000 && moving) {
                center={250000,-410000};reference.recenter(center);optimized.recenter(center);
            }
            reference.step();optimized.step();
            require(reference.finite() && optimized.finite(),"solver became nonfinite");
            for (std::size_t i=0;i<reference.cells().size();++i) {
                maxHeight=std::max(maxHeight,std::abs(double(reference.cells()[i].height)-optimized.cells()[i].height));
                maxVelocity=std::max(maxVelocity,std::abs(double(reference.cells()[i].velocity)-optimized.cells()[i].velocity));
                ++comparisons;
            }
            require(reference.diagnostics().steps==optimized.diagnostics().steps,"optimization changed step schedule");
            require(reference.diagnostics().clippedCells==optimized.diagnostics().clippedCells,"optimization changed clipping behavior");
        }
    }
    std::cout<<"solver comparisons="<<comparisons<<" maxHeightError="<<maxHeight
        <<" maxVelocityError="<<maxVelocity<<'\n';
    require(maxHeight<5e-4 && maxVelocity<5e-3,"optimized waves diverged from accepted solver");
}
void noWind() {
    st::Settings s;s.resolution=32;s.spongeCells=8;s.wind=0;
    st::Surface a(s,false),b(s,true);
    a.addImpulse({{0,0},30,40});b.addImpulse({{0,0},30,40});
    for(int i=0;i<300;++i){a.step();b.step();}
    for(std::size_t i=0;i<a.cells().size();++i)
        require(a.cells()[i].height==b.cells()[i].height && a.cells()[i].velocity==b.cells()[i].velocity,
            "wind-off control changed");
}
}
int main() {
    std::cout<<std::setprecision(12);
    try { fields();solver();noWind();std::cout<<"PASS wind formula, wet masks, movement/reset/retune and wind-off control\n"; }
    catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
}
