#include "surfacetides/ShaderCacheData.hpp"
#include <cstdlib>
#include <iostream>
#include <set>

namespace {
void require(bool value,const char* reason) { if (!value) { std::cerr<<reason<<'\n';std::exit(1); } }
std::string digest(std::string_view text) { st::Sha256 hash;hash.add(text);return st::hexDigest(hash.finish()); }
}
int main() {
    require(digest("")=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","SHA256 empty vector");
    require(digest("abc")=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","SHA256 short vector");
    require(digest("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq")=="248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1","SHA256 padding boundary vector");
    const std::string million(1000000,'a');
    require(digest(million)=="cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0","SHA256 million-byte vector");
    st::Sha256 chunked;for (unsigned i=0;i<1000;++i) chunked.add(std::string_view(million).substr(1000*i,1000));
    require(st::hexDigest(chunked.finish())==digest(million),"streaming chunks preserve digest");
    st::Sha256 one,two;st::hashPart(one,"a");st::hashPart(one,"bc");st::hashPart(two,"ab");st::hashPart(two,"c");
    require(one.finish()!=two.finish(),"length delimiters prevent ambiguous keys");

    const auto key=st::shaderCacheKey("compiler/profile/sources","vs_5_0","VSHADER=1","source",5,"VS offsets","PS offsets");
    require(key!=st::shaderCacheKey("changed compiler/profile/sources","vs_5_0","VSHADER=1","source",5,"VS offsets","PS offsets"),"compiler/source tree/mode invalidation");
    require(key!=st::shaderCacheKey("compiler/profile/sources","ps_5_0","VSHADER=1","source",5,"VS offsets","PS offsets"),"target invalidation");
    require(key!=st::shaderCacheKey("compiler/profile/sources","vs_5_0","HSHADER=1","source",5,"VS offsets","PS offsets"),"defines invalidation");
    require(key!=st::shaderCacheKey("compiler/profile/sources","vs_5_0","VSHADER=1","changed source",5,"VS offsets","PS offsets"),"root source invalidation");
    require(key!=st::shaderCacheKey("compiler/profile/sources","vs_5_0","VSHADER=1","source",6,"VS offsets","PS offsets"),"flags invalidation");
    require(key!=st::shaderCacheKey("compiler/profile/sources","vs_5_0","VSHADER=1","source",5,"changed VS offsets","PS offsets"),"VS layout invalidation");
    require(key!=st::shaderCacheKey("compiler/profile/sources","vs_5_0","VSHADER=1","source",5,"VS offsets","changed PS offsets"),"PS layout invalidation");
    const std::vector<std::uint8_t> code{0,1,0,255,0,0,3,4,5};
    const auto file=st::encodeShaderCache(key,code);
    auto decoded=st::decodeShaderCache(file,key);
    require(std::equal(code.begin(),code.end(),decoded.begin(),decoded.end()),"exact bytecode round trip");
    auto changedKey=key;changedKey[0]^=1;
    require(st::decodeShaderCache(file,changedKey).empty(),"wrong key rejected");
    for (std::size_t i=0;i<file.size();++i) {
        auto changed=file;changed[i]^=1;
        require(st::decodeShaderCache(changed,key).empty(),"every corrupt byte must reject hit");
        require(st::decodeShaderCache(std::span(file).first(i),key).empty(),"every truncation rejected");
    }
    auto trailing=file;trailing.push_back(0);
    require(st::decodeShaderCache(trailing,key).empty(),"trailing payload rejected");
    require(st::encodeShaderCache(key,{}).empty(),"empty bytecode rejected");
    const std::vector<std::uint8_t> oversized(st::maxShaderBytes+1);
    require(st::encodeShaderCache(key,oversized).empty(),"oversized bytecode rejected");
    require(st::decodeShaderCache(oversized,key).empty(),"malformed oversized entry rejected");

    std::vector<st::WaterPermutation> history;
    require(st::rememberPermutation(history,{0x3002,0x3002}),"first observation learned");
    require(!st::rememberPermutation(history,{0x3002,0x3002}),"repeated draws do not write history");
    for (unsigned i=0;i<100;++i) st::rememberPermutation(history,{i,1000+i});
    require(history.size()==32 && history.front().vs==68 && history.back().vs==99,"bounded recent history");
    const auto bytes=st::encodePrewarmHistory(history);
    require(st::decodePrewarmHistory(bytes)==history,"history round trip");
    auto bad=bytes;bad[0]=0;require(st::decodePrewarmHistory(bad).empty(),"invalid history magic rejected");
    bad=bytes;bad.pop_back();require(st::decodePrewarmHistory(bad).empty(),"truncated history rejected");
    bad=bytes;bad.resize(1000);require(st::decodePrewarmHistory(bad).empty(),"oversized history rejected");
    const auto plan=st::prewarmPlan(history);
    require(plan.size()==32,"prewarming bounded with learned entries");
    require(std::find(plan.begin(),plan.end(),st::WaterPermutation{99,1099})!=plan.end(),"most recent learned pair gets priority");
    for (unsigned id:{0x3002u,0x15eu,0x71eu})
        require(std::find(plan.begin(),plan.end(),st::WaterPermutation{id,id})!=plan.end(),"observed hitch permutations seeded");
    const auto seeds=st::prewarmPlan({});
    require(seeds.size()==11 && st::prewarmPlan(seeds)==seeds,"seed list deduplicates learned seeds");
    std::set<std::pair<unsigned,unsigned>> unique;
    for (auto pair:plan) unique.emplace(pair.vs,pair.ps);
    require(unique.size()==plan.size(),"prewarm pairs unique");
    std::cout<<"SHA256 vectors, complete cache-key invalidation, bytecode corruption/truncation rejection, bounded learned prewarm coverage passed\n";
}
