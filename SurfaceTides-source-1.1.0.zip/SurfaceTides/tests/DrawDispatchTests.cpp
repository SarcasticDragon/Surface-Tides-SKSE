#include "surfacetides/DrawDispatch.hpp"
#include <cstdlib>
#include <iostream>

static void require(bool value, const char* message) {
    if (!value) { std::cerr << message << '\n'; std::exit(1); }
}
int main() {
    using Registry=st::DrawDispatchRegistry<7,2>;
    Registry registry;
    Registry::Targets first{100,200,300,400,500,600,700};
    Registry::Targets second{101,201,301,401,501,601,701};
    auto initial=registry.plan(first);
    require(bool(initial) && registry.commit(initial),"initial installation");
    // The returned log has all seven method addresses changing together.
    auto replacement=registry.plan(second);
    require(bool(replacement),"all-seven transition is accepted");
    for (std::size_t i=0;i<7;++i) {
        require(replacement.added[i] && replacement.indices[i]==1,"new address gets separate trampoline index");
        require(registry.count(i)==1 && !registry.find(i,second[i]),"planning cannot publish unfinished hooks");
    }
    // Model a failed backend installation by not committing; retry is identical.
    auto retry=registry.plan(second);
    require(retry.indices==replacement.indices && registry.commit(retry),"failed install can retry without losing old targets");
    for (std::size_t i=0;i<7;++i) {
        require(registry.find(i,first[i])==0 && registry.find(i,second[i])==1,"both implementations retain their own original");
    }
    auto back=registry.plan(first);
    require(bool(back) && registry.commit(back),"switch back to previously hooked table");
    for (bool added:back.added) require(!added,"known addresses must not be hooked twice");
    auto mixed=first; mixed[0]=second[0]; mixed[6]=second[6];
    auto mix=registry.plan(mixed);
    require(bool(mix) && mix.indices[0]==1 && mix.indices[1]==0 && mix.indices[6]==1,"partial table transition routes each method correctly");
    auto exhausted=second; exhausted[3]=402;
    require(registry.plan(exhausted).error==Registry::Error::capacity,"bounded variants");
    auto alias=second; alias[0]=first[1];
    require(registry.plan(alias).error==Registry::Error::differentKindAlias,"reject incompatible method alias with older target");
    alias=second; alias[0]=alias[1];
    require(registry.plan(alias).error==Registry::Error::differentKindAlias,"reject alias within new table");
    auto null=second; null[2]=0;
    require(registry.plan(null).error==Registry::Error::nullTarget,"reject null targets before mutation");
    require(!registry.commit(initial),"reject stale installation plan");
    for (std::size_t i=0;i<7;++i) require(registry.count(i)==2,"failed plans leave registered hooks intact");
    std::cout << "Draw dispatch transition, trampoline identity, retry, alias and capacity checks passed\n";
}
