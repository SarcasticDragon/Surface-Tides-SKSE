#include "surfacetides/NativeWaterSource.hpp"
#include "surfacetides/NativeWaterReadiness.hpp"
#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <sstream>
static std::string read(const char* path) {std::ifstream f(path);std::ostringstream s;s<<f.rdbuf();return s.str();}
int main(int argc,char** argv) {
    if (argc==5) {
        const int bits=std::stoi(argv[3]);
        try {std::cout<<st::augmentNativeWater(read(argv[1]),read(argv[2]),{bool(bits&1),bool(bits&2),bool(bits&4),bool(bits&8)});return 0;}
        catch (const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
    }
    const std::string vs="struct VS_OUTPUT { float4 HPosition : SV_POSITION0; };\nVS_OUTPUT main(VS_INPUT input) { return (VS_OUTPUT)0; }";
    const std::string ps="struct VS_OUTPUT { float4 HPosition : SV_POSITION0; };\nPS_OUTPUT main(PS_INPUT input) { float3 normal = waterData.normal;return psout; }";
    int tested=0;
    for (int bits=0;bits<16;++bits) {
        st::NativeWaterMode mode{bool(bits&1),bool(bits&2),bool(bits&4),bool(bits&8)};
        const auto input=mode.vertex?vs:ps;const auto original=input;
        auto result=st::augmentNativeWater(input,"// field",mode);
        if (input!=original || result.find("STOSBaseHeight")==std::string::npos) return 2;
        if (mode.vertex && mode.stencil && result.find("STHeight(result.PreviousWorldPosition")==std::string::npos) return 3;
        if (!mode.vertex && !mode.stencil && result.find("-stosField.yz*STOptions.y")==std::string::npos) return 4;
        ++tested;
    }
    for (const auto& malformed:{std::string("unrelated shader"),vs+vs,vs+"\nfloat x:TEXCOORD14;",vs+"\n// STOSVertexCore"}) {
        bool rejected=false;try { st::augmentNativeWater(malformed,"",{true,false,false,false}); }
        catch (const std::runtime_error&) { rejected=true; }
        if (!rejected) return 5;++tested;
    }
    // D3DPreprocess and DXC need not preserve the same punctuation spacing.
    // Every valid spelling must produce the same injected program.
    const auto expected=st::augmentNativeWater(ps,"// field",{});
    for (const auto* member:{"waterData . normal", "waterData. normal", "waterData .normal", "waterData\t.\nnormal"}) {
        auto spaced=ps;spaced.replace(spaced.find("waterData.normal"),16,member);
        if (st::augmentNativeWater(spaced,"// field",{})!=expected) return 6;
        ++tested;
    }
    for (const auto* statement:{"float3 normal = waterData.normal + another;", "float3 normal = other.normal;",
            "min16float3 normal = waterData.normal;", "float3 normal = waterData.normal; float3 normal = waterData . normal;"}) {
        auto invalid=ps;invalid.replace(invalid.find("float3 normal"),33,statement);
        bool rejected=false;try { st::augmentNativeWater(invalid,"",{}); }
        catch (const std::runtime_error&) { rejected=true; }
        if (!rejected) return 7;++tested;
    }
    // Shader creation is asynchronous: all 24 orders must stay on native OS
    // until all four stage classes exist AND a frame boundary has passed.
    std::array<unsigned,4> order{0,1,2,3};
    do {
        st::NativeWaterReadiness gate;
        for (unsigned n=0;n<4;++n) {
            if (gate.canRender()) return 8;
            const auto stage=order[n];gate.succeeded((stage&1)==0,(stage&2)!=0);
            if (gate.canRender()) return 9;
            gate.nextFrame();
            if (gate.canRender()!=(n==3)) return 10;
        }
        gate.failed();
        if (gate.canRender()) return 11;
        gate.nextFrame();gate.succeeded(true,false);
        if (gate.canRender() || !gate.hasFailure()) return 12;
        ++tested;
    } while (std::next_permutation(order.begin(),order.end()));
    // Reproduce the reported condition: stencil PS + all vertex variants
    // succeed, but color PS fails. Never allow a displaced stencil-only path.
    st::NativeWaterReadiness failedColor;
    failedColor.succeeded(false,true);failedColor.succeeded(true,false);failedColor.succeeded(true,true);
    failedColor.nextFrame();if (failedColor.canRender()) return 13;
    failedColor.failed();failedColor.succeeded(false,false);failedColor.nextFrame();
    if (failedColor.canRender()) return 14;++tested;
    std::cout<<tested<<" native OS source contract cases passed\n";
}
