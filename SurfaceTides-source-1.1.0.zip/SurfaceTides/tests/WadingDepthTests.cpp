#include "surfacetides/WadingDepth.hpp"
#include <iostream>

struct Face {
    unsigned StencilFailOp=1, StencilDepthFailOp=1, StencilPassOp=1, StencilFunc=3;
    bool operator==(const Face&) const = default;
};
struct Description {
    bool DepthEnable=true;
    unsigned DepthWriteMask=0, DepthFunc=4;
    bool StencilEnable=true;
    unsigned StencilReadMask=2, StencilWriteMask=255;
    Face FrontFace, BackFace;
    bool operator==(const Description&) const = default;
};

int main() {
    unsigned checks=0, failures=0;
    auto test=[&](bool condition) { ++checks; if (!condition) ++failures; };
    Description captured;
    test(st::primaryWadingPair(0x15e,0x15e));
    for (unsigned other : {0x11e,0x35e,0x3002,0x5000,0x5001,0x17e,0x4802}) {
        test(!st::primaryWadingPair(other,0x15e));
        test(!st::primaryWadingPair(0x15e,other));
        test(!st::primaryWadingPair(other,other));
    }
    // Exhaust the byte-sized stencil masks/references: only the three observed
    // selected-water bits can qualify, never zero or unselected pixels.
    for (unsigned mask=0;mask<256;++mask) for (unsigned ref=0;ref<256;++ref) {
        auto d=captured;d.StencilReadMask=mask;
        const bool wanted=(mask==2 || mask==4 || mask==8) && (ref&mask)==mask;
        test(st::canRelaxWadingDepth(d,ref,true)==wanted);
    }
    for (unsigned func=1;func<=8;++func) {
        auto d=captured;d.DepthFunc=func;
        test(st::canRelaxWadingDepth(d,2,true)==(func==4));
    }
    for (unsigned side=0;side<2;++side) for (unsigned field=0;field<4;++field) for (unsigned value=1;value<=8;++value) {
        auto d=captured;auto& f=side ? d.BackFace : d.FrontFace;
        unsigned* fields[]={&f.StencilFailOp,&f.StencilDepthFailOp,&f.StencilPassOp,&f.StencilFunc};
        *fields[field]=value;
        test(st::canRelaxWadingDepth(d,2,true)==(value==(field==3 ? 3u : 1u)));
    }
    auto d=captured;d.DepthWriteMask=1;test(!st::canRelaxWadingDepth(d,2,true));
    d=captured;d.DepthEnable=false;test(!st::canRelaxWadingDepth(d,2,true));
    d=captured;d.StencilEnable=false;test(!st::canRelaxWadingDepth(d,2,true));
    test(!st::canRelaxWadingDepth(captured,2,false));
    for (unsigned mask : {2u,4u,8u}) for (unsigned writeMask : {0u,2u,4u,255u}) {
        d=captured;d.StencilReadMask=mask;d.StencilWriteMask=writeMask;
        auto relaxed=st::relaxWadingDepth(d);
        test(relaxed.DepthFunc==8);relaxed.DepthFunc=4;test(relaxed==d);
        // Selected stencil pixels are retained, unselected pixels still fail.
        for (unsigned stored=0;stored<256;++stored) {
            const bool before=(stored&d.StencilReadMask)==mask;
            const bool after=(stored&relaxed.StencilReadMask)==mask;
            test(before==after);
        }
    }
    std::cout << (failures ? "FAIL " : "PASS ") << checks << " guarded wading depth checks; failures=" << failures << '\n';
    return failures ? 1 : 0;
}
