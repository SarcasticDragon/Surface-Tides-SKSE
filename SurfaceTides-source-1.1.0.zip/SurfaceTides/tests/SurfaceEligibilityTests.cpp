#include "surfacetides/SurfaceEligibility.hpp"
#include <iostream>
#include <stdexcept>

void require(bool value,const char* message) { if (!value) throw std::runtime_error(message); }
int main() {
    using namespace st;
    // Use a nonstandard Dawnguard index to catch accidental screenshot-ID masking.
    const SurfaceCatalog known{0x9727E,0x07014B85,0x07014FD1,0x07012345};
    require(classifySurface(known,{known.puddleBase,0,false})==SurfaceKind::DecorativePuddle,"puddle reference");
    require(classifySurface(known,{known.lavaBase,0,false})==SurfaceKind::Lava,"lava activator");
    require(classifySurface(known,{known.forgeLavaBase,0,false})==SurfaceKind::Lava,"forge static");
    require(classifySurface(known,{0x98123,known.lavaWater,false})==SurfaceKind::Lava,"other placement of the same lava water type");
    require(classifySurface(known,{0,0,true})==SurfaceKind::Lava,"unowned geometry with exact lava material");
    require(classifySurface(known,{known.puddleBase,known.lavaWater,true})==SurfaceKind::DecorativePuddle,"puddle never becomes lava-addon eligible");
    require(classifySurface({}, {})==SurfaceKind::Water,"missing forms and missing owner must remain permissive");
    require(classifySurface(known,{})==SurfaceKind::Water,"unknown geometry must not disable ordinary water");
    require(classifySurface(known,{0x02014B85,0,false})==SurfaceKind::Water,"same local ID in another plugin");
    require(classifySurface(known,{0x19727E,0,false})==SurfaceKind::Water,"nearby unrelated base form");
    require(classifySurface(known,{0x98123,0x76543,false})==SurfaceKind::Water,"normal water using shared Water1024 geometry");
    require(baseSimulationEligible(SurfaceKind::Water),"ordinary water remains enabled");
    require(!baseSimulationEligible(SurfaceKind::Lava) && !baseSimulationEligible(SurfaceKind::DecorativePuddle),"excluded surfaces remain entirely native");
    require(drawSurface(SurfaceKind::Lava,false,{})==SurfaceKind::Lava,"direct draw exclusion");
    require(drawSurface(SurfaceKind::Water,true,SurfaceKind::Lava)==SurfaceKind::Lava,"forwarded draw retains copied exclusion");
    require(drawSurface(SurfaceKind::Lava,true,SurfaceKind::Water)==SurfaceKind::Water,"ordinary forwarded draw cannot inherit another geometry exclusion");
    require(drawSurface({},false,{})==SurfaceKind::Water,"cleared setup/restore/frame scope does not retain exclusion");
    std::cout << "PASS surface eligibility: exact forms, load-order isolation, known lava type/material, unknown-water fallback and forwarded scope isolation\n";
}
