#include "surfacetides/RenderWork.hpp"
#include "surfacetides/PerformanceTiming.hpp"
#include <cstdlib>
#include <iostream>
#include <unordered_map>

namespace {
void require(bool okay, const char* reason) {
    if (!okay) { std::cerr<<reason<<'\n'; std::exit(1); }
}
}
int main() {
    int owner[2]{}, records[3]{}, objects[3]{};
    st::ShaderIndexSnapshot index;
    std::vector<st::ShaderObjectRecord> vs{{&records[0],&objects[0]},{&records[1],&objects[1]}};
    std::vector<st::ShaderObjectRecord> ps{{&records[2],&objects[2]}};
    require(!index.matches(&owner[0],vs,ps),"first index must build");
    index.commit(&owner[0],vs,ps);
    require(index.matches(&owner[0],vs,ps),"unchanged objects must retain generation");
    require(!index.matches(&owner[1],vs,ps),"owner replacement invalidates index");
    auto modified=vs;
    modified[1].object=&objects[2];
    require(!index.matches(&owner[0],modified,ps),"same-count object replacement invalidates");
    modified=vs; modified[1].metadata=&records[2];
    require(!index.matches(&owner[0],modified,ps),"record replacement invalidates");
    modified=vs; std::swap(modified[0],modified[1]);
    require(!index.matches(&owner[0],modified,ps),"first-alias ordering cannot silently change");
    modified=vs; modified.pop_back();
    require(!index.matches(&owner[0],modified,ps),"removal invalidates");
    modified=vs; modified.push_back(ps[0]);
    require(!index.matches(&owner[0],modified,ps),"addition invalidates");
    auto pixels=ps; pixels[0].object=&objects[0];
    require(!index.matches(&owner[0],vs,pixels),"pixel replacement invalidates");
    index.commit(&owner[1],{},{});
    require(index.matches(&owner[1],{},{}),"empty shader collection is a valid snapshot");

    st::WaterShaderKey key{0x1234,0x5678};
    for (std::size_t i=0;i<key.vertexOffsets.size();++i) key.vertexOffsets[i]=static_cast<std::int8_t>(i-1);
    for (std::size_t i=0;i<key.pixelOffsets.size();++i) key.pixelOffsets[i]=static_cast<std::int8_t>(i-1);
    std::unordered_map<st::WaterShaderKey,int,st::WaterShaderKeyHash> cache;
    cache.emplace(key,42);
    require(cache.at(key)==42,"typed key lookup");
    auto other=key; ++other.vs; require(!cache.contains(other),"VS descriptor separates permutations");
    other=key; ++other.ps; require(!cache.contains(other),"PS descriptor separates permutations");
    for (std::size_t i=0;i<key.vertexOffsets.size();++i) {
        other=key; ++other.vertexOffsets[i]; require(!cache.contains(other),"every VS layout byte matters");
    }
    for (std::size_t i=0;i<key.pixelOffsets.size();++i) {
        other=key; ++other.pixelOffsets[i]; require(!cache.contains(other),"every PS layout byte matters");
    }
    const int* retained=&cache.at(key);
    for (unsigned i=0;i<8192;++i) { other=key; other.vs=i; cache.emplace(other,0); }
    require(retained==&cache.at(key) && *retained==42,"last-bundle pointer survives rehash");

    // Exercise the actual production range helpers with all 32 combinations
    // of null CB slots, both modes, and unrelated OS slots populated.
    for (bool batched:{false,true}) for (unsigned nullMask=0;nullMask<32;++nullMask) {
        std::array<int*,14> bindings{};
        int values[14]{};
        for (unsigned i=0;i<14;++i) bindings[i]=&values[i];
        constexpr unsigned slots[]{0,1,2,11,12};
        for (unsigned i=0;i<5;++i) if (nullMask&(1u<<i)) bindings[slots[i]]=nullptr;
        const auto original=bindings;
        std::array<int*,5> saved{};
        unsigned gets=0,sets=0;
        st::captureWaterConstants<int*>([&](unsigned start,unsigned count,int** out) {
            ++gets; for (unsigned i=0;i<count;++i) out[i]=bindings[start+i];
        },[&](unsigned i,int* p) { saved[i]=p; },batched);
        for (unsigned slot:slots) bindings[slot]=&owner[0];
        st::restoreWaterConstants<int*>([&](unsigned i) { return saved[i]; },
            [&](unsigned start,unsigned count,int* const* in) {
                ++sets; for (unsigned i=0;i<count;++i) bindings[start+i]=in[i];
            },batched);
        require(bindings==original,"restore must preserve nulls and all untouched slots");
        require(gets==(batched?2u:5u) && sets==gets,"batching reduces calls without widening ranges");
    }

    st::TimingStat stats;
    require(stats.meanMS()==0,"empty timings");
    stats.add(1); stats.add(3); stats.add(2);
    require(stats.count==3 && stats.totalMS==6 && stats.meanMS()==2 && stats.maxMS==3,"timing aggregation");
    { st::CpuTimer timer(nullptr); timer.stop(); timer.stop(); }
    st::FrameIntervals<4> frames;
    require(frames.percentile(0.99)==0,"empty intervals");
    for (double n:{4.,1.,3.,2.}) frames.add(n);
    require(frames.percentile(.5)==2 && frames.percentile(.99)==4,"nearest-rank percentiles");
    frames.add(5);
    require(frames.retained()==4 && frames.stats.count==5 && frames.percentile(1)==5,"bounded interval ring");
    frames.reset(); frames.add(9);
    require(frames.retained()==1 && frames.percentile(.5)==9 && frames.stats.maxMS==9,"new window cannot include stale samples");
    st::DrawTimingSampler sampler;
    unsigned selected=0;
    std::array<unsigned,128> residues{};
    for (unsigned i=0;i<128000;++i) if (sampler.sample()) { ++selected; ++residues[i%128]; }
    require(selected>850 && selected<1150,"draw sampling rate stays near 1/128");
    require(std::all_of(residues.begin(),residues.end(),[](unsigned n) { return n>0; }),"sampling avoids fixed draw-position aliasing");
    std::cout<<"Index invalidation, complete shader keys, binding restoration/null slots, bounded timing and randomized sampling checks passed\n";
}
