#include "surfacetides/ShaderCompatibility.hpp"
#include "surfacetides/WaterRenderState.hpp"
#include <algorithm>
#include <cmath>
#include <iostream>

int main() {
    using R=st::ShaderRenderer;
    using N=st::NativeRenderer;
    // The old AllowCS key is deliberately not an input to the new policy.
    bool pass =
        st::selectShaderRenderer(false,false,true)==R::None &&
        st::selectShaderRenderer(true,false,true)==R::BlockedCS &&
        st::selectShaderRenderer(true,false,false)==R::UnsupportedCS &&
        st::selectShaderRenderer(true,true,true)==R::OpenShaders &&
        st::selectShaderRenderer(true,true,false)==R::OpenShaders &&
        st::selectShaderRenderer(false,true,true)==R::MissingOpenShaders &&
        st::selectShaderRenderer(false,true,false)==R::MissingOpenShaders &&
        st::selectNativeRenderer(false,false)==N::Vanilla &&
        st::selectNativeRenderer(false,true)==N::Vanilla &&
        st::selectNativeRenderer(true,false)==N::ENBCoexistence &&
        st::selectNativeRenderer(true,true)==N::ENBIntegration;
    using M=st::WaterRenderMode;
    // Off, absent initial frame, and inactive frame must all preserve OS
    // compatibility. Native/ENB must still relinquish their water draw.
    for (bool preview:{false,true}) for (bool frame:{false,true}) {
        const auto os=st::waterRenderMode(true,preview,frame);
        const auto native=st::waterRenderMode(false,preview,frame);
        pass &= preview && frame ? os==M::simulation && native==M::simulation :
            os==M::osCompatibility && native==M::native;
    }
    const auto neutral=st::inactiveSurfaceParameters();
    pass &= std::all_of(neutral.begin(),neutral.end(),[](float x){return std::isfinite(x);});
    pass &= neutral[2]>0 && neutral[6]>0 && neutral[8]>0; // shader divisors
    pass &= neutral[9]==0 && neutral[10]==0 && neutral[11]==1; // normals, height, tessellation
    pass &= neutral[12]==0 && neutral[13]==0 && neutral[16]==0; // enable, history, debug
    std::cout << (pass ? "PASS" : "FAIL") << " CS/OS/ENB selection, OS inactive compatibility and neutral field constants\n";
    return pass ? 0 : 1;
}
