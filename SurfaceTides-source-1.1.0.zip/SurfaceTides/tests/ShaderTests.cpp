#include <Windows.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include "surfacetides/ShaderLayout.hpp"
#include "surfacetides/ShaderReflection.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>

int main(int argc, char** argv) {
    if(argc<2 || argc>5) { std::cerr<<"Pass the SurfaceTides shader directory, optionally OS shader directory, then --water-effects and/or --unified-water\n"; return 2; }
    const bool os=argc>=3;
    bool waterEffects=false, unifiedWater=false;
    for(int i=3;i<argc;++i) {
        if(std::string_view(argv[i])=="--water-effects") waterEffects=true;
        else if(std::string_view(argv[i])=="--unified-water") unifiedWater=true;
        else { std::cerr<<"Unknown shader test flag\n"; return 2; }
    }
    const auto temp=std::filesystem::temp_directory_path()/ ("SurfaceTides-shader-tests-"+std::to_string(GetCurrentProcessId()));
    std::filesystem::create_directories(temp);
    std::filesystem::copy(argv[1],temp,std::filesystem::copy_options::recursive|std::filesystem::copy_options::overwrite_existing);
    if (os) std::filesystem::copy(std::filesystem::path(argv[2])/"Common",temp/"Common",
        std::filesystem::copy_options::recursive|std::filesystem::copy_options::overwrite_existing);
    if (waterEffects) std::filesystem::copy(std::filesystem::path(argv[2])/"WaterEffects",temp/"WaterEffects",
        std::filesystem::copy_options::recursive|std::filesystem::copy_options::overwrite_existing);
    std::ofstream(temp/"EngineVS.hlsli")<<st::engineConstantHeader(st::ShaderStage::Vertex,st::referenceConstantTable(st::ShaderStage::Vertex));
    std::ofstream(temp/"EnginePS.hlsli")<<st::engineConstantHeader(st::ShaderStage::Pixel,st::referenceConstantTable(st::ShaderStage::Pixel));
    // Representative reachable families: lakes, flowmap rivers, interiors, additive lights, stencil, underwater.
    const std::uint32_t descriptors[]={0x0002,0x001e,0x005e,0x00df,0x071e,0x075e,0x003e,0x015e,
                                      0x081e,0x101e,0x381e,0x401e,0x471e,0x5000,0x5802,0x5001,0x031e,
                                      0x410e,0x430e,0x434e,0x035e,0x3002,0x011e,
                                      0x073e,0x077e,0x071f,0x4802};
    const std::pair<const char*,const char*> stages[]={{"VSHADER","vs_5_0"},{"CONTROL_SHADER","vs_5_0"},
        {"HSHADER","hs_5_0"},{"DSHADER","ds_5_0"},{"PSHADER","ps_5_0"}};
    int failures=0, total=0, remaps=0;
    for(auto descriptor:descriptors) for(auto [stage,target]:stages) {
        std::ofstream(temp/"EngineVS.hlsli")<<st::engineConstantHeader(st::ShaderStage::Vertex,st::referenceConstantTable(st::ShaderStage::Vertex));
        std::ofstream(temp/"EnginePS.hlsli")<<st::engineConstantHeader(st::ShaderStage::Pixel,st::referenceConstantTable(st::ShaderStage::Pixel));
        auto pairs=st::shaderDefines(descriptor,stage,descriptor);
        if (os) pairs.emplace_back("ST_OPEN_SHADERS","1");
        if (waterEffects) pairs.emplace_back("ST_OS_WATER_EFFECTS","1");
        if (unifiedWater) pairs.emplace_back("ST_OS_UNIFIED_WATER","1");
        std::vector<D3D_SHADER_MACRO> defines;
        for(auto& [key,value]:pairs) defines.push_back({key.c_str(),value.c_str()});
        defines.push_back({nullptr,nullptr});
        Microsoft::WRL::ComPtr<ID3DBlob> code,errors;
        const HRESULT hr=D3DCompileFromFile((temp/L"Water.hlsl").c_str(),defines.data(),D3D_COMPILE_STANDARD_FILE_INCLUDE,
            "main",target,D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&errors);
        ++total;
        if(FAILED(hr)) {
            ++failures; std::cerr<<"FAIL "<<std::hex<<descriptor<<' '<<target<<' '<<stage<<'\n';
            if(errors) std::cerr<<static_cast<const char*>(errors->GetBufferPointer())<<'\n';
        } else if(std::string_view(stage)=="VSHADER" || std::string_view(stage)=="PSHADER") {
            try {
                const auto kind=std::string_view(stage)=="VSHADER" ? st::ShaderStage::Vertex : st::ShaderStage::Pixel;
                const auto live=st::activeEngineConstants(code.Get());
                std::ofstream(temp/(kind==st::ShaderStage::Vertex ? "EngineVS.hlsli" : "EnginePS.hlsli"))
                    <<st::engineConstantHeader(kind,st::referenceConstantTable(kind),std::span<const std::string>(live));
                Microsoft::WRL::ComPtr<ID3DBlob> mapped, stripped;
                errors.Reset();
                const auto mappedHR=D3DCompileFromFile((temp/L"Water.hlsl").c_str(),defines.data(),D3D_COMPILE_STANDARD_FILE_INCLUDE,
                    "main",target,D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&mapped,&errors);
                if(FAILED(mappedHR)) throw std::runtime_error(errors ? static_cast<const char*>(errors->GetBufferPointer()) : "Remap failed");
                if(kind==st::ShaderStage::Vertex) {
                    if(FAILED(D3DStripShader(code->GetBufferPointer(),code->GetBufferSize(),D3DCOMPILER_STRIP_REFLECTION_DATA,&stripped)))
                        throw std::runtime_error("Strip reflection failed");
                    st::validateVertexInputs(stripped->GetBufferPointer(),stripped->GetBufferSize(),mapped.Get());
                }
                ++remaps;
            } catch(const std::exception& e) {
                ++failures; std::cerr<<"FAIL remap/signature "<<std::hex<<descriptor<<' '<<stage<<": "<<e.what()<<'\n';
            }
        }
    }
    // New geometry preparation covers all four position/UV/color input families.
    // This remains an SM5 compile check; it is not an in-game ENB integration test.
    const std::pair<const char*,const char*> meshStages[]={{"MESH_VS","vs_5_0"},{"MESH_HS","hs_5_0"},
        {"MESH_DS","ds_5_0"},{"MESH_GS","gs_5_0"}};
    const std::vector<std::string> worldOnly{"World","PreviousWorld","WorldViewProj"};
    std::ofstream(temp/"EngineVS.hlsli")<<st::engineConstantHeader(st::ShaderStage::Vertex,
        st::referenceConstantTable(st::ShaderStage::Vertex),std::span<const std::string>(worldOnly));
    for(const char* cap:{"8","16"}) for(unsigned attrs=0;attrs<8;++attrs) for(auto [stage,target]:meshStages) {
        std::vector<D3D_SHADER_MACRO> defines{{stage,"1"},{"ST_MESH_MAX_FACTOR",cap}};
        if(attrs&1) defines.push_back({"ST_MESH_UV","1"});
        if(attrs&2) defines.push_back({"ST_MESH_COLOR","1"});
        if(attrs&4) defines.push_back({"ST_MESH_HISTORY","1"});
        defines.push_back({nullptr,nullptr});
        Microsoft::WRL::ComPtr<ID3DBlob> code,errors;
        const HRESULT hr=D3DCompileFromFile((temp/L"MeshInput.hlsl").c_str(),defines.data(),D3D_COMPILE_STANDARD_FILE_INCLUDE,
            "main",target,D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&errors);
        ++total;
        if(FAILED(hr)) {
            ++failures; std::cerr<<"FAIL mesh cap="<<cap<<" attrs="<<attrs<<' '<<stage<<'\n';
            if(errors) std::cerr<<static_cast<const char*>(errors->GetBufferPointer())<<'\n';
        }
    }
    {
        const D3D_SHADER_MACRO defines[]={{"MESH_MOTION_VS","1"},{"ST_MESH_HISTORY","1"},{nullptr,nullptr}};
        Microsoft::WRL::ComPtr<ID3DBlob> code,errors;
        const auto hr=D3DCompileFromFile((temp/L"MeshInput.hlsl").c_str(),defines,D3D_COMPILE_STANDARD_FILE_INCLUDE,
            "main","vs_5_0",D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3,0,&code,&errors);
        ++total;
        if(FAILED(hr)) { ++failures; if(errors) std::cerr<<static_cast<const char*>(errors->GetBufferPointer())<<'\n'; }
    }
    std::filesystem::remove_all(temp);
    std::cout<<std::dec<<total<<" SM5 stage checks; "<<remaps<<'/'<<std::size(descriptors)*2<<" remaps; "<<failures<<" failures\n";
    return failures ? 1 : 0;
}
