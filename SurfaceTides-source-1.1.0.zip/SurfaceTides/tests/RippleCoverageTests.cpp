#include "surfacetides/WadingDepth.hpp"
#include <iostream>
#include <limits>

struct Face {
    unsigned StencilFailOp=1, StencilDepthFailOp=1, StencilPassOp=1, StencilFunc=3;
    bool operator==(const Face&) const = default;
};
struct Description {
    bool DepthEnable=true;
    unsigned DepthWriteMask=0, DepthFunc=4;
    bool StencilEnable=true;
    unsigned StencilReadMask=2, StencilWriteMask=255;
    Face FrontFace, BackFace;
    bool operator==(const Description&) const = default;
};

int main() {
    unsigned checks=0, failures=0;
    auto test=[&](bool value) { ++checks; if (!value) ++failures; };
    const Description wading;
    auto base=wading; base.StencilReadMask=1;
    base.FrontFace.StencilFunc=base.BackFace.StencilFunc=6;
    test(st::recognizesRippleBase(base,1));
    test(st::canMarkRippleCoverage(wading,3,true));
    test(!st::canMarkRippleCoverage(wading,3,false));
    test(!st::recognizesRippleBase(wading,1));
    test(!st::canMarkRippleCoverage(base,3,true));

    // Regression: 123104 trace scopes 2/4/5 and all later sampled base/wading
    // rows use RGB writes=7, blending=0, alpha-to-coverage=0, sampleMask=FFFFFFFF.
    // The old RGBA-only guard rejected these before either stencil policy ran.
    const bool capturedColor=st::opaqueRippleColorWrites(7,false,false,UINT32_MAX);
    test(capturedColor && st::recognizesRippleBase(base,1));
    test(capturedColor && st::canMarkRippleCoverage(wading,3,true));
    test(capturedColor && st::recentRippleBase(1,2)); // wading precedes base
    test(st::opaqueRippleColorWrites(15,false,false,UINT32_MAX)); // D3D default
    for (unsigned mask=0; mask<256; ++mask) for (bool blend : {false,true})
        for (bool alphaCoverage : {false,true}) {
            // Require every visible RGB component; alpha storage is independent.
            const bool rgbComplete=(mask & 1) && (mask & 2) && (mask & 4);
            const bool knownBits=(mask & ~15u)==0;
            test(st::opaqueRippleColorWrites(mask,blend,alphaCoverage,UINT32_MAX)==
                (rgbComplete && knownBits && !blend && !alphaCoverage));
        }
    for (unsigned bit=0; bit<32; ++bit) for (unsigned mask : {7u,15u})
        test(!st::opaqueRippleColorWrites(mask,false,false,UINT32_MAX ^ (1u<<bit)));
    test(!st::opaqueRippleColorWrites(7,false,false,0));
    test(!st::opaqueRippleColorWrites(15,false,false,0));

    // Every byte-valued mask/reference must stay within the captured contract.
    for (unsigned mask=0; mask<256; ++mask) for (unsigned ref=0; ref<256; ++ref) {
        auto w=wading; w.StencilReadMask=mask;
        auto b=base; b.StencilReadMask=mask;
        test(st::canMarkRippleCoverage(w,ref,true)==(mask==2 && ref==3));
        test(st::recognizesRippleBase(b,ref)==(mask==1 && ref==1));
    }
    for (unsigned mask=0; mask<256; ++mask) {
        auto w=wading; w.StencilWriteMask=mask;
        auto b=base; b.StencilWriteMask=mask;
        test(st::canMarkRippleCoverage(w,3,true)==(mask==255));
        test(st::recognizesRippleBase(b,1)==(mask==255));
    }
    for (unsigned side=0; side<2; ++side) for (unsigned field=0; field<4; ++field) for (unsigned value=1; value<=8; ++value) {
        auto w=wading; auto b=base;
        auto& wf=side ? w.BackFace : w.FrontFace;
        auto& bf=side ? b.BackFace : b.FrontFace;
        unsigned* wp[]={&wf.StencilFailOp,&wf.StencilDepthFailOp,&wf.StencilPassOp,&wf.StencilFunc};
        unsigned* bp[]={&bf.StencilFailOp,&bf.StencilDepthFailOp,&bf.StencilPassOp,&bf.StencilFunc};
        *wp[field]=*bp[field]=value;
        test(st::canMarkRippleCoverage(w,3,true)==(value==(field==3 ? 3u : 1u)));
        test(st::recognizesRippleBase(b,1)==(value==(field==3 ? 6u : 1u)));
    }
    for (unsigned func=1; func<=8; ++func) {
        auto w=wading; w.DepthFunc=func;
        auto b=base; b.DepthFunc=func;
        test(st::canMarkRippleCoverage(w,3,true)==(func==4));
        test(st::recognizesRippleBase(b,1)==(func==4));
    }
    for (unsigned field=0; field<3; ++field) {
        auto w=wading; auto b=base;
        if (field==0) w.DepthEnable=b.DepthEnable=false;
        if (field==1) w.StencilEnable=b.StencilEnable=false;
        if (field==2) w.DepthWriteMask=b.DepthWriteMask=1;
        test(!st::canMarkRippleCoverage(w,3,true));
        test(!st::recognizesRippleBase(b,1));
    }
    auto marked=st::markRippleCoverage(wading);
    test(marked.DepthFunc==8 && marked.StencilWriteMask==1);
    test(marked.FrontFace.StencilPassOp==3 && marked.BackFace.StencilPassOp==3);
    auto restored=marked;
    restored.DepthFunc=4; restored.StencilWriteMask=255;
    restored.FrontFace.StencilPassOp=restored.BackFace.StencilPassOp=1;
    test(restored==wading); // no other depth/stencil field changed

    // Model the documented output merger operations independently of the policy:
    // coverage/discard can suppress a wading fragment, then base water draws.
    for (unsigned stored=0; stored<256; ++stored) for (bool fragment : {false,true}) {
        const bool selected=(stored & 2)==2;
        const bool wadingWrites=fragment && selected;
        const unsigned after=wadingWrites ? ((stored & ~marked.StencilWriteMask) | (3 & marked.StencilWriteMask)) : stored;
        const bool baseBefore=(stored & 1)!=1;
        const bool baseAfter=(after & 1)!=1;
        test((after & ~1u)==(stored & ~1u)); // all seven other bits untouched
        test((after & 2)==(stored & 2)); // selection survives repeat wading draws
        test(!wadingWrites ? after==stored : !baseAfter);
        test(baseAfter==(baseBefore && !wadingWrites));
    }
    // A small tiled surface: a limited wading footprint must not create holes
    // outside it. This also covers discarded fragments inside that footprint.
    for (unsigned y=0; y<32; ++y) for (unsigned x=0; x<32; ++x) {
        unsigned stencil=2, color=0; // engine water selection, empty color
        const bool ripple=x>=10 && x<22 && y>=10 && y<22 && (x+y)%3!=0;
        if (ripple) { color=1; stencil=(stencil & ~marked.StencilWriteMask) | (3 & marked.StencilWriteMask); }
        if ((stencil & base.StencilReadMask)!=(1 & base.StencilReadMask)) color=2;
        test(color==(ripple ? 1u : 2u));
    }
    test(!st::recentRippleBase(0,1));
    test(st::recentRippleBase(1,1));
    test(st::recentRippleBase(1,2));
    test(!st::recentRippleBase(1,3));
    test(!st::recentRippleBase(2,1));
    test(!st::recentRippleBase(std::numeric_limits<std::uint64_t>::max(),0));
    std::cout << (failures ? "FAIL " : "PASS ") << checks << " ripple coverage checks; failures=" << failures << '\n';
    return failures ? 1 : 0;
}
