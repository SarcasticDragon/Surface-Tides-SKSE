#include "surfacetides/MotionWriteControl.hpp"
#include "surfacetides/Tuning.hpp"
#include <array>
#include <cstdlib>
#include <iostream>

namespace {
void require(bool value, const char* message) {
    if (!value) { std::cerr << message << '\n'; std::exit(1); }
}
// Stand-in for the D3D11 descriptor; the algorithm is also instantiated with
// the real Windows type by Renderer.cpp. Check effective target behavior, not
// just the bytes of an inactive descriptor slot.
struct Target {
    int BlendEnable{}, SrcBlend{}, DestBlend{}, BlendOp{};
    int SrcBlendAlpha{}, DestBlendAlpha{}, BlendOpAlpha{};
    unsigned char RenderTargetWriteMask{};
    bool operator==(const Target&) const = default;
};
struct Blend {
    int AlphaToCoverageEnable{}, IndependentBlendEnable{};
    Target RenderTarget[8]{};
    bool operator==(const Blend&) const = default;
};
Target effective(const Blend& blend, std::size_t slot) {
    return blend.RenderTarget[blend.IndependentBlendEnable ? slot : 0];
}
}

int main() {
    for (bool independent:{false,true}) for (int alpha:{0,1}) for (int mask=0; mask<16; ++mask) {
        Blend before{};
        before.IndependentBlendEnable=independent;
        before.AlphaToCoverageEnable=alpha;
        for (int i=0;i<8;++i)
            before.RenderTarget[i]={i%2,1+i,11+i,21+i,31+i,41+i,51+i,
                static_cast<unsigned char>((mask+i)%16)};
        const auto original=before;
        const auto after=st::withoutMotionTargetWrites(before);
        require(before==original,"source blend state must remain immutable");
        require(after.IndependentBlendEnable && after.AlphaToCoverageEnable==alpha,"retain alpha coverage");
        for (std::size_t i=0;i<8;++i) {
            auto expected=effective(before,i);
            if (i==1) expected.RenderTargetWriteMask=0;
            require(effective(after,i)==expected,"only RT1 effective write mask may change");
        }
        require(st::withoutMotionTargetWrites(after)==after,"already-masked states are idempotent");
    }
    for (auto stencil:{0x5000u,0x5001u,0x5400u,0x57ffu}) {
        require(st::isWaterStencilPair(stencil,stencil),"water stencil variants accepted");
        for (auto other:{0x0002u,0x015eu,0x031eu,0x035eu,0x410eu,0x430eu,0x4800u,0x5802u,0x6000u}) {
            require(!st::isWaterStencilPair(other,stencil),"mixed vertex stage rejected");
            require(!st::isWaterStencilPair(stencil,other),"mixed pixel stage rejected");
            require(!st::isWaterStencilPair(other,other),"non-stencil pass rejected");
        }
    }
    st::Tuning normal, diagnostic;
    require(normal.osPreserveSceneMotion,"accepted OS workaround on by default");
    diagnostic.osPreserveSceneMotion=false;
    diagnostic.validate();
    require(!st::needsSurfaceReset(normal,diagnostic),"comparison must not reset the waves");
    std::cout << "Effective MRT state, alpha coverage, stencil scope and live toggle checks passed\n";
}
