// SPDX-License-Identifier: GPL-3.0-or-later
// Calls the user's installed Open Shaders helpers; no fixed feature-buffer
// offsets, hard-coded gamma, preset writes, or redistributed OS shader files.
// Interface reference: alandtse/open-shaders a996a271790ffa9f944d2d7e8a05e6fbd73a85d3.
#ifndef ST_OPEN_SHADERS_COLOR
#define ST_OPEN_SHADERS_COLOR
#if defined(ST_OPEN_SHADERS)
#include "Common/Color.hlsli"
#include "Common/Permutation.hlsli"
// Retain Surface Tides' existing motion-vector convention. OS moved this
// helper out of its frame header, so use the same matrices explicitly.
float2 GetSSMotionVector(float4 position, float4 previousPosition)
{
    float4 current = mul(FrameBuffer::CameraViewProjUnjittered[0], position);
    float4 previous = mul(FrameBuffer::CameraPreviousViewProjUnjittered[0], previousPosition);
    return float2(-0.5, 0.5) * (current.xy / current.ww - previous.xy / previous.ww);
}
bool STGammaTarget()
{
    return ENABLE_LL && (Permutation::ExtraShaderDescriptor & Permutation::ExtraFlags::GammaRenderTarget);
}
float3 STWaterColor(float3 color) { return Color::Water(color); }
float3 STSceneColor(float3 color)
{
    return STGammaTarget() ? Color::SceneGammaToLinear(color) : color;
}
float3 STFogColor(float3 color, float3 fog, float weight)
{
    return Color::BlendFog(color, Color::Fog(fog), weight);
}
float4 STWaterOutput(float3 color, float exposure, float alpha)
{
    // OS controls scene exposure separately. Its water output uses brightness
    // without the vanilla saturation/exposure step, then encodes gamma targets.
    color *= SharedData::csUtilitySettings.waterBrightness;
    if (STGammaTarget()) color = Color::SceneLinearToGamma(color);
    return float4(color, alpha);
}
#else
float3 STWaterColor(float3 color) { return color; }
float3 STSceneColor(float3 color) { return color; }
float3 STFogColor(float3 color, float3 fog, float weight) { return lerp(color, fog, weight); }
float4 STWaterOutput(float3 color, float exposure, float alpha) { return saturate(float4(color * exposure, alpha)); }
#endif
#endif
