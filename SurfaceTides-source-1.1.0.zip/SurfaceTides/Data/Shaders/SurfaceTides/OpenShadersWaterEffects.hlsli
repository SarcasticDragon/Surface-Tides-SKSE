// SPDX-License-Identifier: GPL-3.0-or-later
// Surface Tides adapter for the user's installed OS WaterEffects helpers.
// Interface/flow sampling reference: alandtse/open-shaders
// a996a271790ffa9f944d2d7e8a05e6fbd73a85d3, package/Shaders/Water.hlsl.
// Caustics remain in OS lighting; do not apply them again to refracted color.
#ifndef ST_OPEN_SHADERS_WATER_EFFECTS
#define ST_OPEN_SHADERS_WATER_EFFECTS

#include "Common/Random.hlsli"

#if defined(FLOWMAP)
// Callback expected by OS WaterParallax.hlsli. The existing ST flow coordinates
// and OS use the same rotation convention. Explicit LOD matches OS's helper.
struct FlowmapData { float4 color; float2 flowVector; };
FlowmapData GetFlowmapDataUV(PS_INPUT input, float2 uvShift)
{
    FlowmapData data;
    data.color = FlowMapTex.SampleLevel(FlowMapSampler, input.TexCoord2.zw + uvShift, 0);
    float2 flow = (64 * input.TexCoord3.xy) * sqrt(1.01 - data.color.z);
    float2 direction = data.color.xy * 2 - 1;
    float2x2 rotation = float2x2(direction.x, direction.y, -direction.y, direction.x);
    data.flowVector = mul(transpose(rotation), flow);
    return data;
}
#endif

#include "WaterEffects/WaterParallax.hlsli"

bool STOSParallaxUsable(float3 viewDirection, float3 normalScalesRcp)
{
    // Reject invalid live values before entering the installed helper's loops.
    // 4..64 is the inspected OS menu's supported quality range.
    return all(isfinite(viewDirection)) && abs(viewDirection.z) > 0.0001 &&
        all(isfinite(normalScalesRcp)) &&
        isfinite(SharedData::csUtilitySettings.waterParallaxStrength) &&
        SharedData::csUtilitySettings.waterParallaxStrength > 0 &&
        SharedData::csUtilitySettings.waterParallaxQuality >= 4 &&
        SharedData::csUtilitySettings.waterParallaxQuality <= 64;
}
float2 STOSParallaxOffset(PS_INPUT input, float3 normalScalesRcp)
{
    if (!STOSParallaxUsable(normalize(input.WPosition.xyz), normalScalesRcp)) return 0;
    float2 offset = WaterEffects::GetParallaxOffset(input, normalScalesRcp);
    return all(isfinite(offset)) ? offset : 0;
}

#if defined(FLOWMAP)
void STOSFlowParallax(PS_INPUT input, float3 viewDirection, float3 normalScalesRcp,
    out PS_INPUT shiftedInput, out float2 baseOffset)
{
    shiftedInput = input;
    baseOffset = 0;
    if (!STOSParallaxUsable(viewDirection, normalScalesRcp) || viewDirection.z > -0.05) return;
#if defined(ST_UW_EXTERIOR)
    float2 dimensions = input.TexCoord4.xy;
#else
    float2 dimensions = input.TexCoord4.xx;
#endif
    if (!all(isfinite(dimensions)) || any(dimensions <= 0)) return;
    float amount = WaterEffects::GetFlowmapParallaxAmount(input, dimensions, viewDirection);
    float2 offset = amount * WaterEffects::GetFlowmapParallaxDirection(viewDirection);
    if (all(isfinite(offset))) shiftedInput.TexCoord3.xy += offset;
    offset = WaterEffects::GetFlowmapParallaxOffset(input, dimensions, viewDirection, normalScalesRcp);
    if (all(isfinite(offset))) baseOffset = offset;
}
float3 STOSFlowNormal(PS_INPUT input, float2 uvShift, float multiplier, float offset,
    float2 dx, float2 dy)
{
    FlowmapData flow = GetFlowmapDataUV(input, uvShift);
    float2 uv = offset + flow.flowVector - float2(multiplier * (0.001 * ReflectionColor.w) * flow.color.w, 0);
    float mipScale = exp2(SharedData::MipBias) * sqrt(1.01 - flow.color.z);
    return float3(FlowMapNormalsTex.SampleGrad(FlowMapNormalsSampler, uv, dx * mipScale, dy * mipScale).xy, flow.color.z);
}
#endif
#endif
