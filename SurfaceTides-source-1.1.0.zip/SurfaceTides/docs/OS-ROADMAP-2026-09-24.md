# Native OS Water candidate — 2026-10-02

The user also accepts the Unified Water enabled on/off return visually; no new log accompanied that acceptance. Both accepted adapter configurations remain the baseline. The next priority is native OS Water replacement ON and simple ST removal, ahead of further performance work.

[Native OS test 1](OS-NATIVE-beta12-test.1.md) adds a separately opted-in `OSNativeWater=1` path. It augments copies of OS's actual compiled water source/feature definitions, leaves OS files/settings/cache intact, and returns directly to native OS rendering when inactive. An initial OS shader rebuild teaches ST the recipes; subsequent use has a private content/compiler-keyed cache. Compiled candidate only; in-game acceptance remains pending. The older accepted adapter stays available with `OSNativeWater=0`.

## Accepted adapter checkpoint

The user confirms correct on/off behavior with beta.12-os-state-test.1,
WaterEffects enabled and Unified Water disabled. The matching JSON/logs confirm
OS Water replacement OFF and ST OSUnifiedWater=0. Successful water bindings and
compatibility-only draws continue through preview-off, with zero failed draws.
See [acceptance and remaining checks](OS-TOGGLE-beta12-ACCEPTED.md).

New concrete uninstall lead: SettingsUser(2).json has CS Utility.water.waveAmplitude=0.
OS v2.13's own shader uses zero to flatten surface normals; its default is1.
Restoring this value is the next no-ST visual check. ST does not write OS settings;
the origin of the zero value is unknown. No uninstall success has been claimed.

The subsequent user report also accepts the toggle with UW enabled on both sides
(OS feature on and ST OSUnifiedWater=1); no new log was supplied for that return.
The accepted DLL remains available as a fallback. The false-height-switch guard was not
triggered in this return; keep observing rare spontaneous stops. Discovery remains
untested and off. Preserve accepted wind, ENB and Beta11 installer checkpoints.

## Earlier checkpoints below

# Active candidate: Beta 12 OS state test 1 — 2026-10-02

Correctness work takes priority over discovery performance testing. The 095353
log records a river-height switch from -250 to an unverified actor height
-107.1443, followed by an inactive frame 50ms later. The new candidate protects
still-attached, revalidated nearby water from that false immersion and retains
OS compatibility rendering when the simulation is off or temporarily absent.
See [candidate, uninstall control and test instructions](OS-STATE-beta12-test.1.md).

Latest uninstall control: re-enabling OS Water replacement changed pale water
into mirror-like water but did not fix it. The uninstall problem is unresolved.
Next requested: ST absent, OS Water ON, UW disabled at boot; return the winning
SettingsUser.json and Data/Shaders/Water.hlsl. See the candidate notes. Do not
repeat the failed Water-on-only control or claim the candidate repairs uninstall.

Target four remains untested and now defaults off (OptimizeDiscovery=0); its
implementation and previous source checkpoint are preserved. Accepted wind,
cache/prewarm, ENB ripple/camera and pond work remain. No field-size reduction.
The DLL is AE16 only, labeled 1.1.0-beta.12-os-state-test.1; do not promote until
in-game results. The full Beta 11 installer is unchanged.

## Historical checkpoints below

# Active source: Beta 12 discovery test 1

The wind performance change is accepted from the returned ENB A/B logs. The current candidate implements only target four: one-cell foam/ice-decal discovery slices, deferred handle-based shape inspection, phase timings, and an independent OptimizeDiscovery switch. See [discovery scope, comparison and limits](PERFORMANCE-beta12-discovery-test.1.md). The DLL label is 1.1.0-beta.12-discovery-test.1. Await in-game results before promoting this discovery candidate.

Preserve simulation size/detail, wind math, pond retention, ENB ripple/camera correction, OS support and caching. Target five is deferred. Record the user's larger-field request for later menu/coverage work; the existing resolution/spacing controls already permit field-size adjustments, but this test changes neither them nor their defaults. Keep the accepted wind-test overlay and Beta 11 installer as rollback checkpoints.

## Historical checkpoints below

# Accepted pond / target three performance work — 2026-10-01 UTC

The user accepts the pond repair; the new log confirms epoch 3 and -5327.14 retained against the dry -5616 actor fallback, with no further level switches. Keep the fix. They request returning to the original third performance target after renderer optimizations and shader caching/prewarming.

Target three remains game-thread wind math and recurring work. The current beta.12-performance-test.1 first pass optimizes continuous wind through world-space axis caches and per-step time terms, with a startup OptimizeSimulation comparison switch. Local portable solver measurements show substantial CPU reduction with sub-micro-unit height differences; this does not establish game FPS. Await matched northwest-route logs in both modes before promoting. Gusts, terrain scans/copies and remaining frame costs are unchanged and can be prioritized from that return.

Preserve accepted ENB ripple/camera fixes, OS integration, pond retention and caching. Color remains deferred, prior underwater issues remain absent, and no ENB implementation inspection is permitted. Do not repeat prior renderer/tessellation isolation tests for this CPU-only change. Beta 11 FOMOD remains unchanged; this is an AE16 overlay with no active INI or shader payload.

## Historical priorities below

# Beta 11 accepted checkpoint / dry-bank test — 2026-09-30

The user accepts coverage.2 as solving both ripple clipping and mid-distance water. Rename planned Beta 2 to Beta 11 and count upward thereafter. Package the accepted implementation for all three runtime profiles. Preserve Beta 1, all OS/caching work, the accepted camera fix and absent underwater defects. Color remains deferred.

Next: a returning water-exit reset at the pond below Deep Folk Crossing, also observed with OS. The returned log switches between -5327.14 and -5616 and repeatedly clears the field during bank crossings. A separate beta.11-pond-test.1 AE16 overlay changes dry-bank water selection and adds bounded level-switch diagnostics. Keep it out of the accepted FOMOD until a visual return. See POND-beta11-test.1.md for scope and tests. No ENB source/shader/bytecode/SDK inspection, repeated density tests or unrelated rendering changes.

## Historical priorities below

# Active coverage guard correction — 2026-09-30 UTC

The user reports coverage.1 restored the tiles but ripple clipping returned. The 123104 log records 13,249 base rejections, zero matches/marks, and 1,488 fallbacks; all 1,488 accepted camera corrections still apply. All 15 sampled base/wading color rows write RGB only (mask 7). coverage.1 mistakenly required RGBA (15), so the marking proposal was never exercised.

[Coverage test 2](ENB-RIPPLE-beta2-coverage.2.md) corrects that one guard, accepting RGB or RGBA while preserving blending, shader, stencil, same-target and other constraints. Added portable regression coverage includes the returned native RGB state. Await an AE16 return showing baseMatched/marked greater than zero and intact rings plus full water coverage. If marking activates but artifacts remain, investigate that actual result rather than treating the previous zero-activation run as a stencil failure.

Keep the released Beta 1 FOMOD and accepted camera fix, OS/Vanilla behavior and caching intact. No color work, repeated tessellation/culling tests or ENB implementation inspection. Prior underwater defects remain absent per the user.

## Earlier coverage checkpoint

# Active Beta 2 coverage candidate — 2026-09-30 UTC

The user reports continuous ripples with base-test.1, plus missing mid-distance tiles. The returned clip is consistent with blanket base-color suppression; the 112907 log has 3,215 applied depth corrections, 1,071,554 prepared draws and zero preparation/state failures. Treat the diagnostic as positive evidence for base-color overdraw, not a complete release fix or proof of a cell-streaming defect.

[Coverage test 1](ENB-RIPPLE-beta2-coverage.1.md) restores the default shader and supplies an AE16 DLL. Only matching native ENB wading pixels write the existing base exclusion bit, with recent same-view base-state verification, opaque-color and writable-stencil guards. All other recognized wading draws retain the accepted Beta 1 depth correction. The new startup switch defaults on; 0 restores Beta 1 coverage. Native stencil lifecycle and later consumers still require the user's in-game movement test. No full-coverage success is claimed yet.

Beta 1 FOMOD and its three runtime DLLs remain unchanged. This candidate is only cross-built for AE16. Preserve OS behavior, caching/prewarming, ENB guard removal and the current INI. Keep color parked and previous underwater defects marked absent. Do not repeat failed density/culling controls or obtain ENB source, shaders, bytecode or SDK.

## Earlier diagnostic planning

# Active Beta 2 ripple test — 2026-09-30 UTC

The corrected 031324 trace and INI confirm 24 successful sampled scopes, 3,649 wading corrections and no preparation failures. In seven co-sampled frames, ordinary 011E base color follows 015E wading color. This motivates [base-color isolation test 1](ENB-RIPPLE-beta2-base-test.1.md): a shader-only overlay that culls prepared 011E color geometry. Source default is off; the released Beta 1 FOMOD remains untouched. Await whether visible retained ripple arcs become continuous. Missing ripple water makes the result inconclusive.

Keep current ENB water/tessellation settings for this test. No repeated density/culling/splash-mod controls, global displacement disable or reopening color work. Preserve the accepted camera fix. The previous underwater issue remains absent per the user. No renderer source/shader/bytecode inspection.

# Beta 1 packaged / Beta 2 target — 2026-09-30 UTC

The user authorizes folding the accepted ENB fix into the complete Beta 1 FOMOD. Reuse the exact enb-depth.1 DLLs for AE16, SE and AE17; include the current full INI with MeshWadingDepth enabled. Preserve shader caching/prewarming, accepted OS behavior, all renderer/object choices and removed ENB presence guards.

**Beta 2 target:** investigate and fix native ENB ripple clipping. Compare ripple-bearing and main water geometry/depth handling if work resumes; no confirmed native-ENB ripple repair is waiting to be copied. Do not repeat the failed density/culling controls without new evidence. The camera shapes are fixed in the user's 1.6.1170 test, and prior underwater issues are absent in their current testing. Color stays parked. No ENB implementation/source/shader inspection is permitted.

Beta 1 is ready for broader stress testing after packaging validation. No additional rendering changes belong in this packaging task. Earlier no-promotion instructions below are historical and superseded by this authorization.

## Prior checkpoint history

# Accepted ENB depth correction — 2026-09-30 UTC

The user confirms enb-depth.1 fixes the camera-dependent surface shapes. The returned 1.6.1170 log confirms 7,659 corrections, no fallbacks or creation failures. Previous underwater issues are absent in the user's current testing; this log itself does not exercise underwater draws. Ripple clipping remains a minor known issue. Source history shows it disappeared with the switch to Surface Tides-owned rendering, not with a separate confirmed native-ENB repair. See [acceptance and ripple history](ENB-DEPTH-beta.1-ACCEPTED.md).

Keep the accepted DLL overlays and beta.1 caching/FOMOD checkpoint. This acceptance update changes documentation only. No new ripple change or FOMOD promotion is requested. Preserve OS/Vanilla rendering, parked color work, ENB-presence guard removal and all accepted fixes. Do not repeat failed tessellation/culling controls. No ENB source/code may be obtained or used.

# Current checkpoint — 2026-09-30

The user has authorized a complete public-test beta FOMOD, preserving shader caching/prewarming and all accumulated updates, and restoring experimental ENB integration for a quick test. ENB presence blocking is removed entirely, including the old AllowENB=0 behavior. Regular CS's configurable incompatibility guard remains. Do not obtain or use ENB source/code.

The returned northwest-Skyrim preview.10 log confirms persistent cache success: 77 hits, no cold/invalid/I/O failures, 11 pairs prewarmed in 58.687 ms. Warm-cache reuse is established for that session; overall FPS, VRAM and broader stutter attribution remain open. Retain the CPU comparison switch and timing reports. Northwest Skyrim is the user's intended controlled test location going forward.

[1.1.0-beta.1](BETA-1.1.0-beta.1.md) is the new packaging checkpoint: runtime-specific binaries, OS/ENB/Vanilla renderer choices, OS WaterEffects/Unified Water options, and native ENB integration or ENB-water-off fallback. Source/HLSL/cache/solver behavior otherwise stays at preview.10. The accepted OS motion/WE/UW baseline is retained. Color stays deferred. Gather broader stress-test results before further performance changes.

## Historical plan below — superseded where noted above

# Surface Tides — current OS priorities

Updated 2026-09-26. Current visual stress-test baseline: 1.1.0-os-preview.7-unified-water.

The motion-preservation test succeeded according to the user and is verified
active in the returned log. Keep it on by default for OS, with a saved switch.
Broader temporal/reflection quality testing remains, but the user explicitly
wants to retain the accepted OS effects and review performance before ENB. Do not reopen the solved movement-speed or
Wade in Water controls without a new regression.

WaterEffects is now accepted from the returned preview.6 log/clip and user report.
Unified Water is accepted for stress testing after the returned preview.7 run.
The active candidate is [preview.10 compiler-identity correction](OPEN-SHADERS-preview.10.md).
Both returned preview.9 runs successfully prewarmed the 11 seed pairs with no
later ST compilation, but the persistent cache was bypassed because the identity
lookup found SurfaceTides' import thunk. Preview.10 reads the resolved compiler
import target while preserving the strict compiler guard and existing compile
calls. Cross-launch cache hits still need confirmation. See [returned results](SHADER-CACHE-RETURN-2026-09-26.md).
The returned preview.8 comparison showed lower ST CPU indexing/setup costs but
did not isolate whole-game performance: cold ST shader builds occurred inside
the optimized clip and outside the reference clip. See [returned findings](PERFORMANCE-RETURN-2026-09-26.md).
The user authorized shader prewarming and caching next and will monitor VRAM and
try to record compilation. VRAM attribution is unresolved. Keep the CPU comparison
switch and timing measurements; compare two launches with identical settings.
Solver/wind optimization and tessellation changes remain outside this pass.
Preview.7 remains the accepted visual baseline; preview.10 requires game testing.
Do not claim every reported stutter is Surface Tides or promise an FPS gain without a controlled comparison.
Experimental ENB water integration follows this performance phase.

## Agreed sequence

1. Retain the accepted OS scene-motion workaround; reopen jitter only for a regression.
2. Retain accepted WaterEffects and Unified Water as the stress-test baseline.
3. Profile/optimize performance while preserving the accepted appearance and compatibility.
4. Revisit experimental ENB water integration after this performance phase. This
   means the previously deferred full integration, not a change to established
   ENB-water-off coexistence. Keep integration off until that phase. No ENB
   source/code is to be obtained or used.

Community Shaders remains unsupported with its existing default guard. Do not
reopen CS compatibility as part of these tasks.

Color investigation is parked. The user confirms the pale water persists with
Surface Tides, OS and ENB all removed and with or without water texture replacers.
This does not establish that it is the same issue as the original tester's
discoloration. Do not mark that original report fixed or add a tint adjustment
to hide it. Revisit color with more evidence and, later, ENB comparisons.

## Accepted rendering evidence

- SurfaceTides(20260924-002519).log loaded preview.4 but blocked it at the CS/OS
  compatibility guard because OpenShaders was not effectively selected. The user
  identified the wrong INI copy. The paired 18-24-20 clip/report still showed leg
  jitter with Surface Tides rendering inactive; that does not prove every earlier
  artifact has the same cause.
- SurfaceTides(20260924-013103).log selects OpenShaders=true, compiles/binds color
  passes including 031E and 035E, retains targetMask=7F and entryMask=7F, and advances
  uploadedSeq from 1 to 637. Draw failures are zero. The user confirms wakes return.
- The latter run does not log an address transition or "OS draw dispatch recovered".
  It establishes working rendering in preview.4, not an exercised recovery event.
- Color-test.2 and refraction-control.2 were already tested without resolving the
  reported issues. Do not repeat them as new tests. Reflection-probe.3's returned
  run lacked color-pass coverage and therefore yielded no reflection conclusion.

## Historical temporal investigation — do not repeat without a regression

The earlier supplied CommunityShaders.log (17:12 startup, version string
v2-13-0-0) explicitly reports "Frame Generation enabled, using D3D12 proxy" and
creation of an FSR3 context at 2560x1440 render/display resolution. The paired
SettingsUser(1).json has frameGenerationMode=1, frameGenerationForceEnable=0,
upscaleMethod=3, and upscaleMethodNoDLSS=2; the log reports DLSS unavailable.
These are historical settings, not confirmation of the user's current setup.

The OS source reference below maps method 0=None, 1=TAA, 2=FSR, 3=DLSS. Its UI
uses the no-DLSS method when DLSS is unavailable, and maps the Frame Generation
checkbox to frameGenerationMode 1/0 with a restart annotation. Native-resolution
FSR still uses temporal processing; selecting a native-resolution preset is not
equivalent to turning the method off.

Surface Tides already double-buffers current/previous simulation textures and
samples the previous field for stencil motion vectors. Its unjittered-matrix
screen-motion convention matches the inspected OS convention. This review does
not validate every depth/mask/history interaction or prove that FSR/FG causes
the artifact. It provides no justification for changing vector signs or deleting
motion outputs blindly.

## Historical preview.4 control — superseded by accepted motion workaround

Use the working preview.4 DLL/shaders and INI (BlockCS=1, OpenShaders=1). Keep
OS Water shader replacement off and WaterEffects/Unified Water disabled at boot.
Keep the old color/refraction/reflection diagnostic overlays disabled.

1. In OS's Upscaling page, switch **Frame Generation off**, save and fully restart
   Skyrim. Leave the upscaling Method and quality settings unchanged. Repeat the
   short leg/mace movement. Send the new SurfaceTides and CommunityShaders logs
   with the result/clip. Do not change brightness, water material, textures or
   simulation strength at the same time.
2. Only if jitter persists, leave Frame Generation off, set Upscaling **Method
   to None**, save and restart, then repeat. This is a temporary diagnostic;
   increased aliasing is expected without temporal anti-aliasing. Do not mistake
   that for the original moving-edge artifact.

For manual configuration, edit the current winning JSON with the game closed:
the first test changes only Upscaling.frameGenerationMode to 0 (and requires
Force Enable to be off, as it was in the supplied settings). The second test
sets both upscaleMethod and upscaleMethodNoDLSS to 0 while FG remains off.
Do not install an old full SettingsUser.json or add a persistent global override.
Prefer the UI and use the returned logs to confirm effective settings. If FG
is already off in the current setup, report that instead of repeating the test.

If the first control removes the jitter, frame generation or its inputs are
implicated; that is an isolation result, not a permanent "disable FG" fix. If
only the second removes it, investigate temporal reconstruction and its inputs.
If neither helps, return to depth/stencil/refraction coverage with that simpler
baseline. Preserve simulation and the accepted shoreline fixes throughout.

## WaterEffects phase boundary

No effects are enabled by this checkpoint. The inspected OS WaterEffects module
exposes WATER_EFFECTS and binds a caustics texture at PS t65. OS Water.hlsl also
uses feature-specific parallax helpers; this is more than a settings toggle.
Inventory the installed feature version, includes, constants/resources and
surface/underwater interactions at the start of that phase. Wetness Effects
is a separate feature and must not be conflated with WaterEffects. Do not enable
Unified Water or experimental ENB integration during WaterEffects validation.

## Source reference and limits

Open Shaders commit a996a271790ffa9f944d2d7e8a05e6fbd73a85d3:

- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/src/Features/Upscaling.h
- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/src/Features/Upscaling.cpp
- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/src/Features/WaterEffects.cpp
- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/package/Shaders/Water.hlsl

Only public OS code was read; no ENB code was fetched. The installed OS DLL's
exact commit is not established by its version string. No new native build,
shader modification or in-game test was performed in this checkpoint. Prior
preview.4 build evidence remains valid for its unchanged code, and the next
result requires the user's game run.
