# Open Shaders preview.6: accepted motion workaround and WaterEffects

Version `1.1.0-os-preview.6-water-effects`, 2026-09-24. The motion workaround is
accepted for the tested setup. WaterEffects integration is a new opt-in candidate
requiring an in-game test, with Unified Water deferred.

## Install and test

Install the ZIP matching your Skyrim executable over preview.5. Let the new DLL
and all seven Surface Tides shader files win conflicts. Keep your working INI;
the overlay does not install an active INI or any OS settings JSON.

Merge these keys into the **existing** `[Compatibility]` section:

```ini
[Compatibility]
OpenShaders=1
BlockCS=1
OSPreserveSceneMotion=1
OSWaterEffects=1
```

The first two should already be set. `OSPreserveSceneMotion` now defaults to 1
even when absent, applies only in OS mode, and can be changed live under
Appearance / Preserve scene motion (Open Shaders). Save tuning writes that key;
Reload tuning reads its saved value. The preview.5 session-only checkbox is gone.
The same target verification, write mask and render-state restoration are retained.

`OSWaterEffects` defaults to 0 and requires a restart. It enables Surface Tides'
adapter, not OS's feature itself. In OS, **uncheck WaterEffects under Disable at
Boot**, save, and restart Skyrim. Keep **Replace Original Shaders / Water off**
and **UnifiedWater disabled at boot**. Do not replace your whole OS preset or
clear its settings as part of this test.

Keep FG on, displacement 2 and normal strength 2 for the first comparison. Check
the same movement for recurring jitter, then look at sunlit shallow water and a
flowing river. Wakes and displacement should remain. OS's water controls govern
parallax strength/quality and caustics. Try parallax strength 0 versus its normal
value in OS to confirm that the new surface path responds live. Parallax depends
on height information in the normal textures; caustics also depend on lighting.
Send a short clip plus fresh SurfaceTides and OS logs so both the adapter and
OS feature startup can be checked. Interior and underwater checks are useful
after the initial river/lake result; do not change Unified Water yet.

## Returned motion result

The supplied `SurfaceTides(20260924-062137).log` records preview.5 on Skyrim
1.6.1170, OS explicitly selected, with an off/on/off comparison at displacement
2 and normal strength 2. The toggle was on from 00:20:57.847 to 00:21:07.577.
There were 173,921 reported applications to the verified motion target and zero
target mismatches, unsupported states or failures. The fully enabled reporting
interval applied the mask to all 99,121 identified stencil draws. Subsequent
fully disabled intervals return to zero applications. Hook masks remain 7F/7F,
draw failures are zero, and simulation uploads continue.

The user reports the test was very effective at preventing jitter and accepts
it as the interim solution. The 21.27-second, 1080p/60 clip was sampled for visual
inspection; this is not a quantitative jitter benchmark. No new paired OS log
was supplied, so FG-on follows the test setup and user report. The workaround
preserves existing scene motion; it still does not reconstruct refracted motion
or correct depth. Water history/reflections and other FG configurations need
broader testing. Details are in `os-preview.6-evidence/accepted-motion-result.json`.

## WaterEffects integration

The reviewed OS implementation splits the feature between:

- Caustics applied by OS's lighting shaders to the scene, using OS's texture at
  PS t65. Surface Tides leaves that lighting pass and binding alone. Applying a
  second caustics multiplier to the water's refracted color would double it.
- Surface parallax using the installed `WaterEffects/WaterParallax.hlsli` and
  live `SharedData::csUtilitySettings` values. The new adapter connects those
  helpers to Surface Tides' existing normal blending and displaced geometry.

Both ordinary normal layers and flow-mapped water are covered. Flow callbacks,
UV rotation and explicit-gradient sampling follow OS's public water shader.
Vertex-colored water, distant LOD and stencil passes do not use the adapter,
matching its intended parallax scope. No OS tessellation, Unified Water, wetness
ripples or additional water color changes are introduced.

`Includes` resolves `Common/` and `WaterEffects/` against the user's installed
OS shader tree. No OS shader headers, textures or binaries are redistributed.
The PS compiler checks that the new adapter was included, preventing an older
Surface Tides shader overlay from being silently reported as parallax-ready.
If an eligible feature permutation fails compilation, its bundle is retried
without the adapter; the accepted scene-motion workaround remains enabled.
If the base shader also fails, the existing native-draw fallback applies.

The adapter reads OS's live b4/b5/b6 buffers with sizes reflected from the
installed headers. It does not copy preset values, write OS settings, hard-code
buffer offsets or read GPU data back to the CPU. Invalid parallax inputs and
quality outside OS's supported 4..64 range bypass parallax; finite-result checks
prevent invalid offsets from reaching normal samples. OS retains its own
water-height assumptions for caustics; wave-synchronized caustics are not claimed.

## Diagnostics

- `OS compatibility`: saved startup options, with WaterEffects activation in OS
  explicitly left to the user.
- `OS scene motion tuning` and `OS scene motion`: live toggle/displacement and
  the existing target-verification/application counters.
- `OS WaterEffects bindings`: whether a permutation compiled with the adapter,
  plus whether anything is bound at t65. Binding presence is not texture identity
  or proof that OS enabled the feature.
- `OS WaterEffects`: counts of draws using adapter-compiled bundles and compile
  fallbacks since the preceding report. A configured strength of zero can still
  produce `parallaxDraws`; this counter establishes shader selection, not visible
  parallax magnitude.
- `OS WaterEffects adapter fallback`: exact compiler error when the installed
  interface does not work, followed by an attempt to retain the accepted shader.

To isolate a WaterEffects regression, set `OSWaterEffects=0` and restart while
leaving the motion workaround on. OS caustics will still run if enabled in OS;
disable WaterEffects at boot there as well to return to the complete preview.5
feature setup. Setting `OSPreserveSceneMotion=0` restores water motion writes.

## Validation and references

All six portable CTest suites pass. Secondary DXC checks pass 180/180 for each
of standalone, OS color-only and OS WaterEffects (540 total), across 23 water
descriptors/five stages plus existing mesh/motion stages. These are SM6 semantic
checks, with temporary namespace aliases for FXC-style OS buffers; those alias
headers and generated DXIL are never shipped. A native Windows SM5 validator
was rebuilt with an optional `--water-effects` mode, but was not executed in
this Linux environment. Skyrim performs the actual D3DCompiler/SM5 compilation
during the requested test. Cross-build/PE evidence for all three runtime DLLs is
in `os-preview.6-validation.json` and `os-preview.6-evidence/`.

Public source reference: [Open Shaders](https://github.com/alandtse/open-shaders/tree/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3),
especially `src/Features/WaterEffects.cpp`, `package/Shaders/Lighting.hlsl`,
`package/Shaders/Water.hlsl`, and `features/Water Effects/Shaders/WaterEffects/WaterParallax.hlsli`.
The parallax helper is byte-identical to release 2.14.0 at
`164d06bd657c07970e3633a8659bae061f6273b1`. This is interface validation, not proof
that the tester's installed DLL exactly matches that commit.

CS remains unsupported and guarded. Color remains parked. After WaterEffects is
confirmed, proceed to Unified Water, then the previously deferred experimental
ENB water integration. No ENB source or code was obtained or used.
