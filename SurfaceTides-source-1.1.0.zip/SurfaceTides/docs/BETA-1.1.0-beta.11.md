# Surface Tides 1.1.0-beta.11

Public Beta 11 rolls the accepted work since Beta 1 into one complete installer,
through the lava and decorative-puddle exclusion fix. The separate lava preview
is **not included**. This package supersedes the earlier ripple-only Beta 11
checkpoint and the water test overlays developed after it.

## Install or upgrade

1. Back up custom `SurfaceTides.ini` tuning. Disable older ST test overlays,
   including DLL-only and shader-only tests.
2. Install this FOMOD with MO2 or Vortex and **replace** the previous installation.
   Do not merge over it: deselected optional files must not remain. Remove any
   obsolete ST-owned `SurfaceTides_Global.json` override from an earlier test.
3. Choose your exact Skyrim executable, renderer and optional surface features.
   The installer supplies one matching DLL, seven ST shader/include files and
   a **fresh complete INI**. Reapply custom tuning selectively afterward.
4. Restart Skyrim. A first uncached water load can pause for shader compilation;
   allow it to finish. Follow the OS first-use step below if applicable.

| Skyrim executable | Build | Dependencies, installed separately |
| --- | --- | --- |
| Steam 1.6.1170 / GOG 1.6.1179 | AE16 | Matching SKSE 2.2.6 and AE Address Library |
| 1.5.97 | SE | SKSE 2.0.20 and SE Address Library |
| 1.7.104 | AE17 | SKSE 2.3.1 and matching Address Library v13 |

Other executables and VR are unsupported. SKSE Menu Framework 3.x is optional;
INI configuration works without it. Earlier runtime ports were tested by the
author. The latest native-OS/exclusion test returns were on Skyrim 1.6.1170;
this public build needs broader testing across the supported runtimes.

## Renderer choices

**Open Shaders (OS):** The installer sets `OpenShaders=1` and `OSNativeWater=1`.
Keep **Replace Original Shaders → Water ON** in OS. Choose WaterEffects and
Unified Water normally in OS; matching ST adapter switches are no longer needed.
On first use of this integration, request **one OS shader-cache rebuild with ST
loaded**, then let compilation finish. If you already completed that step with
the accepted native-OS test DLL, this package does not require another rebuild.
ST keeps its augmented shader copies and cache separate and does not write OS
source files, settings or its cache. Turning the ST preview off returns to native
OS water. For removal, disable ST and restart with OS Water replacement still ON.
The accepted scene-motion workaround remains enabled for frame-generation jitter.

Regular **Community Shaders is incompatible** and blocked by default. Select OS
only with an actual Open Shaders installation; the two share a DLL name.
`BlockCS=0` is retained solely as an unsupported manual testing bypass.

**ENB:** The recommended **ENB water integration (experimental)** option retains
native/ENB water shaders and allows ENB water to remain ON. It includes the
accepted camera-artifact and ripple-coverage corrections, including the intact
mid-distance water result. No separate ENB patch is needed. Previous underwater
problems were absent in the author's recent tests. The alternative **ENB water
off (coexistence)** uses ST water shading; save `[EFFECT] EnableWater=false` in
`enbseries.ini` beside SkyrimSE.exe, restart, and keep ENB water OFF for that mode.
The installer does not edit the preset. ENB presence never disables ST, and the
obsolete `AllowENB` key is ignored. Mixed OS/ENB installations are not established
as supported by this beta.

**Vanilla:** ST water rendering with no renderer framework required. If ENB is
present, this profile uses the water-off coexistence path automatically.

## Changes since Beta 1

- ENB ripple clipping and camera-dependent water artifacts corrected while
  retaining mid-distance water and native shading.
- Verified nearby water retained when leaving a pond, including the accepted
  Deep Folk Crossing test. Protection against false water-height switches also
  retains the active field when an actor's reported immersion is unreliable.
- Native OS Water integration, with the accepted refraction correction, guarded
  shader activation, working preview on/off behavior and simpler removal.
  WaterEffects and Unified Water use OS's own water shader configuration.
- Existing CPU renderer work, shader caching/prewarming and compiler-identity
  cache fix, plus cached continuous-wind calculations and sliced foam/ice-decal
  discovery. Timing reports remain enabled for beta feedback.
- Reviewed Forge lava and decorative WaterPuddle draws bypass ST augmentation
  and retain their native appearance. Shared ordinary-water meshes remain
  eligible; this is not a blanket ban on Water1024. Custom unreviewed lava/puddle
  types may need additional identification. There is no lava simulation addon.
- Existing attached/standalone foam choices, ice-decal filtering and optional
  ice-floe bobbing, with updated menu guidance and full installer INIs.

Standalone foam removal requires Base Object Swapper 3.0 or newer. Foam and ice
options are independent. Ice bobbing remains incompatible with Ice is Slick.
No replacement game meshes, textures, ESPs, Papyrus scripts or save records are
installed. The separate water-color investigation remains deferred; this release
does not claim to resolve color differences between renderer setups.

## Performance and feedback

`OptimizeRenderer`, `OptimizeSimulation`, `OptimizeDiscovery`, `ShaderCache`,
`PrewarmShaders`, `LogStats` and `PerformanceTimings` are enabled. Discovery now
spreads foam/ice-decal searches across updates. Its A/B return showed smaller
CPU peaks with a small average-cost increase; broader testing is needed. Newly
loaded foam/ice decals can take several updates to be discovered. This change
does not shrink the simulation field or reduce its resolution or quality.
Target-five workload reduction is not included.

Keep the private cache under `%LOCALAPPDATA%\SurfaceTides\ShaderCache` between
normal launches. ST water stages use `v1`; native OS augmentation uses
`NativeOS-v1`. Unknown variants may compile on demand. Native ENB mesh-input
stages retain their existing compilation path. Debug colors and detailed
pass/ripple traces default OFF.

For reports, include the log from that launch, winning ST INI, exact runtime and
renderer versions, water features, location, and whether the cache was warm.
Include OS's log for OS issues and a clip for visual defects. Copy logs before
another launch overwrites them. Repeated routes with unchanged settings are
most useful for performance comparisons.

## Package validation

All three Windows DLLs are built from the accepted water implementation with
public Beta 11 metadata. Fourteen portable suites, PE/runtime declarations,
XML schema, **192 installer paths** and **32 complete INIs** are checked. There
are fewer installer paths because the obsolete OS feature-matching page has
been removed. Each path installs exactly one matching DLL and full INI, the
seven ST shader files, notices and the requested BOS file where applicable.

Automated checks are not a MO2/Vortex UI test or in-game execution of these newly
built DLLs. The latest acceptance was on AE16; stress testing continues. The
installer/log label is `1.1.0-beta.11`. The packed machine version is `1.1.1.1`
because the four-bit SKSE revision counter had reached 15 during private tests.
Beta 1 and the separate lava-prototype checkpoint remain available as distinct
checkpoints. No ENB implementation, shader source, bytecode or SDK was accessed.
