# Surface Tides 1.1.0-os-preview.7 — Unified Water candidate

**Returned result, 2026-09-24:** the user reports no visible issues and accepts
preview.7 for stress testing. Fresh ST/OS logs confirm both OS features active;
ST draw, parallax fallback and motion-target failure counts are zero. Performance
assessment now precedes ENB. See PERFORMANCE-REVIEW-2026-09-24.md. The following
installation/design notes describe the original candidate; binaries are unchanged.

2026-09-24. Preview.6 is the accepted WaterEffects baseline. This candidate adds
an opt-in adapter for Open Shaders Unified Water while retaining WaterEffects
and the accepted scene-motion workaround. Unified Water needs an in-game test.

## Install and test

Install the zip matching your Skyrim executable after the working Surface Tides
installation and older shader overlays. Replace its DLL and all seven files in
Shaders/SurfaceTides. The overlay supplies no active INI or OS settings JSON.

In the winning `Data/SKSE/Plugins/SurfaceTides.ini`, keep the existing settings
and add `OSUnifiedWater=1` under the existing `[Compatibility]` section:

```ini
[Compatibility]
BlockCS=1
OpenShaders=1
OSPreserveSceneMotion=1
OSWaterEffects=1
OSUnifiedWater=1
```

In OS, uncheck **Unified Water / Disable at Boot**. Leave WaterEffects enabled
and **Replace Original Shaders / Water OFF**. Save and fully restart Skyrim.
The Surface Tides flag does not enable OS's feature automatically. Both sides
must agree: using UW's engine layout with the ordinary shader coordinates, or
vice versa, is unsupported. OS retains its own mesh/cache generation; allow
that startup work to finish. No cache deletion or preset replacement is needed.

Keep the accepted FG, displacement and normal settings for the first test.

1. Return to the same river. Check wakes, wading transitions and flowing normals.
2. Look across a lake or coast while moving the camera: check distant tiles,
   seams and fog, then move toward the water to exercise near/distant transitions.
3. Enter an interior with water and return outside; briefly check underwater.

Send fresh SurfaceTides and CommunityShaders logs and a short clip. The latter
log can establish whether OS itself activated Unified Water. Our counters only
establish that the requested adapter was compiled/selected. If anything regresses,
set `OSUnifiedWater=0`, disable Unified Water at boot in OS, save and restart.
That restores the accepted feature configuration; the preview.6 zip is retained
unchanged for a full rollback. Leave OSPreserveSceneMotion and OSWaterEffects on.

## What changed

OS Unified Water constructs larger water tiles and still submits them through
BSWaterShader. Its exterior SetupGeometry hook reuses ObjectUV.xyz for flowmap
width, height and tile scale, plus worldspace cell offsets. This adapter uses
that public layout without installing new engine hooks:

- Rectangular flowmap dimensions throughout cell blending and parallax sampling.
- Scaled tile UVs and OS's separate wading/displacement-mesh coordinate formula.
- Per-pixel distance and surface fog for large tiles, with UW's close-water
  reflection/refraction blend at distance. Existing normal-distance fading stays.
- The simulation still displaces/tessellates its local patch; UW owns distant
  mesh generation and caches. No claim of simulation across the whole worldspace.

The startup flag defaults off and only acts in explicit OpenShaders mode.
Interior descriptors and stencil/motion shaders keep their baseline layout;
native LOD passes are still left untouched. UW-generated close-water tiles use
the adapted close-water path. This scope needs transition testing in game.

WaterEffects compilation may retry without parallax, but always retains the
requested UW layout. It must not silently fall back to ordinary coordinates
while OS continues supplying UW constants. If that shader also fails, the
existing native-draw fallback logs the failure; native water with UW constants
is not guaranteed to look correct. Disable UW on both sides before retesting.
Old shader overlays missing the adapter trigger an explicit compilation error.

OS owns caustics, t8 flowmaps, textures, meshes and settings. No new texture
bindings, GPU readback, feature hooks or preset writes are added. The verified
motion-target mask and draw-state restoration are unchanged. No tint adjustment
or ENB implementation change is included. Regular CS remains guarded/unsupported.

## Baseline evidence and diagnostics

The returned preview.6 log, SurfaceTides(20260924-075621).log, records 261 periodic
samples, 415,656 parallax draws, zero compile fallbacks and no warning/error lines.
All 22,051,975 reported stencil draws received the motion mask, with zero target
mismatches, unsupported states or failures. Counters are draw calls, not frames.
The user reports no noticeable issues and accepts this baseline. The supplied
33.92-second 1080p/60 clip was sampled; this is not a frame-perfect jitter metric.

New log lines:

- `OS compatibility`: requested startup flags.
- `OS UnifiedWater bindings`: adapted bundle, flowmap permutation and t8 binding
  presence. Presence is not texture identity or OS feature-state detection.
- `OS UnifiedWater`: adapted draws and flowmap draws since the previous report.
  Nonzero counters do not prove correct visual output or full tile coverage.

Existing WaterEffects, motion and draw-failure diagnostics remain available.

## Validation and source

All three Windows DLL profiles build; PE metadata is verified separately for
1.5.97, 1.6.1170/1.6.1179 and 1.7.104. This does not establish that OS supports
each executable. Six portable test suites pass. Secondary DXC checks cover
27 water descriptors/five stages plus 65 mesh/motion cases in each of five
configurations: standalone, OS color only, WaterEffects, UW, and UW+WaterEffects
(1,000 checks). Interior flowmaps, vertex color, stencil, underwater and LOD
are included. DXC produces temporary SM6 validation code, not Skyrim's SM5 code.
The native SM5 validator was rebuilt with `--unified-water` and `--water-effects`
options but cannot be executed here. Runtime D3DCompiler and game behavior remain
to be verified by the returned test. See os-preview.7-validation.json.

Public source: [Open Shaders v2.13.0](https://github.com/alandtse/open-shaders/tree/v2.13.0),
`src/Features/UnifiedWater.cpp` and `package/Shaders/Water.hlsl`. UnifiedWater.cpp
is byte-identical to the earlier pinned reference at
`a996a271790ffa9f944d2d7e8a05e6fbd73a85d3`; the relevant UW shader branches were
checked against v2.13.0. The clip shows OS 2.13.0, but the exact installed package
is not independently verified. Provenance/hashes are included with the evidence.
No OS assets or headers are redistributed. No ENB source/code was obtained or used.

After Unified Water is confirmed, the agreed next task is experimental ENB water
integration. Color remains parked until there is more evidence.
