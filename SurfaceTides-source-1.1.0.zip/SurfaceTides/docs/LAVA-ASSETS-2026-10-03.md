# Accepted exclusions and lava asset inspection

## Acceptance

The user confirms the surface-exclusions-test.1 fix works. Returned log
`SurfaceTides(20261003-084439).log` runs AE16 1.6.1170, native OS Water, and
OptimizeDiscovery=true. Across the reported intervals it records 17,707 lava
draws and 14,462 puddle draws forwarded without ST augmentation. The first
matched lava scopes use reference 02015C60, base 02014B85, water 02014B86, and
geometry `Water1024:0` at passes 5C00006D and 5C0001AF. Puddle matches include
02017A1A, 02009D48 and 02009D47, all base 0009727E, geometry `WaterPuddle01:0`.
The first logged puddle also matches passes 5C00006E and 5C000230.

All 50 native readiness reports are F/F, enabled=true, failureLatched=false;
augmentation failures and rejected native draws remain zero. There are
3,124,970 reported augmented native draws elsewhere in this session. Private
cache reuse continues: captured=0, recipeHits=13, bytecodeHits=34, compiled=0,
tagged=106. Counts are logged report totals, not necessarily every final draw
before process exit. Ordinary-water visual behavior was not supplied as a new
clip; user acceptance and these draw counters are the available evidence.

One warning at 02:34:51.197 reports the scene-motion workaround declining an
unverified stencil RT1. This is the existing guarded fallback retaining normal
rendering, not an augmentation failure. No errors are logged. Do not silently
relax that verification based on this warning.

Keep the existing test-1 DLL and exclusions. This checkpoint changes analysis/
documentation and an offline inspection tool only, not game runtime/defaults.

## Lava1024 is resolved

The clip identified the ACTI `Lava1024`, not a guaranteed NIF filename. The new
runtime log explicitly resolves its winning model to `Water\Water1024.nif`,
which is among the supplied files. Its effective water form is Dawnguard.esm
local 0x14B86 (02014B86 in the supplied load order). There is no evidence that
another Lava1024.nif is required by this setup.

Other winning paths:

- Puddle: `Water\WaterPuddle01.nif`.
- Forge pool art: `DLC01\Dungeons\Dwemer\Animated\DweSpecialForge01\DweSpecialForgeLava01.nif`.

The latter was supplied without its original directory structure; the runtime
log supplies that path. Subsequently supplied xEdit screenshots confirm the
ACTI/WATR link and water settings; that evidence belongs to the separate prototype source checkpoint.

## Read-only NIF inspection

All seven files successfully load with ousnius/nifly commit
`cca0a770094bb962fb28ea1fec5ea903e68fda8e`, the same parser revision used for
earlier ST foam work. Results include block types, hierarchy, shader links,
textures, controller targets, alpha state and unanimated NIF-space bounds.
The tool neither modifies nor saves NIFs. It does not render DDS content,
evaluate controller keyframes, or infer placed-reference position/scale.

| Supplied file | Confirmed structure | Prototype relevance |
| --- | --- | --- |
| dwespecialforgelava01.nif | Five effect-shader shapes: one flat pool plane, four animated GeoSphere bubbles | First pool target; select the plane, retain the separate bubble controllers initially |
| dwespecialforgelava02.nif | One small flat effect-shader patch, 21 vertices / 28 triangles | Additional surface variant; exact placement/base still unconfirmed |
| dwespecialforgelava03.nif | Three effect-shader shapes forming a vertical assembly, extending from about Z=0 to -512 in NIF space, with collision | Vertical column; out of current scope |
| dwespecialforge01.nif | Forge apparatus, 13 shapes, behavior graph, transform/visibility controllers and collision; 12 lighting shaders and one Aetherium effect shader | Preserve machinery and gameplay animation; not the pool target |
| water1024.nif | One flat BSWaterShaderProperty shape, 81 vertices / 128 triangles; 1024 by 1024 NIF-space bounds | Actual Lava1024 activator model; generic/shared water asset |
| water1024anim.nif | One flat water-shader shape, 1089 vertices / 2048 triangles; 4096 by 4096 NIF-space bounds; no NiTimeController blocks | Denser alternative; not bound by the observed Lava1024 and not a drop-in equivalent based on filename |
| water1024noreflections.nif | One flat water-shader shape, 81 vertices / 128 triangles; 1024 by 1024 NIF-space bounds | Alternative water flags, not the observed model |

The standard and no-reflection files have waterFlags 196 and 132 respectively;
the animated-named file also has 132. No interpretation of additional unknown
flag bits is required for selection. Do not globally replace any shared water
mesh for this addon.

## Visible pool target and explanation of the old artifact

In dwespecialforgelava01.nif, block 66 is `DweSpecialForgeLava01:0`. It has
81 vertices and 128 triangles, spans -1024 to 1024 on both axes, and is flat
at approximately Z=0.000244 in NIF space. It uses BSEffectShaderProperty block
67, has no geometry transform controller, and has no NiAlphaProperty. Its
material has color and float controllers; the latter controls variable 6.
The four GeoSphere shapes each have 108 vertices / 180 triangles and separate
transform, color, float and alpha-threshold controller chains.

The pool plane references:

- `textures\dlc01\clutter\WavyTurbulence01.dds` as source.
- `textures\effects\gradients\GradHotCoals.dds` as greyscale/gradient.

The bubbles reference:

- `textures\effects\FXfluidStream01.dds`.
- `textures\dlc01\effects\gradients\GradLavaBubble.dds`.

The visible lava artwork therefore is not the BSWaterShader plane ST originally
displaced. The water draw and effect-shader plane are separate; this explains
the observed water waves emerging through otherwise flat lava art. Their exact
placed transforms cannot be reconstructed from NIFs alone, so synchronization
must use each live reference transform and the active lava-water level rather
than assuming both files share bounds or scale.

## First prototype design

Use an optional lava renderer/simulation, keyed to the confirmed lava identity,
while base ST continues to exclude lava and decorative puddles. First target
only the flat pool shape in the reviewed Lava01 model, initially preserving its
existing source/gradient look. Give it slower, strongly damped disturbances and
local upwelling forcing, with its own settings. High damping alone should not
be labeled a full viscous-flow solver. Actual viscosity/heat/crust advection
remain later simulation work.

Do not simply turn ordinary water displacement back on. The addon needs one
coherent visible surface: either synchronize the water and effect layers using
the same lava field, or suppress only the redundant lava-water rendering while
preserving the activator's immersion/damage behavior. The latter needs explicit
color/stencil and underwater validation before becoming the default. Preserve
the bubble controllers, forge mechanisms, collision and falling column.

The 128-triangle pool provides a starting mesh but will need more sampling for
small disturbances; prefer controlled subdivision/tessellation of this lava
surface, not expansion of ordinary ST water workload. Scope selection must use
reviewed base/model/shape identity and preserve asset overrides deliberately.

For OS PBR, these effect-shader planes are not already PBR lighting materials.
The previously examined OS 2.13 TruePBR.cpp handles BSLightingShaderProperty and
requires diffuse/normal/RMAOS material inputs, with separate emissive bindings.
Options are a lava-only conversion to that material path or a custom lava
shader using an explicit material contract. A texture assignment alone cannot
provide that integration. ENB Complex Material is a separate compatibility
target; no ENB implementation/shader/SDK/bytecode is consulted or promised.

## Subsequent evidence and implementation

The supplied ACTI/WATR screenshots close the record-identification request.
The first prototype uses live reference transforms and the existing loaded
textures, so neither placed-reference screenshots nor DDS bytes are required
to begin it. DDS bytes have not been inspected for channel content.

This document records the earlier asset-review checkpoint. The subsequent lava
prototype is maintained in a separate source/test package and is not included
in public Beta 11. Base lava exclusion remains active in this public branch.
