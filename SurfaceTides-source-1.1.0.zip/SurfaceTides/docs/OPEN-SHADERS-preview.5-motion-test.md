# Open Shaders preview.5: scene-motion diagnostic

Version `1.1.0-os-preview.5-motion-test`, 2026-09-24. This is a reversible
diagnostic built on the working preview.4 renderer, not a confirmed jitter fix.

## Test

1. Install the ZIP matching your Skyrim runtime over preview.4. Let its DLL and
   six normal Surface Tides shader files win conflicts; disable older diagnostic
   overlays. It contains no active INI or OS settings JSON. Preserve the working
   `OpenShaders=1`, `BlockCS=1` configuration and enable `LogStats=1` for the log.
2. Keep OS frame generation on and its Water shader replacement, WaterEffects
   and Unified Water off, as in the working Surface Tides control. Keep temporal
   upscaling and all other settings unchanged. Use Displacement Strength 2.00 and
   Normal Strength 2.00, with diagnostic colors off.
3. In Surface Tides **Appearance**, toggle **OS test: preserve scene motion
   (this session)** off, on, then off again. Repeat the same movement past the
   same camera in the same water. Include stationary moments and faster movement.
   Hold Wade in Water's state constant; the user has already ruled it out.
4. Send a short comparison clip and the fresh SurfaceTides log. Note any change
   in FPS as well as jitter, wave quality or ghosting. A fresh OS log can confirm
   the frame-generation startup path if its settings changed.

The toggle defaults to off each launch, takes effect live without resetting the
simulation, and is never written to the INI. Reloading the INI retains its current
session value; restoring session-start tuning switches it off. Switch it off to
restore the previous motion writes, or disable this overlay to return to preview.4.

## Why this test

The user reports substantially less jitter with OS frame generation off. OS's
native water with FG on showed slight similar blur, but did not reproduce the
same stronger Surface Tides artifact. Lowering displacement from 2 to 0 made
the issue less obvious while normal strength remained 2. Removing Wade in Water
Redone did not fix it: faster movement made the artifact worse.

These observations implicate temporal handling of moving objects seen through
water. They do not identify a particular motion-vector calculation as wrong.
The next test keeps full wave displacement while preventing one water pass from
overwriting existing scene motion. See OS-FRAMEGEN-2026-09-24.md for the evidence.

## Implementation

- OS mode only; both identified shader stages must use water stencil technique
  10. Color, underwater and LOD passes are untouched.
- Before changing state, compare the canonical COM resource identity of bound
  RT1 to the engine's current `kMOTION_VECTOR` texture. An absent or different
  target leaves rendering unchanged and reports `targetMismatch`.
- Set only that target's color write mask to zero using a cached blend state.
  This retains prior contents; it does not clear motion or write zero vectors.
  Preserve effective blending for all other targets, alpha-to-coverage, blend
  factors and sample mask. Restore the original blend state after the draw.
- Null blend state is expanded to the documented D3D11 defaults. States using
  D3D11.1 logic operations and excess variants beyond the bounded cache are left
  alone. Shader outputs, displacement, depth/stencil and the solver are unchanged.
- Default-off bypasses the new output-merger queries and changes. Regular CS's
  guard, standalone rendering and established ENB-water-off coexistence remain.

Microsoft's [blend descriptor documentation](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ns-d3d11-d3d11_blend_desc)
specifies that target 0 controls every render target when independent blending
is disabled. The helper therefore copies its effective state before enabling an
independent write mask for RT1. Merely editing the inactive RT1 descriptor would
not work, and enabling independent blending without that copy could affect
other outputs.

## Reading the log

`OS motion test tuning` records the toggle, displacement and normal strength at
each applied tuning revision when LogStats is enabled. Periodic `OS motion test`
lines report stencil draws and the counters since the preceding report:

| Counter | Meaning |
| --- | --- |
| `applied` | The verified target was found and the modified blend state bound. |
| `alreadyMasked` | The original state already prevented RT1 writes. |
| `targetMismatch` | RT1 did not match the engine motion texture; no change made. |
| `unsupported` | A logic operation or the cache limit prevented the change. |
| `failed` | Blend-state creation or another caught operation failed. |

With the toggle on, a useful negative result requires `applied` to increase.
Intervals crossing a toggle can contain both states; use the tuning lines as
boundaries. `applied` verifies this code's binding, not what a later hook or pass
does to the buffer. Target verification warnings appear only once per session.

## Limits and next decision

This preserves whatever scene motion already exists; it does not reconstruct
motion for refracted objects or resolve depth mismatch. Later passes may still
overwrite the data. It changes a shared motion buffer used by temporal rendering,
not an input exclusive to frame generation. Reflection/wave history may worsen,
and extra state queries may cost performance while enabled.

Improvement would implicate water-motion replacement and justify a narrower
depth/coverage-aware correction. No change with a verified active toggle would
redirect investigation toward remaining depth, coverage and refraction history.
Neither result alone proves the entire FG implementation is correct or incorrect.

The six portable test suites pass. The motion-control suite checks effective MRT
state preservation, unchanged input, idempotence, stencil selection and default-off
tuning without simulation reset. Windows builds and PE metadata checks are
recorded in os-preview.5-motion-validation.json. No Skyrim/GPU execution or
runtime blend-state restoration has been tested here; that requires this game
test. HLSL is byte-identical to the accepted preview.4 source baseline.

Color remains parked. WaterEffects, Unified Water and full experimental ENB
water integration follow the jitter investigation in that order. No ENB source
or code was obtained or used.
