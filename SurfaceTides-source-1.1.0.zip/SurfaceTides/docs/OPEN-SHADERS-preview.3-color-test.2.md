> Returned result, 2026-09-23: neither this candidate nor its refraction control
> resolved color or jitter. These tests are complete. Disable their overlays
> and follow OPEN-SHADERS-preview.3-reflection-probe.3.md for the next diagnostic.
> The following text records the original test, not a confirmed fix.

# Surface Tides OS preview.3 — color test 2

2026-09-23. Shader-only candidate for the existing preview.3 DLLs.

## First run: color candidate

Install `SurfaceTides-OS-preview.3-color-test.2.zip` after preview.3 and shader
hotfix 1; let this package's `Shaders/SurfaceTides/Water.hlsl` win. Restart
Skyrim. Keep the currently working INI and OS feature settings. No cache purge,
DLL rebuild, preset change or save cleanup is needed. The log still reports the
preview.3 DLL version.

Repeat the river/mace movement from the latest clip. Report whether the blue
veil changes and whether the mace edge still jitters. Send the new log and a
short clip. This is a candidate, not a confirmed visual fix.

## Optional second run: refraction control

Only if the mace still jitters, install
`SurfaceTides-OS-preview.3-refraction-control.2.zip` after color test 2 and
restart. Repeat the same movement. This retains the color candidate but removes
above-water refraction UV distortion on the depth-supported water passes.
It retains simulation waves, surface normals, reflections, contact blending,
stencil/motion outputs, and the accepted wading-depth workaround. It is a
comparison control, not the intended final appearance.

A reduction specifically implicates the refraction sampling/distortion path;
it does not by itself prove a particular depth, filtering or temporal fault.
If unchanged, remove the control and keep color test 2 for the next diagnosis.
Disable both test overlays to return to shader hotfix 1.

## Returned evidence

The supplied `SurfaceTides(20260923-143338).log` reports the OS adapter ready for
031E, 410E, 430E, 035E, 3002, 015E and 011E, plus stencil 5000/5001. Reported draw
failures are zero. Required color PS b4/b5/b6 sizes are [144,0,1760]; live sizes
are [192,16384,1792]. The previous `FrameBuffer::name` compile fault is resolved
in the user's actual runtime. No remaining binding failure is established.

The 13.8-second clip shows restored water coverage and a pale blue-gray river;
the user reports small motion artifacts around the mace. Video alone cannot
separate refraction, temporal reconstruction and depth/stencil coverage.

## Color change and limits

The old adapter converts color spaces but then uses the older water composition:
combine captured scene and water tint, then apply reflection and surface fog to
the combined result. The OS 2.14 shader has a different non-vertex-color path:
shade/fog the water material, apply scene fog to the captured scene separately,
and use material opacity to combine them. The zero-opacity endpoint therefore
preserves the captured scene instead of adding the surface reflection/fog veil.
The candidate adopts that composition, uses material opacity for the OS
vertex-color reflection blend, and honors OS's Fresnel minimum/maximum controls.
This is a concrete source discrepancy and a plausible contributor to the reported
color; an in-game comparison is still required to establish its visual effect.

Surface Tides' displaced-depth calculation and guarded refraction coordinates
are retained. Scene fog uses the existing unperturbed scene-depth sample; this
is not a complete port of OS's refracted-depth reconstruction. Dynamic cubemaps,
skylighting/IBL, height fog, directional shadow sampling and clustered lighting
are not newly integrated. Reflection sources and the water material/preset can
still affect the result. No arbitrary tint or gamma correction is applied.

The old PS015E zero comparison-depth workaround remains. Historical traces
validated its shoreline benefit with specific native depth/stencil states;
they do not establish foreground occlusion correctness under OS. This test does
not remove it or claim it caused the mace jitter. The OS motion-vector helper
matches the referenced OS helper's unjittered matrix/sign convention.

Reference: [Open Shaders 2.14 Water.hlsl](https://github.com/alandtse/open-shaders/blob/164d06bd657c07970e3633a8659bae061f6273b1/package/Shaders/Water.hlsl),
`GetWaterDiffuseColor`, `GetFresnelValue`, and non-VC/VC final composition.
Installed OS Color/Permutation/FrameBuffer helpers remain unmodified.

## Validation

See `os-preview.3-color-test.2-evidence/` and `tools/validate_os_color2.py`.
Secondary host DXC/SM6 checks pass for standalone and OS 2.14. The comparison
checks standalone bytecode identity with hotfix 1, unchanged OS geometry and
stencil/motion bytecode, unchanged resource binding tables and depth/discard
presence, and the narrow scope of the optional refraction control.
These checks use the documented validation-only namespace adaptation for OS
headers. They do not establish native Windows D3DCompiler/SM5 or in-game success.
No DLL, simulation, hooks, offsets, INI or user JSON is changed.
