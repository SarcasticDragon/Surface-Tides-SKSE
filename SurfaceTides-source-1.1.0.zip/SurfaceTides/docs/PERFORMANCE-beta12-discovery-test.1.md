# Beta 12 discovery test 1

> Testing resumed October 3, 2026 on the accepted native OS test-2 DLL. Use
> `[Performance] OptimizeDiscovery=1` explicitly: the current default is 0.
> Keep that current DLL; do not reinstall this older discovery-only overlay.
> See `OS-NATIVE-beta12-ACCEPTED.md`. The original notes below describe the
> historical discovery candidate, including its former default of 1.

Version: 1.1.0-beta.12-discovery-test.1. AE16 DLL overlay for Skyrim 1.6.1170 / GOG 1.6.1179. Packed SKSE revision remains 15; the complete display label and binary hash distinguish this build. Focused test candidate, not a new complete installer.

## Accepted baseline and scope

The user accepted beta.12-performance-test.1 continuous-wind optimization after ENB A/B runs. Selected fully active clip windows averaged 1.363637 -> 0.573216 ms for the solver and 1.625135 -> 0.848909 ms for the total ST game update. Both logs reported zero clipped steps or dropped time. These are CPU wall-time scopes, not game-wide percentages or post-frame-generation FPS. Camera positions differed, and short disabled spans mixed with active work in the five-second reports; the reported 135 -> 145 disabled FPS remains unconfirmed. Exact selected windows and input hashes are in beta12-discovery.1-evidence/wind-accepted-return.json.

Only original performance target four is authorized now. Preserve the accepted wind optimization, dry-bank pond fix, ENB camera/ripple coverage, OS integration, prewarming and shader cache. Target five is deferred. Simulation resolution, spacing, field reach, edge fade, terrain sampling, wave physics, gusts, tessellation, rendering and menu values are unchanged.

## Discovery change

Previously Foam.cpp searched every attached grid cell plus the sky cell in a single update once per second, including scene inspection while enumerating cell references. This candidate:

- Searches one attached cell per update, with the current player cell first. The same exterior grid/sky scope and interior-cell scope remain eligible, without a new cell-count cap. The existing 128 tracked-reference limit remains unchanged. Prioritization at that existing limit can differ from the old grid order.
- Queues handles only for eligible model profiles from that cell, then releases the engine cell lock before detailed shape inspection or cull changes. It drains that cell's queue before searching the next cell.
- Processes at most eight queued candidates per update, with a 200-microsecond soft discovery budget. At least one pending candidate can progress even if enumeration exceeded the budget.
- Restarts discovery and discards queued handles when the world/interior or observed attached-cell identity/order changes. Cell pointers and reference-set iterators are reconstructed within each update, never retained for deferred use.
- Revalidates handles, attachment, model/profile and current 3D immediately before inspecting a queued object. Existing tracked objects continue their original per-update validation and restoration. Turning the effect off immediately restores tracked shapes and clears pending discovery.

This is deliberately a cell-granularity optimization. One unusually dense cell's enumeration or an individual engine operation cannot be preempted by the soft budget; the candidate does not guarantee a 0.2-ms whole-update ceiling. Candidate handles for one cell can occupy more than eight slots, but at most eight are consumed per update. Discovery may take several updates after streaming, and an unusually large/dense grid may take longer than one second to sweep. An unfinished sweep completes before restarting, so slow scans cannot repeatedly strand later cells. No permanent negative cache masks newly available 3D. Floe discovery/bobbing and its existing slicing are untouched.

## Install and comparison

Replace the previous wind-test DLL overlay with this overlay, keeping the working Beta 11 base, INI and shaders. No INI replacement or shader-cache deletion is required. Verify the full discovery-test.1 label and Object discovery: OptimizeDiscovery=true in the new log.

The independent startup setting [Performance] OptimizeDiscovery defaults to 1 when missing. Set OptimizeDiscovery=0 and restart to compare the original whole-grid discovery using this same DLL. Keep OptimizeSimulation=1 so the accepted wind improvement stays enabled in both runs. Restoring the previous wind-test overlay is a full rollback of discovery changes.

With PerformanceTimings=1, the existing ST CPU game foam report covers the overall filter update. New ST CPU discovery maintenance, enumerate and inspect rows separate the work, and ST discovery counters show scanned cells/references, queued/inspected/matched/stale candidates, invalidations and backlog. The reference-mode enumerate scope includes nested inspections; do not add nested scope totals. Optimized enumerate includes cell-list preparation/checking, including idle updates. Inspect counts cover eligible untracked roots; queued candidate counts can also include handles later invalidated. These are CPU wall timings only, and no per-object timing logs or GPU queries are added.

Return a fresh log from the usual route for the first test. Look for reduced periodic maxima in the overall foam phase, and confirm foam/ice removal still behaves normally when approaching or loading an area. An old/new A/B is available if the difference is unclear. Native game visual/performance testing is pending; portable tests alone do not establish less stutter.

## Deferred coverage request

The user reports feedback that the field appears to cover roughly one water cell, and wants a larger-field option for those willing to spend more performance. Do not shrink coverage or perform target-five geometry changes as part of this work. The current menu already has Simulation grid and terrain / Grid resolution / Grid spacing / Apply grid. Later work should examine actual useful coverage including the edge fade, make coverage clearer in the menu, and assess increased resolution versus increased spacing before selecting presets or raising limits. Existing controls, limits and defaults are retained for this test.

## Validation and release limits

The portable discovery suite checks full attached-cell coverage (including 401 cells), cadence, progress through slow sweeps, cell/area invalidation, empty scenes, reset/re-enable, and both inspection budgets. Existing eleven portable suites are also run. Package checks compare the complete source against the accepted wind archive, retaining all previous files and proving solver, shaders, renderer, hooks, menu, pond selection, shape-selection rules and tracked-object maintenance unchanged. The AE16 Windows DLL is cross-built and checked for AMD64, SKSE exports and exact runtime declarations. No native Skyrim execution or GPU measurement is performed here. SE/AE17 and the complete FOMOD are not rebuilt for this focused test. No ENB implementation/source/shader/bytecode/SDK is accessed.
