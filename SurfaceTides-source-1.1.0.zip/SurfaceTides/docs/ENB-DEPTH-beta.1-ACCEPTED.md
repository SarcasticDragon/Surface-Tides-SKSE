# ENB depth correction accepted — 2026-09-30

**Subsequent packaging decision:** the user authorized promoting these exact DLLs into the complete Beta 1 FOMOD, with ripple clipping targeted for Beta 2. See [current release notes](BETA-1.1.0-beta.1.md). The docs-only checkpoint scope below records the earlier acceptance turn.

The user confirms that 1.1.0-beta.1-enb-depth.1 fixes the camera-dependent shapes. The returned Skyrim 1.6.1170 log records 7,659 eligible primary-wading draws, all corrected, with no native fallback or state-creation failures. The observed state has stencil read mask 2 and reference 3. See [returned evidence](enb-depth.1-evidence/accepted-return.json).

The user also explicitly reports that the earlier ENB underwater problems are absent in their current testing. Treat these as not reproduced, rather than an active known defect in this setup. The supplied log records zero underwater samples, so this status is based on the user's testing, not independent underwater coverage in this capture. The binary's older startup wording about known underwater defects is stale; update it when next changing the binary, without rebuilding solely for that message.

## Ripple clipping remains distinct

No confirmed, separate native-ENB ripple fix was found waiting to be copied:

- [0.1.15](RESUME-0.1.15.md) restored native stencil/motion handling with MeshMotionVectors=0. The partial improvement is already retained and verified off in the latest log.
- [0.1.16 reassessment](REASSESSMENT-0.1.16.md) records persistent clipping despite increased mesh refinement. Two-sided culling did not address the earlier underwater problem either. Do not repeat those controls without new evidence.
- [0.1.17](COEXISTENCE-0.1.17.md) eliminated reported ripple clipping in the Surface Tides-owned rendering path. This was a rendering-path change, not a demonstrated native-ENB ripple repair.
- The newly accepted depth correction targets primary 015E wading color draws. Its activation and success against the camera shapes do not establish the cause of the remaining clipped ripples.

A related disagreement between the ripple-bearing surface and main displaced water remains a hypothesis. The useful next comparison, if ripple work is resumed, is their geometry/depth handling across the working Surface Tides-owned path and native integration, using project code and public draw state only. Do not broaden the depth override or suppress ripples merely on this hypothesis. No ENB source, shaders, bytecode, SDK or implementation inspection is permitted.

## Checkpoint scope

This is a documentation-only acceptance update to source version 17. Preserve the exact accepted enb-depth.1 DLL overlays and beta.1 FOMOD. No code, HLSL, INI, cache, solver, OS path or installer payload changes; no binary rebuild or FOMOD promotion. The original build validation and pre-fix returned log remain historical evidence. No new game test is requested by this checkpoint.
