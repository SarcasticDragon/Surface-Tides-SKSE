# Accepted pond retention — 2026-09-30 Denver

The user reports the Deep Folk Crossing pond issue is gone and accepts the fix. No new clip was supplied; visual confirmation is the user's report. They will watch for other affected locations. The returned SurfaceTides(20261001-022830).log loads beta.11-pond-test.1 on Skyrim 1.6.1170 with native ENB integration.

After travel to cell 00006FE6, every pond summary remains at epoch 3 and water height -5327.14. Four dry-bank summaries report source=retained while actorWater=-5616 and actorBelowWater=false. The field retains nonzero waves; no same-area water-level switches or warning/error/critical entries appear. This corroborates the intended repair instead of merely hiding its rendering symptom. The same shared game-side selection code serves OS, but this return directly establishes the ENB case only.

Preserve the accepted retention code in the next performance candidate. The complete Beta 11 FOMOD remains unchanged and does not contain the pond fix; its separate pond overlay and source checkpoint remain a rollback. A later complete Beta 12 installer can include accepted updates after testing. The ripple/camera fixes remain accepted, prior underwater defects remain absent, and color investigation stays parked.

See beta12-performance.1-evidence/pond-accepted-return.json for the log checksum, exact samples and timings. Do not ask for another pond clip merely to restate this acceptance.
