# Surface Tides 0.1.20 — optional foam preview

**Superseded by [0.1.20.1](FOAM-0.1.20.1.md).** The first 0.1.20 in-game test crashed in global reference discovery. The hotfix retains the profiles and settings described here while replacing that failing lookup. Use its install ZIP, not the original 0.1.20 DLL.

This development update adds an opt-in filter for the separate foam shapes in two reviewed rapid-rock meshes. It retains the accepted 0.1.19.2 water rendering, underwater correction, shoreline correction and live settings/save behavior. It is compiled, but its new scene filtering still requires in-game testing.

## Install and enable attached-foam filtering

Install `SurfaceTides-0.1.20-foam-update.zip` after the current Surface Tides installation. It contains the DLL and the unchanged accepted shaders; it deliberately does not replace your INI. Add this section to the winning `Data/SKSE/Plugins/SurfaceTides.ini`:

```ini
[Objects]
HideAttachedFoam=1
```

If `[Objects]` already exists, add/update the key there instead of duplicating the section. Restart Skyrim. The default for a missing key is 0. The menu displays this startup setting read-only; Save/Reload tuning preserves it. The existing live simulation preview checkbox restores filter-owned visibility changes when off and reapplies filtering when on, once gameplay resumes.

No ENB/CS settings changes accompany this update. Keep master ENB water off and experimental ENB integration off for the accepted coexistence setup. CS remains a later task. The Skyrim/SKSE/Address Library requirements are unchanged.

## Exact attached coverage

| Winning model path, relative to meshes | Foam shapes hidden | Rock retained |
|---|---|---|
| `effects\fxrapidsrocks01.nif` | `Plane12`, `BIGwHITEWATER` | `WetRocksCombined` |
| `architecture\whiterun\wreffects\wrrapidrocks01.nif` | `rockRapid04` | `RockM06` |

Selection requires the reviewed model path, shape names, effect-shader material and source/greyscale texture paths. A solid rock shape must also be present. Paths are case/slash normalized; polygon counts are not used. The first profile expects FXWhiteWater01/GradWhiteWaterSoft; the second NWF_Rapids/GradWhiteWater02. Unsupported or ambiguous layouts stay visible. This supports the supplied variants; it is not a blanket claim for every ERM/Gol Mora version or every rapid-rock NIF.

The filter changes only the selected loaded shape's hidden flag. It does not replace or edit NIF files, detach nodes, edit shared materials, change rock vertices/textures, alter collision