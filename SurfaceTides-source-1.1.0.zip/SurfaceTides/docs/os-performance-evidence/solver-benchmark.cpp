// Analysis only: unchanged production solver, fixed 120 Hz, no Skyrim/API/GPU work.
// Host timings are not predictions for the user's PC. No fast-math.
#include "surfacetides/Simulation.hpp"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <vector>

int main() {
    for (int wetPercent : {50,100}) for (int mode : {0,1,2}) {
        st::Settings settings;
        settings.resolution=192; settings.spacing=20; settings.wind=mode?5:0;
        settings.gustStrength=mode==2?1:0;
        st::Surface surface(settings);
        surface.reset({89132,-61865},10624);
        std::vector<std::uint8_t> mask(192*192,1);
        if(wetPercent==50) for(int y=0;y<192;++y) for(int x=96;x<192;++x) mask[y*192+x]=0;
        surface.setWetMask(mask);
        constexpr int ticks=3600;
        std::vector<double> timings;timings.reserve(ticks);
        for(int i=0;i<ticks+120;++i) {
            const auto start=std::chrono::steady_clock::now();
            surface.advance(1.0/120.0,16);
            const auto end=std::chrono::steady_clock::now();
            if(i>=120)timings.push_back(std::chrono::duration<double,std::milli>(end-start).count());
        }
        double sum=0;for(auto t:timings)sum+=t;
        std::sort(timings.begin(),timings.end());
        std::printf("wet=%d wind=%.0f gust=%.0f ticks=%d mean_ms=%.6f median_ms=%.6f p95_ms=%.6f p99_ms=%.6f max_ms=%.6f\n",
            wetPercent,settings.wind,settings.gustStrength,ticks,sum/ticks,timings[ticks/2],timings[ticks*95/100],timings[ticks*99/100],timings.back());
        std::fflush(stdout);
    }
}
