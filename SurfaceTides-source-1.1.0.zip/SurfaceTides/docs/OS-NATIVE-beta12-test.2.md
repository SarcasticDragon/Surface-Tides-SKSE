# Native Open Shaders Water — Beta 12 test 2

> Accepted by the user on October 3, 2026 (Denver). The matching logs confirm
> complete shader readiness and no augmentation failures/rejected native draws.
> The original candidate and validation notes below are historical.
> Current status and target-four comparison: `OS-NATIVE-beta12-ACCEPTED.md`.

Candidate: `1.1.0-beta.12-os-native-test.2`, Skyrim 1.6.1170 / GOG 1.6.1179.
In-game refraction result is pending. This DLL overlay contains no INI or shader
replacements and installs over the complete existing Surface Tides installation.

## What the return established

The supplied SurfaceTides(20261003-054454).log starts with no captured recipes and
no augmented draws. After OS's full cache clear, ST successfully augments the
stencil pixel shader and seven vertex variants, but rejects five color pixel
shader attempts at the `float3 normal = waterData.normal;` source contract.
Displaced stencil draws continue while color draws are rejected. This mismatch
is confirmed; its responsibility for the reported screen smearing is the next
in-game test, not an already validated visual fix.

The original matcher required the member-access dot to touch both identifiers.
Valid preprocessing with spaces around that dot reproduces its rejection. Test 2
accepts equivalent whitespace while still rejecting missing, changed, or
ambiguous expressions. The exact Microsoft-preprocessed input from the failed
run was not attached, so this remains the leading explanation for that rejection.
Rejection logs now include stage, source key, and bounded source context.

## Safeguard

ST waits until color and stencil VS/PS programs have all been built successfully,
then enables augmentation at a frame boundary. A known augmentation, capture, or
tagging failure latches native ST rendering off until Skyrim restarts. Successful
stencil compilation alone can no longer enable displacement after a known color
failure. This guard does not change OS's shader objects, saved files or settings.

## Install and test

Replace test 1 with this DLL overlay and restart Skyrim. Retain:

```ini
[Compatibility]
OpenShaders=1
OSNativeWater=1
```

Keep OS's Water shader replacement ON, with your current Water Effects and
Unified Water configuration. Keep Wave Amplitude at 1 for the comparison.
No cache deletion or new INI is required for the upgrade: the stored recipes are
the original OS source, and changed augmented programs have content-based keys.
New OS variants without a learned recipe still require the initial learning
recompile described below. Existing failures were not stored as compiled programs.

Check refraction and wakes while moving/turning the camera, followed by the ST
in-game off/on toggle. Return both ST and OS logs. If the simulation stays off,
the readiness line and rejection context will distinguish a protective fallback
from missing recipes; do not change presets to compensate.

For a genuinely fresh installation, open OS's main window, hover the action icons
at the top right next to Save/Restore Settings, and select **Clear Shader Cache**.
If it says **Clear Active Shaders**, hold Shift for the full-clear mode, then
click and confirm. Close the menu and let encountered shaders compile with ST
loaded. This is a learning step, not an uninstall requirement.

## Removal and preserved work

Disable ST and its test overlays, then restart Skyrim with OS Water ON. ST never
writes OS settings, OS shader sources, OS's compiled cache, or save records.
The user reports normal OS water after test-1 removal without preset repair.
CommunityShaders(10).log also shows an automatic cache rebuild following the
manual clear in the prior run; that result alone does not establish cache-hit
reuse after uninstall. Optional ST private cache files are inert without ST.

The accepted legacy adapter (`OSNativeWater=0`, OS Water replacement OFF), ENB
integration, field extent/detail, solver, wind optimization, retention, and
default-off discovery work remain unchanged. No new FOMOD is included.

## Verification

All 13 portable suites pass, including 53 native-source/readiness cases: valid
member-access formatting, rejection of unknown/ambiguous expressions, every
shader-stage arrival order, frame-boundary activation, and failure latching.
Secondary DXC validation passes 120 stage compilations and 18 token-spacing
regressions against public OS v2.13.0 water sources. Windows x64 MSVC-ABI build
and runtime metadata are checked during packaging. Windows D3DCompiler/SM5 and
Skyrim execution are not available in this build environment. Evidence is under
`beta12-os-native.2-evidence/`; test-1 evidence remains historical and unchanged.
