# Surface Tides runtime compatibility — preview 1

Based on the released 1.0.2 source, including the confirmed interior water-retention fix and Frozen Marsh decal coverage. Runtime support is experimental until testers confirm it in Skyrim.

## Targets

| Build profile | Exact executable | SKSE | Address Library | Engine dependency |
| --- | --- | --- | --- | --- |
| SE | 1.5.97.0 | 2.0.20 | SE package containing version-1-5-97-0.bin | Original CommonLibSSE-NG b93280e |
| AE17 | 1.7.104.0 | 2.3.1 | v13, containing versionlib-1-7-104-0.bin | alandtse CommonLibSSE-NG 8.1.0 |

Other executables are rejected by these candidate DLLs. The original AE16 source profile still selects 1.6.1170 / 1.6.1179; it is not a newly tested release.

## Implementation

The SE profile enables the original dependency's SE family exclusively, and adds the SKSEPlugin_Query export used by SKSE 2.0.20. Query and Load both enforce exact supported versions before engine initialization. The AE17 profile uses the updated Address Library reader, the V5 compatibility declaration, updated structure declarations and version-aware accessors from CommonLib 8.1.0.

The original dependency is not overwritten. CMake selects a separate vendored dependency for AE17 and separate build directories. The new renderer adapter uses Renderer::GetRuntimeData() for that dependency. Raw-array/std::array access to shader constant tables is normalized through std::data. Geometry properties use the new named alpha/shader fields in AE17, preserving both existing checks. A motion-type adapter passes the same fixed/keyframed values through the updated typed API; movement logic is unchanged.

The dependency declarations agree on the four existing game vtable hook slots: BSShader::SetupGeometry 0x06, RestoreGeometry 0x07, Actor::Update 0xAD, and JumpHandler::ProcessButton 0x04. These were checked in source headers; no claim is made that they have been independently verified against either running target. D3D11 interface hooks retain their existing API-defined slots.

Simulation and shader behavior retain the release baseline. The renderer still derives constant mappings from the native shader tables and checks bindings/topology. Actual shader compatibility must be confirmed in-game. Foam/ice filters and floe motion remain available with existing INI options; the different engine structures mean those features need target-specific testing too.

## Build

On Windows with Visual Studio 2022 and the C++/Windows SDK components installed:

```powershell
cmake --preset windows-se
cmake --build --preset windows-se --parallel 2
ctest --preset windows-se

cmake --preset windows-ae17
cmake --build --preset windows-ae17 --parallel 2
ctest --preset windows-ae17
```

All source dependencies are vendored. AE17 builds the full upstream SimpleMath component that CommonLib needs; it does not build unrelated DirectXTK shaders/audio. Linux cross-build instructions are in CROSS-BUILD-RECOVERY.md; pass ST_RUNTIME=SE or AE17 and use a separate build directory for each.

## Tester handoff

Install Surface Tides 1.0.2 with the desired FOMOD choices, then install the matching preview ZIP after it so its SurfaceTides.dll wins. The overlay supplies no INI, shaders, BOS preset or CS override: the existing selection and tuning remain in effect. Only one SurfaceTides.dll should win. Disable the overlay to restore the release DLL.

Use matching runtime builds of any optional dependencies. The menu remains optional. ENB/CS coexistence still requires their water processing off. A renderer framework's own compatibility with 1.7.104 is separate from this plugin's port.

Please return SurfaceTides.log and the exact executable version with initial results. The first useful results are whether the plugin loads, water deforms and reacts to actors, waves persist after leaving interior water, and underwater/shoreline rendering remains intact. If enabled, check foam/ice removal and floe collision, rider carry and jumping. A crash report should include the crash log and skse64.log.

## Validation status

Portable solver, floe-motion and water-selection CTest suites passed. Both Windows x64 MSVC-ABI DLLs compiled and linked successfully. PE export and metadata checks passed for the exact runtime, with the V5 flag and minimum SKSE 2.3.1 verified in AE17. Detailed results are recorded in runtime-preview-validation.json. No Skyrim runtime execution has been performed in this environment. In-game compatibility, optional menu compatibility and ENB/CS coexistence on the new targets remain unverified.

## Primary references

- [SKSE runtime/build mapping](https://skse.silverlock.org/)
- [Address Library](https://www.nexusmods.com/skyrimspecialedition/mods/32444)
- [CommonLib 7.5.3: 1.7.x PlayerCharacter accessor fixes](https://github.com/alandtse/CommonLibSSE-NG/releases/tag/v7.5.3)
- [CommonLib 8.0.1: V5 plugin declaration fix](https://github.com/alandtse/CommonLibSSE-NG/releases/tag/v8.0.1)
- [Pinned CommonLib 8.1.0 source](https://github.com/alandtse/CommonLibSSE-NG/tree/v8.1.0)
