> Returned run, 2026-09-23: no visible simulation or guides. The log shows
> draw-method address changes and no compiled color passes; this is not a
> usable reflection comparison. Disable this probe and test the DLL recovery
> described in OPEN-SHADERS-preview.4.md before resuming visual diagnostics.

# Surface Tides OS preview.3 — reflection probe 3

2026-09-23. Diagnostic overlay, not a proposed appearance fix.

## One run

Disable the color-test.2 and refraction-control.2 overlays. Install
`SurfaceTides-OS-preview.3-reflection-probe.3.zip` after preview.3/hotfix 1 and
let its `Shaders/SurfaceTides/Water.hlsl` win. Restart Skyrim. The probe includes
the color-test.2 shader as its comparison baseline and restores normal guarded
refraction. Keep the working OS feature settings and INI.

Begin with Surface Tides > Settings > Appearance > **Diagnostic water colors**
unchecked (DebugView=0). Eligible above-water surfaces now have three screen
regions separated by thin orange lines:

| Screen region | Rendering |
| --- | --- |
| Left third | Color-test.2 baseline |
| Middle third | Screen-space reflections omitted; cubemap/planar reflections retained |
| Right third | Environment reflection blend omitted; water material, refraction, sun highlights and fog retained |

The dividers are intentional. They establish that this particular test shader
is active; missing dividers mean the visual comparison cannot be interpreted.
View the same body of water across the thirds and record a short camera pan.
The middle third normally contains the player, making it useful for the mace.

Then check **Diagnostic water colors** in Surface Tides' menu. For this overlay
only, eligible above-water passes omit environment reflections over the whole
view; the guide lines turn magenta. The switch applies live. Repeat the mace
movement, then uncheck it. Do not use the probe's underwater view for this test:
non-target passes retain the original diagnostic-color behavior.

Return the clip and SurfaceTides.log, plus the **current** OS
`CommunityShaders.log` and `SettingsUser.json`. The OS log keeps that filename
because the fork keeps the shared module identity. They are needed to establish
current OS version/features and temporal rendering settings; the previously
provided JSON predates these tests.

Remove this overlay and leave Diagnostic water colors unchecked afterward.
With both test.2 overlays disabled, this restores shader hotfix 1. No save
cleaning, shader-cache deletion, DLL replacement or preset rewrite is needed.

## Interpreting the result

- Improvement in the middle third points to the screen-space reflection
  contribution. It does not prove a particular reflection-buffer or temporal bug.
- Improvement only in the right third points toward the remaining cubemap/planar
  contribution or reflection weighting. Compare matched water areas by panning;
  neighboring thirds naturally cover different depths and reflected scenery.
- Persistent pale water with reflections omitted keeps material tint, fog,
  captured scene color and later image processing under investigation.
- If the mace still jitters in full-view reflection suppression, reflections
  are insufficient to explain it. The retained depth/stencil workaround and
  temporal reconstruction remain possible; neither is diagnosed from this clip.

Sun highlights and additive light passes are deliberately retained. This is
not a complete removal of every specular-light contribution.

## Returned test.2 result and evidence

The user reports that neither color test 2 nor the undistorted-refraction control
resolved either symptom. Treat both controls as negative results; do not repeat
them as current fixes. The supplied `SurfaceTides(20260923-215116).log` is from
one run and does not fingerprint the installed HLSL, so it cannot independently
identify which overlay produced it. Its observed OS color permutations compile
and bind without errors or failed draws. Live buffers are large enough for the
reflected declarations; size checks do not establish matching contents/layouts.

The 10.416667-second, 1920x1080/60fps clip still shows pale blue-gray water and
strong reflected wake patterns. User-reported mace jitter remains unresolved.
No numerical shader fault or active color-pass compilation failure is shown.
The specific PS015E pass that emits the old zero-depth workaround is not
observed anywhere in this supplied run; PS035E wading is present. This makes
that narrow workaround a weaker explanation for this clip, without proving
all water depth/stencil handling correct.

Review of the pinned OS 2.14 water source confirms that the adapter retains an
older screen-space reflection blend and omits OS dynamic cubemap integration.
OS uses different reflection distortion/blur/confidence weighting. The negative
refraction result and this implementation gap justify isolating reflections;
they do not yet establish reflections as the cause of either symptom.

Reference: [OS Water.hlsl, pinned 2.14](https://github.com/alandtse/open-shaders/blob/164d06bd657c07970e3633a8659bae061f6273b1/package/Shaders/Water.hlsl),
GetWaterSpecularColor. No new OS or ENB source is incorporated into this probe.

## Implementation and validation

The probe is separate at `packaging/os-reflection-probe.3/Water.hlsl`.
Canonical runtime shaders, DLL source, simulation, normals, geometry,
shoreline/contact protection, native wading-depth workaround, stencil/motion,
INI and OS settings are unchanged. Reflection suppression sets the reflection
blend weight to zero instead of substituting black into a nonzero blend.
Eligible passes already use VPOSOffset for refraction/depth; the diagnostic
requires no additional resource slots or live native constants.

`tools/validate_os_reflection_probe3.py` compiles baseline/probe across both
standalone and OS modes and compares bytecode, binding tables, output signatures,
and depth/discard presence. Secondary DXC/SM6 with validation-only OS namespace
adaptation cannot establish native D3DCompiler/SM5 or in-game success. Results
are in `os-preview.3-reflection-probe.3-evidence/`.
