# OS toggle accepted with WaterEffects, UW disabled

2026-10-02. The user reports correct on/off behavior with the existing
1.1.0-beta.12-os-state-test.1 AE16 DLL. No code, shader, INI default or binary
changes accompany this acceptance. The current DLL hash remains
43b2f62b42eb0be2bda62c4a23f9e9714daedff547b3cdb50bb55858d62c9819.

## Confirmed configuration and behavior

SettingsUser(2).json has Replace Original Shaders.Water=false,
Disable at Boot.UnifiedWater=true and Disable at Boot.WaterEffects=false.
SurfaceTides(20261002-115013).log confirms OSWaterEffects=true,
OSUnifiedWater=false and OSPreserveSceneMotion=true. OS log8 confirms UW is
disabled at boot. This corrects log7's inconsistent ST OSUnifiedWater=true.

The 05-48-45 clip shows surface detail retained with ST off, displacement/wakes
when enabled, and retained shading after disabling it again. The log records:

| Time | State |
| --- | --- |
| 05:47:52.371 | Compatibility-only rendering before any active field exists |
| 05:48:07.823 | Simulation rendering begins |
| 05:48:33.890 / .902 | Explicit preview-off; compatibility-only rendering retained |
| 05:48:50.073 | Simulation resumes with a fresh epoch |
| 05:48:57.395 / .405 | Explicit preview-off; compatibility-only rendering retained |

Across reported windows: 1,034,121 bound water draws, 527,943 tessellated draws,
506,178 compatibility-only draws, zero failed/incompatible draws. WaterEffects
records 27,131 parallax draws and zero compile fallbacks. The last two wholly-off
windows have zero tessellation and zero scene-motion-mask applications while
water rendering continues. These are draw counts, not frame counts or timings.

The selected river stays at -250. No level switch or rejected actor-switch episode
is logged. Both inactive transitions are preview-off. Thus the toggle repair is
accepted for this setup; the intermittent actor-height failure has not been
reproduced and its guard has not been demonstrated by this return.

## Concrete lead for the no-ST mirror appearance

The JSON contains `CS Utility.water.waveAmplitude=0.0`. The public OS v2.13.0
shader uses waterWaveAmplitude to blend between the flat normal (0,0,1) and
the computed water normal. Zero therefore removes normal-map surface detail.
CSUtility.h defaults this value to1.0; its UI calls it Wave Amplitude and explains
that it controls normals including flowmap and rain-ripple detail.

- [Water normal application](https://github.com/alandtse/open-shaders/blob/v2.13.0/package/Shaders/Water.hlsl#L859-L860)
- [Default water parameters](https://github.com/alandtse/open-shaders/blob/v2.13.0/src/Features/CSUtility.h#L76)
- [UI meaning and settings upload](https://github.com/alandtse/open-shaders/blob/v2.13.0/src/Features/CSUtility.cpp#L295-L296)

The downloaded Water.hlsl is 61,529 bytes, SHA256
85bd45755cdc1efe076c8076225d8c4d3a149d4f50580796bccc5ef70d875f34,
matching the OS v2.13 source previously reviewed for the UW adapter. Source
provenance and small relevant excerpts are retained with the acceptance evidence.
The user's currently winning Water.hlsl has not been supplied, so this confirms
the published version's behavior rather than its on-disk identity.

This setting strongly fits the mirror-like no-ST result when OS Water replacement
was restored. It does not establish who changed the value or prove every earlier
color symptom has the same cause. ST never writes SettingsUser.json. Its existing
water adapter does not consume waterWaveAmplitude, explaining why its own water
shading can retain normal detail while OS's native shader flattens it.

For a future no-ST control, restore OS Wave Amplitude to1.0, enable OS Water
replacement, save and restart. Record that visual return before declaring the
uninstall issue resolved. No full preset reset or repeated cache deletion is
needed for this specific control. The current successful ST settings are retained.

## Next and preserved checkpoints

Repeat the on/off check with Unified Water enabled in OS and OSUnifiedWater=1
in ST, retaining OS Water replacement OFF. No new DLL is required. This validates
the inactive adapter against UW's different geometry/coordinate layout.

Keep observing bank crossings for the rare spontaneous stop. Discovery target4
remains untested and defaults off until correctness is settled; target5 stays
deferred. Accepted wind optimizations, caching/prewarming, ENB camera/ripple
corrections and pond behavior are retained. Beta11 FOMOD is unchanged.

See beta12-os-toggle-accepted-evidence for input hashes, exact state transitions,
counts and source references. Acceptance adds documentation only, so no compile
or portable suite was repeated. The candidate's prior build/test evidence remains
applicable to its unchanged executable code.

## Subsequent Unified Water return

The user subsequently reports the UW-enabled on/off test also looks good. This is visual user acceptance, without an accompanying new log. Native OS Water replacement ON is now the next target; see [native test 1](OS-NATIVE-beta12-test.1.md). The rare height-switch reproduction remains unconfirmed.
