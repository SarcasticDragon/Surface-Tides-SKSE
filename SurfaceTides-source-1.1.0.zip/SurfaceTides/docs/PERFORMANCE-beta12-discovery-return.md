# Target 4 A/B return — October 3, 2026

The user's DiscoveryOn/DiscoveryOff logs both use native OS test 2 with renderer
and simulation optimizations enabled. The intended discovery flag differs.
The user could not reliably distinguish stutter changes because other sources
of stutter are present. Review supports keeping discovery enabled for broader
beta testing, not claiming an overall FPS improvement or full stress acceptance.

| ST CPU game foam statistic | Off | On |
| --- | ---: | ---: |
| Recorded updates | 6706 | 5370 |
| Recorded total CPU wall time | 118.898 ms | 125.391 ms |
| Weighted mean per measured update | 0.017730 ms | 0.023350 ms |
| Largest recorded update | 1.066 ms | 0.476 ms |
| Median of five-second report maxima | 0.769 ms | 0.3825 ms |

The maximum is 55.35% smaller; average cost rises by 0.005620 ms per measured
update. The median here describes report maxima, not a frame-time percentile.
Do not compare the per-call mean of `discovery enumerate` directly: one path
runs a whole-grid scan once per second while the other enters once per update.
Do not add nested timing scopes.

Comparable-work selection: reports with cycles=5, cells=130 and 39000 through
39200 reference visits. Off has seven reports ending 01:30:52.434 through
01:31:22.482; on has four ending 01:24:08.888 through 01:24:23.912. Average foam
total per selected report is 4.627286 ms off versus 6.049250 ms on; maximum is
0.978 ms versus 0.357 ms. Thus the smoothing/average-cost tradeoff persists
with closely comparable scan work, without claiming identical camera/game load.

Both runs identify the same seven unique foam references. On queues and
inspects 13 candidates (including rediscovery after preview-off), with 13
matches; pending=0 at all report boundaries and maxPending=6. This does not
exercise a large inspection backlog or ice profiles. Neither log has warnings
or errors, native shader compilation, augmentation failure or rejected native
draws. Discovery invalidations on=11 reflect changing cell identity/order;
the off path does not use this scheduler counter.

The on run includes preview-off from 01:24:51.172 and resumption before
01:25:12.375. Both runs also contain water-selection inactivity and much larger
Present-interval interruptions. Global game-update averages, hook cadence and
post-frame-generation FPS are not controlled A/B outcomes here. These CPU
scopes do not establish the cause of the larger interruptions or exclude all
other ST/GPU costs. Coverage, grid size, default INI value and DLL were unchanged
for this A/B. No target-five work was performed.
