# Beta 2 ENB ripple coverage test 2

2026-09-30. `1.1.0-beta.2-ripple-coverage.2`, machine revision 14.
AE16 overlay: Skyrim 1.6.1170 / 1.6.1179. In-game testing pending.

## Install and return

Replace the **coverage.1** overlay with this one over Beta 1. Keep the earlier
**base-test.1** shader diagnostic disabled. Let the new DLL and included default
MeshInput shader win conflicts, then fully restart Skyrim. Keep the current
INI, ENB water/tessellation and other settings; no INI edit or cache deletion
is needed. `MeshWadingDepth=1` and `MeshRippleCoverage=1` remain the defaults.

Check the same ripple rings and mid-distance water while entering/leaving the
water. Send the new log and a short clip. With `LogStats=1`, the new version
should now report `baseMatched` and `marked` greater than zero in the periodic
`ENB ripple coverage` counters. Those counters, together with the clip, will
tell us whether the stencil coverage proposal works once activated. A brief
fallback before a matching base pass has been observed can be expected.

Set `MeshRippleCoverage=0` in the existing Experimental section and restart to
return to Beta 1 coverage while preserving its accepted camera fix. Or disable
this overlay and the older diagnostic overlays to return to the released Beta 1.

## Returned result and correction

The user reports that coverage.1 restores the water but ripple clipping returns.
`SurfaceTides(20260930-123104).log` confirms the correct DLL and enabled setting:

- Base matches: **0**; base rejections: **13,249**.
- Marked wading draws: **0**; coverage fallbacks: **1,488**.
- Accepted camera-depth corrections: **1,488**, with no failures or fallbacks.
- Prepared draws: **556,283**, with no preparation failures or skips.

The guard in coverage.1 incorrectly required the native color pass to write
RGBA (`writeMask=15`). All eight sampled base and seven wading rows write RGB
(`writeMask=7`), leaving alpha untouched. They otherwise have blending disabled,
alpha-to-coverage disabled and all samples enabled. Consequently, the guard
rejected the ordinary water state before any ripple coverage could be marked.
This was an implementation mistake; the returned run did not exercise the
proposed stencil marking.

Coverage.2 accepts complete RGB writes with alpha either preserved or written.
It still rejects incomplete RGB, unknown channel bits, blending,
alpha-to-coverage and partial sample masks. It **does not change native blend
state, alpha writes, shaders, target matching, stencil policy or depth policy**.
The guard now lives in the portable policy header and is used by both base
observation and wading eligibility. Null blend state retains the D3D default.

The same-view, recent-frame, writable-stencil and exact pass/state guards from
coverage.1 remain. Original bindings/reference are restored after each draw;
stencil contents intentionally remain for the later base pass. Stencil lifetime
and other consumers remain integration questions for the next in-game result.

## Validation

All ten portable suites pass. The expanded coverage suite passes 135,914 checks,
including the returned RGB state combined with the captured depth/stencil
contracts, every byte-sized channel mask, blending/alpha-to-coverage combinations
and each missing sample bit. The accepted depth suite still passes 68,730 checks.

The AE16 DLL is cross-built and its AMD64 machine, SKSE exports and revision-14
runtime metadata are verified. All HLSL and INI files remain byte-identical to
source checkpoint 21. Portable checks and cross-compilation do not prove the
visual fix; native D3D and Skyrim execution are not available here.

Beta 1 FOMOD, OS/Vanilla paths, caching/prewarming and the accepted camera fix
are preserved. SE/AE17 DLLs are not rebuilt for this focused test. Color work
remains parked; prior underwater problems remain absent per the user. No ENB
source, shaders, bytecode, SDK or decompilation were obtained or used.
