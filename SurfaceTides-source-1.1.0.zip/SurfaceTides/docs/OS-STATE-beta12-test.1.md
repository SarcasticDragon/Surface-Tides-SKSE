# Surface Tides 1.1.0-beta.12-os-state-test.1

2026-10-02. Focused AE16 candidate for Skyrim 1.6.1170 / 1.6.1179.
Awaiting in-game validation. Discovery performance work remains on hold.

## Returned result: live toggle accepted with UW off

The 05:51 return confirms correct preview on/off behavior with OSWaterEffects=1,
OSUnifiedWater=0, OS Water replacement OFF, and OS UnifiedWater disabled at boot.
This supersedes the awaiting-validation wording above for this configuration.
See [acceptance and remaining checks](OS-TOGGLE-beta12-ACCEPTED.md). The same
DLL is retained. Combined UW toggle behavior and the rare actor-height failure
still need confirmation; this return did not trigger an actor-switch rejection.

The supplied JSON also exposes CS Utility.water.waveAmplitude=0. OS v2.13's
public shader flattens normals at zero; the default is1. This gives a specific
likely explanation for the earlier no-ST mirror appearance. Who changed the
setting is unknown. Restoring it with OS's own water shader remains a visual
control, not a completed uninstall repair. Earlier investigation notes below
are historical; do not repeat their unsuccessful controls as untried.

## Uninstall investigation: Water-on control did not fix it

The user completely uninstalled ST, enabled **OS / Replace Original Shaders /
Water**, saved and restarted. The 04-13-50 clip is different but still broken:
reflections return, while the surface looks almost like a flat mirror with little
normal/flow detail. Do not repeat the Water-on test as though it is untried, or
mark the uninstall problem solved. Suspect normal/flow inputs or feature/layout
configuration, but no specific cause has been established.

The next requested control keeps ST absent and OS Water replacement ON, enables
**Unified Water / Disable at Boot**, saves and fully restarts. Keep WaterEffects
otherwise unchanged. This separates UW-dependent behavior from the remaining
water path. The current winning SettingsUser.json and Data/Shaders/Water.hlsl
were requested to inspect actual settings/source. Do not clear all caches or
reset the entire preset before recording that evidence.

CommunityShaders(6).log confirms user settings applied, Unified Water hooks and
caches active, and the newly requested compilation tasks completed 4/4 with zero
failures. It does not print effective water normal/flow settings or establish
which shader files won mod conflicts. Older separately installed
SurfaceTides_Global.json overrides should not be present; this overlay supplies
none. Check the winning mod-manager file when investigating one.

The previous uninstall clip (04-02-09) had pale, featureless water; its log (5)
records UW flowmap regeneration and cache loading. Restoring Water replacement
changed the result but was insufficient. A disabled Water shader was therefore
not established as the sole cause. ST's in-game off path has a separate verified
code defect (it removed the adapter), addressed below. Do not conflate that fix
with repairing OS after ST has been removed.

Source review: ST saves menu tuning only to SurfaceTides.ini. Its shader cache
is private under %LOCALAPPDATA%/SurfaceTides/ShaderCache/v1. It reads OS shader
headers but does not write OS settings, OS shaders, OS caches or savegame records.
These observations establish code behavior, not the exact contents of a remote
mod-manager installation. ST code cannot restore OS settings after it is removed.

## Install this candidate

Install the os-state-test.1 zip after the working Beta 11 / accepted wind-test
installation. It replaces **only SurfaceTides.dll** and adds documentation.
It includes no active INI, HLSL, OS JSON, OS cache, game asset or preset.
Verify the log banner says `1.1.0-beta.12-os-state-test.1`.

For the ST-installed test, restore **OS / Replace Original Shaders / Water OFF**,
save and restart. Keep the working ST settings: OpenShaders=1, OSWaterEffects=1,
OSUnifiedWater=1 and the matching features enabled in OS. Leave the accepted
frame-generation workaround and displacement settings unchanged initially.

OptimizeDiscovery now defaults to 0 when the key is absent. If it was manually
added, set `[Performance] OptimizeDiscovery=0` for this test. OptimizeSimulation,
OptimizeRenderer, ShaderCache and PrewarmShaders keep their current defaults.
The untested discovery implementation and its previous package are preserved.

1. At the river, switch Preview Surface Tides off and on. Off should remove ST
   waves/displacement without turning the water pale or losing its flowing normals.
2. Walk from the water onto the bank and return, including the earlier route.
   Watch for the spontaneous stop/return; a fresh log is useful even without a clip.

Return SurfaceTides.log and CommunityShaders.log; include a clip if an issue
recurs. Keep the discovery comparison paused until these are settled.

## Changes and evidence

In SurfaceTides(20261002-095353).log, at 03:52:08.475 the selected level changes
from -250 to -107.1443 with player Z=-107.6678. At 03:52:08.525 the simulation
becomes inactive. At 03:52:12.901 it resumes at -250, epoch 4. Those times align
approximately with the first clip's pale-water interval. There was no menu
revision at the shutdown. The old generic message cannot establish the exact
reason for the following inactive frame.

The selector previously trusted any actor height above the feet immediately,
discarding the river anchor even if no water existed at that new level. It now
revalidates the nearby anchor before allowing an unconfirmed actor-height switch
to replace it. Confirmed immersion into another body still takes priority.
Distance, world/interior boundaries, detached water and explicit resets still
expire an anchor; no timed grace period, wider field or fabricated contact is added.
Actor-only placed/interior water remains available without a verified alternative.

The second clip's toggle transitions align with 03:53:06.477 and 03:53:09.603.
Previously, preview-off or an inactive field also removed ST's entire OS adapter,
even though OS features and geometry remained active. The candidate preserves
the adapter and binds an immutable zero texel for both current and previous fields.
All ST height, normal, history and debug contributions are zero. ST tessellation
and its scene-motion write mask are disabled in this state. No field is uploaded
or solver advanced while preview is off. Re-entry starts fresh field history.
The same compatibility state works before the first simulation frame exists.

This off state is OS-compatible shading through ST's adapter, not a guarantee of
pixel-identical native OS rendering or zero ST render overhead. A full no-ST
performance comparison requires uninstall plus restoration of OS's Water switch
and a working OS baseline, which has not yet been re-established.
The native/ENB off path still relinquishes the draw as before. ENB mesh-input,
camera and ripple-coverage implementations and all HLSL are unchanged.

Logs now identify the actual inactive branch (preview off, missing player/cell/3D,
runtime disabled, or unavailable water), with query reasons, position, revision
and epoch. Rejected actor-height switches log up to 64 episodes. OS render-state
changes and compatibility-only draw counts make the inactive adapter observable.

## Validation and rollback

All 12 portable CTest suites pass. The water suite includes the recorded height
jump followed by an absent actor cache, repeated transitions, changed/unavailable
anchors, distance/world limits, genuine new-body entry and the accepted pond/wake
retention cases. OS/native mode and neutral-constant checks pass as well.
The package script requires successful Windows cross-build and AE16 PE/SKSE
metadata validation before it creates the overlay. Evidence is in the source
checkpoint under docs/beta12-os-state.1-evidence and its validation JSON.

No Skyrim or native D3D execution is available here. Shader sources are unchanged;
this candidate has not been visually validated and is not promoted into Beta 11.
SE 1.5.97 and AE17 1.7.104 binaries are not included in this focused test.

To roll back this test while retaining ST, disable the overlay so the accepted
wind-test DLL wins, and restart. Keep the ST-compatible OS settings in that case.
To remove ST completely, restore OS Water replacement ON, save, and restart.
