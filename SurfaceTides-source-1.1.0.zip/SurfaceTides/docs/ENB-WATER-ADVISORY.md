# ENB water startup check: advisory source change

Date: 2026-09-22

Status updated 2026-09-23: preserved in OS-preview.4 and included in all three runtime DLL builds. See `os-preview.4-validation.json` for the build/metadata checks. Older OS-preview.3 DLLs do not contain this change. In-game testing remains outstanding; earlier build-validation files are not evidence for this source change.

## Report and finding

The supplied 1.0.2 log records `EnableWater=true`, `confirmedOff=false` and the explicit startup rejection. In that source, Main.cpp passes an empty default to GetPrivateProfileStringW and logs the returned, whitespace-trimmed string. The logged `true` is therefore not the fallback for an absent key or a Boolean conversion of an unrecognized value. Both the released 1.0.2 source and OS-preview.3 use this same check.

This reads the INI beside SkyrimSE.exe once at data load. It does not query ENB's live state. A different configuration file/view, a change after the check, duplicate entries interpreted differently, or an unsaved in-game change could explain a mismatch. These are hypotheses, not a reproduced cause; the report does not include the reporter's INI or a corresponding live-state capture.

API reference: https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getprivateprofilestringw

## Change

- Remove the `return false` caused by an EnableWater observation other than false/0 or by a truncated read.
- Retain diagnostic output, explicitly labeled advisory and `liveState=unknown`.
- Log `savedOff` instead of `confirmedOff`; missing/unreadable text is labeled explicitly.
- Warn and continue when the saved observation does not establish water off in coexistence mode.
- Describe the selected renderer without asserting that ENB water is actually off.
- Keep disabling ENB water a user responsibility. Full ENB water integration remains experimental and disabled by default.

The separate AllowENB opt-in, runtime gates and CS/OS selection remain in place. No rendering, simulation, hook or preset-writing behavior changes. No ENB code is used.

## Validation and build limitation

The source diff was reviewed against both the supplied-log release and the current preview. The shared Main.cpp patch applies to both. A separate 1.0.3 hotfix was successfully cross-compiled and passed PE version/runtime and diagnostic-marker checks against the released 1.0.2 branch. The three OS-preview runtime profiles include it starting with preview.4. In-game verification remains outstanding. The unchanged solver tests do not validate this Windows-only startup path, so they are not presented as evidence for the change.

On the next Windows build, confirm a run with `AllowENB=1`, experimental ENBWaterIntegration off, and a saved INI value of true logs the warning and proceeds to hook installation. Repeat with false and an absent key. Perform the rendering check with ENB water actually disabled. Do not enable experimental integration merely to bypass the old guard.
