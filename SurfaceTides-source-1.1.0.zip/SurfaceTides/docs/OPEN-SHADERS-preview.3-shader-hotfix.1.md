# Surface Tides OS preview.3 — shader hotfix 1

2026-09-23. Applies to all three existing OS preview.3 runtime builds.

## Install

Install `SurfaceTides-OS-preview.3-shader-hotfix.1.zip` after the OS preview.3
overlay and let its `Shaders/SurfaceTides/Water.hlsl` win file conflicts.
Restart Skyrim so Surface Tides recompiles its shaders. No CS/OS cache deletion
is needed for Surface Tides' own shaders. No DLL or INI replacement is included;
the startup log will continue to identify the DLL as `1.1.0-os-preview.3`.

Keep the working preview settings: `BlockCS=1`, `OpenShaders=1`; OS Water shader
replacement off; UnifiedWater and WaterEffects disabled at boot.

## Fault and correction

The supplied September 23 log reports `undeclared identifier 'FrameBuffer::name'`
for color permutations 031E, 410E, 430E, 434E, 035E, 3002, 011E and 015E.
Stencil permutations 5000 and 5001 compile and tessellate successfully.
Displaced stencil passes combined with unchanged color passes can produce
exposed riverbed patches and torn water boundaries like those in the clip.

The OS branch of `ST_FRAME(name)` placed its argument directly after `::`.
The legacy compiler left the literal `name` in the qualified identifier.
Seven explicit object-like aliases now name the actual fields/functions,
avoiding argument substitution beside the namespace qualifier.

The simulation, displacement calculations, shoreline/contact protections,
native-ripple controls and color-adapter calculations are unchanged.

## Validation and next test

All eight reported failing descriptors are now included in both shader test
tools. Secondary DXC validation passes 180/180 stage checks for standalone and
180/180 for OS 2.14. The OS DXC check retains the documented validation-only
header namespace adaptation; installed headers are not modified.

DXC also accepted the original faulty macro, so these results alone cannot
establish legacy-compiler compatibility. A Microsoft D3DCompiler/SM5 run could
not be completed in this Linux workspace: Wine IPC was unavailable and an
alternative Windows CLI runtime lacked required APIs. The native Windows
`SurfaceTidesShaderTests` target remains the intended SM5 validation gate.
No native SM5 or in-game success is claimed for this hotfix.

Repeat the same water scene and provide the new SurfaceTides.log. Success
should include compiled/ready color permutations such as 031E and 410E, not
only 5000/5001. The `FrameBuffer::name` errors should disappear. The appearance
and original discoloration still require in-game confirmation after the color
shader is actually active.

Disable the hotfix overlay to restore the preview.3 shader.
See `os-preview.3-shader-hotfix.1-evidence/` in the source archive for checks.
