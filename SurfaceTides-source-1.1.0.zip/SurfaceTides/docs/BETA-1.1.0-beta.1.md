# Surface Tides 1.1.0-beta.1

Beta 1 includes the accepted ENB camera-artifact correction, the working shader cache/prewarming update and the accumulated Open Shaders work. Native ENB water integration and ENB-water-off coexistence are installer choices; ENB presence never blocks startup. Community Shaders remains incompatible and blocked by default. Minor ENB ripple clipping is a known issue targeted for Beta 2.

## Install

Install the ZIP with MO2 or Vortex. **Back up custom SurfaceTides.ini tuning, then cleanly replace the previous mod.** This is a complete installer, not a DLL overlay: it installs one matching DLL, all seven ST shader files and a fresh, complete INI reflecting your selections. Disable old ST test overlays and remove a legacy `SurfaceTides_Global.json` if still present. Restart Skyrim after changing startup options.

Choose the exact game executable version, not the edition name:

| Skyrim executable | Build | Required dependencies |
|---|---|---|
| Steam 1.6.1170 / GOG 1.6.1179 | AE16 | Matching SKSE 2.2.6 and AE Address Library |
| 1.5.97 | SE | SKSE 2.0.20 and SE Address Library |
| 1.7.104 | AE17 | SKSE 2.3.1 and matching Address Library v13 |

Other executables and VR are not supported. Dependencies are not bundled. SKSE Menu Framework 3.x is optional; configuration works through the INI without it. Earlier runtime ports were tested by the author. The latest ENB correction was accepted in the returned Skyrim 1.6.1170 test; broader beta testing across runtimes and presets continues.

## Renderer choices

**Open Shaders (OS):** Keep OS's Water shader replacement **OFF**. On the next installer page choose both WaterEffects and Unified Water, either one, or neither. These choices must match the features enabled at boot in OS; configure OS separately, save, and restart. The default OS choice is both, matching the accepted test baseline. ST does not detect feature activation automatically and does not write OS settings or install renderer overrides. `OSPreserveSceneMotion=1` retains the accepted temporal workaround. Regular Community Shaders is not the same renderer despite the shared DLL filename. `BlockCS=0` remains an unsupported manual testing bypass.

**ENB:** The default ENB sub-option, **ENB water integration (experimental)**, sets `ENBWaterIntegration=1` and retains native/ENB water shaders. ENB water may remain on. The camera-dependent surface shapes are fixed in the latest user test; `MeshWadingDepth=1` enables that correction by default. Minor ripple clipping remains a Beta 2 target. The previous underwater issues were absent in the latest user testing. These results do not establish every runtime/preset combination. The alternative **ENB water off (coexistence)** uses ST's water shading; save `[EFFECT] EnableWater=false` in `enbseries.ini` beside SkyrimSE.exe and restart. ST observes that saved setting only as an advisory and does not edit the preset.

ENB presence no longer disables ST. The obsolete `AllowENB` key is omitted from the new INI and ignored even when an old INI sets it to 0. Renderer detection selects the ENB path automatically outside OS. A local graphics proxy or leftover ENB INI can count as possible ENB; that is logged, not treated as proof of a loaded ENB. If both OS/CS and ENB modules are loaded, ST keeps the selected OS/CS path and warns; removing the guard does not establish support for mixed frameworks.

**Vanilla:** ST's own water rendering, with no renderer framework required. If ENB is detected, the water-off coexistence path is selected automatically.

## Included checkpoint

- Accepted native ENB camera-artifact correction, enabled by default.
- All accumulated simulation, shoreline/water-retention and runtime-query fixes.
- OS draw-hook recovery, color helper integration, scene-motion preservation, WaterEffects and Unified Water adapters.
- CPU renderer optimizations and independent timing measurements.
- Persistent shader caching, prewarming and the resolved-compiler-import identity fix.
- Existing attached-foam filtering, Frozen Marsh/ice decal filtering, floe bobbing and rider/jump behavior.
- Updated menu startup descriptions and complete installer-generated INIs.

The simulation, HLSL, cache implementation and accepted OS rendering behavior are unchanged from preview.10. Color investigation remains deferred; no discoloration fix is claimed.

Foam and ice choices remain independent. Standalone foam removal requires Base Object Swapper 3.0 or newer. Bobbing remains incompatible with Ice is Slick. No replacement meshes, textures, ESP, Papyrus scripts or save records are added.

## Cache and performance testing

`OptimizeRenderer=1`, `ShaderCache=1`, `PrewarmShaders=1`, `LogStats=1` and `PerformanceTimings=1` are supplied for beta testing. Debug colors and detailed pass/ripple traces default off. The cache is under `%LOCALAPPDATA%\SurfaceTides\ShaderCache\v1`; it is separate from OS's cache. Keep it between normal runs. The first uncached eligible water load may pause while prewarming; changed shaders/compiler/layout create new cache entries. Unseen variants can still compile on demand. Cache I/O failure falls back to compilation.

**Scope:** this cache/prewarm system covers ST-owned water stages in Vanilla, OS and ENB-water-off modes. The experimental native ENB mesh-input stages retain their existing compilation path.

The returned northwest-Skyrim preview.10 log confirms **77 disk-cache hits, zero cold stages, zero invalid entries/I/O failures and 11 prewarmed pairs in 58.687 ms**. No later ST compilation appears in the supplied session. This establishes warm-cache reuse, not a general FPS gain or attribution of every stutter.

For useful reports, send `SurfaceTides.log` from that launch, the winning ST INI, exact game/runtime and renderer versions, selected water mode/features, location and whether this was a first or repeat launch. Include a clip for visual defects and OS's log when applicable. Use the same northwest route/settings for performance comparisons. Copy logs before another launch overwrites them.

## Validation and limits

The three included Windows x64 DLLs are byte-for-byte the existing enb-depth.1 builds. Their original validation records nine portable suites and PE/runtime checks. Packaging rechecks the binary identities and schema/payload behavior of all **336 installer selection paths** with **56 complete INI variants**, including `MeshWadingDepth=1` in every INI. Each choice installs one correct DLL and INI, conditional BOS files, seven unchanged shader files and required notices. The actual MO2/Vortex wizard has not been exercised here. The user has accepted the ENB camera fix on Skyrim 1.6.1170; broader stress testing remains.

The installer is labeled `1.1.0-beta.1`; SKSE/FOMOD machine revision is `1.1.0.12`. To preserve the exact accepted DLLs, the log retains `1.1.0-beta.1-enb-depth.1`. Its older startup phrase about known underwater defects is historical; the current user report is that those issues are absent. No ENB source or shader code was obtained or used.
