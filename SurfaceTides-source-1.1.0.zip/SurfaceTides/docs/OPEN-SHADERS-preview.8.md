# Surface Tides 1.1.0-os-preview.8 — performance candidate

2026-09-24. Implements the first two agreed CPU optimizations and adds timing
measurements. Preview.7 remains the accepted visual/stress-test baseline.
Preview.8 is built and checked, but awaits an in-game comparison. No FPS gain or
stutter fix is claimed from source inspection or portable tests.

## Install

Install the zip matching your Skyrim executable after the working Surface Tides
installation. It supplies the DLL and the same seven shaders as preview.7.
It supplies no active INI, OS settings JSON, or changes to OS's shader files.
Keep the working OS WaterEffects, Unified Water, FG, displacement and normal
settings. Keep OS's Water shader replacement off and OSPreserveSceneMotion=1.

The two new startup switches default to 1 even when absent from an older INI:

```ini
[Performance]
OptimizeRenderer=1

[Diagnostics]
PerformanceTimings=1
```

Edit the winning `Data/SKSE/Plugins/SurfaceTides.ini`. Add keys to an existing
section if present; do not replace the rest of the INI or duplicate sections.
Restart Skyrim after changing either key. Timings work independently of
LogStats; leave LogStats=1 for the normal draw/compatibility counters.

## First test and comparison

1. With OptimizeRenderer=1, check wakes, wading, distant water, underwater and
   an interior/exterior transition. Appearance should match preview.7. Allow OS
   startup/cache work and first-use ST shader compilation to finish. Walk the
   test route once to warm it up, then repeat for about 60 seconds with OS's
   overlay visible. Save SurfaceTides.log before another launch overwrites it.
2. Change only OptimizeRenderer to 0, restart, load the same save and repeat
   that warm-up and measured route with identical settings. Keep
   PerformanceTimings=1. Save this run's log separately.
3. Send both SurfaceTides logs, the current CommunityShaders log, and any clip
   showing remaining stutters. Label runs optimized/reference. Comparing a
   moving run with a stationary one, or cold shader compilation with warmed
   play, would not isolate the change.

OptimizeRenderer=0 restores the previous indexing, string-cache and binding-call
paths while keeping these timing probes. Both runs therefore use the same
measurement code. Set PerformanceTimings=0 and restart to remove probe overhead
after measurement. Preview.7's original package remains the full rollback.

## Changes

- The optimized path polls the index deadline once per Present instead of every
  intercepted draw. It compares ordered native shader record/object pairs every
  five seconds. Unchanged collections retain tags, generation and positive
  identity cache entries. Owner, record, object, count or order changes rebuild
  the index; failed tag writes retry. Negative identities expire at each poll so
  wrappers that acquire tags later can be discovered. Indexed COM objects are
  retained until replacement to prevent released-address reuse.
- Constant-buffer snapshots/restores batch b0-b2 and b11-b12; t96-t97 are also
  batched. They save exactly the same slots and preserve null bindings. Resource
  snapshot calls fall from 32 to 16, and restore calls from 32 to 16, per accepted
  water draw. These counts exclude shader/topology/blend calls and COM reference
  operations; halving these API calls does not imply halving draw or frame time.
- Tessellated draws reuse the captured VS constants and batch their HS/DS
  assignments. OS b4-b6 validation uses one Get call with the same size checks.
  Incompatible pipelines skip resource snapshots; distant LOD exits earlier.
- Fixed-size keys include both shader descriptors and all 84 constant-layout
  bytes. A last-key hit avoids the hash lookup. Successful and failed compiled
  permutations retain their existing cache behavior. No disk shader cache added.

All HLSL, solver algorithms/settings, object-effect algorithms, hook dispatch and
the accepted scene-motion mask remain unchanged. The game update only gains CPU
timers. Regular CS remains unsupported. Color and full ENB integration remain
deferred; no ENB source/code was obtained or used.

## Reading the timings

Five-second `ST CPU` reports show count, total, mean and maximum CPU wall time in
milliseconds. Game and render collectors are thread-local, with no shared lock,
GPU query, readback, per-draw log or wait. The probes have some overhead; use the
same timing setting in both runs.

| Log label | Scope |
| --- | --- |
| game update | Whole ST game update after timing-report output, including inactive/paused calls and existing diagnostics |
| game foam / terrain / contacts / solver / packField / floes / publish | Individual active-update phases; contacts includes impulses; solver includes however many substeps that update runs |
| render setup.sampled | ST begin/setup only, including early non-water exits; excludes original/downstream draw, outer hook, after-draw probe and restoration |
| render identify.sampled | Index check and bound-shader identification inside setup |
| render capture.sampled / bind.sampled / restore.sampled | Binding snapshot, replacement and restoration API work; restoration excludes subsequent ComPtr member releases |
| render prepare | Once-per-water-frame preparation, including field/constants upload and any resource creation |
| render index / compile | Every index scan/rebuild or first-use permutation compilation, unsampled |
| ST index | Polls, rebuilds, unchanged polls and current tag generation |
| ST Present interval | Hook-to-hook intervals, mean/p50/p95/p99/max; includes menus, loading and the whole game |

Draw scopes use pseudo-random approximately 1/128 sampling to avoid fixed draw
order bias. Their counts/totals are sampled observations, not whole-frame costs;
their maximum may miss a hitch. Capture/bind/restore have fewer samples than
setup because only eligible water draws reach them. Phases overlap: setup includes
identification/capture/bind and sometimes index/prepare/compile, while game update
includes its subphases. Do not sum overlapping totals or convert them to GPU time.

Present percentiles use nearest rank over at most the last 4096 intervals in each
report window; count and percentileN disclose the sample sizes. These intervals
are neither ST-only cost nor post-frame-generation FPS. A pause or load can
dominate a window. Compare sustained gameplay windows after warm-up. On unchanged
shader collections the optimized run should show unchanged polls and a stable
generation; the reference run should continue rebuilding about every five seconds.

## Validation and limits

Seven portable test suites pass, including shader-index invalidation, every key
layout byte, key-cache rehash stability, all 32 null-buffer combinations in both
binding modes, bounded timing/reset behavior and randomized sampling. Windows x64
MSVC-ABI Release DLLs built for SE 1.5.97, AE16 1.6.1170/1.6.1179 and AE17 1.7.104;
PE exports/runtime metadata are checked during packaging. Existing vendor/toolchain
warnings are retained. Native Windows D3D execution and Skyrim testing are not
available here. Prior HLSL validation is retained because all seven shader files
are byte-identical to the accepted candidate. See os-preview.8-validation.json in
the source checkpoint for hashes and build evidence.
