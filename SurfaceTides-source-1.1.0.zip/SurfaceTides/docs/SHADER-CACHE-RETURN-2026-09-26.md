# Surface Tides preview.9 returned test findings

Both runs successfully moved all 11 seeded water pairs into prewarming, and
neither log records subsequent ST compilation. This removes the specific late
compilation events seen in preview.8 from these routes. Persistent caching was
not exercised: an implementation error made compiler identification reject the
local import thunk, so both runs fell back to ordinary compilation. Preview.10
corrects that lookup; a second-launch cache benefit remains unverified.

## Confirmed settings and shader activity

Both logs load preview.9 on Skyrim 1.6.1170, with ShaderCache=true,
PrewarmShaders=true, PerformanceTimings=true, OS selected, WaterEffects and
Unified Water requested, and scene-motion preservation on. Wind, interaction,
displacement, normal strength and tessellation settings match. OptimizeRenderer
is true in SurfaceTidesOptimized.log and false in SurfaceTidesUnoptimized.log.
Thus this is a CPU-path comparison with prewarming enabled in both, rather than
a cache-on/cache-off comparison. No OS startup log accompanies these runs.

| Observation | Optimized | Unoptimized |
| --- | ---: | ---: |
| Prewarmed pairs | 11 | 11 |
| Prewarm wall time | 3,564.555 ms | 3,579.423 ms |
| Actual compiler attempts | 77 stages | 77 stages |
| Compiler wall time | 3,545.892 ms | 3,560.324 ms |
| Later on-demand ST compilation | 0 | 0 |
| Disk cache hits / writes | 0 / 0 | 0 / 0 |
| Cache initialization failures | 1 | 1 |
| Logged bound water draws, whole run | 1,248,018 | 840,074 |
| Failed draws / WaterEffects fallbacks / motion failures | 0 / 0 / 0 | 0 / 0 / 0 |

Both retain zero motion-target mismatches, unsupported motion states and sampled
post-draw binding mismatches. Different run lengths make draw totals coverage
counts, not performance comparisons. Every shader build is phase=prewarm and
valid=true. No phase=draw build appears, and coldDrawBundles stays zero. Cache
counters remain unchanged through each log's end.

## Loading freeze and recording alignment

MP4 creation times imply local starts of 04:01:35 for Optimized2 (77.183 seconds)
and 03:56:25 for Unoptimized2 (76.433 seconds). Both are 1080p/60 recordings.
Creation timestamps have only one-second precision, so these alignments are
approximate, not frame-accurate synchronization.

Optimized prewarming runs from 04:02:15.534 to 04:02:19.098: about 40.5–44.1
seconds into the clip, while the scene is black. The frozen scene is visibly
present around 46–50.5 seconds, followed by black around 51–52.75 seconds and
live fade-in around 53.5 seconds. Unoptimized prewarming runs from 03:57:05.199
to 03:57:08.778, about 40.2–43.8 seconds, with a black scene through the later
loading interval and live fade-in around 53.5 seconds.

ST compilation has finished before the optimized frozen-scene sequence. No
persistent cache writes occurred in either run. This supports treating that
specific sequence separately, particularly given the user's observation without
Surface Tides. It does not identify the responsible renderer/loading subsystem
or prove that ST has no effect on loading time: prewarming itself took 3.6 seconds.

## Remaining gameplay stalls

Both clips contain frame-time spikes while turning toward Riverwood. A scene
crop excluding the overlay, downsampled to 340x270 with freezedetect=-50dB and
a 100 ms threshold, finds repeated/near-static intervals around 59.9–61.3
seconds optimized and 58.4–59.9 seconds unoptimized, plus later shorter clusters.
These coincide broadly with the first Riverwood-facing turns. This detector
measures recorded image changes, not native/post-FG FPS or the cause of a stall.
The stationary clip endings are excluded from any hitch interpretation.

ST's compilation counters do not increase during those events. View-dependent
draw submission, scene streaming, other shaders/features and GPU/memory work
remain plausible. The captures do not establish a particular bottleneck or
clear ST's remaining CPU/GPU cost. A less dense water area with repeatable camera
turns is a useful next control. First verify working cross-launch cache behavior
with the corrected build while keeping OptimizeRenderer fixed.

For an explicit, limited numeric comparison, use complete five-second windows
after both clips reach gameplay at 54 seconds and before recording ends. This
retains the large gameplay spikes; it does not trim slow frames out of windows.
Optimized render report ends: 04:02:36.484, :41.487, :46.537. Unoptimized ends:
03:57:27.288, :32.289, :37.410. Game report windows are separate and slightly
offset. Camera, water draw mix and simulation work are not identical.

| Measurement, weighted by observations | OptimizeRenderer=1 | OptimizeRenderer=0 |
| --- | ---: | ---: |
| Index operation mean, once about every five seconds | 0.043 ms | 2.351 ms |
| Sampled setup per intercepted draw | 0.219 microseconds | 0.230 microseconds |
| Sampled water restore per draw | 0.332 microseconds | 0.475 microseconds |
| ST game update mean | 2.394 ms | 2.086 ms |
| Solver mean per update | 2.113 ms | 1.834 ms |
| Whole-game Present interval mean | 27.891 ms, 546 frames | 26.256 ms, 576 frames |
| Largest Present interval within those windows | 796.311 ms | 431.257 ms |

Indexing and restore work remain cheaper. These runs do not show a clean
whole-frame improvement from the CPU switch. Solver work depends on elapsed
time/substeps and was not changed by that switch. Sampled draw scopes exclude
parts of the surrounding render path and cannot establish GPU cost. Do not add
nested timings or treat recorded Present cadence as post-frame-generation FPS.
The multi-second Present gaps in later log windows straddle or follow the clip
end and are not counted in this displayed gameplay comparison.

## VRAM observation

At optimized clip second 51, during loading, the overlay displays 22.80 GB against
a 21.09 GB budget (108.1%). At second 60 it shows 18.06/21.08 GB, then 10.71/23.19
GB at second 70. Unoptimized shows 16.57/23.19 GB at second 51, 18.04/21.09 GB
at second 60 and 9.83/23.19 GB at second 70. These are isolated displayed readings;
overlay categories update on their own cadence and do not identify ownership.
The large reduction after loading argues against interpreting this short sample
as a demonstrated monotonic ST leak. Memory pressure remains worth watching,
and neither these readings nor the new cache code establish its source.

## Fix and evidence preservation

The SDK D3DCompile declaration lacks dllimport. The preview.9 map has a local
D3DCompile thunk and a distinct __imp_D3DCompile import slot. Taking the former's
address identifies SurfaceTides.dll, so the compiler-only filename guard rejects
it. Preview.10 reads the resolved import target for identity, logs the recognized
compiler and retains the existing compilation path and guard. Only compiler
identification and version metadata change in executable source.

The source checkpoint retains this report, parsed timing/health/build records,
input hashes, detector output and the analysis script. An evidence ZIP also
contains sampled scene/loading/overlay sheets; original attachments remain
unaltered. No native game execution was available for the corrected build.
