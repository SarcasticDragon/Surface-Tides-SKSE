# Surface Tides performance review and OS stress-test baseline

2026-09-24. Version 1.1.0-os-preview.7-unified-water is accepted by the user for
stress testing. The returned test reports no visible issues. Performance review
now precedes experimental ENB integration. This checkpoint changes documentation
and records evidence only; the accepted DLL, shaders and settings are unchanged.

## Evidence and limits

Inputs: SurfaceTides(20260924-112030).log, CommunityShaders(3).log and the
13.5-second 1920x1080/60 clip 2026-09-24 05-18-20.mp4. The logs identify Skyrim
1.6.1170, OS v2-13-0-0, WaterEffects/UnifiedWater loaded, and FSR frame generation
with a D3D12 proxy. Rendering is 2560x1440 in the OS log; the recording is 1080p.

Across 118 Surface Tides reporting intervals, there are no failed draws,
WaterEffects compile fallbacks, or motion-target mismatches/unsupported states.
UW-adapted draws total 12,337,796, including 919,067 flowmap draws. All 12,334,757
reported stencil draws received the verified motion mask. These are draw counts,
not frame counts or timing measurements. Stress testing and other runtime/OS
combinations remain outstanding.

Selected visual readings from the overlay:

| Sample image | Raw frame time / FPS | Water row | Water draws | Other row |
| --- | --- | --- | --- | --- |
| frame-01 | 22.63 ms / 44.2 | 2.13 ms | 802 | 8.78 ms |
| frame-03 | 15.89 ms / 62.9 | 2.26 ms | 837 | 1.91 ms |
| frame-05 | 15.43 ms / 64.8 | 2.27 ms | 844 | 1.69 ms |
| frame-06 | 20.29 ms / 49.3 | 2.32 ms | 843 | 5.34 ms |

These samples suggest that the larger fluctuations are not confined to the water
category. They do not identify which mod causes a spike. There is no matched
Surface Tides off/on baseline, and no CPU/GPU utilization trace.

The inspected OS v2.13.0 State::Debug uses QueryPerformanceCounter intervals
at shader updates for the per-shader rows. Those are CPU-side wall-time
attributions, not isolated GPU timer queries for each shader. The OS Passes row
uses separate GPU profiling, and Other is calculated as remaining frame time.
Consequently, Other is not a dedicated CPU-cost or Surface Tides measurement,
and subtracting these rows cannot cleanly identify a CPU or GPU bottleneck.
The Water row includes the surrounding water path, not just our incremental cost.
The displayed FSR post-FG timing is calculated; use raw frame time to compare
simulation/render changes. The overlay is useful for trends, not causal proof.

## Prioritized opportunities

1. **Remove recurring full shader-index rebuilds.** Renderer::indexWaterShaders
   currently clears maps and identity caches, increments the generation, traverses
   every native water shader, and calls GetPrivateData/SetPrivateData on each.
   The log confirms 2,172 VS + 2,172 PS, repeated approximately every five seconds
   (119 reports). This is a concrete periodic workload and a plausible hitch
   contributor, but its duration is not measured. Keep a stable index while
   objects are unchanged, detect replacement safely, and amortize the fallback
   refresh. Retain the accepted OS draw-hook recovery and identity guarantees.
   LogStats=0 does not disable this indexing work.

2. **Reduce CPU overhead per draw.** About 83% of intercepted draws in the two
   five-second reporting windows overlapping the clip are non-water. Every draw
   still performs identification work. Actual water draws allocate a DrawState,
   construct a string key containing constant tables, query many D3D bindings,
   check live OS buffers, then bind and restore resources across four stages.
   Batch adjacent binding queries, snapshot only state actually modified, reuse
   safe lookup data and make non-water rejection cheaper. Optimize without
   caching unverified external state across mutations or weakening restoration.
   Keep scene-motion preservation enabled; its target/COM checks can later be
   optimized with retained identities and explicit invalidation, not blind reuse.

3. **Optimize the game-thread wind math and recurring data work.** At the current
   192x192 grid, two sines per cell per 120-Hz step mean 8,847,360 evaluations per
   simulated second when wind is enabled, including dry cells. Cache/reuse
   spatial terms and evaluate time-dependent terms once per step, with numerical
   and visual regression checks. Reuse mask/contact/frame buffers where ownership
   allows; avoid refreshing unchanged terrain unnecessarily. Keep game-object
   queries on the game thread. Worker/GPU simulation is a larger follow-up only
   if measurements justify its synchronization and history complexity.

4. **Smooth periodic object discovery.** Foam.cpp scans references in attached
   grid cells and the sky cell in one update every second while below its tracked
   reference cap. Unlike floe discovery, this is not sliced across updates.
   Budget/cache that work and invalidate for loaded-cell/3D changes. The clip's
   floe logs have zero active floes/fits/samples; that rules out active bobbing
   fits for this scene, not all discovery overhead. Wind gusts also occur in
   half-second batches and deserve their own timing counter before changing them.

5. **Make tessellation more selective.** Every bound close-water triangle-list
   draw takes the tessellation pipeline. The hull shader already lowers edge
   factors outside the local patch; distant water is not all subdivided at 64.
   Still, the pipeline and surface sampling have overhead outside the patch.
   Skip tessellation for reliably bounded draws outside both relevant simulation
   fields, and consider projected-size detail reduction for affected tiles.
   Preserve shared-edge agreement, huge triangles enclosing the patch, matching
   color/stencil silhouettes, OS UW color/flow adaptation and temporal history.
   Do not revert distant UW draws to the incompatible ordinary coordinate layout.

6. **Cache or prewarm shaders for first-use hitches.** Water bundles compile
   synchronously from Renderer::begin, using seven D3DCompile stages per normal
   tessellated bundle (including reference/remapped stages). Twelve bundles were
   first encountered during this session. The final compile completion is
   05:11:42.003; none occur in the roughly 05:18:20 clip window. This is a real
   first-encounter optimization, not an explanation of the recorded late spikes.
   A disk cache must include our source, transitive installed OS headers,
   feature flags, compiler target/options and native constant layout in its key.

## Isolated solver check

The unmodified production Simulation.cpp was compiled with GCC -O3 -DNDEBUG,
without fast-math, and measured on this Linux analysis host. Each case uses
192x192, Spacing=20, fixed 120 Hz, 120 warmup steps and 3,600 measured steps.
Half-wet uses a synthetic half-plane, not terrain from the game. No actor wakes,
terrain queries, recentering, frame publication, D3D, or engine work is included.

| Wet cells | Wind / gust strength | Median CPU ms per solver step |
| --- | --- | --- |
| 50% | 0 / 0 | 0.253 |
| 50% | 5 / 0 | 1.642 |
| 50% | 5 / 1 | 1.636 |
| 100% | 0 / 0 | 0.431 |
| 100% | 5 / 0 | 1.809 |
| 100% | 5 / 1 | 1.796 |

This supports targeting continuous wind math. It predicts neither the user's
frame cost nor an FPS gain. The small differences between gust on/off runs are
not evidence that gusts are free or faster; short bursts and host scheduling
require separate measurement. Source, complete results and compiler command are
retained under os-performance-evidence/. No changed solver is being delivered.

## Suggested next implementation

Add lightweight aggregated CPU timings for indexing, water-draw setup/restoration,
terrain, contacts, solver, publication/upload and object scans. Capture maxima
and frame-time percentiles without per-draw log writes or blocking GPU readback.
Make the stable-index/per-draw changes first, then optimize continuous wind math.
Compare against this retained baseline on the same warmed route and settings;
confirm the improvement with the overlay hidden as well. Investigate shader
cache and adaptive tessellation separately so visual regressions can be isolated.

An optional immediate quality/performance control is Rendering.TessellationMax
64 to 32, keeping simulation resolution, wind and displacement unchanged. This
reduces the cap, not every triangle's factor, and may soften finely displaced
silhouettes. It is not a guaranteed speedup. In OS use the live Surface Tides
tessellation-limit slider for comparison; changing it does not require a grid
reset. Do not disable the accepted scene-motion workaround for this test.

## References

- Local source: Renderer.cpp (indexWaterShaders, DrawState, compileWater, begin),
  Game.cpp (refreshTerrain, updateGame), Simulation.cpp (step, addImpulse),
  Foam.cpp (tick), Floes.cpp (discover), Tessellation.hlsli and SurfaceField.hlsli.
- [OS v2.13.0 State.cpp](https://github.com/alandtse/open-shaders/blob/v2.13.0/src/State.cpp)
  and [PerformanceOverlay.cpp](https://github.com/alandtse/open-shaders/blob/v2.13.0/src/Features/PerformanceOverlay.cpp).
  Exact public-source hashes are retained in the evidence. They do not prove
  the installed binary matches the tag byte-for-byte.
- [Microsoft D3D11 query types](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ne-d3d11-d3d11_query)
  for a future GPU timestamp/disjoint measurement path.

Color remains parked. CS remains unsupported. No ENB source/code was obtained
or used; no new ENB implementation work is included in this checkpoint.
