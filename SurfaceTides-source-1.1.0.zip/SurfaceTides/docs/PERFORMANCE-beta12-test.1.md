> Accepted after the user's ENB A/B return on September 30, 2026 (Denver). Solver ~1.36 -> 0.57 ms/update; total ST game update ~1.63 -> 0.85 ms/update in selected fully active windows. These are ST CPU costs, not overall FPS. The disabled-state FPS difference is unconfirmed. Target four now proceeds separately; see PERFORMANCE-beta12-discovery-test.1.md. The original build/benchmark notes below are retained.

# Beta 12 performance test 1 — continuous wind

Version: 1.1.0-beta.12-performance-test.1. AE16 DLL overlay for Skyrim 1.6.1170 / GOG 1.6.1179. The packed SKSE revision stays 15; full display labels and checksums distinguish the builds without overflowing its four-bit field. This is a test candidate, not a new complete FOMOD or an established game-wide performance result.

## Why this target

The September 24 list's third target was game-thread wind math and recurring data work. Targets one and two were stable shader indexing and lower per-draw renderer overhead; preview.8 implemented them and added timings. Later work addressed first-use shader stalls through caching/prewarming. The preview.8 analysis identified the solver as roughly 86% of ST game-update cost. The latest pond log also reports 1,930.762 ms of solver work within 2,244.722 ms of measured ST game-update work, about 86%. These are ST CPU scopes, not total game or GPU time. Update and solver call counts differ because inactive/paused updates can return before running the solver.

The accepted direct wind loop evaluates two sines for each of 192x192 cells every 120-Hz step: 8,847,360 sine evaluations per simulated second, including dry cells. This first pass targets that continuous forcing. Gust kernels, terrain work and other recurring data copies are unchanged; they can be measured separately after this result.

## Change

Cache double-precision sine/cosine terms per world-space x and y coordinate and use angle addition for the same two wave equations. Time terms are evaluated directly once per step, with no recurring oscillator or accumulated phase approximation. The cache updates when origin/spacing changes; its memory is O(resolution), about 12 KiB for the 192 grid. Wet cells alone receive forcing and contribute to the same mean subtraction. Existing float world-coordinate rounding is retained before double phase calculations.

The grid, timestep, wave equation, dispersion, gust schedule, gust strength, wake impulses, damping and renderer/shaders are unchanged. The accepted pond selection, ENB ripple/camera correction, OS integration and prewarming/cache implementation remain intact. An independent startup-only [Performance] OptimizeSimulation switch defaults to 1; 0 selects the original direct formula and retains all accepted fixes. It does not change OptimizeRenderer.

## Checks and benchmark

All eleven portable suites pass, including existing wave/dispersion/conservation, water retention, motion and ripple policies. The new wind suite compares 21,128,850 wet-cell forcing values over resolutions 16–512, fractional spacing, large positive/negative coordinates, wet-mask changes and times up to one week. Maximum forcing difference is 1.1920929e-7; maximum wet-mean difference is 4.2965057e-10.

Thirty-second paired full-solver runs at 64 and 192 include gusts, impulses, scrolling, mask changes, reset/teleport and live retuning. Across 294,912,000 cell comparisons, maximum height error is 4.7683716e-7 game units and maximum velocity error is 5.8412552e-6 game units/second. Step and clipping counters agree. Wind-off state is bit-identical. These numerical checks are not a visual game test.

The table shows the median of five per-run means for each mode, using the GNU 13.3.0 portable build at -O2, one CPU affinity, 120 warm-up steps and 600 measured steps per run; mode order alternates. It times the entire Surface::step, including gusts except the explicit continuous-only/control cases. Scrolling also includes recenter and mask updates. It excludes Skyrim, render hooks, engine terrain queries, actor scanning and GPU work.

| Portable solver case | Direct math ms/step | Cached math ms/step | Reduction |
| --- | ---: | ---: | ---: |
| Continuous wind only | 1.394 | 0.388 | 72.2% |
| Open water with gusts | 1.334 | 0.394 | 70.5% |
| Pond / mostly dry field | 1.167 | 0.168 | 85.6% |
| Scrolling with gusts | 1.222 | 0.364 | 70.2% |
| Entirely dry mask | 0.998 | 0.109 | 89.1% |
| Wind disabled control | 0.902 | 0.899 | 0.3% |

Do not apply these percentages directly to FPS or the Windows game-thread timings. Different CPU/compiler/math-library behavior and frame bottlenecks affect the gain. Raw per-run means, p95/max timings, energies and clipping counts are retained in beta12-performance.1-evidence. The synthetic mask cases can hit the existing height limiter; reference and optimized runs must agree on clipping counts. Max timings also include host scheduling noise, so this benchmark does not establish that all stutters are solved. Localized gust generation remains a possible source of periodic work.

## Install and compare

Replace/disable the pond-test DLL overlay and put this one above Beta 11. It supplies the DLL and documentation only; retain the current INI and shaders. No cache deletion, renderer changes or new INI is needed for the initial run. Confirm the beta.12-performance-test.1 label and OptimizeSimulation=true in the log.

Use the same northwest Skyrim route, renderer, wind/tuning and camera movements for both runs. For a comparison, add OptimizeSimulation=0 inside the existing [Performance] section and restart. Setting 1 or removing that key restores the optimized path after another restart. Keep PerformanceTimings=1. Send both fresh logs and any observed visual difference; a short performance-overlay clip is useful. The default test retains the accepted pond fix in both modes. Disabling this overlay and restoring the accepted pond overlay is a complete rollback.

The AE16 DLL is cross-built and its AMD64/SKSE exports/exact runtime declarations are checked before packaging. SE and AE17 are not rebuilt for this focused performance test. No ENB implementation source, shaders, bytecode or SDK are accessed; no native Skyrim or GPU execution is performed here. The released Beta 11 installer is not modified.
