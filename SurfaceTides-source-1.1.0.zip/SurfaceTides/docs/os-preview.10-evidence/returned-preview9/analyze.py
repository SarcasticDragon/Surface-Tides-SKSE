from pathlib import Path
from datetime import datetime, timedelta
import re, json, hashlib, subprocess

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent / 'upload'
CPU = re.compile(r'ST CPU (game|render) (\S+): n=(\d+) totalMs=([\d.]+) meanMs=([\d.]+) maxMs=([\d.]+)')
KV = re.compile(r'(\w+)=(-?[\d.]+)(?![\w.])')

def fields(line):
    return {k: float(v) for k, v in KV.findall(line)}

def stamp(line):
    return datetime.fromisoformat(line[1:24])

def summarize(rows):
    result = {}
    for key in sorted({k for row in rows for k in row['cpu']}):
        values = [row['cpu'][key] for row in rows if key in row['cpu']]
        count = sum(v['n'] for v in values)
        total = sum(v['totalMs'] for v in values)
        result[key] = {'n': count, 'totalMs': total, 'meanMs': total/count if count else None,
                       'maxMs': max(v['maxMs'] for v in values)}
    presents = [row['present'] for row in rows if 'present' in row]
    if presents:
        n = sum(p['n'] for p in presents)
        result['present'] = {'n': n, 'weightedMeanMs': sum(p['n']*p['meanMs'] for p in presents)/n,
                             'maxMs': max(p['maxMs'] for p in presents)}
    return result

runs = {}
for name in ['Optimized', 'Unoptimized']:
    path = INPUT / f'SurfaceTides{name}.log'
    lines = path.read_text().splitlines()
    video = INPUT / f'{name}2.mp4'
    meta = json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries',
        'format=duration:format_tags=creation_time:stream=codec_name,width,height,r_frame_rate,nb_frames',
        '-of','json',str(video)],text=True))
    # Creation timestamps have only one-second precision; approximate alignment.
    start = datetime.fromisoformat(meta['format']['tags']['creation_time'].replace('Z','+00:00')).replace(tzinfo=None)-timedelta(hours=6)
    duration = float(meta['format']['duration'])
    rows, builds, caches, sim = [], [], [], []
    active = {'game':None,'render':None}
    previous_report = {'game':None,'render':None}
    for line in lines:
        t=stamp(line);time=t.isoformat(sep=' ')
        match=CPU.search(line)
        if match:
            domain=match[1]
            if match[2] in ('update','setup.sampled') or active[domain] is None:
                active[domain]={'time':time,'clipSeconds':(t-start).total_seconds(),'cpu':{},
                                'previousReport':previous_report[domain]}
                previous_report[domain]=time;rows.append(active[domain])
            active[domain]['cpu'][domain+'.'+match[2]]={'n':int(match[3]),'totalMs':float(match[4]),
                'reportedMeanMs':float(match[5]),'maxMs':float(match[6])}
        for tag,label in [('ST Present interval:','present'),('ST index:','index')]:
            if tag in line and active['render'] is not None:active['render'][label]=fields(line.split(tag)[1])
        if 'Shader build:' in line:
            row=fields(line);row.update(time=time,clipSeconds=(t-start).total_seconds(),
                phase=re.search(r'phase=(\w+)',line)[1],vs=re.search(r'VS=([A-F0-9]+)',line)[1],
                ps=re.search(r'PS=([A-F0-9]+)',line)[1],valid='valid=true' in line)
            builds.append(row)
        if 'Shader cache totals:' in line:caches.append(dict(fields(line),time=time))
        if 'Simulation seq=' in line:
            row=fields(line);row.update(time=time,clipSeconds=(t-start).total_seconds(),
                position=list(map(float,re.search(r'player=\(([^)]+)\)',line)[1].split(','))))
            sim.append(row)
    # Both clips are visibly in active gameplay by 54 s. Include only complete
    # reporting windows after that cutoff and fully within the supplied clip.
    steady=[row for row in rows if row['previousReport'] and
            (datetime.fromisoformat(row['previousReport'])-start).total_seconds()>=54 and row['clipSeconds']<=duration]
    health={tag:[fields(line.split(tag)[1]) for line in lines if tag in line] for tag in
        ['Draw scan since report:','OS scene motion:','OS WaterEffects:','OS UnifiedWater:','Coexistence probe:','Hook health:']}
    runs[name]={'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'video_sha256':hashlib.sha256(video.read_bytes()).hexdigest(),
        'video_metadata':meta,'clip_local_start':start.isoformat(sep=' '),'rows':rows,'builds':builds,'cache_totals':caches,
        'startup':[line for line in lines if any(t in line for t in ['Performance:','Shaders:','Config:','Interaction strength=','OS compatibility:'])],
        'warnings':[line for line in lines if '[warning]' in line or '[error]' in line],
        'prewarm':[line for line in lines if 'Shader prewarm' in line],
        'health':health,'simulation':sim,'complete_gameplay_windows':{'cutoff_seconds':54,'times':[row['time'] for row in steady],
                                                                   'summary':summarize(steady)}}
    print(name, 'builds',len(builds),'draw builds',sum(b['phase']=='draw' for b in builds),'last cache',caches[-1])
    for row in rows:
        if 'present' in row:
            p=row['present'];print('present',row['time'][11:],row['clipSeconds'],p['n'],p['meanMs'],p['p95Ms'],p['maxMs'])
    print('Complete gameplay windows', json.dumps(runs[name]['complete_gameplay_windows'],indent=2))
    print('Health sums', {tag:{key:sum(row.get(key,0) for row in values) for key in
        ['bound','failed','compileFallbacks','targetMismatch','unsupported','changedAfterDraw','disabled','foreign']} for tag,values in health.items()})
(ROOT/'parsed.json').write_text(json.dumps(runs,indent=2)+'\n')
