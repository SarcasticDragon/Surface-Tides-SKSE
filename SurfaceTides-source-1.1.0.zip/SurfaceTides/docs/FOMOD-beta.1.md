# Beta FOMOD authoring and validation

Current version: 1.1.0-beta.1, machine revision 1.1.0.12. This supersedes the historical 1.0/OS-preview.3 generator behavior.

The installer offers requirements, exact runtime, renderer, one visible renderer-specific page (OS or ENB), then surface-object choices. Vanilla needs no renderer-specific page. All choices are explicit; the installer does not infer a runtime from an edition label or infer OS from the shared CommunityShaders.dll filename.

Three exact-runtime binaries serve SE 1.5.97, AE16 1.6.1170/1.6.1179 and AE17 1.7.104. Seven rendering configurations (Vanilla, two ENB, four OS) each have eight attached-foam/ice/bobbing INIs. Standalone BOS foam selection is independent: 3 runtimes × 7 renderer modes × 4 foam modes × 2 ice modes × 2 bobbing modes = 336 valid paths, 56 distinct full INIs.

Defaults: AE16 runtime, Vanilla renderer, authored foam/ice and static floes. If OS is selected, both water features are recommended; they must match OS boot settings. If ENB is selected, experimental integration is recommended for the requested beta test; the coexistence fallback is available on the same page. New INIs retain current simulation tuning, caching/prewarming/timings and the accepted OS motion workaround. They omit AllowENB entirely and include MeshWadingDepth=1. Native ENB ripple clipping remains a Beta 2 target.

The payload contains only our three runtime DLLs (one installed), ST-owned shaders, full configuration variants, the optional BOS preset, documentation and license notices. Renderer packages, preset JSONs and caches are not bundled. No renderer configuration is edited. Conditional rules depend on renderer as well as submode, so stale flags from a hidden page cannot select another renderer's INI.

For this promotion, reuse the three exact DLLs from the accepted enb-depth.1 overlays. Do not rebuild simply to change the log label. The original three-profile builds, nine portable suites and PE/runtime checks remain in `docs/enb-depth.1-evidence`; the returned visual result is in `docs/ENB-DEPTH-beta.1-ACCEPTED.md`. Package and verify with:

```sh
python tools/package_beta1_final.py --baseline-source /checkpoints/SurfaceTides-source-ENB-depth-accepted.zip --previous-fomod /checkpoints/SurfaceTides-1.1.0-beta.1-FOMOD.zip --overlay-dir /checkpoints/enb-depth1 --output-dir /output/beta1-final
```

The historical `package_beta1.py` records the original pre-fix packaging recipe; use `package_beta1_final.py` for the current package. The final recipe authenticates source, previous installer, overlay archives and DLL hashes, then validates every selection with binary revision 12. It checks that all game code and shaders remain byte-identical to the accepted source, and existing INI values match the previous FOMOD with only MeshWadingDepth added. `docs/beta.1-final-validation.json` records the current installer checksum and provenance.

Use a clean stage. `build_fomod.py` also regenerates the tracked `installer/fomod` XML. The validator uses the vendored official ModConfig5.0 schema, checks manager encoding rewrites, walks only visible pages, exercises stale hidden flags, compares each runtime DLL's metadata and verifies every full INI against the canonical template. Packaging rejects unexpected changes or lost files relative to the authoritative source checkpoint and excludes build products from the source archive. It bundles no compiler or Windows SDK.

Automated validation is not a native mod-manager UI test. Confirm the wizard's page transitions, winning DLL and fresh INI on first install.
