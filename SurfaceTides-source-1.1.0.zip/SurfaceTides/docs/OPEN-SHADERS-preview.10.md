# Surface Tides 1.1.0-os-preview.10 — compiler identity correction

2026-09-26. A narrow correction to preview.9's persistent cache. The returned
Optimized2/Unoptimized2 runs both prewarmed all 11 known water pairs, with no
later Surface Tides compilation. However, both reported `Shader cache
unavailable: Unrecognized D3D compiler module`, zero cache hits and zero writes.
Those runs validate prewarming, not persistence across launches.

## Install and next test

Install the ZIP matching the Skyrim runtime after the working Surface Tides
installation. Your INI and OS settings are preserved. ShaderCache=1 and
PrewarmShaders=1 remain the defaults under [Performance], including when absent.

For the next two launches, leave OptimizeRenderer=1 in both. Use the same save,
settings and route, with a full game exit between runs. A less dense water area
is a useful control for the Riverwood-facing spikes. Keep the cache between
runs and save each SurfaceTides.log before the next launch overwrites it.

The first run can spend several seconds compiling at the first water draw.
The second should report cacheHits with coldStages=0 for those same prepared
pairs. The log now identifies the compiler with `via=resolved-import` before
`Shader cache ready`. An unrecognized redirected import still bypasses caching
and reports the actual module filename. The detailed controls, bounds and
limitations from Shader-cache-details.md (preview.9 notes) still apply.

The prior recordings varied OptimizeRenderer, not the two new shader switches:
both had ShaderCache=true and PrewarmShaders=true. No INI error caused the cache
bypass; it was an implementation error in the compiler identity lookup.

## Correction and checks

The Windows SDK declares D3DCompile without dllimport. In these builds its
address therefore names an import thunk inside SurfaceTides.dll. The old
GetModuleHandleExW call correctly found that local module, which then failed
the intended d3dcompiler_47.dll guard. The linked map confirms separate
D3DCompile and __imp_D3DCompile symbols.

The correction reads the resolved __imp_D3DCompile import slot for module
identification. Normal compilation still follows the existing D3DCompile call
path; no import table or hook is changed. The strict compiler filename guard
remains. Only the recognized Microsoft compiler file is fingerprinted, with
no renderer module inspection. Unknown targets retain ordinary compilation.

Eight portable test suites pass. All three Windows x64 MSVC-ABI runtime builds
and PE runtime/version checks pass. An additional object-code regression check
verifies a load from __imp_D3DCompile into the address argument immediately
before GetModuleHandleExW, rather than an address of the local thunk. The check
is tied to each packaged DLL's hash. It does not replace native Windows testing.

All renderer code, HLSL, simulation, hooks, object effects, INI values and vendor
files are byte-identical to preview.9. Cache/prewarm behavior below compiler
identification is unchanged. Native cache I/O and second-launch hits require
the user's next game run. No FPS improvement or VRAM attribution is claimed.

See docs/os-preview.10-validation.json and docs/os-preview.10-evidence in the
complete source checkpoint. Rebuild with the existing three runtime profiles,
run tools/verify_compiler_import.py with --build-root, --objdump and --output,
then tools/package_os_cache_fix10.py with --baseline-source (preview.9 source),
--build-root and --output-dir. Build tool versions remain those in
docs/os-preview.9-evidence/provenance.json.

Microsoft's description of the linker thunk and import-table slot:
https://learn.microsoft.com/en-us/cpp/build/importing-function-calls-using-declspec-dllimport
