# Lava side add-on: feasibility, not an implemented feature

> Updated evidence: the user has now supplied seven NIFs and accepted the lava/
> puddle exclusions. See `LAVA-ASSETS-2026-10-03.md`. The water activator and
> visible effect-shader pool are distinct, confirmed objects. The original
> pre-inspection assessment below is retained as historical context.

The user requests investigation during target-four performance testing, then a
lava prototype after that test. Keep the accepted Surface Tides water behavior
as the baseline. Scope is an optional surface-level lava add-on, initially the
Aetherium Forge, with distinct motion and improved materials.

## Assessment

A surface simulation is feasible in principle. Reuse ST's grid, bounded updates,
contact impulses, masking, displacement and lifecycle patterns. Actual integration
depends on the Forge's winning records and NIF shader properties, which have not
been supplied or inspected. Water-like damage/immersion behavior does not prove
that the visible lava uses BSWaterShader. Do not hardcode guessed record IDs or
identify lava solely from the cause-damage water flag.

The public CommonLib TESWaterForm model exposes a water material, damage flag,
contact spell and linear/angular velocity. These can assist identification when
a real water form is involved; they do not establish which forms the Forge uses.

ST currently stores surface height and vertical velocity and evolves a dispersive
wave equation with damping. Slower, strongly damped disturbances provide a useful
first approximation, but do not constitute physical viscosity or advected molten
flow. A lava-specific extension could add viscosity-like spatial velocity
smoothing and horizontal transport for crust/heat. Stability and timestep limits
must be checked for any added diffusion. Local upwelling/bubble impulses and
gentle circulation are more suitable default forcing than water's wind waves.
Temperature-dependent viscosity and a drifting/cracking crust are later layers,
not prerequisites for the first moving surface. A height field suits pools;
falling columns, overhangs and arbitrary three-dimensional lava flow need separate
geometry/animation treatment.

## Rendering and material options

Use an opaque molten/crust surface with base color, normals, roughness and
emissive masks, optionally height relief. Hot cracks can glow while cooler crust
is rougher and darker. Screen bloom/emission and lighting the surrounding room
are separate capabilities; do not promise automatic environmental illumination
merely from an emissive texture.

OS 2.13 TruePBR hooks the lighting-material/property path and binds dedicated
material textures, including emissive and displacement textures. Its native
Water shader instead binds reflection/refraction, normals, depth, flowmaps and
SSR textures. Therefore TruePBR textures cannot be assumed to work by assigning
them to a water/effect texture slot. Possible implementations are a reviewed lava
mesh/material conversion using the renderer's supported material path, or a
dedicated lava shader that interprets the selected texture maps. Inspection of
the actual pool NIF/draw determines which is practical. Complex Material and
OS PBR compatibility require renderer-specific integration and validation; a
shared simulation and modular material backends keep the add-on separate.
No ENB code, shaders, SDK or bytecode were consulted.

## Public evidence examined

- OS v2.13.0 `src/TruePBR.cpp` and `.h`, downloaded from
  https://github.com/alandtse/open-shaders/tree/v2.13.0/src
  (lighting-property hooks, diffuse/normal/RMAOS validation, emission/displacement).
- OS v2.13.0 `package/Shaders/Water.hlsl`, previously retrieved and verified for
  the native integration, especially its declared texture resources:
  https://github.com/alandtse/open-shaders/blob/v2.13.0/package/Shaders/Water.hlsl
- Jebbalon's Lava Column Correction author description identifies the Forge
  column as a two-layer mesh, with an alpha-cut outer layer revealing the inner:
  https://www.nexusmods.com/skyrimspecialedition/mods/22050
- Rally's Lava author reply on April 13, 2020 identifies the examined falling
  column mesh as using an FX shader:
  https://www.nexusmods.com/skyrimspecialedition/mods/34695?tab=posts
- HD Lava for Dawnguard author identifies a lava-shader texture used primarily
  at the Forge: https://www.nexusmods.com/skyrimspecialedition/mods/7285

These author reports are evidence about those assets, not verification of the
user's current winning pool mesh or a universal claim about all Skyrim lava.
No third-party lava mesh or texture has been downloaded, copied or redistributed.

## Next prototype steps after target four

1. Inspect the Forge lava reference/base records, any water type, and the winning
   lava pool NIF and texture paths. One representative pool is sufficient to
   choose the first rendering path; inspect the falling column separately.
2. Establish a lava-only selector and a reversible, isolated displaced surface.
3. Tune sluggish disturbances and local forcing, then add viscosity/transport
   where the visual target requires it.
4. Add rough crust, hot emission and texture detail, starting with one material
   backend before claiming Complex Material/PBR parity.
5. Validate seams, lighting, streaming, temporal rendering and clean removal,
   with ordinary ST water running alongside it.

No lava prototype is packaged at this checkpoint. The needed next evidence is
the actual lava pool NIF(s) and an xEdit record view/export showing which forms
the Forge references, including any WATR assignment.
