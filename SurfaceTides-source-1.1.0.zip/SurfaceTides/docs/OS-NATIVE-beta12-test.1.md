# Native Open Shaders Water — Beta 12 test 1

Status: compiled candidate; in-game result pending. Skyrim 1.6.1170 / GOG 1.6.1179 only in this test overlay.

## Setup

Install this DLL overlay after the accepted Beta 12 OS state/toggle build. It does not replace your INI or any shader files. Keep the existing complete ST shader directory.

In `Data/SKSE/Plugins/SurfaceTides.ini`, under `[Compatibility]`, use:

```ini
OpenShaders=1
OSNativeWater=1
```

In OS, turn **Replace Original Shaders → Water ON** and save. Leave Water Effects and Unified Water enabled if desired; OS chooses the native shader's feature definitions. The ST `OSWaterEffects`/`OSUnifiedWater` switches govern only the older adapter, so do not need to mirror OS in this new mode.

Keep **CS Utility → water → Wave Amplitude = 1** for this comparison. The previously returned value 0 flattens native OS water normals independently of ST.

For the first run with this DLL installed, request one OS shader-cache rebuild through OS's menu (Water only if offered; otherwise the normal shader-cache clear/recompile). Let compilation complete; restart if OS requests it. ST learns each original OS water shader during that compilation and keeps its own cache. A later OS feature/shader update naturally provides new recipes when OS recompiles. If ST's private cache is deliberately removed while OS's cache is retained, repeat this learning rebuild. This is an initial setup requirement, not an uninstall step.

## Test

Check wakes/displacement with ST on, the in-game ST off/on toggle, and one restart with ST removed. Water should retain OS's appearance when ST is off or absent. Include `SurfaceTides.log` and the OS log with the result; the ST log records recipe capture/cache use, successful native augmented draws, and reasons a shader was left native. A short same-view toggle clip is useful if appearance changes unexpectedly.

Keep frame-generation/motion settings as in the accepted setup. The accepted scene-motion suppression remains available for the displaced stencil pass.

## Removal and fallback

Remove or disable ST and all its test overlays through the mod manager, then restart Skyrim. Leave OS Water ON. This candidate never writes OS settings, installed OS shader files, OS's compiled shader cache, or save records. No OS preset reinstall or OS cache deletion should be needed to remove its rendering changes. ST's private `%LOCALAPPDATA%/SurfaceTides/ShaderCache/NativeOS-v1` files can be left behind: OS never reads them; deleting them is optional housekeeping.

For the accepted ST adapter instead, set `OSNativeWater=0`, restore OS Water OFF, and restart. The original WaterEffects/UnifiedWater adapter flags then apply again. The previous accepted DLL overlay is also retained as a separate checkpoint.

## Implementation and boundaries

The Microsoft compiler observer returns OS's original result and bytecode unchanged. It separately preprocesses the exact OS water source with the actual compile macros/includes, records the original-bytecode digest, and builds ST-owned shaders. Only original shader objects whose bytecode matches a captured recipe receive ST identity metadata. No shader is identified by geometry scope, filename alone at draw time, or guessed renderer offsets.

The augmented VS/HS/DS add field displacement, tessellation, original surface height and displacement history. The PS adds field normals before OS's lighting/reflection/refraction calculations, retaining native water controls and compiled feature branches. All altered draw bindings, including additional OS hull/domain constants and the optional motion-write mask, are restored after the draw. Inactive ST uses the original OS pipeline directly.

Native LOD and the separate underwater mask shader stay untouched. Main surface, wading, simple, underwater-view and stencil variants are eligible. Unsupported source/input/resource contracts retain the original OS draw and log the failure. VR is excluded. Runtime feature/device/hook behavior, visual parity, removal, and performance still require the user's game test; secondary DXC validation is not Windows D3DCompiler/SM5 execution.

The accepted continuous-wind optimization, discovery implementation (still default-off), solver, field coverage, actor/water retention, ENB path and existing HLSL files are retained. No FOMOD or release baseline is changed by this test overlay.

## Build evidence

AE16 Windows x64 MSVC-ABI DLL builds and passes PE/SKSE metadata checks. All 13 portable suites pass; 120 secondary DXC shader checks pass across eight water variants and three feature combinations. The runtime still compiles with Windows D3DCompiler/SM5, which has not been executed in this Linux build environment. Test results and source provenance are in `beta12-os-native.1-evidence/`. The native path retains the accepted 1..64 tessellation range and edge/interior subdivision policy.
