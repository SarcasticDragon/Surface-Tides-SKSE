# Accepted return

The user has accepted this fix. The new log confirms stable pond height and epoch while dry, with the lower actor fallback rejected in favor of retained water. See [acceptance evidence](POND-beta11-ACCEPTED.md). The candidate instructions below are historical; the accepted implementation is preserved in the subsequent performance test.

## Original test notes

# Deep Folk Crossing pond — beta.11-pond-test.1

Status: test candidate, not accepted. The complete Beta 11 FOMOD contains the accepted ripple fix without this experiment. The AE16 overlay supports Skyrim 1.6.1170/1.6.1179 only and replaces SKSE/Plugins/SurfaceTides.dll; it preserves the winning INI and all shaders. It can test either the existing ENB or OS configuration. Disable previous DLL overlays, place this above Beta 11 and restart. The log must identify 1.1.0-beta.11-pond-test.1. Disable the overlay to return to Beta 11.

## Evidence and cause being tested

SurfaceTides(20260930-224230).log initially records the northern test, then travel to the pond. At 16:40:00 the pond level is -5327.14 (epoch 4). Epochs increase to 6, 8 and 10 during short bank crossings, then to 13 at 16:40:25, when the selected height is -5616 and the wet field is empty. There is no intervening inactive event at those bank crossings. The supplied 2026-09-30 16-40-09.mp4 shows repeated short entry/exit movements, matching the reported surface/reflection change. The five-second stats do not expose every intermediate height transition, so the candidate adds bounded transition logging.

The original Ragged Flagon retention handles a missing actor water cache, but any valid actor height currently takes priority. The vendored GetWaterHeight implementation can return the parent cell's exterior water height when its actor cache is absent. A lower but valid dry-bank fallback therefore replaces the verified pond and resets the solver. This is a shared game-side selection issue and can affect ENB and OS.

## Candidate behavior

An immersed actor still selects its current water body immediately. A dry actor first retains the nearby, revalidated wet anchor instead of replacing it with another valid fallback height. Entering another verified water body, changing world/interior, leaving the local radius, a detached/invalid anchor or an explicit reset releases the old selection. Exterior anchors additionally require terrain below the queried water height, matching the existing terrain mask rule; interior queries are unchanged. Contact generation uses actual actor heights and no dry contacts are fabricated. Solver, rendering, shaders, cache and INI values are unchanged.

Portable regression tests cover the reported -5327.14/-5616 values, repeated dry fallback changes, missing caches, range/area invalidation, entering another body, buried exterior fallbacks and continued decay of existing wakes after contacts end. Engine water/land queries and the visual result still require the game test. This is not claimed as a confirmed fix.

## Focused test

Use the same pond and current ENB settings. Walk in to create displacement, step onto the same bank, wait several seconds, then reenter. The existing waves should continue and decay without an abrupt surface snap. Repeat with OS when convenient. Send the new SurfaceTides.log and a short clip; no diagnostic colors or additional setting changes are required. A short visit to another water level helps check that entering new water still selects it. Regular LogStats=1 captures the new bounded level-transition rows and source=retained summaries.

The DLL's packed revision remains 15 because this metadata field has only four bits; use the full display label and checksum to distinguish it from accepted Beta 11. No save data is added.
