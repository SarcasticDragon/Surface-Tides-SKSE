# Accepted ENB ripple coverage — Beta 11

The user confirms that coverage.2 fixes both ripple clipping and the mid-distance water defect: everything looks good. The planned Beta 2 is renamed Beta 11 to match the author's local labeling. Preserve the released Beta 1 FOMOD and the existing camera correction. Earlier underwater defects remain absent; color investigation remains parked.

Returned evidence: SurfaceTides(20260930-223045).log, SurfaceTides(20260930-224230).log, and 2026-09-30 16-26-52.mp4. Both logs identify 1.1.0-beta.2-ripple-coverage.2 on Skyrim 1.6.1170. Coverage marking is active rather than falling through the old RGBA-only guard. The first log totals 75,035 matched base draws, 7,842 marked draws and six fallbacks; the second totals 10,401 matches, 1,601 marks and two fallbacks. Both report zero coverage-state creation failures, zero wading-depth creation failures and zero mesh preparation failures. No warnings/errors/critical entries were found. These counters support the visual acceptance; they do not establish every runtime or preset.

Beta 11 changes the version/status labels and packaging, not the accepted rendering algorithm, simulation, HLSL, OS adapter or caching code. Ten portable suites and three runtime builds validate the promotion. The new dry-bank experiment remains separate so the accepted installer is reproducible.

No ENB implementation source, shaders, bytecode or SDK were accessed. All prior constraints remain in force.
