# Surface Tides: nearby-water discovery test 1

Version: `1.1.0-beta.12-water-discovery.1` (SKSE version `1.1.1.3`).
Windows x64: Skyrim 1.6.1170 and GOG 1.6.1179 (AE16).
Development checkpoint based on public Beta 11; in-game acceptance pending.

## Installation and test

Install the test archive over public Beta 11, with this archive winning the
`SKSE/Plugins/SurfaceTides.dll` conflict. Disable previous DLL test overlays,
including the lava prototype, for this ordinary-water test. Keep your INI and
the installed Beta 11 shaders. No shader-cache rebuild is needed for this change.

Load or approach a new stretch of river while remaining on the bank. Allow a
few seconds for bounded discovery and the normal terrain-mask refresh. Ambient
waves should start without stepping into the water. Continue along the bank
beyond the original simulation footprint, then enter and leave the water to
check that wakes still work and persist. Return the SurfaceTides log if water
still requires contact to activate. Disable this test overlay to return to
public Beta 11.

## Diagnosis

The supplied 2026-10-05 log records five `water-selection-unavailable`
transitions with `spatialQuery=water-below-ground`, while preview remains on.
The first occurs at 23:02:33.709, approximately 1,733 units from the established
wet anchor, just beyond the 1,728-unit retention radius. A subsequent player
entry re-establishes the water surface. Another activation uses a spatial query
while above water: physical immersion is not required if the queried XY point
already covers exposed water.

The old selector sampled only the player's XY and a retained wet point. A dry
bank could therefore provide neither an initial anchor nor a replacement after
the old point left range. The renderer correctly passed through native water
while the simulation was inactive.

## Changes

- Discover nearby exposed water through the existing attached-cell, same-world
  and terrain-validation query. Store only verified coordinates and height.
- Search in concentric rings, at most eight additional engine queries per game
  update. Preserve progress while inactive. The full outer scan takes up to
  136 updates at a stationary position; very small pools between samples may
  still require approaching closer. At the default field size, ring spacing is
  108 world units.
- When the retained point becomes distant, look for a closer point at the same
  water level before it leaves range. First test the previous wet offset at the
  player's new position, then use the bounded search if necessary. Every proposed
  point is revalidated; retain the original point while searching.
- Preserve immersed-player priority, wet-point revalidation, and the safeguards
  against buried exterior fallback heights and unrelated water levels.
- Log activation source (`nearby`, `spatial`, or `actor`) and add a
  `waterSelection` CPU timing section to existing performance diagnostics.

The simulation size, solver, rendering integrations, shader caching, shader
sources, and lava/puddle exclusions are unchanged. This checkpoint contains no
lava prototype. The public Beta 11 installer and source release remain intact.

Validation passed: 20 water-selection regression groups, all 14 portable test
suites, and the AE16 Windows build/PE runtime declaration. Skyrim execution
remains the tester's check. The archive includes only the DLL and documentation.
