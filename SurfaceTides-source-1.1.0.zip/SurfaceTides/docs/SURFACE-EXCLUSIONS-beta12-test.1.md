# Beta 12 surface exclusions test 1

> Accepted by the user on October 3, 2026. The return log confirms the targeted
> exclusions. See `LAVA-ASSETS-2026-10-03.md` for acceptance and the now-inspected
> asset structure. The candidate description below is preserved as history.

Version: `1.1.0-beta.12-surface-exclusions-test.1`. DLL-only AE16 overlay for
Skyrim 1.6.1170 / GOG 1.6.1179. Packed SKSE revision remains 15; the display
label and binary hash distinguish this candidate. No new INI is required.

## Evidence and scope

The user's two Forge clips show ST waves above the lava appearance and a
decorative puddle with displaced, smeared refraction. The console identifies:

| Object | Defining file / local base ID | Reference observed | Model shown |
| --- | --- | --- | --- |
| WaterPuddle | Skyrim.esm / 0x9727E | Dawnguard.esm / 0x09D46 | Not expanded in clip |
| Lava1024 | Dawnguard.esm / 0x14B85 | Dawnguard.esm / 0x15C60 | Water1024.nif |
| DweSpecialForgeLava01 | Dawnguard.esm / 0x14FD1 | Dawnguard.esm / 0x14FD3 | DweSpecialForgeLava01.nif |

The puddle base is last overridden by Water for ENB (Shades of Skyrim).esp in
the console. Both lava bases are shown as originating in Dawnguard.esm. These
are two separate objects at the lava pool; their exact rendering/material
relationship still needs the winning assets. No NIF bytes were supplied or
inspected. The matching ST log confirms simulation in cell 02005734, including
water level -2 near the pool, with no logged native augmentation failures or
rejected draws. The old log does not identify per-draw owning forms.

Vertical lava is out of scope. No inference is made from danger flags, damage
spells, water color, the cell as a whole, or a generic Water1024 filename.

## Change

- At data load, resolve the three exact bases by defining plugin and local ID.
  Preserve overrides and load-order independence. Read Lava1024's effective
  water type; other activators using that exact type also classify as lava.
- During the existing water geometry setup hook, read the geometry's owning
  reference (including the engine scene parent chain). Capture only the resulting
  surface kind for the draw. Exact identity with the known lava water shader
  material is a fallback for generated geometry lacking an owner. No material
  pointer, streamed reference or geometry pointer is cached for this decision.
- A classified lava or WaterPuddle draw goes straight to the original D3D
  draw before any ST shader replacement, tessellation, scene-motion override
  or ENB mesh-input preparation. The same policy applies to color and stencil
  setup scopes. It suppresses ST augmentation, not the object or native effect.
- Forwarded draws carry their own classification. Setup, restore, frame
  boundaries, ClearState and ExecuteCommandList clear the existing geometry
  hint as before. Unknown geometry remains eligible for the accepted bound-
  shader path; the old positive geometry-scope gate is not reinstated.
- Lava and decorative puddles have distinct classifications. A future addon
  can route lava to its own physics/material implementation while puddles
  remain excluded. There is intentionally no switch to turn unfinished lava
  support on in this candidate, and no lava simulation/addon is implemented yet.

No changes to simulation physics, selection/retention, field reach, shaders,
OS source/settings/cache, mesh files, ESPs or saved-game data. Global simulation
may still run near excluded surfaces; this patch excludes their rendered draws.
Other unreviewed puddle bases and unrelated custom lava types are not guessed.

## Test

Install this overlay after the working Beta 12 files, replacing the previous
native-OS-test-2 DLL overlay. Keep the working INI, `OSNativeWater=1`, OS Water
replacement ON, and `OptimizeDiscovery=1`. Restart. No shader-cache rebuild
or deletion is required; augmented shader source and private-cache keys did
not change.

Check the same Forge pool and puddle, then ordinary river/lake water. Expected:
the two excluded surfaces retain native appearance while river/lake waves and
wakes remain available. Return the new log, especially if either exclusion
does not engage. It logs the resolved base/water IDs and winning model paths,
the first four matched scopes per kind, and periodic `ST surface exclusions`
draw counts. `unownedScopes` is diagnostic, not an error by itself. Runtime
confirmation is necessary because the previous log lacks ownership metadata.

Rollback: restore the accepted native-OS-test-2 DLL. No preset repair or INI
change is involved.

For the future lava addon, the winning model paths printed by this build and
the ACTI/WATR record view are the next useful evidence. The pool's ordinary
Water1024 plane and separate DweSpecialForgeLava01 model both matter; a search
restricted to lava-named files cannot find the shared plane.

## Validation

AE16 Windows cross-build and PE/runtime declarations checked. Fourteen portable
test suites pass, including new cases covering known/unknown identity, absent
DLC, load-order isolation, shared ordinary-water geometry, and forwarded-draw
classification. The unchanged shader sources need no new shader compilation
matrix for this CPU-side exclusion. Existing ENB-owned implementation, shaders,
SDK and bytecode were not consulted. In-game visual acceptance is pending.
