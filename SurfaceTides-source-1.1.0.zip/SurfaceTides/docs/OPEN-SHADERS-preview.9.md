# Surface Tides 1.1.0-os-preview.9 — shader cache and prewarming

2026-09-26. This candidate targets the first-use water shader compilation stalls
found in the returned preview.8 comparison. Performance benefit and native game
behavior still require testing. Preview.7 remains the accepted visual baseline.

## Install and test

Install the ZIP matching your Skyrim executable after the working Surface Tides
installation. It contains the DLL, the same seven shaders, and documentation.
The overlay preserves your INI and OS settings. Keep the working WaterEffects,
Unified Water, motion-preservation, FG, water displacement and other settings.
Keep OS's Water shader replacement off, as in the accepted setup.

Both new settings default to 1 when missing, so the first test needs no INI edit:

```ini
[Performance]
ShaderCache=1
PrewarmShaders=1
```

If adding them manually, use the existing Performance section in the winning
`Data/SKSE/Plugins/SurfaceTides.ini`; preserve the other sections and keys.
These settings require a full game restart. Keep OptimizeRenderer at the same
value for both runs. Leave PerformanceTimings=1 and LogStats=1 for this test.

1. Launch, load the usual save, and follow the test route. A cold cache can make
   the initial load or first water encounter pause longer while prewarming runs.
   Record from before loading if practical. Include wakes/wading, underwater,
   distant water and a transition. Continue at least five seconds after reaching
   the last new area so the learned variant list can be saved. Copy
   SurfaceTides.log and CommunityShaders.log before another launch replaces them.
2. Fully exit and relaunch with the same files, settings and save. Repeat the
   same route and recording. Keep the cache between runs. Send both logs/clips,
   labelled first launch and second launch, and note any remaining stalls or
   VRAM change. Do not clear OS's shader cache for this comparison.

The second run is the key check: known water stages should report cache hits
with coldStages=0. New variants or changed shader files may still compile. This
targets compilation stalls, not steady-state solver cost or every frame-time
spike. Driver shader creation and OS's own compilation can still cost time.

## Controls and rollback

| ShaderCache | PrewarmShaders | Behavior after restart |
| --- | --- | --- |
| 1 | 1 | Persistent cache plus early preparation of known/learned water pairs; default test |
| 1 | 0 | Persistent cache; prepare each pair when first drawn |
| 0 | 1 | Ordinary compilation with the fixed seed prewarm list; disk history is disabled |
| 0 | 0 | Preview.8's on-demand compilation behavior, with the new diagnostic lines |

OptimizeRenderer remains an independent CPU-path comparison switch. Setting it
to 0 does not disable caching or prewarming. Restore the prior preview.8 overlay
for a full binary rollback. Existing preview.7 packages remain the visual baseline.

Cache location: `%LOCALAPPDATA%\SurfaceTides\ShaderCache\v1`. These are disposable
Surface Tides files, separate from OS's cache and game saves. If deliberately
starting a fresh-cache test, close Skyrim and remove only this ST cache folder.
Ordinary updates do not require deleting it: content changes produce new keys.
Restart Skyrim after replacing shader files; inputs are frozen for the session.

## What changed

Water shader stage bytecode is saved after a successful ordinary D3DCompile call.
Its key includes the loaded d3dcompiler_47.dll content hash, runtime/feature mode,
source-tree content, root source, ordered macro definitions, compiler flags,
target profile and both generated native constant-layout headers. Source files
come from the existing include resolver; no compiler preprocessing step or HLSL
change is introduced. Cache hits still go through reflection, the existing input
signature/constant-buffer checks and normal D3D11 shader creation.

The source snapshot covers Data/Shaders/SurfaceTides and, when OS is selected,
Data/Shaders/Common and Data/Shaders/WaterEffects. All files in these roots are
fingerprinted conservatively, even if inactive in a particular stage. Snapshot
limits are 32 MiB and 2048 files. An unrecognized compiler, unavailable directory,
oversized snapshot or include outside that snapshot bypasses persistent caching
and retains ordinary compilation. No renderer DLL is inspected or fingerprinted.

Cache entries have a versioned header, exact length/key checks and a payload
SHA-256 checksum, followed by D3D reflection validation. Invalid entries compile
again. Writes use a temporary file and atomic replacement. At startup, completed
ST bytecode entries are pruned toward 96 MiB/384 files; new writes stop at
128 MiB/512 entries per process. Each stage is limited to 8 MiB. These limits do
not cover small history files or temporary files left by an interrupted process.
No OS shader files or caches are modified. Cache failures are logged.

Prewarming runs once, synchronously, at the first eligible active water draw,
before replacement bindings. This usually occurs while loading but is not a
loading-screen guarantee: entering water later can trigger that initial pause.
It creates the normal shader bundles from current native metadata for 11 pairs
observed in the supplied logs, including 3002, 015E and 071E. It adds recently
learned pairs up to a total of 32; unavailable native records and LOD are skipped.
No new metadata is invented, no D3D context binding is changed by prewarming,
and a failed speculative preparation can retry on a real draw.

Successfully prepared pairs encountered by real draws are learned, with up to
32 IDs stored per runtime/feature mode. A dirty history is flushed at most once
every five seconds. Unseen variants continue to compile on demand. The private
disk cache stores bytecode, not textures; prewarming does create a bounded set of
shader objects earlier in the process. Its actual memory/performance impact
requires measurement. Mesh preparation remains on its existing compiler path.

The solver, all seven shader files, hooks, motion-preservation implementation,
WaterEffects/Unified Water behavior and object effects are unchanged. Regular
CS remains unsupported. Color, full ENB integration and solver optimization are
deferred. No ENB source/code was obtained or used.

## Reading the logs

| Line/field | Meaning |
| --- | --- |
| Shaders: ShaderCache / PrewarmShaders | Effective startup settings |
| Shader cache ready / unavailable / bypass | Private cache initialization and any fallback reason |
| Shader prewarm begin / complete | One early batch; prepared, missing, failed and elapsed time |
| Shader build: phase=prewarm or phase=draw | Why a water bundle was prepared; no per-frame build logging |
| cacheHits / coldStages | Stage bytecode loads versus actual D3DCompile attempts in this bundle |
| compilerMs | Time inside D3DCompile, including failed attempts |
| elapsedMs | Whole bundle preparation, including I/O, reflection and shader creation |
| Shader cache totals | Session totals, including prewarm and failed attempts; shown with LogStats=1 |
| coldDrawBundles | Bundles that invoked D3DCompile on demand, outside the prewarm batch |

A pair can have several stages and reference-layout probes, so stage counts are
not numbers of water materials or frames. The older `ST CPU render compile`
scope now measures bundle preparation on both hits and misses; use coldStages
and compilerMs to identify actual compilation. Prewarm start/end times include
more than compiler time. Missing/failing speculative variants alone do not prove
a failed real draw; retain the existing draw/OS counters when checking behavior.

## Validation and reproduction

Eight portable test suites pass, including SHA-256 known vectors, all cache-key
inputs, corruption/truncation rejection and bounded learned prewarm selection.
Windows x64 MSVC-ABI Release DLLs are built for SE 1.5.97, AE16 1.6.1170/1.6.1179
and AE17 1.7.104. Packaging verifies their PE exports, runtime metadata and
version, preserves every baseline source file, and compares all seven shaders
byte-for-byte. No native Windows/D3D11 or Skyrim execution is available here.
Prior shader validation is retained because the HLSL and cold compiler inputs
are unchanged. See os-preview.9-validation.json and os-preview.9-evidence in the
source archive for build logs and provenance.

Build using the existing cmake/windows-clang.cmake toolchain with ST_RUNTIME set
to AE16, SE or AE17 and ST_BUILD_PLUGIN=ON. For portable tests use
ST_BUILD_PLUGIN=OFF, ST_BUILD_SHADER_TESTS=OFF and ST_BUILD_TESTS=ON, then CTest.
Package with tools/package_os_shader_preview9.py, supplying --baseline-source
(the complete preview.8 source ZIP), --build-root (ae16/se/ae17 subdirectories)
and --output-dir outside the source tree.

The compiler call follows Microsoft's D3DCompile API:
https://learn.microsoft.com/en-us/windows/win32/api/d3dcompiler/nf-d3dcompiler-d3dcompile
