# Surface Tides 1.1.0 FOMOD authoring

Display version `1.1.0`, machine version `1.1.0.0`. This release promotes the
accepted public Beta 11 water baseline plus the accepted nearby-water discovery
fix. The separate lava prototype is not a build or packaging input.

## Structure

- Exact-runtime DLLs: AE16 (1.6.1170/1.6.1179), SE (1.5.97), AE17 (1.7.104).
- Renderer choices: Open Shaders, ENB and Vanilla. ENB has a conditional page
  offering native integration or water-off coexistence.
- Four renderer configurations, four foam choices, two ice-decal choices and
  two bobbing choices produce 192 installer selections and 32 complete INIs.
- Five pages, seven groups and 36 conditional file patterns. Each selection
  installs exactly one runtime DLL and complete INI.
- Default choices remain AE16, Vanilla, authored foam/ice and static floes.
  Native integration is recommended on the ENB page. OS selects native water
  with OpenShaders=1 and OSNativeWater=1; legacy adapter feature flags remain 0.
- Accepted fixes, all three optimizations, caching/prewarming and LogStats are
  enabled. PerformanceTimings, detailed traces and diagnostic colors are off.

Only seven ordinary-water ST shader/include files are shipped. No lava addon,
OS/ENB configuration override, game asset, ESP or cache is included. Standalone
foam removal adds its reviewed BOS preset. Licensing notices are installed.

## Reproduce

Build each runtime using CMake and the bundled dependencies, selecting
`ST_RUNTIME=AE16`, `SE` or `AE17`. Use `cmake/windows-clang.cmake` with clang-cl,
lld-link, llvm-lib, llvm-rc and an MSVC CRT/Windows SDK sysroot, or a compatible
native Windows MSVC toolchain. Build portable tests separately with
`ST_BUILD_PLUGIN=OFF`, `ST_BUILD_TESTS=ON`, `ST_BUILD_SHADER_TESTS=OFF`; run CTest.

Run `tools/package_release_110.py` with `--baseline-source` pointing to the
pinned accepted water-discovery source ZIP, `--previous-fomod` pointing to the
public Beta 11 FOMOD ZIP, `--dll-dir` containing AE16/SE/AE17 build directories,
and `--output-dir` outside the source tree. It requires completed build and
portable evidence in `docs/release-1.1.0-evidence`. The script rejects unrelated
implementation/vendor/shader changes and lava payloads, generates installer
XML/INIs, checks all selections and writes the FOMOD and full source archive.

See `release-1.1.0-validation.json` and `release-1.1.0-evidence` for the audit,
builds, portable tests and installer validation. Native game execution and
mod-manager UI interaction are not performed by the automated checks. Historical
packaging scripts retain their original version-specific assumptions and are
not the recipe for this final release.
