# Surface Tides 1.1.0-os-preview.4 — draw-dispatch recovery

Latest result, 2026-09-24: the user reports that switching frame generation off substantially removes the jitter. The matching 022230 SurfaceTides log confirms active rendering and uploads through sequence 1549; the paired OS log lacks the FG proxy startup message while still creating an FSR3 context. This isolates a frame-generation-path interaction, not a completed fix. See [the current FG investigation](OS-FRAMEGEN-2026-09-24.md). The minor residual mace ghosting is deferred; no shader/DLL change is shipped here.

Update 2026-09-24: the user confirms wakes have returned after correcting the active INI. The matching 013103 log has working color passes, targetMask/entryMask=7F and uploadedSeq advancing to 637, with no failed draws. It contains no dispatch-recovery event, so this run confirms working rendering without independently exercising an address transition. Jitter persists. Color investigation is now parked by agreement; follow [the current roadmap](OS-ROADMAP-2026-09-24.md).

2026-09-23. DLL recovery candidate for the loss of water rendering reported
with reflection probe 3. Color and mace-edge jitter are still unresolved.

## Install

Disable color-test.2, refraction-control.2 and reflection-probe.3 overlays.
Install the preview.4 package matching the Skyrim executable after preview.3
and earlier shader hotfixes. Its DLL and complete SurfaceTides shader directory
must win. Leave Diagnostic water colors unchecked and restart Skyrim.
Keep the working INI and OS water settings; this package supplies no active INI
or OS JSON. Confirm `1.1.0-os-preview.4` in the new SurfaceTides.log.

This run restores the normal color-test.2 shader baseline, which compiled and
rendered in the earlier returned tests. It has no diagnostic screen dividers.
First check that wakes and surface displacement return, then send the log.
Expected recovery evidence is `OS draw dispatch recovered` if methods change,
followed by compiled/bound color passes such as 031E/035E, advancing uploadedSeq,
and hook targetMask/entryMask values of 7F. If no transition occurs, the recovery
line is not expected. No cache deletion or save cleanup is required.

## What the returned run establishes

SurfaceTides(20260923-232107).log shows one initial bound/tessellated 5000 stencil
draw. No water color pass is subsequently identified or compiled. No HLSL error
or reported failed replacement draw explains this absence.

Every later hook-health sample has targetMask=00, entryMask=7F and
immediateContextSame=true: all seven current public draw-method addresses differ
from those hooked at startup, while the old detour entry bytes are intact and
the immediate-context object is unchanged. Rendered/uploadedSeq remains 1 while
the CPU simulation sequence and wake impulses advance. Thus the simulation is
running, but the relevant draws are bypassing the registered entry points.
The old plugin reports the mismatch but never recovers it.

This identifies a renderer-hook coverage gap. It does not establish which
runtime component changed the table, or that editing a shader caused it.
Reflection probe 3 was not exercised on a color pass in this run; its visual
result remains unknown. This is different from the earlier FXC macro failure.

Current SettingsUser(1).json has Water replacement false and UnifiedWater/
WaterEffects disabled at boot. The OS log agrees with those disabled features
and reports FSR3 context creation. Those facts do not establish upscaling as
the cause of the hook transition or the earlier jitter. Linear lighting is off;
post-processing/tonemapping is enabled. No preset settings are changed here.

## Implementation

At each game Present boundary, the explicit Open Shaders path checks the seven
current draw-method addresses. Newly observed executable targets receive
MinHook detours with their own permanent trampoline indices. Earlier targets
remain registered, allowing dispatch to alternate without redirecting an older
hook through a newer method's original function. Existing nested-draw guards,
water identification, argument matching and native draw arguments are retained.
No game offsets, shader-identity guesses or direct vtable replacements are added.

Recovery has a fixed maximum of eight implementations per draw method. Null
targets, cross-method aliases, hook failures or a different immediate-context
object stop OS replacement with an explicit log error. A failed installation
attempt rolls back its own newly created hooks. It does not remove previously
registered entries. Automatic recovery is limited to OpenShaders=1; standalone
and the experimental ENB path retain startup-only registration.

The recovery checks public COM method pointers and executable-page metadata;
it does not inspect OS/ENB shader bytecode or fetch ENB code. The normal shaders,
solver, object behavior and INI defaults are unchanged from source version 5.
The existing source-only ENB EnableWater advisory change is preserved and becomes
compiled in these DLLs; it has no effect on the explicitly selected OS path.

## Validation and limitations

The portable draw-dispatch tests cover all-seven address changes, mixed tables,
return to older implementations, stable trampoline identity, failed-attempt
retry, stale plans, capacity and incompatible method aliases. Existing portable
solver, floe, water-selection and compatibility tests are also run.
The Windows builds and PE checks cover each runtime profile separately.
See os-preview.4-evidence and os-preview.4-validation.json for actual results.

No Skyrim or native GPU execution is available here. Portable registry tests
cannot reproduce D3D11 driver dispatch or prove native hook behavior in game.
The shipped HLSL is unchanged; previous native color-pass compilation evidence
applies to its source, not to this new DLL's runtime behavior. No color, jitter,
performance or broad OS compatibility fix is claimed by this checkpoint.

To roll back, disable preview.4 and the diagnostic overlays, restoring preview.3
with shader hotfix 1. The underlying startup-only hook gap can still recur there.
