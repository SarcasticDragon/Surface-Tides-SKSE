# ENB wading-depth candidate — 1.1.0-beta.1-enb-depth.1

**Promoted to Beta 1:** the complete FOMOD now contains the exact accepted DLLs; a separate test overlay is no longer required. Ripple clipping is a Beta 2 target. Candidate instructions below are historical.

**Returned result, 2026-09-30:** the user confirms the camera shapes are fixed and previous underwater issues are absent in current testing. See [acceptance and remaining ripple issue](ENB-DEPTH-beta.1-ACCEPTED.md). The candidate/test instructions below are retained as historical documentation; the requested test has been completed. The original beta FOMOD has not been replaced.

This is a focused test overlay for the accepted beta.1 installer. The beta FOMOD remains the checkpoint; this candidate is not yet promoted into it. Ripple clipping is recorded as a known ENB integration issue and is outside this change.

## Evidence

The returned `SurfaceTides(20260930-012539).log` selects beta.1's experimental native ENB mesh-input path on Skyrim 1.6.1170. It reports no warnings, preparation failures, mesh-output overflow or rendering suspension. The clip is 9.75 seconds and shows camera-dependent irregular water patches near the shore. The video and log do not establish pixel-level causation or an exact synchronized frame trace.

The startup observation reads saved ENB EnableWater=false, but that is not live ENB state. A few log intervals contain native tessellation patches; do not infer the exact switch times or attribute the whole run to one ENB water setting. The cache counters remain zero because this path uses the separate mesh-input compiler, as documented in beta.1. That is not a recurrence of the compiler-identity/cache defect.

Source review finds a concrete difference from the previously accepted shoreline fix: ST's Water.hlsl outputs comparison depth zero in the primary wading PS015E. The native ENB integration retains downstream shaders and therefore bypasses that correction. Earlier captured wading states were read-only depth, LESS_EQUAL, and selective EQUAL stencil tests. Review of the actual eight saved wading samples finds masks 2, 4 **and 8**, with references 3, 5 and 9; the older prose summary mentioned only 2/4. These are historical captures, not proof of the new ENB run's state.

This makes missing wading-depth handling a specific testable explanation for the returning shapes. It does not establish that every ENB artifact has this cause, and it does not diagnose the deferred clipped ripple.

## Candidate behavior

Only successfully prepared native ENB-integration draws with the exact VS/PS pair 015E/015E are considered. The candidate requires a stencil-capable depth view and the captured state shape:

- Depth enabled, writes disabled, comparison LESS_EQUAL.
- Stencil enabled, read mask 2, 4 or 8, corresponding selected bit present in the current reference.
- Both faces use EQUAL and KEEP for stencil fail, depth fail and pass.

For that one color draw it changes only DepthFunc to ALWAYS, then restores the exact original state and reference through a scoped guard. This tests the same redundant-depth-rejection hypothesis without replacing or inspecting an ENB shader. Native geometry, texture/color calculations, shaders, stencil selection and stored depth/stencil values are retained. Unknown states, absent stencil views, state-cache exhaustion or state-creation failure retain the original behavior.

The variant cache holds original COM references, is limited to 64 states, and avoids repeated state creation. Up to eight distinct initial states are logged. Five-second counters report candidates, applied corrections, native fallbacks and creation failures. `[Experimental] MeshWadingDepth` defaults to 1 even in an existing INI. Setting it to 0 and restarting restores beta.1 depth behavior for comparison. It has no effect in OS, Vanilla or ENB-water-off coexistence mode.

This is a candidate for in-game validation: retaining stencil selection does not independently prove correct occlusion against every rock/actor in every renderer setup. In particular, report any new water drawn over solid objects. No new ENB guard, shader tint, simulation reduction or ripple suppression is introduced.

## Install and return test

Install the matching runtime ZIP **after beta.1**, letting its `SKSE/Plugins/SurfaceTides.dll` win, then restart. The update contains no INI or shader replacement, so it preserves all installer selections and tuning. The supplied log uses 1.6.1170: use the 1.6.1170–1.6.1179 build for that setup. SE 1.5.97 and AE 1.7.104 overlays target their exact runtimes as before.

Keep `ENBWaterIntegration=1` and the same ENB settings used for the artifacting clip. No cache deletion or other settings change is needed. Repeat the camera sweep and check whether the irregular patches are gone/reduced/unchanged, plus whether water appears over the character or shore rocks. Send the ordinary `SurfaceTides.log` and short clip. Existing LogStats=1 captures whether the correction actually applied; no large pass trace is requested.

If it introduces a regression, disable this overlay or set MeshWadingDepth=0 and restart. The original beta.1 FOMOD remains available unchanged. Ripple clipping remains a known issue.

## Validation and scope

Three Windows x64 runtime DLL builds, PE/runtime metadata checks and nine portable suites are recorded in `enb-depth.1-evidence`. The new policy suite checks all byte-sized stencil mask/reference combinations, unrelated shader pairs, depth comparisons/writes, both stencil faces and field preservation. These are host/build checks, not a native D3D draw, mod-manager interaction or Skyrim visual confirmation.

All seven HLSL files, shader caching/prewarming, the solver, OS adapters/motion workaround, hooks, object behavior, renderer selection and the beta FOMOD payload remain unchanged. No ENB implementation, SDK, shader bytecode or source was obtained, inspected or used. SKSE packed build revision is 12; the display version is 1.1.0-beta.1-enb-depth.1.

Public API references: [depth/stencil state binding](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-omsetdepthstencilstate) and [comparison functions](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ne-d3d11-d3d11_comparison_func). The runtime uses public state descriptors; it does not analyze renderer shader implementations.
