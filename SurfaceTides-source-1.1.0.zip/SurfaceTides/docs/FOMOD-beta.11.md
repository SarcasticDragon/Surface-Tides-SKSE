# Public Beta 11 FOMOD authoring

Display version: `1.1.0-beta.11`. Machine version: `1.1.1.1` (patch 1, revision 1).
This public rollup supersedes the earlier ripple-only Beta 11 package. It includes
accepted water work through surface exclusions and deliberately removes the
subsequent lava prototype from this source branch. The prototype's separate
source and test overlay are preserved.

## Installer structure

- Three exact runtime profiles: AE16 (1.6.1170/1.6.1179), SE (1.5.97), AE17 (1.7.104).
- OS, ENB and Vanilla. OS uses native Water replacement ON, without a redundant
  feature-matching page. ENB offers native integration and water-off coexistence.
- Four renderer configurations, four independent foam choices, two ice-decal
  choices and two bobbing choices: **192 selections, 32 full INIs**.
- Five pages, seven groups and 36 conditional file patterns. The ENB page is
  conditional. Exactly one DLL and one complete INI are installed per path.
- Defaults remain AE16/Vanilla, authored foam/ice and static floes. Native ENB
  integration is recommended within ENB. OS automatically sets OpenShaders and
  OSNativeWater to 1; obsolete adapter feature flags stay 0 and are ignored.
- Renderer, wind and discovery optimizations, shader caching/prewarming and
  performance timing are ON. Standard field size/quality are unchanged.

No OS/ENB configuration, renderer shader override, game asset, ESP or cache is
installed. Optional standalone foam supplies only its reviewed BOS preset.
The fresh INI is intentional; users must back up custom tuning before replacing
an old installation. Legacy OS adapter support remains a manual INI option.

## Reproduction and verification

Build all profiles with the bundled dependencies and `cmake/windows-clang.cmake`
(or the supported Windows MSVC setup). The clang toolchain needs clang-cl,
lld-link, llvm-lib and llvm-rc plus a licensed MSVC CRT/Windows SDK sysroot.
The LLVM distribution may require a clang-cl symlink to its clang driver.
Commands, build logs and portable test results are in `beta.11-public-evidence`.

Use `tools/package_beta11_public.py` with `--baseline-source` set to the pinned
prototype-1 source archive, `--previous-fomod` set to the earlier Beta 11 FOMOD,
`--dll-dir` containing AE16/SE/AE17 build subdirectories, and `--output-dir`
outside the source tree. The recipe verifies input hashes, checks the explicit
prototype-removal list, rejects unrelated implementation/vendor/shader changes,
checks the completed builds/tests, regenerates XML, validates every selection,
and writes the installer and matching full source ZIP. `package_beta11.py` is
retained only as the historical recipe for the earlier ripple-only checkpoint.

The validator covers schema, encoding rewrites, visible pages and stale hidden
flags, runtime metadata, INI completeness/options, BOS rules, shaders and notices.
Native manager UI and game execution are not performed here. See
`beta.11-public-validation.json` for the final audit and package hash. The source
includes development history; current public instructions take precedence over
historical test instructions.
