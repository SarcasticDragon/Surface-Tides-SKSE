# Surface Tides preview.8 performance results

The optimized clip has substantial late hitches. The logs show improved CPU
costs for the targeted renderer work, alongside first-use Surface Tides shader
compilation during the optimized recording. This is not a clean measurement of
the optimizations' effect on overall smoothness. Keep preview.8 as a candidate;
do not declare either an FPS improvement or a confirmed regression from these runs.

## Confirmed configuration and operation

Both logs load 1.1.0-os-preview.8-performance on Skyrim 1.6.1170. The requested
OptimizeRenderer modes are correct and PerformanceTimings is on in both. Logged
wind, displacement, normal strength, tessellation and interaction settings match.
Open Shaders, WaterEffects, Unified Water and scene-motion preservation are
selected in both. No OS startup log was supplied for these runs, so this does not
independently establish every OS setting or background task was identical.

Reported bound draws: 3,032,320 optimized and 1,606,195 reference; the runs have
different lengths, so these are coverage counts, not comparative performance.
Both report zero ST draw failures, WaterEffects compilation fallbacks,
motion-target mismatches/failures and sampled post-draw binding mismatches.
Optimized indexing reports 20 checks: one rebuild and 19 unchanged checks,
with generation remaining 1. Reference indexing reports 13 checks and 13 rebuilds.

## The major hitch finding

MP4 creation timestamps correspond to local starts of approximately 01:45:10
for optimized.mp4 (23.800 seconds) and 01:51:55 for not optimized.mp4 (13.183
seconds). Timestamps are second-resolution and not a frame-accurate synchronization
signal. The videos contain matching near-static starts and ends; these should
not automatically be counted as gameplay stalls.

The optimized log records these additional first-use water permutations during
its recording:

| Completion time | VS/PS descriptor | Compile scope wall time |
| --- | --- | ---: |
| 01:45:26.061 | 3002 / 3002 | 219.742 ms |
| 01:45:26.459 | 15E / 15E | approximately 362.129 ms |
| 01:45:29.524 | 71E / 71E | approximately 570.011 ms |

The last two timings are inferred from the shared two-event report: 932.140 ms
total and 570.011 ms maximum. Log spacing establishes that the earlier event is
the shorter one. All three together occupy approximately 1.152 seconds of
synchronous compile-scope CPU wall time. This scope includes the permutation's
compilation/creation work; it is not a measurement of GPU execution time.

The reference run compiled 3002 and 15E at 01:51:32, before its recording, and
never logs 71E. Its last ST compile finishes at 01:51:32.720, about 22 seconds
before recording. Thus it has no ST compile event during its supplied clip.
Each logged descriptor pair is unique within its run; there is no sign here of
recompiling the same pair repeatedly due to a broken new cache key.

Scene-only freeze detection (excluding the overlay, downsampled, mean change
threshold -50 dB, minimum 100 ms) finds long near-static intervals around
15.4–16.4 and 17.8–19.1 seconds in the optimized clip. This agrees broadly with
the compile timestamps. It establishes a strong contributor to those hitches,
not proof that compilation explains every stall. The reference clip has one
approximately 117 ms detected interval during its moving section. This detector
measures repeated/near-identical recorded imagery, not native or generated FPS.

The earlier September 24 recording had no nearby ST compile events. These new
results change the priority: compile stalls are now directly evidenced during
gameplay, even after an initial warm-up.

## Ordinary CPU work improves

For a limited comparison, use the first two complete five-second report windows
inside each recording, before the new optimized-run compiles. Renderer window
end times are 01:45:15.948 and 01:45:20.964 optimized; 01:52:01.183 and
01:52:06.189 reference. Game report boundaries differ by tens of milliseconds.
These are comparable recording segments, not identical frame/camera workloads.

Means are weighted by observation counts, not averages of reported averages.

| Measurement | OptimizeRenderer=0 | OptimizeRenderer=1 |
| --- | ---: | ---: |
| Index operation, once about every five seconds | 2.847 ms rebuild | 0.062 ms unchanged check |
| Sampled setup per intercepted draw | 0.297 microseconds | 0.205 microseconds |
| Sampled water state capture per draw | 0.168 microseconds | 0.136 microseconds |
| Sampled water binding per draw | 0.540 microseconds | 0.461 microseconds |
| Sampled water state restoration per draw | 0.468 microseconds | 0.324 microseconds |
| Field preparation/upload per water frame | 0.140 ms | 0.122 ms |
| ST game update per call | 2.114 ms | 1.940 ms |
| Simulation solver per active update | 1.825 ms | 1.680 ms |
| Whole-game Present interval mean | 25.018 ms / 400 frames | 24.472 ms / 410 frames |

Sampled setup counts are 27,130 reference and 29,374 optimized. Water state sample
counts are 3,412 and 3,806. The index means contain two observations per mode;
the same substantial reduction recurs in the other optimized unchanged checks.

The sampled renderer CPU work is cheaper. These sub-microsecond measurements
do not include all hook, draw, GPU, driver or COM destruction costs. Setup includes
some other reported phases, so adding all rows would double-count. The tiny
whole-frame difference is not sufficient to claim an FPS gain from a single pair
of runs. Camera direction, draw mix and water counts differ. Solver/update
differences cannot be attributed to the renderer switch: that algorithm was not
changed, and substep count per update depends on frame timing.

The solver accounts for approximately 86% of measured ST game-update time in
these segments. It is the leading steady game-thread target. This is not 86% of
the whole game's frame time, nor proof that it determines frame rate. Wind is a
candidate within the solver based on the prior benchmark, but these new timings
do not separately measure the wind routine.

## Other observations and limitations

The optimized overlay shows about 17.85 GB used against a 21.22 GB budget at
20 seconds; the reference clip shows about 12.18 GB against 23.19 GB at 12 seconds.
The optimized clip starts around 9 GB and rises markedly later. This warrants
tracking in the next comparison. These isolated overlay readings do not identify
the allocating component, establish a leak, or prove the renderer changes caused
it. The GPU budget also changes. Do not dismiss a driver/GPU/residency regression
solely because the instrumented CPU scopes improved.

OS's per-shader table includes broader attribution than the new ST scopes and
must not be reported as isolated ST GPU time. Neither whole-log averages nor the
overlay's running average are fair A/B results: the logs include startup, long
gaps and different routes/durations. Per-window percentiles cannot be combined
into an exact whole-run percentile from these aggregate logs.

## Recommended next step

Prioritize preventing first-use compilation on an active water draw. A bounded
prewarm of observed permutations and a persistent compiled-bytecode cache are
reasonable next implementations; cache validity must include shader/include
contents, defines/layout, compilation settings and compatibility mode. Caching
alone will not eliminate the first ever encounter or all driver resource-creation
stalls. Avoid compiling thousands of unused permutations up front.

Then optimize the measured solver cost, retaining the accepted wave behavior.
Keep the renderer comparison switch so a regression can still be isolated. A
quick corroborating test would repeat the same camera turns immediately in the
same session after the first stutter, without restarting; compilation should not
repeat for those already-seen keys. Track VRAM as well. No new build or source
change is made by this analysis; preview.7 remains the accepted visual baseline.

Inputs: the two supplied OptimizeRenderer logs and optimized/reference MP4s.
The accompanying evidence archive contains the parser, parsed timings, input
hashes/video metadata, selected frames and freeze-detection output. CPU values
are rounded as logged. Native gameplay and GPU profiling were not performed here.
