# Beta 2 ENB ripple coverage test 1

2026-09-30. Version `1.1.0-beta.2-ripple-coverage.1`, machine revision 13.
Targeted AE16 test overlay for Skyrim 1.6.1170 / 1.6.1179; the returned test
runtime is 1.6.1170. Beta 1 remains the released FOMOD. This new candidate still
needs an in-game result.

## Install and test

1. Fully exit Skyrim. Disable **beta2-ripple-base-test.1**, the shader-only
   diagnostic. Install this overlay after Beta 1 and let its DLL and
   `Shaders/SurfaceTides/MeshInput.hlsl` win conflicts. The included shader
   restores normal base-water geometry. Keep the working INI and ENB settings.
2. Restart, return to the same water, and check both the complete ripple rings
   and the mid-distance tiles. Walk into and out of the water and turn the
   camera: look for holes or a water outline left behind as the player moves.
3. Send a short clip and the fresh `SurfaceTides.log`. Keep `LogStats=1` and
   `RippleTrace=1`. The new log title must be
   `1.1.0-beta.2-ripple-coverage.1`. The periodic `ENB ripple coverage` line
   reports matching base passes, marked wading draws, fallbacks and failures.

No INI replacement or cache deletion is required. The new startup setting
defaults to 1 when absent:

```ini
[Experimental]
MeshWadingDepth=1
MeshRippleCoverage=1
```

For rollback, disable this overlay and the older shader-only diagnostic,
then restart to return to Beta 1. For a focused comparison with this DLL,
set `MeshRippleCoverage=0` in the **existing** Experimental section and restart.
That restores Beta 1 coverage while keeping its accepted camera correction.
Leave `MeshWadingDepth=1`. Setting the new switch to 0 does not restore the
base-culling diagnostic, which must remain disabled.

## Evidence and change

The user reports that base-test.1 fixes the ripple clipping but leaves broken
water at mid distance. The returned clip shows retained ripples and rectangular
coverage gaps, consistent with the diagnostic deliberately suppressing the
ordinary water tiles. The log records 3,215 applied wading-depth corrections,
1,071,554 prepared draws, and no preparation or state-creation failures. There
is no evidence here establishing a separate cell-streaming failure.

The earlier public D3D trace shows the 015E wading color pass followed by 011E
base color on the same target. The base pass excludes stencil bit 0x01; wading
selects bit 0x02 with reference 3 but originally leaves all stencil bits alone.
This candidate restores the complete base geometry. Successfully shaded wading
pixels write only bit 0x01, allowing the later base pass to fill other pixels
without repainting those pixels. The accepted wading depth comparison remains.
No water pixel shader or ENB implementation is replaced or inspected.

The candidate only applies when all these observations match:

- Native ENB mesh integration and `MeshWadingDepth` are enabled; VS/PS are
  the primary 015E pair.
- The original depth/stencil state has depth enabled, no depth writes,
  LESS_EQUAL, stencil read mask 0x02, write mask 0xFF, reference 3 and EQUAL/KEEP
  on both faces. The DSV has writable stencil and a supported stencil format.
- A primary 011E base pass with the captured NOT_EQUAL/mask-0x01/reference-1
  contract has been observed on the same color and depth views this frame or
  the previous frame. An incompatible observed base state invalidates it.
- Both color passes are opaque with all color channels and samples enabled.

Unrecognized states, target mismatches and unavailable coverage states retain
the accepted Beta 1 wading-depth behavior. The cache holds at most four target
pairs and 64 state variants; COM references prevent address-reuse false matches.
The original depth/stencil binding and reference are restored after the draw.
The stencil **contents** intentionally persist for the later base pass.

## Validation and limits

Ten portable suites pass, including 134,820 coverage-policy checks and 68,730
accepted depth-policy checks. The coverage tests exhaust stencil byte masks
and references, verify all seven other bits remain unchanged, reject unknown
states, and model a tiled surface with limited or discarded wading fragments.
All HLSL is byte-identical to source checkpoint 20, with the diagnostic off.
The AE16 Windows x64 DLL is cross-built and its SKSE exports/runtime metadata
are checked. Native D3D/Skyrim execution has not been performed here.

The trace does not establish stencil clearing across every frame or every
later consumer of bit 0x01. Guarded state matching and portable tests cannot
prove those engine integration details. That is why movement and leaving the
water matter in the next test. Do not call this a confirmed full-coverage fix
until that result returns. The previous underwater defect remains absent per
the user; it is not reopened as an active bug. Color work stays parked.

SE and AE17 DLLs are not rebuilt for this focused AE16 test. The released
three-runtime Beta 1 FOMOD, OS support, shader caching/prewarming, simulation,
and ENB-presence guard removal are preserved.

Public API references used for this change:

- [Microsoft depth/stencil state description](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ns-d3d11-d3d11_depth_stencil_desc)
- [Microsoft stencil operations](https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ne-d3d11-d3d11_stencil_op)

No ENB source, shader code, bytecode, SDK or decompilation was obtained or used.
