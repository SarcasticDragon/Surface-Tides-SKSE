# Surface Tides 1.1.0-preview.2 — Skyrim 1.7.104

## Failure and change

The preview 1 tester build aborted with `REL/IDDB.cpp(31): Failed to find the id within the address library: 13358`. CommonLib's `TES::GetWaterHeight` requests this ID. It is present in the public 1.6.1170 offset table and absent from the 1.7.104 table. This is a missing mapping in the query used by the preview, not evidence that the tester needs to reinstall Address Library.

For `ST_RUNTIME=AE17`, all three spatial water-query sites now call `TESObjectCELL::GetWaterHeight(position, height)` through `WaterQuery.hpp`. This maintained CommonLib API uses ID 19002, mapped in the 1.7.104 table. If the cell query reports no result, the adapter uses `GetExteriorWaterHeight()`, which rejects interiors and cells without water and resolves exterior cell/world default water. Invalid nonfinite results remain unavailable. Existing attached-cell and world checks remain in place. No engine address is hardcoded.

The adapter is used for nearby surface selection, terrain wet masks and floe water checks. Actor cached water-height reads and the accepted water-retention logic are unchanged. This is an alternative API path; equivalence to the unavailable TES wrapper has not been established by executable disassembly or in-game testing.

The DLL metadata, startup log and menu identify this build as preview 2. The SE and AE16 code paths retain the original TES query. No new SE DLL is issued in this handoff.

## Install and check

Requires exactly Skyrim 1.7.104.0, SKSE 2.3.1 and the matching Address Library. Install this ZIP after Surface Tides 1.0.2 and the earlier preview, allowing its `SKSE/Plugins/SurfaceTides.dll` to win. The overlay contains the DLL and documentation; it does not change INI settings or shaders. Disabling the overlay restores the previous DLL.

First check whether the same save now loads. Once it does, verify exterior water and the interior pool where water-retention was previously checked. Return `SurfaceTides.log` with the result; the startup line should say `1.1.0-preview.2` and identify the cell spatial query. If the next failure is another ID dialog, include that ID. Optional foam, ice and floe features still require runtime-specific testing.

## Verification

- Windows x64 MSVC-ABI build compiled and linked.
- PE checks confirm preview 2, the exact 1.7.104 runtime, SKSE exports, Address Library V5 and minimum SKSE 2.3.1.
- The linked-DLL scan identifies 41 direct lookup sites using 29 unique IDs. All are mapped in the pinned public 1.7.104 CSV; the water lookup is 19002 and 13358 is absent from these sites. The scanner rejects unrecognized lookup forms rather than silently skipping them.
- All 53 existing portable test groups pass, including the water-retention regressions.
- Solver, shaders, defaults and release assets match the 1.0.2 source baseline.

The ID audit checks presence only. It does not establish native function semantics, structure layouts, vtable compatibility or in-game behavior. Skyrim has not been executed in this environment. Preview 2 awaits the tester's load and water checks.

Evidence is in `runtime-preview-evidence/ae17-preview2-id-audit.json`, the matching linker map, Windows build log and `portable-tests-preview2.txt`. `runtime-preview-validation.json` records DLL/package hashes. Build commands remain in the preview 1 compatibility notes. Packaging defaults to AE17 only:

```sh
python3 tools/audit_ae17_ids.py --dll build/ae17/SurfaceTides.dll --map build/ae17/SurfaceTides.map --csv /path/to/offsets-1-7-104.0.csv --objdump /path/to/llvm-objdump
python3 tools/package_runtime_previews.py --baseline-source /path/to/SurfaceTides-source-menu.zip --output-dir /path/to/deliverables
```

## Primary sources

- [CommonLib 8.1.0 TES query](https://github.com/alandtse/CommonLibSSE-NG/blob/3c0f5a87c3b166c9a6712d5c3bd180e9ac5ad0fd/src/RE/T/TES.cpp)
- [CommonLib cell spatial query and exterior fallback](https://github.com/alandtse/CommonLibSSE-NG/blob/3c0f5a87c3b166c9a6712d5c3bd180e9ac5ad0fd/src/RE/T/TESObjectCELL.cpp)
- [1.7.104 offset table, pinned repository revision](https://github.com/alandtse/skyrim_vr_address_library/blob/4f96cec371cdf1068437a28687e215534cdf2f83/offsets-1-7-104.0.csv)

The downloaded CSV's SHA-256 is `cb31890ba1a58703fa226938e613513b00b1e8ccc53b37f7a2d474abda6316b9`. Its Git blob is `e2fef0fcf67d6576db2a6a4085d49ecf1e52c32d`.
