# Beta 2 ripple investigation — base-color isolation test 1

This is a temporary shader diagnostic over the released Beta 1 checkpoint, not a Beta 2 release or a ripple fix. Keep the public Beta 1 FOMOD unchanged. The accepted camera correction and reported absence of underwater issues remain the baseline.

## Returned evidence

SurfaceTides(20260930-031324).log and SurfaceTides(3).ini confirm RippleTrace=1 on Skyrim 1.6.1170, native ENB integration and MeshWadingDepth enabled. The user confirms ENB water and tessellation enabled. The earlier Sequence #1(28).mp4 shows interrupted ripple arcs; there is no new clip in this follow-up. That earlier 030323 log had tracing disabled.

The corrected trace contains eight samples each of stencil 5000, base 011E and wading 015E. All 24 selected draws are prepared. Across the periodic reports, 1,374,129 prepared draws and 3,649 applied wading corrections have no preparation failures, native depth fallbacks or state-creation failures. Sampled stencil/base geometry is DefaultProceduralWater (49 vertices/72 triangles); wading uses the moving Water2048 surface (289 vertices/512 triangles). Their bounds centers differ from rest level by at most about 0.001 units; this does not measure every vertex or prove displaced surfaces coincide.

In seven frames where both color families were sampled, the ordinary base-color draw follows the wading-color draw. Both write the same color target without blending in the samples. The wading pass tests stencil bit 2 for equality; the base pass tests bit 1 for inequality. The native trace shows the pre-override LESS_EQUAL state, while the separate counters confirm the accepted 015E override applied. This provides a reason to isolate later base color, but does not prove that it overwrites the clipped pixels.

All 25 sampled native rows have no hull/domain shader bound, and the periodic nativePatchDraws counters are zero. This is narrower than a claim about every ENB pass or its GUI state. No ENB tessellation toggle is requested yet. See `ripple-beta2-base-test.1-evidence/returned-trace.json`.

## What the diagnostic changes

Only Surface Tides' MeshInput.hlsl is installed. An opt-in macro returns zero tessellation factors for preparation vertex descriptor 011E, removing those prepared base-color primitives. In this mesh compiler ST_PIXEL_DESCRIPTOR is supplied from the original vertex descriptor; it does not independently validate a mixed VS/PS pair. The returned samples are 011E/011E. The test is scoped to this captured setup.

The 015E ripple-bearing preparation and 5000 stencil/depth preparation remain unchanged. Native shaders are retained. There is no replacement DLL, INI, terrain/solver change, ripple suppression, depth/stencil state change, external renderer code or ENB shader inspection. Outside prepared eligible draws, native fallback/bounds behavior remains unchanged. Missing ordinary water coverage is expected, particularly beyond the player-following ripple surface; preserved depth/masks can also make the scene look unusual. Do not assess color or performance with this diagnostic.

Source defaults keep ST_DIAGNOSTIC_SKIP_ENB_BASE_COLOR=0. Only the diagnostic overlay sets it to 1. The released Beta 1 FOMOD and DLLs are untouched.

## Test and restore

Install `SurfaceTides-beta2-ripple-base-test.1.zip` as a separate mod after Beta 1 so its `Shaders/SurfaceTides/MeshInput.hlsl` wins. Fully restart Skyrim; these preparation shaders compile at process runtime through the existing path. No cache deletion is needed. Retain the same ENB water/tessellation, displacement and camera-fix settings. Keep RippleTrace=1 for this run.

Load directly at the same water and reproduce the rings near the character. Send a short clip and the ordinary SurfaceTides.log. The key observation is whether the rings become continuous **where the ripple-bearing water is still visible**. Also report whether that water/ripple surface disappears altogether. If it vanishes, absence of clipping there is inconclusive. If visible ripples become continuous, later base-color contribution becomes a stronger lead; the missing coverage is not a fix. If visible ripples still clip, removing this particular base contribution was insufficient.

Disable the overlay and restart afterwards to restore Beta 1. Return RippleTrace to 0 after the diagnostic run. The DLL log label stays 1.1.0-beta.1-enb-depth.1.

## Validation and limits

72 host DXC/SM6 compilations cover baseline, default and overlay across six representative descriptors and four preparation stages. All 24 default compiled outputs match Beta 1 byte-for-byte. Only 011E MESH_HS differs in the overlay; all four patch factors are constant zero. The checked ripple, stencil, underwater, neighboring and flowmap preparations are unchanged. Host DXC does not validate native Windows SM5 execution or the game's visual result. No new DLL build was needed.

Microsoft's public [D3D11 tessellation documentation](https://learn.microsoft.com/en-us/windows/win32/direct3d11/direct3d-11-advanced-stages-tessellation) specifies that a zero edge factor culls a patch. This diagnostic uses that documented behavior in our preparation stage. No ENB implementation, source, shader bytecode or SDK was obtained or used.
