# Native OS Water accepted; target four resumed

October 3, 2026, America/Denver. The user reports everything looks good after
native test 2 and marks the correctness issue complete for now. This is an AE16
acceptance on Skyrim 1.6.1170 with OS 2.13, not a new SE/AE17 compatibility claim.

## Evidence

`SurfaceTides(20261003-064218).log` identifies
`1.1.0-beta.12-os-native-test.2`. All 37 readiness reports have stages F/F,
enabled=true, failureLatched=false. There are no ST warnings/errors, no
augmentation failures, and no rejected native draws. Both color and stencil
pixel programs are present. Final cache counters: captured=0, recipeHits=13,
bytecodeHits=34, compiled=0, tagged=106. This validates reuse of the private ST
recipes/bytecode in the returned run. Unrecognized draw counters also include
non-water and do not by themselves indicate failures.

The user accepts the visual result; this log does not show inactiveNative draws,
so it is not separately timed evidence of an in-menu off interval. Earlier test-1
removal restored normal OS water by user report; the earlier OS removal run also
rebuilt its cache. Do not convert that into a claim of independently verified
cache-hit uninstall behavior. No new removal test was requested here.

The paired OS log identifies 2.13.0, WaterEffects 1.3.0 and UnifiedWater 0.2.0.
Its unrelated Effects11 missing-file warning is not an ST shader failure.
Input hashes, counters and baseline discovery measurements are recorded in
`beta12-os-native-accepted-evidence/return.json`.

## Target four: use the accepted DLL

The discovery implementation and timing already exist in native test 2. The
returned log has OptimizeDiscovery=false. In the existing INI, set:

```ini
[Performance]
OptimizeDiscovery=1
PerformanceTimings=1
```

Restart. Keep the other settings, OS features and DLL unchanged. No shader cache
clear is needed. Compare a repeated route with OptimizeDiscovery=0, then 1,
restarting between changes. The current log is an initial off baseline; a matched
route is preferable for attribution. Keep accepted OptimizeSimulation=1 in both.

The optimization spreads foam/ice-decal searches over updates: one cell per
slice and up to eight queued candidates under a soft 200-microsecond inspection
budget. Cell enumeration or one engine operation can exceed that soft budget.
It retains the eligible attached-cell area, existing reference limit, simulation
field size, detail and rendering. Newly loaded objects can take several updates
to be discovered, so observe foam/ice behavior while approaching and loading
areas. Floe motion/discovery and existing object maintenance are unchanged.

The off return contains 86 enumerate calls: weighted mean 0.971 ms/call and
maximum 1.366 ms. These are CPU scope measurements, generally once per second,
not per-frame cost or a GPU/FPS claim. Evaluate periodic maxima in the overall
foam update, sliced enumerate/inspect scopes, backlog/progress and visual
correctness. Do not add nested timing scopes together.

Default remains 0 pending this test. Target five and field-size work stay deferred.
The user is testing target four while lava feasibility research proceeds.

## Retained binary

DLL SHA256: `08c317e6e41db90630905b92422d329c5dbe80fcd832717d5e4863c3233ea707`.
Overlay: `SurfaceTides-Beta12-OSNative-Test2-AE16.zip`, SHA256
`9ed615db1526b6f2aa3e593aabe78217a6e99503142c80f10c976cbc13e45fc8`.
The prior 13-suite/120-DXC-stage/18-spacing validation applies to this unchanged
binary. This checkpoint changes documentation and one INI comment only; no new
binary or functional default is introduced and no tests were unnecessarily rerun.
