# Accepted motion workaround — preview.6

The user returned preview.5's off/on/off test and reports it is very effective
at preventing jitter. The log confirms 173,921 applications to the verified
motion target with zero mismatches or failures, at displacement 2/normal 2.
Preview.6 defaults this OS-only workaround on and exposes a saved live switch.
This is accepted for the tested setup, not a universal temporal correctness claim.
See [the returned evidence and WaterEffects test](OPEN-SHADERS-preview.6.md).

The previous pending motion-test instructions below are historical. Do not
repeat the accepted test before proceeding with WaterEffects.

# OS frame-generation jitter: results and motion diagnostic

Updated 2026-09-24. Current candidate: preview.5-motion-test. The older next-test
instructions below are historical. Use [the session motion toggle](OPEN-SHADERS-preview.5-motion-test.md)
at full displacement; do not repeat the completed controls.

## Latest returned results

1. **OS native water, FG on, Surface Tides off:** user reports slight blurring
   resembling the earlier artifact, but explicitly not quite the same. Returned
   `CommunityShaders(2).log` confirms FG enabled with the D3D12 proxy and an FSR3
   2560x1440 context; WaterEffects and UnifiedWater disabled. Clip
   `2026-09-23 22-09-25.mp4` accompanies it. Native-water selection follows the
   reported test setup; the log alone does not prove replacement on every draw.
   Do not claim an identical upstream reproduction or clear Surface Tides.
2. **Displacement control:** `SurfaceTides(20260924-052319).log` remains active in
   OS mode with healthy 7F/7F hooks, advancing uploads (through 3720) and no failed
   draws. In `2026-09-23 23-21-57.mp4`, inspected menu frames show displacement
   2.00 then 0.00 while normal strength stays 2.00. The user says the issue seemed
   better and less obvious at lower displacement, not eliminated. Preview.4 does
   not log each live tuning value; no complete 2-to-0-to-2 sequence is claimed.
   There is no new paired OS log for this run; FG-on follows the test context.
3. **Wade in Water Redone removal:** current user report rules it out as the
   cause. Faster character movement without the slowdown made the artifact worse.
   No new clip/log accompanies this report. Keep its state constant during the
   next test rather than requesting another removal control.

These results support investigating temporal treatment of moving objects seen
through displaced water. Speed dependence does not alone distinguish motion
vectors, depth, coverage, refraction or history rejection.

Reviewed Surface Tides and public OS stencil shaders both write water-surface
motion to target 1. Preview.5 tests retaining the existing motion at that stage,
only after matching the bound target's resource identity to the engine motion
texture. It does not reconstruct refracted object vectors, fix depth, or edit OS
frame-generation code. See the diagnostic document for limitations and counters.

## Returned result

The user reports that disabling OS frame generation mostly removes the jitter.
Very slight mace ghosting remains but is explicitly a lower priority. They want
frame generation working if possible, and report that their previous ENB frame
generation setup did not show this problem. That comparison is useful history;
it does not establish identical interpolation implementations or input buffers.
No ENB code was inspected or obtained.

Supplied evidence:

- `SurfaceTides(20260924-022230).log`: preview.4, Skyrim 1.6.1170,
  BlockCS=true/OpenShaders=true, debugView=0. Stencil 5000/5001 and color
  031E/035E/410E/430E/434E compile and bind. All nine hook-health samples retain
  targetMask=7F/entryMask=7F with the same immediate context. uploadedSeq advances
  1, 5, 183, 417, 661, 923, 1115, 1370, 1549. No failed draws or observed
  changedAfterDraw events; CPU simulation reaches sequence 1557.
- `CommunityShaders(1).log`: version string v2-13-0-0; WaterEffects and
  UnifiedWater disabled at boot. FSR3 context created at 2560x1440 render/display.
  Unlike the earlier FG-on log, this log contains neither the explicit
  "Frame Generation enabled, using D3D12 proxy" message nor DX12SwapChain startup.
  The frame-generation DLL still loads; that alone does not mean FG is active.
  This corroborates the user's reported setting change rather than constituting
  a per-frame measurement of generated output.
- `2026-09-23 20-20-59.mp4`: approximately 9.97 seconds, 1920x1080 at 60 fps.
  Sampled movement frames show the character and weapon through displaced water.
  User observation supplies the qualitative before/after conclusion; these
  different camera/movement recordings are not a quantitative matched benchmark.

Conclusion: frame generation or its associated render path is implicated in the
major artifact. Surface Tides was not accidentally disabled in the successful
control. Do not call the FG-on issue fixed, blame all residual artifacts on one
cause, or spend the next test turning off temporal upscaling unnecessarily.

## Source findings and limits

Reviewed public Open Shaders source at pinned commit
`a996a271790ffa9f944d2d7e8a05e6fbd73a85d3`:

- `src/Features/Upscaling.cpp`, `CopySharedD3D12Resources`: copies the engine
  kMOTION_VECTOR texture and samples kMAIN depth into shared D3D12 resources.
  `Main_PostProcessing::thunk` invokes this before PerformUpscaling when FG runs.
- `features/Upscaling/Shaders/Upscaling/CopyDepthToSharedBufferPS.hlsl` copies
  input depth at pixel coordinates. It does not reconstruct water/object layers.
- `src/Features/Upscaling/FidelityFX.cpp`, `Present`: supplies those shared depth
  and motion resources, render dimensions, jitter offset and camera information
  to the frame-generation prepare dispatch.
- `features/Upscaling/Shaders/Upscaling/EncodeTexturesCS.hlsl` generates reactive
  and transparency masks for temporal upscaling. The inspected FG prepare call
  does not take those masks. Increasing an upscaler reactive mask is therefore
  not an established direct repair for the FG input path.
- `package/Shaders/Common/MotionBlur.hlsli` uses the same unjittered projection
  matrices and signed UV delta as Surface Tides' OpenShadersColor helper.
- Both OS Water.hlsl and Surface Tides' stencil pixel pass write surface motion
  to SV_Target1. Surface Tides additionally tracks displacement with current and
  previous fields. Its history advances once per observed game Present boundary.

No incorrect sign, demonstrably stale history, or missing motion output was
established by this review. The logs cannot show which motion/depth values reach
FG at a leg or weapon pixel. A possible conflict between surface motion and
objects seen through water remains a hypothesis, not a diagnosed defect.
The installed OS build's exact commit has not been established from its version
string; verify against installed files before distributing an OS shader patch.

References (public OS only):

- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/src/Features/Upscaling.cpp
- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/src/Features/Upscaling/FidelityFX.cpp
- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/features/Upscaling/Shaders/Upscaling/CopyDepthToSharedBufferPS.hlsl
- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/features/Upscaling/Shaders/Upscaling/EncodeTexturesCS.hlsl
- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/package/Shaders/Common/MotionBlur.hlsli
- https://github.com/alandtse/open-shaders/blob/a996a271790ffa9f944d2d7e8a05e6fbd73a85d3/package/Shaders/Water.hlsl

## Next control: OS's own water with FG on

Earlier, the user reported jitter while the compatibility guard had prevented
Surface Tides from installing its rendering hooks. However, OS water replacement
was also off in that test setup. It did not establish behavior with OS's own
water shader active. Test that rendering-provider change before making another
Surface Tides shader modification:

1. Disable the Surface Tides mod in the test profile.
2. Enable OS's Water entry under Replace Original Shaders and re-enable Frame
   Generation. Save OS settings and fully restart Skyrim.
3. Keep the existing upscaler method/quality, preset, textures and water location.
   Keep WaterEffects and Unified Water disabled at boot for this comparison.
4. Repeat the same short leg/weapon movement. Return a clip and fresh
   CommunityShaders.log; a SurfaceTides log is not expected with the mod disabled.

If OS's own water is stable, compare its live water motion/depth coverage with
the Surface Tides path before choosing a correction. If the same jitter remains,
it is reproducible without Surface Tides on OS's intended water path; investigate
that OS FG interaction, using a matching-version source/input capture if needed.
Neither outcome alone names the exact failing buffer or operation.

To restore the accepted preview.4 setup: switch OS Water replacement back off,
disable FG for the known stable baseline, save/exit, then re-enable Surface Tides
and restart. Preserve its working INI. No shader-cache deletion, preset reinstall,
save cleanup or new test DLL is required.

## Change scope

Only documentation changed. No runtime, shader, INI, OS setting or binary was
modified. Build and shader tests are not rerun for this notes-only checkpoint.
The next inference depends on the user's game comparison. Color remains parked;
WaterEffects, Unified Water and experimental ENB integration follow afterward.
