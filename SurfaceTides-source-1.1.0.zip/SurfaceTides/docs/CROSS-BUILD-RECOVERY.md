# Current Unified Water checkpoint (2026-09-24)

Current source: `SurfaceTides-source-OS-preview.7-unified-water.zip`.
Baseline is source version 10, SHA256
`31b2eeb42b830034f5cf9a6431881d3a9d065e10f75f7ac7ae774db9a6dec24c`.
Keep the same source archive identity/history. Preview.6 WaterEffects is accepted.
Use docs/OPEN-SHADERS-preview.7.md and its validation/evidence directory.

The same three incremental build profiles/toolchain below apply. AE16 also
builds SurfaceTidesShaderTests.exe; it accepts an OS shader directory and
`--water-effects` and/or `--unified-water`. Native SM5 execution remains unavailable
here. Secondary validation uses tools/validate_hlsl.py with `--os-unified-water`
in addition to the existing OS/WaterEffects flags. Each of five configurations
checks 200 stages, including interior/VC/LOD cases. Recheck changed shader modes
after edits; preserve completed logs, not mutable logs from a running process.

Package with tools/package_os_unified_preview7.py --baseline-source VERSION10.zip
--build-root BUILD_ROOT --output-dir OUTSIDE_SOURCE. This verifies source retention,
unchanged core/hooks/motion behavior and old INI values, runtime PE metadata,
build/test evidence, and absence of active INI/OS assets in the overlay.

# Historical WaterEffects checkpoint (2026-09-24)

Current source: `SurfaceTides-source-OS-preview.6-water-effects.zip`. Preserve
its existing OS source archive identity. Baseline is source version 9,
SHA256 `389a8d9b471b965c643b808f12e44dea0408f5d36387576b690db7a135c6904f`.
Use `docs/OPEN-SHADERS-preview.6.md`; the preview.5 test is now accepted.

Build all three runtime profiles as before. Rebuild the AE16 native shader
validator with ST_BUILD_SHADER_TESTS=ON. It takes the ST shader directory,
optionally the matching OS Data/Shaders directory, then `--water-effects`.
Native SM5 execution was unavailable here. Secondary Linux checks use
`tools/validate_hlsl.py` for standalone, `--os-shaders PATH` for color-only,
and additionally `--os-water-effects` for the adapter. The OS directory must
contain matching Common/ and WaterEffects/ headers. Temporary DXC namespace
aliases are validation-only and must not enter install packages.

Use `tools/package_os_water_preview6.py --baseline-source /path/to/source-version-9.zip
--build-root /path/to/build --output-dir /path/outside/source` after placing
completed build/test evidence in docs/os-preview.6-evidence. Incremental builds
can reuse the preview.5 toolchain/build directories when the source path is
unchanged. Do not read a running command's mutable log from another exec;
this session captures output and writes completed logs after the command ends.

# Historical motion diagnostic checkpoint (2026-09-24)

Current source: `SurfaceTides-source-OS-preview.5-motion-test.zip`. Preserve the
existing OS source archive identity/history. Setup:
`docs/OPEN-SHADERS-preview.5-motion-test.md`. The diagnostic is default-off and
session-only; no HLSL or saved configuration changes are needed.

Build `AE16`, `SE` and `AE17` separately with the toolchain below, using separate
directories outside the source tree. This update used Release, ST_BUILD_PLUGIN=ON,
ST_BUILD_TESTS=OFF, ST_BUILD_SHADER_TESTS=OFF, four jobs, sequential profiles.
All six portable CTest suites ran separately with GNU 13.3.0. Windows validation
executables and native SM5 execution were not repeated because HLSL is unchanged;
runtime GPU behavior remains a user test. See `docs/os-preview.5-motion-validation.json`
and `docs/os-preview.5-motion-evidence/` for the actual evidence.

Package with `tools/package_os_motion_preview5.py --baseline-source /path/to/source-version-8.zip
--build-root /path/to/build --output-dir /path/outside/source`. The build root
contains ae16/se/ae17. The baseline SHA256 is
`1296ac25ef61c12f4af17cba2b2cf08eed8f28307c06ee13b50d2341adc9ed38`.
The packager requires build logs and portable test evidence copied into the
evidence directory, checks runtime metadata and unchanged Data/core/hooks,
and preserves all files in the prior source archive.

# Historical OS preview checkpoint (2026-09-23)

Current source: `SurfaceTides-source-OS-preview.4.zip`, preserving the OS source archive identity. Current setup is `docs/OPEN-SHADERS-preview.4.md`. Build all three runtime profiles separately (`ae16`, `se`, `ae17`), then use `tools/package_os_preview4.py --baseline-source /path/to/source-version-5.zip --output-dir /path/outside/source`. The packager verifies PE runtime/version metadata, unchanged canonical shaders/INI, and preservation of every baseline source file. See `docs/os-preview.4-validation.json` and `docs/os-preview.4-evidence/` for results and toolchain provenance.

Preview.4 adds OS-only recovery of changed public draw-method targets with permanent per-target original trampolines. The normal shader baseline is restored in its packages; disable reflection/refraction diagnostic overlays. The returned reflection-probe run never reached a water color pass, so it cannot isolate the reported tint/jitter. Native recovery and visual results require a game test.

Main.cpp's existing ENB EnableWater advisory source change is included in preview.4's DLL builds. Prior preview.3 DLLs did not contain it. See ENB-WATER-ADVISORY.md. Do not use older build evidence as validation of preview.4.

# Historical OS preview checkpoint (2026-09-21)

Current source: `SurfaceTides-source-OS-preview.3.zip`; current setup is `docs/OPEN-SHADERS-preview.3.md`. Retain the source archive identity when updating. Build all three runtime profiles separately (`ae16`, `se`, `ae17`) and use `tools/package_os_preview.py`. User has confirmed the earlier SE1.5.97 and AE1.7.104 runtime previews in game; this OS adapter still needs in-game results. The solver, floe, foam and engine hooks were preserved. `BlockCS=1` is the new guard; `OpenShaders=1` explicitly selects the fork sharing the CS DLL name.

Compiler/SDK recovery below remains applicable. The native SM5 validation executable is built but cannot be run in this Linux session. For secondary OS DXC checks use `tools/validate_hlsl.py --os-shaders /path/to/matching/OS/package/Shaders`; its namespace aliases are temporary validation-only adaptations. Never distribute those transformed OS headers. The eleven examined color headers match OS2.14.0 exactly. See the provenance and validation files in `docs/os-preview.3-evidence/`.

# Cross-build recovery

Known working September 9, 2026: LLVM-MinGW 20260826 Ubuntu22.04 x64 (clang23.1), xwin0.10.0, CMake4.4.3/Ninja1.13.2 from pip, xwin MSVC14.44.17.14 and SDK10.0.26100. This is clang-cl targeting MSVC ABI, not MinGW ABI. The full vendored source is already included; do not re-fetch dependencies.

If the temporary toolchain is lost, download these exact release assets:
- https://github.com/mstorsjo/llvm-mingw/releases/download/20260826/llvm-mingw-20260826-ucrt-ubuntu-22.04-x86_64.tar.xz
- https://github.com/Jake-Shadle/xwin/releases/download/0.10.0/xwin-0.10.0-x86_64-unknown-linux-musl.tar.gz

Extract with tar --no-same-owner. In the LLVM bin directory create clang-cl as a symlink to clang; lld-link already exists. pip install --target work-tools/python-packages cmake==4.4.3 ninja==1.13.2. Use the actual CMake executable at python-packages/cmake/data/bin/cmake and ELF Ninja at python-packages/bin/ninja.

Use xwin --accept-license --cache-dir work-tools/xwin-cache --http-retry 2 splat --output work-tools/sdk --use-winsysroot-style --preserve-ms-arch-notation. Accepting the license is required for SDK acquisition. SDK and compilers are not redistributed in this source package.

Configure the source with Ninja, cmake/windows-clang.cmake, absolute ST_LLVM_BIN and ST_WINDOWS_SYSROOT paths, absolute CMAKE_MAKE_PROGRAM path to Ninja, CMAKE_BUILD_TYPE=Release, ST_BUILD_PLUGIN=ON, ST_BUILD_TESTS=ON, ST_BUILD_SHADER_TESTS=ON. Build with --parallel2 (384 actions on clean build). Install --component SurfaceTides to a staging prefix. Archive staging contents for mod installation; archive source excluding build/out for source distribution. Refresh validation binaries and binary inspection only after successful linking. Shader tests need native Windows; do not spend another session setting up blocked Wine sockets.

Use a freshly materialized current source checkpoint as the authoritative tree; workspace directory names below are historical. Do not build an older leftover tree. Retain the saved source identity and version history when saving a new checkpoint.


## Runtime compatibility preview 1 (2026-09-16)

The authoritative source for this branch is SurfaceTides-source-runtime-preview.1.zip. This branch is a separate copy of the released 1.0.2 checkpoint; the release FOMOD and source archive are preserved. Configure separate `build/se` and `build/ae17` directories with `-DST_RUNTIME=SE` or `-DST_RUNTIME=AE17`. The AE17 profile automatically selects its own vendored CommonLib 8.1.0 plus the SimpleMath component. Do not substitute the original dependency for AE17.

Source packaging: after both DLLs link and the portable tests pass, run `python tools/package_runtime_previews.py --baseline-source /path/to/released/SurfaceTides-source-menu.zip --output-dir /path/outside/source`. The script checks PE runtime declarations, preserves release data/defaults, packages settings-preserving DLL overlays and writes complete source. Old release/FOMOD packaging scripts are historical and version-specific; they are not the runtime-preview packager.

No game execution occurs in this environment. Cross-compilation and metadata checks are build evidence, not in-game confirmation. Keep the previews separate until reports arrive.
