> Apply [shader hotfix 1](OPEN-SHADERS-preview.3-shader-hotfix.1.md) to this preview.
> It corrects a legacy shader-compiler failure discovered during in-game testing.

# Surface Tides 1.1.0-os-preview.3

2026-09-21. Initial Open Shaders color-adapter test; not a compatibility release.
Community Shaders is now unsupported. This policy supersedes previous CS
coexistence instructions, installer options, and test acceptance notes.

## Install and test

Install the overlay matching Skyrim's executable version after the existing
Surface Tides installation. It supplies the new DLL and complete Surface Tides
shader directory, preserving your active INI and object-removal choices.

Edit the existing `Data/SKSE/Plugins/SurfaceTides.ini`:

```ini
[Compatibility]
BlockCS=1
OpenShaders=1
```

Keep any other entries in this section, including your ENB settings. The OS path
does not select ENB rendering. Use this selection only with an actual Open
Shaders installation. OS intentionally retains the `CommunityShaders.dll`
filename, SKSE plugin name, and `CommunityShaders` data directory; this is an
explicit selection, not automatic identification of the fork.

Remove the old
`Data/SKSE/Plugins/CommunityShaders/Overrides/SurfaceTides_Global.json` if present.
This preview installs no renderer override or renderer settings JSON. In OS,
keep **Replace Original Shaders / Water** unchecked and keep **UnifiedWater**
and **WaterEffects** checked under **Disable at Boot**, then save and restart.
These are the initial coexistence conditions, not support for OS's own water
renderer or Unified Water mesh changes. OS's other rendering features can
remain enabled for the initial comparison.

The reviewed interface is **Open Shaders 2.14.0**. If your OS package is another
version, report its version with the results. Keep its DLL and shader files from
the same package. This preview compiles against the installed OS headers; missing
helpers or short/missing buffers leave the native water draw unchanged and log
the reason. A different same-sized buffer layout cannot be detected by size
checks, so matching OS files matter.

Repeat the scene where the discoloration occurs. Check color, idle waves, wakes,
and a shallow edge/underwater view. Return `SurfaceTides.log`,
`CommunityShaders.log`, the OS version and a comparison image if the color still
looks wrong. The useful Surface Tides entries are `OS color adapter ready`,
`OS color adapter deferred`, and `Water permutation ... left unchanged`.

## What changed

- `BlockCS=1` defaults to blocking upstream CS. `BlockCS=0` is an explicit
  unsupported-testing bypass; it does not promise compatibility. The old
  `AllowCS` key is ignored, so previously installed `AllowCS=1` profiles do not
  silently defeat the new default.
- `OpenShaders=1` selects the OS adapter and enables coexistence hooks. Without
  the shared renderer DLL, this selection disables Surface Tides with a log.
- The OS pixel shader calls installed OS helpers for authored water color, fog,
  refraction color decoding, and output encoding. It uses the live gamma-target
  flag, water brightness/muddiness/reflection/sun controls and directional-light
  color handling. It removes the vanilla output saturation/exposure step from
  this path and retains the original behavior when OS is not selected.
- Native scene-color contact blending stays in the output target's color space.
  Original displacement, simulation normals, shoreline protections, motion
  vectors, water retention and floe behavior remain in place.
- OS shader constants use its installed declarations and live PS buffers; no
  hard-coded feature offsets, disk preset snapshots, or GPU-to-CPU readback.
  Reflected byte requirements are checked before using the adapter.
- The current FOMOD generator replaces its CS option with an OS preview option
  and no longer installs a persistent renderer override. Historical recovery
  archives and old documentation remain as evidence, not current instructions.

## Validation and limits

See `os-preview.3-validation.json` and `os-preview.3-evidence/` for build results.
Portable tests cover the solver, floes, water retention and renderer guard.
Secondary DXC checks cover standalone and OS permutations. DXC does not implement
FXC's namespace-scoped cbuffer-member lookup; the OS check uses temporary renamed
exports and namespace aliases, preserving types/order/registers. This validation
transformation is never installed or used by the plugin. It does not replace
native Shader Model 5 validation or Skyrim testing.

The Windows `SurfaceTidesShaderTests` target can validate actual D3DCompiler SM5
and remapping, with an optional second argument pointing to the installed OS
`Data/Shaders` directory. Native Windows shader-test execution and Skyrim
execution were not performed here. Runtime compilation errors are logged.

This is an initial color adapter, not full OS water-feature integration. OS's
dynamic cubemaps, extended local lights, height-fog water integration and other
advanced water features are not ported by this preview. Their combinations need
further testing. No VR build is supplied. No new engine relocations were added;
the previously tested SE and AE17 runtime-specific engine paths are retained.

## Rollback

Disable this overlay to restore the previous DLL and Surface Tides shaders.
Remove or set `OpenShaders=0` if leaving the OS test. To restore OS's own water,
reenable Water shader replacement and restore UnifiedWater/WaterEffects to your
previous choices, save and restart. Removing a mod or clearing compiled shaders
does not necessarily undo saved OS settings. No save cleaning is required by
this adapter, and it does not write save records or OS settings.

## Source references

Open Shaders 2.14.0 is commit `164d06bd657c07970e3633a8659bae061f6273b1`.
The 11 color-helper dependencies were byte-identical to inspected dev commit
`a996a271790ffa9f944d2d7e8a05e6fbd73a85d3`.

- [OS identity and compatibility filenames](https://github.com/alandtse/open-shaders/blob/164d06bd657c07970e3633a8659bae061f6273b1/README.md)
- [OS water composition](https://github.com/alandtse/open-shaders/blob/164d06bd657c07970e3633a8659bae061f6273b1/package/Shaders/Water.hlsl)
- [OS color helpers](https://github.com/alandtse/open-shaders/blob/164d06bd657c07970e3633a8659bae061f6273b1/package/Shaders/Common/Color.hlsli)
- [OS live buffer binding](https://github.com/alandtse/open-shaders/blob/164d06bd657c07970e3633a8659bae061f6273b1/src/Deferred.cpp)

Only public Open Shaders source was consulted for this adapter. No ENB source
or binaries were retrieved or incorporated. OS itself is installed separately.


OS follow-up (2026-09-23): shader hotfix 1 is confirmed compiling in the returned
Skyrim log. The color-test.2 candidate and optional refraction control are
documented in OPEN-SHADERS-preview.3-color-test.2.md; visual results are pending.


Returned OS test.2 result: no improvement in color or jitter with either overlay.
See OPEN-SHADERS-preview.3-reflection-probe.3.md for the next
controlled diagnostic. Canonical runtime shader source is unchanged this turn.
