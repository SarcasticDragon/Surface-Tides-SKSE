#pragma once
#include <RE/T/TES.h>
#include <RE/T/TESObjectCELL.h>
#include <cmath>
#include <limits>

namespace st::plugin {
inline float waterHeightAt(RE::TES* tes, RE::TESObjectCELL* cell, const RE::NiPoint3& position) {
    constexpr float unavailable = -std::numeric_limits<float>::infinity();
    if (!tes || !cell || !cell->IsAttached()) return unavailable;
#if defined(ST_RUNTIME_AE17)
    // TES::GetWaterHeight's ID 13358 is absent from 1.7.104. The cell's
    // position-based query is mapped as 19002 and still handles placed water.
    float height = unavailable;
    if (!cell->GetWaterHeight(position,height)) height = cell->GetExteriorWaterHeight();
    return std::isfinite(height) ? height : unavailable;
#else
    return tes->GetWaterHeight(position,cell);
#endif
}
}
