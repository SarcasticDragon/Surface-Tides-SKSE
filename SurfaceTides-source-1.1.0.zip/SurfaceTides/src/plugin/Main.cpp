#include "PCH.hpp"
#include "Bridge.hpp"
#include "BuildVersion.hpp"
#include "NativeOS.hpp"
#include "surfacetides/ShaderCompatibility.hpp"

namespace {
constexpr REL::Version candidateVersion{1,1,st::plugin::previewPatch,st::plugin::previewRevision};
#if defined(ST_RUNTIME_SE)
constexpr std::array targetRuntimes{REL::Version{1,5,97,0}};
constexpr auto targetLabel = "SE 1.5.97";
#elif defined(ST_RUNTIME_AE17)
constexpr std::array targetRuntimes{REL::Version{1,7,104,0}};
constexpr auto targetLabel = "AE 1.7.104";
#else
constexpr std::array targetRuntimes{REL::Version{1,6,1170,0},REL::Version{1,6,1179,0}};
constexpr auto targetLabel = "AE 1.6.1170 / GOG 1.6.1179";
#endif
bool supportsRuntime(const SKSE::QueryInterface* skse) {
    return skse && !skse->IsEditor() &&
        std::find(targetRuntimes.begin(),targetRuntimes.end(),skse->RuntimeVersion()) != targetRuntimes.end();
}
}

extern "C" __declspec(dllexport) constinit SKSE::PluginVersionData SKSEPlugin_Version = [] {
    SKSE::PluginVersionData v;
    v.PluginName("SurfaceTides"); v.PluginVersion(candidateVersion); v.AuthorName("SurfaceTides contributors");
#if defined(ST_RUNTIME_AE17)
    v.UsesAddressLibrary(); v.UsesUpdatedStructs();
    v.MinimumRequiredXSEVersion({2,3,1,0});
#elif defined(ST_RUNTIME_SE)
    v.UsesAddressLibrary(true);
#else
    v.UsesAddressLibrary(true); v.UsesStructsPost629(true);
#endif
    std::transform(targetRuntimes.begin(),targetRuntimes.end(),std::begin(v.compatibleVersions),
        [](const REL::Version& runtime) { return runtime.pack(); });
    return v;
}();

// SKSE 2.0.20 uses Query. Reject other executables before SKSE::Init can
// resolve an address or touch game data using this build's structure layout.
extern "C" __declspec(dllexport) bool SKSEPlugin_Query(const SKSE::QueryInterface* skse, SKSE::PluginInfo* info) {
    if (!info) return false;
    info->infoVersion = SKSE::PluginInfo::kVersion;
    info->name = "SurfaceTides";
    info->version = candidateVersion.pack();
    return supportsRuntime(skse);
}

namespace {
void reset() {
    st::plugin::resetFloe();
    st::plugin::resetAttachedFoam();
    st::plugin::resetRequested.store(true);
    st::plugin::exchange.publish(std::make_shared<st::plugin::Frame>());
}
// Inspect module paths and user configuration only. No ENB SDK or shader code.
std::filesystem::path modulePath(HMODULE module) {
    std::array<wchar_t,32768> path{};
    const auto size = GetModuleFileNameW(module,path.data(),static_cast<DWORD>(path.size()));
    if (!size || size >= path.size()) throw std::runtime_error("Cannot resolve renderer module path");
    return std::filesystem::path(std::wstring(path.data(),size));
}
bool rendererAllowed() {
    try {
        const auto cs = GetModuleHandleW(L"CommunityShaders.dll");
        auto& config = st::plugin::config;
        const auto shaderRenderer = st::selectShaderRenderer(cs != nullptr,config.openShaders,config.blockCS);
        if (shaderRenderer == st::ShaderRenderer::MissingOpenShaders) {
            SKSE::log::error("OpenShaders=1 was selected but CommunityShaders.dll (OS's shared runtime filename) is not loaded. SurfaceTides disabled.");
            return false;
        }
        if (shaderRenderer == st::ShaderRenderer::BlockedCS) {
            SKSE::log::error("CommunityShaders.dll detected: Community Shaders is incompatible and blocked. BlockCS=0 bypasses this guard for unsupported testing. For an actual Open Shaders installation, select OpenShaders=1 instead. SurfaceTides disabled.");
            return false;
        }
        if (cs) {
            SKSE::log::info("Shared renderer module={} BlockCS={} OpenShaders={} (explicit selection; DLL name does not distinguish forks)",modulePath(cs).string(),config.blockCS,config.openShaders);
            if (GetModuleHandleW(L"enbseries.dll"))
                SKSE::log::warn("Both the CS/OS renderer and enbseries.dll are loaded. Continuing with the selected CS/OS path; mixed frameworks remain untested. ENB presence is not a startup guard.");
            const auto overridePath = modulePath(nullptr).parent_path() / "Data/SKSE/Plugins/CommunityShaders/Overrides/SurfaceTides_Global.json";
            if (std::filesystem::is_regular_file(overridePath))
                SKSE::log::warn("Legacy SurfaceTides_Global.json is still installed: {}. Remove it and control water settings manually for this installation; SurfaceTides does not write CS/OS configuration.",overridePath.string());
            // A CS installation may retain an old enbseries.ini or use a local
            // graphics proxy. Those alone must not route it into the ENB path.
            config.enbActive=false;
            config.enbMeshInput=false;
            st::plugin::openShadersActive=shaderRenderer == st::ShaderRenderer::OpenShaders;
            st::plugin::communityShadersActive=!st::plugin::openShadersActive;
            if (st::plugin::openShadersActive) {
                for (const auto* file : {"Common/Color.hlsli","Common/SharedData.hlsli","Common/Permutation.hlsli"}) {
                    if (!std::filesystem::is_regular_file(modulePath(nullptr).parent_path() / "Data/Shaders" / file)) {
                        SKSE::log::error("Open Shaders integration requires the matching installed OS shader headers; missing {}. SurfaceTides disabled.",file);
                        return false;
                    }
                }
                if (config.osNativeWater)
                    SKSE::log::info("Water renderer: native Open Shaders Water augmentation. Keep OS Water replacement ON. OS owns feature selection; OSWaterEffects/OSUnifiedWater flags apply only to the legacy adapter. Inactive ST retains original OS shaders. No OS settings, source or cache writes.");
                else SKSE::log::info("Water renderer: legacy Open Shaders adapter. Uses installed OS helpers and live PS b4/b5/b6; no preset writes. Requires OS Water shader replacement OFF. Match OSWaterEffects/OSUnifiedWater with the features enabled separately in OS, then restart. Parallax compile failures retry without parallax while retaining requested UnifiedWater coordinates.");
                SKSE::log::info("OS compatibility: OSPreserveSceneMotion={} (live, saved tuning) OSWaterEffects={} OSUnifiedWater={} (startup opt-ins; actual OS feature state is not read)",config.osPreserveSceneMotion,config.osWaterEffects,config.osUnifiedWater);
            } else {
                SKSE::log::warn("Water renderer: UNSUPPORTED Community Shaders bypass (BlockCS=0). No compatibility or color correction is provided. Water shader replacement and water features must remain off for native water draws to be identified.");
            }
            return true;
        }
        const auto directory = modulePath(nullptr).parent_path();
        bool localProxy = false;
        for (const auto* name : {L"d3d11.dll",L"dxgi.dll",L"enbseries.dll",L"d3dcompiler_46e.dll"}) {
            if (const auto module = GetModuleHandleW(name)) {
                const auto path = modulePath(module);
                SKSE::log::info("Renderer module: {}",path.string());
                if ((!_wcsicmp(name,L"d3d11.dll") || !_wcsicmp(name,L"dxgi.dll")) &&
                    !_wcsicmp(path.parent_path().c_str(),directory.c_str())) localProxy = true;
            }
        }
        const auto ini = directory / "enbseries.ini";
        const bool enbModule = GetModuleHandleW(L"enbseries.dll") != nullptr;
        const bool iniPresent = std::filesystem::is_regular_file(ini);
        // A proxy or leftover INI is evidence of a possible renderer, not proof of ENB.
        const bool possibleENB = enbModule || iniPresent || localProxy;
        const auto nativeRenderer = st::selectNativeRenderer(possibleENB,config.enbMeshInput);
        config.enbActive = nativeRenderer != st::NativeRenderer::Vanilla;
        config.enbMeshInput = nativeRenderer == st::NativeRenderer::ENBIntegration;
        SKSE::log::info("Compatibility: ENBDetected={} enbModule={} localGraphicsProxy={} enbINI={} (legacy AllowENB ignored; no ENB presence guard)",
            config.enbActive,enbModule,localProxy,iniPresent);
        if (nativeRenderer == st::NativeRenderer::Vanilla) {
            SKSE::log::info("Water renderer: SurfaceTides standalone (displacement and simulation normals)");
            return true;
        }
        std::array<wchar_t,128> value{};
        const auto count = GetPrivateProfileStringW(L"EFFECT",L"EnableWater",L"",value.data(),
            static_cast<DWORD>(value.size()),ini.c_str());
        std::wstring text(value.data(),count);
        const auto first = text.find_first_not_of(L" \t\r\n");
        const auto last = text.find_last_not_of(L" \t\r\n");
        text = first == std::wstring::npos ? L"" : text.substr(first,last-first+1);
        // This is a saved INI observation, not ENB's live water state. Keep it
        // advisory: a different file view or parser must not disable the mod.
        const bool truncated = count == value.size()-1;
        const bool savedOff = !truncated && (!_wcsicmp(text.c_str(),L"false") || text == L"0");
        SKSE::log::info("ENB INI observation (advisory only): file={} [EFFECT] EnableWater={} savedOff={} truncated={} liveState=unknown",
            ini.string(),text.empty() ? std::string("<missing or unreadable>") : std::string(text.begin(),text.end()),savedOff,truncated);
        if (!savedOff && !st::plugin::config.enbMeshInput) {
            SKSE::log::warn("The saved INI observation did not establish EnableWater=false. SurfaceTides will continue; disabling ENB water is the user's responsibility. This check does not query live ENB state.");
        }
        if (st::plugin::config.enbMeshInput)
            SKSE::log::info("Water renderer: EXPERIMENTAL ENB mesh-input integration (native water shaders retained; accepted ripple coverage)");
        else
            SKSE::log::info("Water renderer: SurfaceTides ENB coexistence (displacement and simulation normals). Keep ENB water OFF for this session; user-managed, live state is not verified.");
        return true;
    } catch (const std::exception& e) {
        SKSE::log::error("Renderer compatibility check failed: {}",e.what());
        return false;
    }
}
void onMessage(SKSE::MessagingInterface::Message* message) {
    if (!message) return;
    switch (message->type) {
    case SKSE::MessagingInterface::kPostPostLoad:
        st::plugin::nativeOS::installCompilerObserver();
        break;
    case SKSE::MessagingInterface::kDataLoaded:
        if (!rendererAllowed()) st::plugin::disabled.store(true);
        else if (st::plugin::config.enabled) st::plugin::installHooks();
        st::plugin::registerMenu();
        break;
    case SKSE::MessagingInterface::kPreLoadGame:
    case SKSE::MessagingInterface::kPostLoadGame:
    case SKSE::MessagingInterface::kNewGame: reset(); break;
    default: break;
    }
}
}

extern "C" __declspec(dllexport) bool SKSEPlugin_Load(const SKSE::LoadInterface* skse) {
    if (!supportsRuntime(skse)) {
        OutputDebugStringA("SurfaceTides: executable does not match this build.\n");
        return false;
    }
    const auto runtime = skse->RuntimeVersion();
    SKSE::Init(skse);
    try {
        auto directory = SKSE::log::log_directory();
        if (!directory) return false;
        auto sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>((*directory / "SurfaceTides.log").string(),true);
        auto log = std::make_shared<spdlog::logger>("SurfaceTides",std::move(sink));
        spdlog::set_default_logger(std::move(log)); spdlog::set_level(spdlog::level::info); spdlog::flush_on(spdlog::level::info);
        SKSE::log::info("SurfaceTides {}, target={}, runtime={}",st::plugin::previewName,targetLabel,runtime.string());
#if defined(ST_RUNTIME_AE17)
        SKSE::log::info("Spatial water query: TESObjectCELL::GetWaterHeight (Address Library ID 19002), with exterior cell fallback");
#endif
        st::plugin::config = st::plugin::Config::read();
        SKSE::log::info("HideAttachedFoam={} (startup-only; 2 reviewed model profiles; no mesh files or collision changes)",st::plugin::config.hideAttachedFoam);
        SKSE::log::info("HideIceDecals={} (startup-only; 12 reviewed ice profiles including 9 Frozen Marsh; solid geometry retained; bobbing limited to original 3)",st::plugin::config.hideIceDecals);
        SKSE::log::info("FloeBobbing={} (startup-only; three reviewed ice models; legacy FloeBobbingTest used only when FloeBobbing is absent; max64 active, max8 dense fits/frame)",st::plugin::config.floeBobbing);
        SKSE::log::info("Floe riders: stable local-delta carry; velocity repair only on observed change; no actor reposition calls");
        SKSE::log::info("Floe jumping: early request/pending-state release and stable-landing reattachment; Ice is Slick incompatible with bobbing for now");
        SKSE::log::info("AttachedFoam discovery: player cell/worldspace and attached grid; legacy TES worldSpace scan bypassed");
        SKSE::log::info("RippleTrace={} (requires LogStats only; standalone supported; max32 scopes, 8 per family at least5seconds apart; scene bounds and D3D metadata only; no GPU readback)",st::plugin::config.rippleTrace);
        SKSE::log::info("MeshBounds={} MeshMotionVectors={}",st::plugin::config.meshBounds,st::plugin::config.meshMotionVectors);
        SKSE::log::info("MeshWadingDepth={} (ENB integration only; guarded primary 015E color depth comparison; native shaders and stencil selection retained)",st::plugin::config.meshWadingDepth);
        SKSE::log::info("MeshRippleCoverage={} (ENB integration only; requires MeshWadingDepth; successful primary 015E pixels mark bit01 for matching 011E base exclusion; startup-only)",st::plugin::config.meshRippleCoverage);
        SKSE::log::info("Experimental ENBWaterIntegration={} MeshTessellationMax={} MeshTwoSided={} (requested; actual water renderer is selected after data load)",st::plugin::config.enbMeshInput,st::plugin::config.meshTessellationMax,st::plugin::config.meshTwoSided);
        SKSE::log::info("RestoreWaterConstants={}",st::plugin::config.restoreWaterConstants);
        SKSE::log::info("Performance: OptimizeRenderer={} PerformanceTimings={} [startup-only; CPU wall timings, draw sample ~1/128; no GPU queries]",
            st::plugin::config.optimizeRenderer,st::plugin::config.performanceTimings);
        SKSE::log::info("Simulation performance: OptimizeSimulation={} [startup-only; cached continuous-wind math; 0 restores accepted direct math; gusts/grid/timestep unchanged]",
            st::plugin::config.optimizeSimulation);
        SKSE::log::info("Object discovery: OptimizeDiscovery={} [startup-only; one cell/update, max8 candidates/200us soft budget; 0 restores whole-grid search; coverage/detail unchanged]",st::plugin::config.optimizeDiscovery);
        SKSE::log::info("Shaders: ShaderCache={} PrewarmShaders={} [startup-only; independent of OptimizeRenderer; first water draw prewarms <=32 known/learned pairs]",
            st::plugin::config.shaderCache,st::plugin::config.prewarmShaders);
        SKSE::log::info("WaterPassTrace={} (public D3D metadata; independent periodic/mismatch budgets, max32 pairs each every2seconds, max8 native passes per sample)",st::plugin::config.waterPassTrace);
        if (st::plugin::config.waterPassTrace && !st::plugin::config.diagnostics)
            SKSE::log::warn("WaterPassTrace requires LogStats=1; detailed capture is disabled by the current logging setting.");
        SKSE::log::info("Config: terrainMask={} wind={} gustStrength={} normalStrength={} displacementStrength={} tessellation={} logStats={} debugView={}",
            st::plugin::config.terrainMask,st::plugin::config.simulation.wind,st::plugin::config.simulation.gustStrength,st::plugin::config.normalStrength,
            st::plugin::config.displacementStrength,st::plugin::config.tessellation,st::plugin::config.diagnostics,st::plugin::config.debugView);
        SKSE::log::info("Interaction strength={} radiusScale={} tessellationSpacing={} tessellationMax={}",
            st::plugin::config.interactionStrength,st::plugin::config.interactionRadius,
            st::plugin::config.tessellationSpacing,st::plugin::config.tessellationMax);
        st::plugin::tuning.publish(st::plugin::config);
        if (!st::plugin::config.enabled) SKSE::log::info("Disabled in configuration; menu available for tuning next launch");
        if (auto* serialization = SKSE::GetSerializationInterface()) {
            serialization->SetUniqueID(0x53544944); // STID; no save records are written
            serialization->SetRevertCallback([](SKSE::SerializationInterface*) { reset(); });
        }
        const auto* messaging = SKSE::GetMessagingInterface();
        return messaging && messaging->RegisterListener(onMessage);
    } catch (const std::exception& e) { OutputDebugStringA(e.what()); return false; }
}
