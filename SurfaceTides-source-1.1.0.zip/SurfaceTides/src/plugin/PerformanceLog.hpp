#pragma once
#include "surfacetides/PerformanceTiming.hpp"

namespace st::plugin {
// Separate instances on the game/render threads; no shared counters, locks,
// GPU queries, per-draw logging or waits introduced by these measurements.
template<std::size_t N>
struct PerformanceLog {
    std::array<st::TimingStat,N> values{};
    std::array<const char*,N> labels;
    st::CpuTimer::Clock::time_point next{};
    explicit PerformanceLog(std::array<const char*,N> names):labels(names) {}
    bool report(const char* domain, st::CpuTimer::Clock::time_point now) {
        if (next==st::CpuTimer::Clock::time_point{}) { next=now+std::chrono::seconds(5); return false; }
        if (now<next) return false;
        for (std::size_t i=0;i<N;++i) if (values[i].count)
            SKSE::log::info("ST CPU {} {}: n={} totalMs={:.3f} meanMs={:.6f} maxMs={:.3f}",
                domain,labels[i],values[i].count,values[i].totalMS,values[i].meanMS(),values[i].maxMS);
        values={}; next=now+std::chrono::seconds(5); return true;
    }
};
}
