#pragma once
#include "PCH.hpp"
#include "surfacetides/ShaderCacheData.hpp"
#include <map>

namespace st::plugin {
struct ShaderCacheStats {
    std::uint64_t hits{},coldStages{},invalid{},writes{},ioFailures{};
    double compileMS{};
};
class ShaderCache {
public:
    static ShaderCache& get();
    ComPtr<ID3DBlob> compile(const std::string& source,const D3D_SHADER_MACRO* defines,ID3DInclude* includes,
        const char* target,std::string_view vertexLayout,std::string_view pixelLayout);
    std::string source(const std::filesystem::path& path);
    std::vector<st::WaterPermutation> plan();
    void observed(st::WaterPermutation pair);
    void flushHistory();
    const ShaderCacheStats& stats() const { return stats_; }
private:
    void initialize();
    bool save(const std::filesystem::path&,std::span<const std::uint8_t>);
    void prune();
    void snapshotSources();
    bool initialized_{},disk_{},historyDirty_{};
    std::filesystem::path root_,historyPath_;
    std::string context_;
    std::map<std::string,std::string> sources_;
    std::vector<st::WaterPermutation> history_;
    ShaderCacheStats stats_;
    std::uint64_t serial_{},diskBytes_{},diskFiles_{};
};
}
