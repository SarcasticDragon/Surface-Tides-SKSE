#pragma once

namespace st::plugin {
inline constexpr auto previewName = "1.1.0";
// Final release metadata is 1.1.0.0; beta counters were private build identifiers.
inline constexpr unsigned previewPatch = 0, previewRevision = 0;
}
