#pragma once
#include "PCH.hpp"
#include "surfacetides/SurfaceEligibility.hpp"

namespace st::plugin {
void initializeSurfaceEligibility();
st::SurfaceKind captureSurfaceKind(RE::BSRenderPass* pass);
void noteExcludedSurfaceDraw(st::SurfaceKind kind);
void reportSurfaceEligibility();
}
