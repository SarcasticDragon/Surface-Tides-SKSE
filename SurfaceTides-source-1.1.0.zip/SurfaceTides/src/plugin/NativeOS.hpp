#pragma once
#include "PCH.hpp"

namespace st::plugin::nativeOS {
// Capture a parallel, ST-owned compilation. OS always receives its ORIGINAL blob.
void installCompilerObserver();
void attachDevice(ID3D11Device*);
struct Stage {
    bool vertex{}, stencil{}, valid{};
    ComPtr<ID3D11VertexShader> vs, control;
    ComPtr<ID3D11HullShader> hs;
    ComPtr<ID3D11DomainShader> ds;
    ComPtr<ID3D11PixelShader> ps;
};
std::shared_ptr<Stage> lookup(ID3D11DeviceChild*);
void nextFrame();
bool canRender();
void report();
}
