#pragma once
#include "PCH.hpp"
#include "Bridge.hpp"
#include "surfacetides/ShaderLayout.hpp"
#include <unordered_map>
#include <chrono>
#include <functional>
#include "surfacetides/ForwardedDraw.hpp"
#include "surfacetides/MeshBounds.hpp"
#include "surfacetides/RenderWork.hpp"

namespace st::plugin {
struct RippleGeometry;
// Restores every D3D binding changed by this plugin. Engine shadow state is never edited.
class DrawState {
public:
    explicit DrawState(ID3D11DeviceContext* context, bool timed = false);
    ~DrawState();
    void restore();
    void overrideBlend(ID3D11BlendState* replacement, ID3D11BlendState* original,
        const float* factor, UINT sampleMask);
    void bindNativeOSConstants();
    DrawState(const DrawState&) = delete;
    DrawState& operator=(const DrawState&) = delete;
    bool compatible = true;
    unsigned incompatibilityMask{};
    bool changed = false;
    bool probe = false;
    ID3D11DeviceContext* probeContext{};
    ID3D11VertexShader* expectedVS{};
    ID3D11PixelShader* expectedPS{};
    ID3D11HullShader* expectedHS{};
    ID3D11DomainShader* expectedDS{};
    ID3D11ShaderResourceView* expectedField{};
    D3D11_PRIMITIVE_TOPOLOGY expectedTopology{};
    ComPtr<ID3D11VertexShader> vs;
    ComPtr<ID3D11PixelShader> ps;
    ID3D11Buffer* pixelBuffer(unsigned group) const { return stages_[1].buffers[group].Get(); }
    ID3D11Buffer* vertexBuffer(unsigned group) const { return stages_[0].buffers[group].Get(); }
    D3D11_PRIMITIVE_TOPOLOGY topology{};
private:
    struct Stage {
        std::array<ComPtr<ID3D11Buffer>,5> buffers;
        std::array<ComPtr<ID3D11ShaderResourceView>,2> textures;
        ComPtr<ID3D11SamplerState> sampler;
    };
    ID3D11DeviceContext* context_;
    ComPtr<ID3D11HullShader> hs_;
    ComPtr<ID3D11DomainShader> ds_;
    std::array<Stage,4> stages_;
    ComPtr<ID3D11BlendState> originalBlend_;
    std::array<float,4> originalBlendFactor_{};
    UINT originalSampleMask_{};
    bool blendChanged_{};
    std::array<std::array<ComPtr<ID3D11Buffer>,9>,2> nativeOSExtra_;
    bool nativeOSConstants_{};
    bool timed_{}, batched_{};
};

class Renderer {
public:
    struct WaterPair {
        RE::BSGraphics::VertexShader* vs{};
        RE::BSGraphics::PixelShader* ps{};
        explicit operator bool() const { return vs && ps; }
    };
    static Renderer& get();
    WaterPair identify(RE::BSShader* owner, ID3D11VertexShader* vs, ID3D11PixelShader* ps);
    void nextFrame();
    void afterDraw(const DrawState& state);
    std::unique_ptr<DrawState> begin(ID3D11DeviceContext* context, RE::BSShader* waterShader, const WaterPair* forwarded = nullptr,
        const st::DrawSignature* traceDraw = nullptr, const RippleGeometry* traceGeometry = nullptr);
    bool drawMesh(ID3D11DeviceContext*, const WaterPair&, const st::DrawSignature&, const st::MeshBounds&,
        const std::function<void()>& sourceDraw, const std::function<void()>& meshDraw);
private:
    struct MeshBundle {
        bool valid{};
        UINT stride=40;
        ComPtr<ID3D11VertexShader> motionVS;
        ComPtr<ID3D11VertexShader> vs;
        ComPtr<ID3D11HullShader> hs;
        ComPtr<ID3D11DomainShader> ds;
        ComPtr<ID3D11GeometryShader> so;
        ComPtr<ID3D11InputLayout> layout;
        std::array<std::uint32_t,3> requiredBytes{};
    };
    MeshBundle compileMesh(RE::BSGraphics::VertexShader*, bool tryMotion=true);
    ID3D11RasterizerState* twoSidedRasterizer(ID3D11RasterizerState*);
    struct RasterVariant { ComPtr<ID3D11RasterizerState> original, twoSided; };
    std::unordered_map<ID3D11RasterizerState*,RasterVariant> meshRasterStates_;
    std::uint64_t meshTwoSidedDraws_{};
    struct MeshDepthVariant {
        ComPtr<ID3D11DepthStencilState> original, relaxed, coverage;
        D3D11_DEPTH_STENCIL_DESC description{};
    };
    std::unordered_map<ID3D11DepthStencilState*,MeshDepthVariant> meshDepthStates_;
    std::array<std::uint64_t,4> meshDepthStats_{}; // candidates, applied, native fallback, creation failures
    ID3D11DepthStencilState* wadingDepthState(ID3D11DepthStencilState*,UINT reference,bool hasStencilView,bool coverageTarget);
    struct MeshCoverageTarget {
        ComPtr<ID3D11RenderTargetView> color;
        ComPtr<ID3D11DepthStencilView> depth;
        std::uint64_t observed{};
    };
    std::array<MeshCoverageTarget,4> meshCoverageTargets_{};
    std::uint64_t meshCoverageFrame_=1;
    std::array<std::uint64_t,5> meshCoverageStats_{}; // base matched/rejected, marked/fallback, create failure
    void observeRippleBase(ID3D11DeviceContext*);
    bool rippleCoverageTarget(ID3D11DeviceContext*,ID3D11RenderTargetView*,ID3D11DepthStencilView*);
    std::unordered_map<std::string,MeshBundle> meshShaders_;
    ComPtr<ID3D11Buffer> meshStream_;
    UINT meshCapacity_{};
    std::array<std::uint64_t,10> meshStats_{}; // draws, patches, skipped, preparation failures, SO primitives
    struct MeshQuery { ComPtr<ID3D11Query> query; bool pending{}; };
    std::array<MeshQuery,4> meshQueries_;
    std::uint64_t meshSerial_{};
    bool meshOverflow_{}, meshPolled_{};
    struct Bundle {
        bool valid{}, loggedBindings{}, observed{};
        unsigned loggedConstantModes{};
        std::array<std::uint32_t,3> requiredPSBytes{};
        std::array<std::uint32_t,3> requiredOSBytes{};
        bool loggedOSMissing{}, loggedOSReady{}, osWaterEffects{}, osUnifiedWater{};
        ComPtr<ID3D11VertexShader> vs, control;
        ComPtr<ID3D11HullShader> hs;
        ComPtr<ID3D11DomainShader> ds;
        ComPtr<ID3D11PixelShader> ps;
    };
    Bundle compile(RE::BSGraphics::VertexShader* vs, RE::BSGraphics::PixelShader* ps);
    Bundle buildWater(RE::BSGraphics::VertexShader*,RE::BSGraphics::PixelShader*,const char* phase);
    void prewarmWater();
    bool prewarmed_{};
    std::uint64_t coldDrawBundles_{};
    std::chrono::steady_clock::time_point nextCacheMaintenance_{};
    Bundle compileWater(RE::BSGraphics::VertexShader* vs, RE::BSGraphics::PixelShader* ps, bool waterEffects);
    void prepare(ID3D11DeviceContext* context);
    std::unique_ptr<DrawState> beginNativeOS(ID3D11DeviceContext*,bool timed);
    std::uint64_t nativeOSDraws_{},nativeOSInactive_{},nativeOSUnknown_{},nativeOSRejected_{};
    void indexWaterShaders(RE::BSShader* shader);
    void ensureWaterIndex(RE::BSShader* shader);
    void preserveSceneMotion(ID3D11DeviceContext*, DrawState&);
    struct MotionBlendVariant { ComPtr<ID3D11BlendState> original, masked; };
    std::vector<MotionBlendVariant> motionBlendStates_;
    // stencil, applied, already masked, target mismatch, unsupported, failed
    std::array<std::uint64_t,6> motionStats_{};
    std::uint64_t waterEffectsDraws_{}, waterEffectsFallbacks_{};
    std::uint64_t unifiedWaterDraws_{}, unifiedFlowmapDraws_{};
    std::uint64_t lastMotionTuningRevision_ = ~std::uint64_t{0};
    unsigned motionWarnings_{};
    RE::BSShader* indexedOwner_{};
    std::chrono::steady_clock::time_point nextIndex_{};
    bool indexPollDue_ = true, indexTagRetry_{};
    st::ShaderIndexSnapshot indexSnapshot_;
    std::vector<st::ShaderObjectRecord> scanVS_, scanPS_;
    // Retain indexed D3D objects so a released shader address cannot be reused
    // while the five-second snapshot still contains that address.
    std::vector<ComPtr<ID3D11VertexShader>> retainedVS_;
    std::vector<ComPtr<ID3D11PixelShader>> retainedPS_;
    std::uint64_t indexChecks_{}, indexRebuilds_{}, indexUnchanged_{};
    std::unordered_map<ID3D11VertexShader*,RE::BSGraphics::VertexShader*> waterVS_;
    std::unordered_map<ID3D11PixelShader*,RE::BSGraphics::PixelShader*> waterPS_;
    template<class Object, class Metadata> struct CachedIdentity {
        ComPtr<Object> object; // retain cached misses too, preventing pointer reuse
        Metadata* metadata{};
    };
    std::unordered_map<ID3D11VertexShader*,CachedIdentity<ID3D11VertexShader,RE::BSGraphics::VertexShader>> identityVS_;
    std::unordered_map<ID3D11PixelShader*,CachedIdentity<ID3D11PixelShader,RE::BSGraphics::PixelShader>> identityPS_;
    std::vector<RE::BSGraphics::VertexShader*> taggedVS_;
    std::vector<RE::BSGraphics::PixelShader*> taggedPS_;
    std::uint64_t tagGeneration_{}, tagReads_{}, tagMatches_{}, unmatchedVS_{}, unmatchedPS_{};
    ComPtr<ID3D11Device> device_;
    std::array<ComPtr<ID3D11Texture2D>,2> textures_;
    std::array<ComPtr<ID3D11ShaderResourceView>,2> views_;
    ComPtr<ID3D11ShaderResourceView> neutralView_;
    ComPtr<ID3D11Buffer> constants_;
    ComPtr<ID3D11SamplerState> sampler_;
    std::unordered_map<std::string,Bundle> legacyShaders_;
    std::unordered_map<st::WaterShaderKey,Bundle,st::WaterShaderKeyHash> shaders_;
    st::WaterShaderKey lastShaderKey_;
    Bundle* lastBundle_{}; // unordered_map element addresses survive rehash
    std::shared_ptr<const Frame> gpuFrame_;
    Tuning renderTuning_; // captured once per water frame, never mutated by the menu
    std::array<float,20> parameters_{};
    std::array<std::uint64_t,7> stats_{}; // attempts, inactive, incompatible, unknown, LOD, bound, tessellated
    std::uint64_t failedDraws_{};
    std::uint64_t compatibilityOnlyDraws_{};
    int lastRenderMode_ = -1;
    std::uint64_t shiftedConstantDraws_{}, unrecognizedConstantDraws_{};
    std::uint64_t probeSerial_{}, probedDraws_{}, changedDraws_{};
    unsigned changedMask_{}, incompatibleMask_{};
    std::chrono::steady_clock::time_point nextStats_{};
    int current_ = 0, previous_ = 0, textureSize_ = 0;
    bool consumed_{}, active_{}, adapterOnly_{};
};
}
