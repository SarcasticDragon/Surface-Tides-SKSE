#include "ShaderCache.hpp"
#include "Bridge.hpp"
#include <chrono>
#include <cctype>

// Windows x64 MSVC-ABI import slot supplied by d3dcompiler.lib. The SDK
// declares D3DCompile without dllimport, so &D3DCompile can point to a linker
// thunk inside SurfaceTides.dll. Read the resolved IAT target for identity;
// ordinary D3DCompile calls below continue through the existing import path.
extern "C" decltype(&D3DCompile) __imp_D3DCompile;

namespace st::plugin {
namespace {
constexpr UINT compileFlags=D3DCOMPILE_ENABLE_STRICTNESS|D3DCOMPILE_OPTIMIZATION_LEVEL3;
constexpr std::uint64_t maxDiskBytes=128ull*1024*1024,maxDiskFiles=512;
std::string sourceName(const std::filesystem::path& path) {
    auto name=std::filesystem::absolute(path).lexically_normal().generic_string();
    std::transform(name.begin(),name.end(),name.begin(),[](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return name;
}
std::vector<std::uint8_t> readBounded(const std::filesystem::path& path,std::size_t limit) {
    std::ifstream file(path,std::ios::binary|std::ios::ate);
    if (!file) return {};
    const auto size=file.tellg();
    if (size<=0 || static_cast<std::uint64_t>(size)>limit) return {};
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size));file.seekg(0);
    if (!file.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()))) return {};
    return bytes;
}
std::string compilerDigest() {
    const auto entry=__imp_D3DCompile;
    if (!entry) throw std::runtime_error("D3D compiler import target unavailable");
    HMODULE module{};
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
        reinterpret_cast<LPCWSTR>(entry),&module)) throw std::runtime_error("Cannot identify loaded D3D compiler import target");
    std::array<wchar_t,32768> path{};
    const auto length=GetModuleFileNameW(module,path.data(),static_cast<DWORD>(path.size()));
    if (!length || length>=path.size()) throw std::runtime_error("Cannot resolve loaded D3D compiler path");
    const auto compilerPath=std::filesystem::path(std::wstring(path.data(),length));
    // Fingerprint only Microsoft's imported compiler, never a renderer module.
    if (_wcsicmp(compilerPath.filename().c_str(),L"d3dcompiler_47.dll")!=0)
        throw std::runtime_error("Unrecognized D3D compiler import module "+compilerPath.filename().string()+"; bypassing persistent cache");
    const auto file=readBounded(compilerPath,64*1024*1024);
    if (file.empty()) throw std::runtime_error("Cannot fingerprint loaded D3D compiler");
    SKSE::log::info("Shader compiler identity: module={} via=resolved-import bytes={}",compilerPath.filename().string(),file.size());
    return st::hexDigest(st::sha256(file));
}
bool cacheFilename(const std::filesystem::path& path) {
    const auto name=path.filename().string();
    return name.size()==68 && name.ends_with(".stc") &&
        std::all_of(name.begin(),name.begin()+64,[](char c) { return (c>='0' && c<='9') || (c>='a' && c<='f'); });
}
std::runtime_error compileError(const char* target,ID3DBlob* error) {
    return std::runtime_error(std::string(target)+": "+(error ?
        std::string(static_cast<const char*>(error->GetBufferPointer()),error->GetBufferSize()):"No compiler diagnostics"));
}
}
ShaderCache& ShaderCache::get() { static ShaderCache cache;return cache; }
void ShaderCache::initialize() {
    if (initialized_) return;
    initialized_=true;
    if (!config.shaderCache) return;
    try {
        std::array<wchar_t,32768> local{};
        const auto length=GetEnvironmentVariableW(L"LOCALAPPDATA",local.data(),static_cast<DWORD>(local.size()));
        if (!length || length>=local.size()) throw std::runtime_error("LOCALAPPDATA unavailable");
        root_=std::filesystem::path(std::wstring(local.data(),length))/"SurfaceTides"/"ShaderCache"/"v1";
        std::filesystem::create_directories(root_);
#if defined(ST_RUNTIME_SE)
        context_="SE";
#elif defined(ST_RUNTIME_AE17)
        context_="AE17";
#else
        context_="AE16";
#endif
        context_+=openShadersActive ? "/OS" : "/native";
        context_+=config.osWaterEffects ? "/WE1" : "/WE0";
        context_+=config.osUnifiedWater ? "/UW1" : "/UW0";
        context_+=config.tessellation ? "/T1" : "/T0";
        st::Sha256 mode;mode.add(context_);
        historyPath_=root_/("observed-"+st::hexDigest(mode.finish())+".bin");
        history_=st::decodePrewarmHistory(readBounded(historyPath_,8+8*st::maxPrewarmPairs));
        context_+="/compiler="+compilerDigest();
        snapshotSources();
        disk_=true;prune();
        SKSE::log::info("Shader cache ready: path={} learnedPairs={} limitMiB=128 limitFiles=512; content/compiler keyed, private ST cache",root_.string(),history_.size());
    } catch (const std::exception& error) {
        disk_=false;++stats_.ioFailures;
        SKSE::log::warn("Shader cache unavailable: {}; ordinary compilation retained",error.what());
    }
}
void ShaderCache::snapshotSources() {
    std::vector<std::filesystem::path> roots{"Data/Shaders/SurfaceTides"};
    if (openShadersActive) { roots.emplace_back("Data/Shaders/Common");roots.emplace_back("Data/Shaders/WaterEffects"); }
    std::size_t total{};
    for (const auto& root:roots) {
        if (!std::filesystem::exists(root)) continue;
        for (const auto& entry:std::filesystem::recursive_directory_iterator(root)) if (entry.is_regular_file()) {
            const auto size=entry.file_size();total+=static_cast<std::size_t>(size);
            if (total>32*1024*1024 || sources_.size()>=2048) throw std::runtime_error("Shader source snapshot exceeds bound");
            const auto bytes=readBounded(entry.path(),32*1024*1024);
            if (bytes.size()!=size) throw std::runtime_error("Cannot snapshot shader source");
            sources_.emplace(sourceName(entry.path()),std::string(bytes.begin(),bytes.end()));
        }
    }
    st::Sha256 hash;
    for (const auto& [name,text]:sources_) { st::hashPart(hash,name);st::hashPart(hash,text); }
    context_+="/sources="+st::hexDigest(hash.finish());
}
std::string ShaderCache::source(const std::filesystem::path& path) {
    initialize();
    if (disk_) {
        if (const auto it=sources_.find(sourceName(path));it!=sources_.end()) return it->second;
        // Unknown include paths cannot be covered by the content fingerprint.
        // Disable disk hits/writes and keep the ordinary compile path functional.
        disk_=false;++stats_.ioFailures;
        SKSE::log::warn("Shader cache bypass: include outside source snapshot {}; restart after shader changes",path.string());
    }
    std::ifstream file(path,std::ios::binary);
    if (!file) throw std::runtime_error("Missing shader: "+path.string());
    return {std::istreambuf_iterator<char>(file),std::istreambuf_iterator<char>()};
}
void ShaderCache::prune() {
    struct Entry { std::filesystem::path path;std::filesystem::file_time_type time;std::uint64_t bytes; };
    std::vector<Entry> files;
    for (const auto& entry:std::filesystem::directory_iterator(root_)) if (entry.is_regular_file() && cacheFilename(entry.path())) {
        files.push_back({entry.path(),entry.last_write_time(),entry.file_size()});diskBytes_+=files.back().bytes;
    }
    diskFiles_=files.size();
    std::sort(files.begin(),files.end(),[](const Entry& a,const Entry& b) { return a.time<b.time; });
    // Reserve room for this session. Pruning is startup-only and never touches
    // OS caches, unknown filenames or files currently being written.
    for (const auto& entry:files) {
        if (diskBytes_<=96ull*1024*1024 && diskFiles_<=384) break;
        std::error_code error;
        if (std::filesystem::remove(entry.path,error)) { diskBytes_-=entry.bytes;--diskFiles_; }
    }
}
bool ShaderCache::save(const std::filesystem::path& path,std::span<const std::uint8_t> bytes) {
    auto temporary=path;
    temporary+=L"."+std::to_wstring(GetCurrentProcessId())+L"."+std::to_wstring(++serial_)+L".tmp";
    bool okay=false;
    {
        std::ofstream file(temporary,std::ios::binary|std::ios::trunc);
        if (file) { file.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));file.flush();okay=bool(file); }
    }
    if (okay) okay=MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
    if (!okay) { std::error_code error;std::filesystem::remove(temporary,error);++stats_.ioFailures; }
    return okay;
}
ComPtr<ID3DBlob> ShaderCache::compile(const std::string& source,const D3D_SHADER_MACRO* defines,ID3DInclude* includes,
    const char* target,std::string_view vertexLayout,std::string_view pixelLayout) {
    initialize();
    ComPtr<ID3DBlob> blob,errors;
    st::Digest key{};
    bool cacheable=disk_;
    if (cacheable) {
        {
            std::string macros;
            for (auto* macro=defines;macro && macro->Name;++macro) {
                macros+=macro->Name;macros.push_back('\0');
                if (macro->Definition) macros+=macro->Definition;
                macros.push_back('\0');
            }
            key=st::shaderCacheKey(context_,target,macros,source,compileFlags,vertexLayout,pixelLayout);
            const auto path=root_/(st::hexDigest(key)+".stc");
            const auto file=readBounded(path,st::maxShaderBytes+st::cacheHeaderBytes);
            const auto code=st::decodeShaderCache(file,key);
            if (!code.empty()) {
                check(D3DCreateBlob(code.size(),&blob),"Allocate cached shader");
                std::memcpy(blob->GetBufferPointer(),code.data(),code.size());
                // Do not trust a structurally invalid blob even with a matching
                // container checksum. Existing input/CB validation still runs.
                ComPtr<ID3D11ShaderReflection> reflection;
                if (SUCCEEDED(D3DReflect(blob->GetBufferPointer(),blob->GetBufferSize(),__uuidof(ID3D11ShaderReflection),
                    reinterpret_cast<void**>(reflection.GetAddressOf())))) { ++stats_.hits;return blob; }
                blob.Reset();++stats_.invalid;
            } else {
                std::error_code error;
                if (std::filesystem::exists(path,error)) ++stats_.invalid;
            }
        }
    }
    ++stats_.coldStages;
    const auto start=std::chrono::steady_clock::now();
    // Preserve the accepted compiler inputs and flags exactly. Snapshot all
    // reachable source roots, including inactive headers, rather than changing
    // preprocessing semantics or trusting timestamps. Restart refreshes inputs.
    const auto hr=D3DCompile(source.data(),source.size(),"SurfaceTides/Water.hlsl",defines,includes,"main",target,compileFlags,0,&blob,&errors);
    stats_.compileMS+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
    if (FAILED(hr)) throw compileError(target,errors.Get());
    if (cacheable && disk_) {
        const auto bytes=st::encodeShaderCache(key,{static_cast<const std::uint8_t*>(blob->GetBufferPointer()),blob->GetBufferSize()});
        if (!bytes.empty() && diskFiles_<maxDiskFiles && diskBytes_+bytes.size()<=maxDiskBytes &&
            save(root_/(st::hexDigest(key)+".stc"),bytes)) { ++stats_.writes;++diskFiles_;diskBytes_+=bytes.size(); }
    }
    return blob;
}
std::vector<st::WaterPermutation> ShaderCache::plan() { initialize();return st::prewarmPlan(history_); }
void ShaderCache::observed(st::WaterPermutation pair) {
    initialize();
    if (disk_ && st::rememberPermutation(history_,pair)) historyDirty_=true;
}
void ShaderCache::flushHistory() {
    if (!historyDirty_) return;
    historyDirty_=false;
    save(historyPath_,st::encodePrewarmHistory(history_));
}
}
