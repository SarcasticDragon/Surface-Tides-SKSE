#pragma once
#include "surfacetides/Simulation.hpp"
#include "surfacetides/Tuning.hpp"
#include "surfacetides/FloeMotion.hpp"
#include <array>
#include <atomic>
#include <memory>
#include <mutex>

namespace st::plugin {
struct Config : Tuning {
    bool enabled = true, tessellation = true;
    bool diagnostics = true;
    bool performanceTimings = false; // optional CPU measurements; startup-only
    bool optimizeRenderer = true; // 0 restores the original CPU path for comparison
    bool optimizeDiscovery = true; // spread foam/ice discovery across updates
    bool optimizeSimulation = true; // cached continuous-wind math; 0 uses accepted direct math
    bool shaderCache = true, prewarmShaders = true; // startup-only, independent switches
    bool waterPassTrace = false; // bounded public D3D metadata sampling, opt-in
    bool rippleTrace = false; // bounded scene/pass metadata; never changes rendering
    bool restoreWaterConstants = true; // validated forwarded-draw PS binding repair
    bool meshBounds = true, meshMotionVectors = false;
    bool meshTwoSided = false;
    bool meshWadingDepth = true; // ENB-only guarded primary-wading depth candidate
    bool meshRippleCoverage = true; // prevent base color overwriting covered wading pixels
    int meshTessellationMax = 8; // 8..16; experimental preparation only
    bool enbMeshInput = false; // experimental geometry input, retains downstream shaders
    bool enbActive = false; // effective renderer state, detected at data load; not an INI permission
    bool blockCS = true; // unsupported upstream CS; explicit testing bypass only
    bool openShaders = false; // user-declared OS installation; shares CS's DLL name
    bool osNativeWater = false; // explicit OS profile: augment OS-owned Water, retain native when inactive
    bool osWaterEffects = false; // startup opt-in; OS WaterEffects enabled separately
    bool osUnifiedWater = false; // startup opt-in; must match OS UnifiedWater boot state
    bool hideAttachedFoam = false; // opt-in, reviewed rapid-rock profiles only
    bool hideIceDecals = false; // opt-in, three reviewed floe slush profiles
    bool floeBobbing = false; // loaded placements of the three reviewed ice models
    static Config read();
};
using Texel = SurfaceTexel;
static_assert(sizeof(Texel) == 16);
struct Frame {
    std::uint64_t sequence{}, epoch{};
    Vec2 origin;
    float level{}, spacing{};
    int resolution{};
    int spongeCells{};
    bool active{};
    std::vector<Texel> texels;
};
class Exchange {
public:
    void publish(std::shared_ptr<const Frame> frame) { std::lock_guard lock(mutex_); frame_ = std::move(frame); }
    std::shared_ptr<const Frame> read() { std::lock_guard lock(mutex_); return frame_; }
private:
    std::mutex mutex_;
    std::shared_ptr<const Frame> frame_;
};
inline Exchange exchange;
inline std::atomic<bool> resetRequested = true;
inline std::atomic<bool> disabled = false;
inline Config config;
inline bool communityShadersActive = false; // selected at data load, before hooks
inline bool openShadersActive = false;
inline bool rendererCoexistence() { return config.enbActive || communityShadersActive || openShadersActive; }
inline TuningExchange tuning;
inline std::atomic<std::uint64_t> appliedTuningRevision = 0;
void registerMenu();
void saveTuning(const Tuning& values);
void updateGame(float delta);
void updateAttachedFoam(bool active);
void resetAttachedFoam();
void updateFloe(const Frame& frame, const Tuning& applied, std::uint64_t area, float delta);
void resetFloe(bool carryRiders = false);
void noteFloeJumpRequest() noexcept;
bool installHooks();
}
