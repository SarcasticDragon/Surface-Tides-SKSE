#include "SurfaceEligibility.hpp"
#include "Bridge.hpp"

namespace st::plugin {
namespace {
st::SurfaceCatalog catalog;
RE::TESWaterForm* lavaWater{}; // data-loaded form, not a streamed reference
std::array<std::atomic<std::uint64_t>,3> excludedDraws{};
std::atomic<std::uint64_t> knownScopes{}, unownedScopes{};
std::array<std::atomic<unsigned>,3> loggedScopes{};
const char* kindName(st::SurfaceKind kind) {
    return kind == st::SurfaceKind::Lava ? "lava" : kind == st::SurfaceKind::DecorativePuddle ? "puddle" : "water";
}
std::uint32_t id(const RE::TESForm* form) { return form ? form->GetFormID() : 0; }
const char* safe(const char* value) { return value ? value : ""; }
}
void initializeSurfaceEligibility() {
    // Plugin-local IDs verified in the user's More Informative Console clips.
    // Resolve through the loader; Dawnguard need not occupy load-order slot 02.
    auto* data=RE::TESDataHandler::GetSingleton();
    auto* puddle=data ? data->LookupForm<RE::TESObjectACTI>(0x9727E,"Skyrim.esm") : nullptr;
    auto* lava=data ? data->LookupForm<RE::TESObjectACTI>(0x14B85,"Dawnguard.esm") : nullptr;
    auto* forge=data ? data->LookupForm<RE::TESObjectSTAT>(0x14FD1,"Dawnguard.esm") : nullptr;
    lavaWater=lava ? lava->waterForm : nullptr;
    catalog={id(puddle),id(lava),id(forge),id(lavaWater)};
    SKSE::log::info("Surface exclusions: puddleBase={:08X} lavaBase={:08X} forgeLavaBase={:08X} lavaWater={:08X} [native rendering retained; plugin-relative forms; no shared Water1024 mesh exclusion]",
        catalog.puddleBase,catalog.lavaBase,catalog.forgeLavaBase,catalog.lavaWater);
    SKSE::log::info("Surface exclusion models: puddle='{}' lava='{}' forge='{}' [winning model paths; identification only, no file writes]",
        puddle ? safe(puddle->GetModel()) : "",lava ? safe(lava->GetModel()) : "",forge ? safe(forge->GetModel()) : "");
}
st::SurfaceKind captureSurfaceKind(RE::BSRenderPass* pass) {
    if (!pass || !pass->geometry) return st::SurfaceKind::Water;
    // GetUserData also checks the live parent chain. Capture value identities
    // during setup; never retain reference, geometry or material pointers for a draw.
    auto* ref=pass->geometry->GetUserData();
    auto* base=ref ? ref->GetBaseObject() : nullptr;
    auto* activator=base ? base->As<RE::TESObjectACTI>() : nullptr;
    auto* water=activator ? activator->waterForm : nullptr;
    // Some generated water geometry has no owning reference. Only an exact
    // positive match to the known lava water material is accepted as a fallback.
    const bool materialMatch=lavaWater && lavaWater->waterShaderMaterial && pass->shaderProperty &&
        pass->shaderProperty->material==lavaWater->waterShaderMaterial;
    const auto kind=st::classifySurface(catalog,{id(base),id(water),materialMatch});
    if (base) ++knownScopes; else ++unownedScopes;
    if (config.diagnostics && kind!=st::SurfaceKind::Water && loggedScopes[static_cast<unsigned>(kind)].fetch_add(1)<4)
        SKSE::log::info("Surface excluded: kind={} ref={:08X} base={:08X} water={:08X} materialMatch={} geometry='{}' pass={:X} [first4 scopes per kind; ST bypass only]",
            kindName(kind),id(ref),id(base),id(water),materialMatch,safe(pass->geometry->name.c_str()),pass->passEnum);
    return kind;
}
void noteExcludedSurfaceDraw(st::SurfaceKind kind) {
    ++excludedDraws[static_cast<unsigned>(kind)];
}
void reportSurfaceEligibility() {
    SKSE::log::info("ST surface exclusions: lavaDraws={} puddleDraws={} ownedScopes={} unownedScopes={} [since report; original draw forwarded unchanged]",
        excludedDraws[static_cast<unsigned>(st::SurfaceKind::Lava)].exchange(0),
        excludedDraws[static_cast<unsigned>(st::SurfaceKind::DecorativePuddle)].exchange(0),
        knownScopes.exchange(0),unownedScopes.exchange(0));
}
}
